# GitHub Copilot Support / GitHub Copilot 支持

This repository now supports GitHub Copilot through standard repository customization files instead of proprietary agent conventions.

本仓库现在通过标准仓库定制文件支持 GitHub Copilot，而不是依赖私有 agent 约定。

## Included Assets / 包含的资产

- `.github/copilot-instructions.md`
- `.github/agents/bosch-parking-runtime-optimizer.agent.md`
- `.github/prompts/*.prompt.md`

## What This Means / 这意味着什么

- Any developer can copy the `.github` folder into a repository and use the same operating mode. / 任意开发者都可以把 `.github` 文件夹复制到仓库中并使用同样的工作模式。
- No OpenClaw or ClawHub setup is required. / 不需要 OpenClaw 或 ClawHub。
- No user-specific filesystem paths are required. / 不需要用户私有路径配置。
- Copilot is guided through instructions, agent mode, and prompt files rather than fake command syntax. / Copilot 通过 instructions、agent 模式和 prompt 文件被引导，而不是依赖虚构命令语法。

## Installation / 安装

1. Copy the `.github` directory into the target repository root.
2. Keep the domain reference documents if you want richer context during code reviews.
3. Open the target repository in VS Code with GitHub Copilot enabled.

## Recommended Usage / 推荐使用方式

- Select the `Bosch Parking Runtime Optimizer` agent mode for focused work. / 需要聚焦分析时，选择 `Bosch Parking Runtime Optimizer` agent 模式。
- Use the prompt files when you want a structured analysis. / 需要结构化分析时，使用 prompt 文件。
- Ask Copilot to separate measured facts, static evidence, hypotheses, proposed edits, and validation steps. / 要求 Copilot 区分测量事实、静态证据、假设、修改建议和验证步骤。

Recommended prompt split: / 推荐 prompt 使用方式：

- `bottleneck-analysis.prompt.md`: source-only or mixed static hotspot review / 仅源码或静态热点审查
- `perf-hotspot-analysis.prompt.md`: perf-assisted ranked hotspot analysis / 基于 perf 的排序热点分析
- `realtime-optimization.prompt.md`: worst-case latency and jitter review / 最坏时延与抖动审查

## Optional Runtime Script / 可选 runtime 脚本

`utils/auto-optimize.sh` is still available for Linux-based profiling workflows, but it is separate from Copilot support.