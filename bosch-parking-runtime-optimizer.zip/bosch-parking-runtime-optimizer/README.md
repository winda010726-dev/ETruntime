# Bosch Parking Runtime Optimizer

Reusable GitHub Copilot customization pack for developers working on autonomous parking and other runtime-sensitive C++ systems.

面向自动泊车和其他运行时敏感 C++ 系统开发者的可复用 GitHub Copilot 定制包。

See also: [CHANGELOG.md](CHANGELOG.md)

另见：[CHANGELOG.md](CHANGELOG.md)

## What This Repository Provides / 仓库提供内容

- domain-specific Copilot instructions for runtime optimization work / 面向 runtime 优化的领域化 Copilot 指令
- a dedicated Copilot agent mode for parking-oriented C++ analysis / 面向泊车场景 C++ 分析的专用 Copilot agent 模式
- reusable prompt files for bottlenecks, memory, real-time, and safety reviews / 可复用的瓶颈、内存、实时性和安全审查 prompt 文件
- perf-assisted hotspot analysis prompt for evidence-driven optimization / 面向证据驱动优化的 perf 热点分析 prompt
- reference documentation for monitoring and optimization decisions / 用于监控与优化决策的参考文档
- an optional shell script for Linux-based profiling workflows / 可选的 Linux profiling 工作流脚本

## Designed For / 适用对象

- autonomous parking developers / 自动泊车开发者
- embedded C++ developers / 嵌入式 C++ 开发者
- performance engineers / 性能工程师
- reviewers working on latency, memory, and scheduling problems / 关注时延、内存和调度问题的评审者
- teams that want a shared Copilot operating model instead of personal prompts / 希望沉淀团队级 Copilot 工作方式而不是个人 prompt 的团队

## GitHub Copilot Setup / GitHub Copilot 配置

Copy the `.github` directory from this repository into the root of the repository where you want to use the pack.

将本仓库中的 `.github` 目录复制到目标仓库根目录即可使用。

The most important files are: / 最重要的文件包括：

- `.github/copilot-instructions.md`
- `.github/agents/bosch-parking-runtime-optimizer.agent.md`
- `.github/prompts/bottleneck-analysis.prompt.md`
- `.github/prompts/perf-directory-analysis.prompt.md`
- `.github/prompts/perf-hotspot-analysis.prompt.md`
- `.github/prompts/memory-optimization.prompt.md`
- `.github/prompts/realtime-optimization.prompt.md`
- `.github/prompts/iso26262-compliance.prompt.md`

After copying the files: / 复制完成后：

1. Open the target repository in VS Code. / 在 VS Code 中打开目标仓库。
2. Open GitHub Copilot Chat. / 打开 GitHub Copilot Chat。
3. Select the `Bosch Parking Runtime Optimizer` agent mode when you need focused analysis. / 需要聚焦分析时，选择 `Bosch Parking Runtime Optimizer` agent 模式。
4. Run one of the prompt files or ask Copilot in natural language using the examples below. / 运行任一 prompt 文件，或直接按下方示例用自然语言提问。

## Quick Trial / 试用方法

Use the following workflow when you want to try the skill on a real repository for the first time.

第一次在真实仓库中试用时，建议按下面的流程进行。

### Trial Path A: Source-Only Review / 试用方式 A：仅基于源码审查

1. Open a runtime-sensitive C++ file in VS Code. / 在 VS Code 中打开一个 runtime 敏感的 C++ 文件。
2. Open GitHub Copilot Chat and select `Bosch Parking Runtime Optimizer`. / 打开 GitHub Copilot Chat 并选择 `Bosch Parking Runtime Optimizer`。
3. Run `bottleneck-analysis.prompt.md`, or ask directly: / 运行 `bottleneck-analysis.prompt.md`，或者直接提问：

```text
Analyze this file for runtime hotspots. Separate static evidence from hypotheses, classify root causes, and give quick wins first.
分析这个文件的 runtime 热点。请区分静态证据与假设，分类根因，并优先给出即时修复建议。
```

Expected result: / 预期结果：

- hotspot overview / 热点总览
- static evidence / 静态证据
- quick wins / 即时修复
- deeper optimizations / 深度优化
- validation plan / 验证方案

### Trial Path B: Perf-Assisted Review / 试用方式 B：结合 perf 证据审查

1. Prepare one of the following inputs: / 准备以下任一输入：
   - `perf report` text
   - `perf script` output
   - flamegraph summary
   - hotspot function list with CPU percentages
2. Open the related source file or module. / 打开对应源码文件或模块。
3. Run `perf-hotspot-analysis.prompt.md`, or ask directly: / 运行 `perf-hotspot-analysis.prompt.md`，或者直接提问：

```text
Analyze this perf report and source together. Build a hotspot overview table, separate measured facts from source-level interpretation, and propose quick wins plus deeper optimizations.
结合这份 perf 报告和源码进行分析。请先给出热点总览表，区分测量事实与源码层解释，再给出即时修复和深度优化建议。
```

Expected result: / 预期结果：

- Top-N hotspot table / Top-N 热点表
- measured facts vs source interpretation / 测量事实与源码解释分层
- root-cause category / 根因分类
- expected gain / 预期收益
- validation and risk notes / 验证与风险说明

### Trial Path C: Perf Directory Review / 试用方式 C：perf 目录审查

Use this path when you do not have a ready-made report, but you do have a decoded perf-data directory containing files such as `.fold`, `.svg`, and `perf_top.log`.

当你没有现成的 perf 报告，但已经有包含 `.fold`、`.svg`、`perf_top.log` 等产物的 perf 解码目录时，使用这种方式。

Run `perf-directory-analysis.prompt.md`, or ask directly: / 运行 `perf-directory-analysis.prompt.md`，或者直接提问：

```text
Analyze this perf-data directory. First decide which recording window best matches the final maneuver, then aggregate hotspots across comparable cases, map them to source, and give prioritized optimization recommendations.
分析这个 perf 数据目录。请先判断哪个录制窗口最符合最后一把，再跨相似 case 聚合热点，映射到源码，并按优先级给出优化建议。
```

Expected result: / 预期结果：

- window judgment / 窗口判断
- aggregated hotspot ranking / 聚合热点排名
- source mapping / 源码映射
- prioritized quick wins and deeper optimizations / 按优先级排序的即时修复与深度优化
- validation plan / 验证方案

## Repository-Level Trial Example / 仓库级试用示例

If you want to try the skill immediately in a real Bosch parking repository, use the following file from `sysoneparkingcn`.

如果你想立刻在真实的 Bosch 泊车仓库里试用这个 skill，可以直接使用 `sysoneparkingcn` 里的下面这个文件。

Target file: / 目标文件：

```text
c:\data\GIT\sysoneparkingcn\aos_model_entrytrim\runnables\fct\cpj\et\runnables\post_compute\src\rbp_apa_fct_post_compute.cpp
```

Why this file is a good trial target: / 为什么这个文件适合作为试用目标：

- it is a post-compute runnable on a periodic path / 它是一个周期路径上的 post-compute runnable
- it contains large mapping sections and many fixed assignments / 它包含大段映射逻辑和大量固定赋值
- it shows patterns such as per-cycle logging and full-buffer reset before partial fill / 它同时包含周期性日志、先全量清零再部分回填等典型模式

Relevant hotspots to look at first: / 建议优先关注的代码点：

- `RbpApaPostCompute_onUpdate` / `RbpApaPostCompute_onUpdate`
- `someipMappingIndicationInfo` / `someipMappingIndicationInfo`
- `LOG_ERROR(...)` near the end of the update path / update 路径尾部的 `LOG_ERROR(...)`
- the `m_FreeParkTrajectoryPoint` reset-and-fill block / `m_FreeParkTrajectoryPoint` 的清零加回填逻辑

Suggested source-only prompt: / 推荐的仅源码试用提问：

```text
Analyze rbp_apa_fct_post_compute.cpp as static hotspot analysis. Focus on RbpApaPostCompute_onUpdate, someipMappingIndicationInfo, per-cycle logging, repeated memory writes, and container refill patterns. Give quick wins first.
把 rbp_apa_fct_post_compute.cpp 当作静态热点分析对象。重点关注 RbpApaPostCompute_onUpdate、someipMappingIndicationInfo、周期性日志、重复内存写入和容器回填模式。请优先给出即时修复建议。
```

Suggested perf-assisted prompt: / 推荐的 perf 结合试用提问：

```text
Use this perf evidence and rbp_apa_fct_post_compute.cpp together. Build a hotspot overview table and tell me whether the main cost comes from logging, full-buffer reset, mapping copies, or container refill.
结合这份 perf 证据和 rbp_apa_fct_post_compute.cpp 一起分析。请先给出热点总览表，并判断主要成本来自日志、全量清零、映射拷贝还是容器回填。
```

Expected observations in this repository example: / 这个仓库级示例中，预期 skill 应识别出的现象：

- high fixed cost inside a periodic post-compute path / 周期性 post-compute 路径中的高固定成本
- duplicated `std::map` lookups in indication mapping / indication mapping 中重复的 `std::map` 查找
- full reset of 160/64 trajectory buffers before partial fill / 160/64 长度轨迹缓冲区先全量清零再部分回填
- per-cycle error logging on a hot path / 热路径中的周期性错误日志
- potential container clear-and-refill overhead / 容器清空再回填带来的潜在开销

## Example Prompts / 示例提问

- Analyze this parking planning runnable for CPU hotspots and missed latency targets. / 分析这个泊车规划 runnable 的 CPU 热点和时延超标问题。
- Analyze this perf report and source together, rank the hottest functions, classify root causes, and suggest quick wins. / 结合 perf 报告和源码分析，给出最热函数排序、根因分类和即时修复建议。
- Review this C++ module for unnecessary allocations and memory lifetime risks. / 审查这个 C++ 模块中不必要的分配和内存生命周期风险。
- Suggest low-risk optimizations for a post-compute runnable while preserving deterministic behavior. / 在保持确定性行为的前提下，为 post-compute runnable 提供低风险优化建议。
- Check whether this refactor could affect safety-critical timing or diagnostics behavior. / 检查这次重构是否会影响安全关键时序或诊断行为。

## Real Code Examples / 真实代码示例

The following examples are based on real parking post-compute code patterns. They are useful for trying the skill on runtime-heavy data-mapping logic.

下面的示例基于真实的泊车 post-compute 代码模式，适合用来试用这个 skill 对高频数据映射逻辑的分析能力。

### Example 1: Per-Cycle Logging On A Hot Path / 示例 1：热路径中的周期性日志

This kind of code is a good candidate for the bottleneck prompt because the logging cost may dominate a periodic runnable.

这类代码非常适合用 bottleneck prompt 分析，因为日志成本可能在周期 runnable 中占据显著比例。

```cpp
l_apa_fct_soctomcu_list.m_APaOperationId = state.get().m_apaOperationId;
LOG_ERROR(
    "l_apa_fct_soctomcu_list.m_functionStates.m_apaStates: {}",
    l_apa_fct_soctomcu_list.m_functionStates.m_apaStates);
out.m_fct_soc_to_mcu_function_state_senderport.setSendState(mwala::generic_io::SendState::SEND);
```

Good prompt to try: / 推荐试用提问：

```text
Review this post-compute code for per-cycle logging overhead and suggest the lowest-risk runtime optimization.
审查这段 post-compute 代码中的周期性日志开销，并给出最低风险的 runtime 优化建议。
```

What the skill should catch: / skill 应该识别出的重点：

- per-cycle logging on a hot path / 热路径中的周期性日志
- formatting and I/O cost / 格式化与 I/O 成本
- quick win: state-change logging or throttled logging / 即时修复：按状态变化记录或节流日志

### Example 2: Full Buffer Reset Before Partial Fill / 示例 2：先全量清零再部分回填

This pattern is common in post-compute mapping code and often creates unnecessary fixed runtime cost.

这种模式在 post-compute 映射代码里很常见，通常会引入不必要的固定 runtime 成本。

```cpp
if (!in.m_FreeParkTrajectoryPoint.empty())
{
    for (vfc::uint8_t i = 0; i < 160; i++)
    {
        out.m_ADAS_strt_APARPAInfo_Ext.m_FreeParkPlannedTrajectory.m_data[i].m_FreeParkTrajectoryPointX    = 0;
        out.m_ADAS_strt_APARPAInfo_Ext.m_FreeParkPlannedTrajectory.m_data[i].m_FreeParkTrajectoryPointY    = 0;
        out.m_ADAS_strt_APARPAInfo_Ext.m_FreeParkPlannedTrajectory.m_data[i].m_FreeParkTrajectoryMoveIndex = 0u;
    }

    vfc::uint8_t idx = 0u;
    for (auto& apaFreeParkTraj : in.m_FreeParkTrajectoryPoint)
    {
        if (idx >= 160)
        {
            break;
        }
        valout::ADAS_strt_FreeParkTrajectoryPoints l_freeParkTrj{};
        l_freeParkTrj.m_FreeParkTrajectoryPointX    = apaFreeParkTraj.m_FreeParkTrajectoryPointX;
        l_freeParkTrj.m_FreeParkTrajectoryPointY    = apaFreeParkTraj.m_FreeParkTrajectoryPointY;
        l_freeParkTrj.m_FreeParkTrajectoryMoveIndex = apaFreeParkTraj.m_FreeParkTrajectoryMoveIndex;
        out.m_ADAS_strt_APARPAInfo_Ext.m_FreeParkPlannedTrajectory.m_data[idx] = l_freeParkTrj;
        idx++;
    }
}
```

Good prompt to try: / 推荐试用提问：

```text
Analyze this trajectory-mapping code for fixed per-cycle cost, memory-write overhead, and low-risk optimizations.
分析这段轨迹映射代码的固定周期成本、内存写开销，并给出低风险优化建议。
```

What the skill should catch: / skill 应该识别出的重点：

- repeated full reset before partial fill / 先全量清零再部分回填
- unnecessary memory writes / 不必要的内存写入
- quick win: clear only the previously valid range or track valid count / 即时修复：只清理上次有效区间，或显式维护有效长度

### Example 3: Same Code, But With Perf Evidence / 示例 3：同一类代码结合 perf 证据分析

If you already have profiler data, switch to the perf prompt and provide both the evidence and the source.

如果你已经有 profiler 数据，就切换到 perf prompt，并同时提供证据和源码。

```text
Use this perf report and the selected post-compute file to rank hotspots. Tell me whether the main cost comes from logging, repeated memory writes, container refill, or something else.
结合这份 perf 报告和当前选中的 post-compute 文件，对热点进行排序。请判断主要成本来自日志、重复内存写、容器回填，还是其他原因。
```

## What Changed From The Original Pack / 相比原始版本的变化

- Removed dependence on OpenClaw-specific `agent.run(...)` examples / 去除了对 OpenClaw 专属 `agent.run(...)` 示例的依赖
- Removed fictional Copilot slash-command syntax such as `@apa-monitor` / 去除了虚构的 Copilot 命令语法，例如 `@apa-monitor`
- Added standard `.github` assets that GitHub Copilot can consume directly / 增加了 GitHub Copilot 可直接消费的标准 `.github` 资产
- Rewrote installation so any developer can use the pack in any repository / 重写了安装方式，使任意开发者都可在任意仓库中使用

## Optional Tooling / 可选工具

The script in `utils/auto-optimize.sh` can support manual profiling on Linux-like environments. It is optional and not required for Copilot customization.

`utils/auto-optimize.sh` 脚本可用于 Linux 类环境中的手工 profiling。它是可选项，不是 Copilot 定制能力的前置依赖。

Recommended tools if you use the script: / 如果使用该脚本，建议安装：

- `perf`
- `pidstat`
- `valgrind`
- `pmap`
- `gprof`

## Recommended Team Workflow / 推荐团队工作流

1. Use the agent mode for initial diagnosis. / 先使用 agent 模式进行初步诊断。
2. Use a prompt file for a structured analysis pass. / 再使用 prompt 文件进行结构化分析。
3. Ask Copilot to separate measured facts, static evidence, root-cause hypotheses, and code changes. / 要求 Copilot 区分测量事实、静态证据、根因假设和代码修改建议。
4. Validate any optimization with tests, profiling data, or replay traces. / 任何优化都应结合测试、profiling 数据或 replay trace 验证。
5. Record safety impact before merging timing-sensitive changes. / 合并时序敏感变更前记录安全影响。

## Repository Layout

```text
bosch-parking-runtime-optimizer/
├── .github/
│   ├── copilot-instructions.md
│   ├── copilot-settings.json
│   ├── agents/
│   │   └── bosch-parking-runtime-optimizer.agent.md
│   └── prompts/
│       ├── bottleneck-analysis.prompt.md
│       ├── perf-hotspot-analysis.prompt.md
│       ├── memory-optimization.prompt.md
│       ├── realtime-optimization.prompt.md
│       └── iso26262-compliance.prompt.md
├── SKILL.md
├── COPILOT-SUPPORT.md
├── copilot-skills.md
├── copilot-commands.json
├── monitoring.md
├── performance-analysis.md
├── optimization-strategies.md
├── apa-specific.md
├── reporting.md
└── utils/
    └── auto-optimize.sh
```

## Usage Boundaries / 使用边界

- This pack guides Copilot behavior. It is not an executable plugin. / 该包用于约束 Copilot 行为，不是可执行插件。
- It does not create new IDE commands. / 它不会创建新的 IDE 命令。
- It should be reviewed and adapted if your project has stricter safety, platform, or coding-standard rules. / 如果你的项目有更严格的安全、平台或编码规范要求，应在使用前评审并调整。

## License / 许可证

MIT License. See `LICENSE`.