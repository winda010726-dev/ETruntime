# Bosch Parking Runtime Optimizer Capability Catalog

This file describes how to ask GitHub Copilot to operate with this pack. These are natural-language capabilities, not executable commands.

本文件说明如何向 GitHub Copilot 提问以使用这套能力。这些是自然语言能力说明，不是可执行命令。

## Bottleneck Analysis / 瓶颈分析

Use when: / 适用场景：

- a runnable or module is slow
- CPU usage spikes under load
- a replay or trace shows latency growth

Ask Copilot: / 可以这样问 Copilot：

- Analyze this code for CPU hotspots and unnecessary work.
- Identify the likely runtime bottlenecks in this parking pipeline.
- Review this function for repeated computations, copies, and branch-heavy logic.

## Perf-Assisted Hotspot Analysis / 基于 perf 的热点分析

Use when: / 适用场景：

- perf report, perf script, or flamegraph evidence is available
- you need ranked hotspot functions rather than static guesses
- you want measured facts separated from code-level interpretation

Ask Copilot: / 可以这样问 Copilot：

- Analyze this perf report and source together, rank the hottest functions, and classify the root causes.
- Use this perf data to identify the top CPU hotspots and propose quick wins plus deeper optimizations.
- Separate measured facts from source-level interpretation for these hotspot functions.

## Memory Optimization / 内存优化

Use when: / 适用场景：

- memory usage is trending upward
- allocations appear in hot loops
- ownership or lifetime is hard to reason about

Ask Copilot: / 可以这样问 Copilot：

- Review this code for allocation churn and memory lifetime issues.
- Find memory risks in this module for an embedded target.
- Suggest low-risk ways to reduce peak memory without changing behavior.

## Real-Time Optimization / 实时性优化

Use when: / 适用场景：

- the end-to-end budget is less than 50 ms
- p99 latency is unstable
- there may be blocking, jitter, or priority inversion

Ask Copilot: / 可以这样问 Copilot：

- Break down the critical path in this code and identify jitter sources.
- Review this module for real-time deadline risks.
- Suggest changes that reduce worst-case latency, not only average latency.

## Safety-Aware Review / 安全感知审查

Use when: / 适用场景：

- optimizing code in safety-relevant paths
- changing data validation or fail-safe behavior
- modifying scheduling or ownership in production logic

Ask Copilot: / 可以这样问 Copilot：

- Explain the safety impact of optimizing this control path.
- Review this change for timing and diagnostic regressions.
- Suggest optimizations that preserve conservative failure behavior.

## Parking-Specific Optimization / 泊车专项优化

Use when: / 适用场景：

- optimizing planning, perception, post-compute, or control code
- analyzing sensor fusion or path planning overhead
- reviewing replay or logging overhead in parking scenarios

Ask Copilot: / 可以这样问 Copilot：

- Review this parking post-compute runnable for high-frequency overhead.
- Suggest optimizations for planning code with deterministic runtime constraints.
- Look for copies, heap allocations, and logging work in this parking path.

## Reporting / 输出格式

Ask Copilot to structure the answer as: / 要求 Copilot 按以下结构输出：

1. hotspot overview
2. measured facts or static evidence
3. source-level interpretation
4. root-cause category
5. quick wins
6. deeper optimizations
7. expected gain
8. validation plan
9. safety and regression risks