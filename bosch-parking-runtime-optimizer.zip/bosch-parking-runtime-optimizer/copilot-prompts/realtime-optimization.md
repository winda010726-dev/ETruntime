# Real-Time Optimization for APA C++ Systems

You are an expert in real-time C++ optimization for safety-critical systems. Analyze the provided code for real-time performance.

## Guidelines:
1. Ensure <50ms end-to-end latency
2. Optimize critical paths
3. Prioritize safety-critical functions
4. Minimize thread synchronization delays
5. Consider ISO 26262 ASIL-D requirements

## Code to Analyze:
```cpp
// [Paste your C++ code here]
```

## Analysis Format:

### Timing Analysis
#### Execution Timing
- **Current Latency**: X ms average, Y ms peak
- **P50 Latency**: X ms
- **P99 Latency**: Y ms
- **Jitter**: Z ms standard deviation

#### Critical Path Analysis
- **End-to-End Path**: Perception → Planning → Control
- **Perception Module**: X ms
- **Planning Module**: Y ms
- **Control Module**: Z ms
- **Total**: X+Y+Z ms

#### Timing Violations
- **Violations Found**: Yes/No
- **Max Violation**: X ms over target
- **Violation Frequency**: Y times/hour
- **Critical Functions Affected**: List of functions

### Thread Synchronization
#### Synchronization Overhead
- **Mutex Wait Time**: X ms average
- **Semaphore Wait Time**: Y ms average
- **Context Switches**: Z per second
- **Priority Inversion**: Detected/Not Detected

#### Deadlock Risk Assessment
- **Lock Ordering**: Analyzed/Not Analyzed
- **Circular Dependencies**: Detected/Not Detected
- **Risk Level**: High/Medium/Low

### Optimization Recommendations

#### Recommendation 1: Critical Path Optimization
- **Target**: [Function/Path name]
- **Current Performance**: X ms
- **Target Performance**: Y ms
- **Techniques**:
  - Algorithm optimization
  - Data structure optimization
  - Cache-friendly access patterns
- **Expected Improvement**: Z%

#### Recommendation 2: Priority Scheduling
- **Current**: Standard scheduling
- **Recommended**: RTS scheduling (SCHED_FIFO/SCHED_RR)
- **Priority Assignment**:
  - Safety-critical: Highest priority
  - Real-time: High priority
  - Background: Low priority
- **Expected Improvement**: X%

#### Recommendation 3: Lock-Free Design
- **Current**: Mutex-based synchronization
- **Recommended**: Lock-free data structures
- **Safety Impact**: Reduced contention
- **Implementation**: Atomic operations, memory barriers

### ISO 26262 ASIL-D Requirements
- **Safety Mechanism**: Timing watchdog
- **Fail-Safe Behavior**: Graceful degradation
- **Priority Guarantee**: Critical functions always meet timing
- **Verification**: Timing analysis results

### Real-Time Best Practices
1. **Minimize Blocking**: Use non-blocking I/O
2. **Predictable Timing**: Avoid dynamic allocation in critical paths
3. **Priority Inheritance**: Prevent priority inversion
4. **Thread Affinity**: Pin critical threads to cores

### Final Recommendations
1. **Immediate**: Fix timing violations
2. **Short-term**: Implement priority scheduling
3. **Long-term**: Architectural real-time optimizations

### Expected Outcomes
- **Latency Reduction**: X ms
- **P99 Latency**: Y ms (target: <50ms)
- **Jitter Reduction**: Z%
- **Safety**: Maintained and enhanced

Please analyze the code and provide real-time optimization recommendations following this format.
