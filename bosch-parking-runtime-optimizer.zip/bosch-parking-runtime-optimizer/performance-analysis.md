# Perf Analysis Module / Perf 分析模块

## Overview / 概述

This module provides automatic performance analysis based on Linux perf profiling data. It analyzes perf report output files to identify performance bottlenecks in autonomous parking C++ systems.

本模块基于 Linux perf profiling 数据提供自动化性能分析，用于识别自动泊车 C++ 系统中的性能瓶颈。

## Capabilities

### 1. Perf File Parsing

```cpp
class PerfAnalyzer {
public:
    struct PerfAnalysisResult {
        std::string analysis_id;
        std::chrono::system_clock::time_point timestamp;
        double total_samples;
        double sampling_rate_hz;
        std::vector<HotFunctionInfo> hot_functions;
        std::vector<HotSourceLocationInfo> hot_locations;
        std::vector<BottleneckInfo> bottlenecks;
        PerformanceMetrics metrics;
    };
    
    PerfAnalysisResult analyzePerfFile(const std::string& perf_file_path,
                                      const std::string& binary_path,
                                      const std::string& symbol_path = "") {
        
        // Step 1: Generate perf report if not already generated
        auto perf_report = generatePerfReport(perf_file_path, binary_path, symbol_path);
        
        // Step 2: Parse the report
        auto parsed_data = parsePerfReport(perf_report);
        
        // Step 3: Analyze hot functions
        auto hot_functions = identifyHotFunctions(parsed_data);
        
        // Step 4: Map to source locations
        auto hot_locations = mapToSourceLocations(hot_functions, binary_path, symbol_path);
        
        // Step 5: Identify bottlenecks
        auto bottlenecks = identifyBottlenecks(hot_locations);
        
        // Step 6: Generate recommendations
        auto recommendations = generateRecommendations(bottlenecks);
        
        return {
            .analysis_id = generateAnalysisId(),
            .timestamp = std::chrono::system_clock::now(),
            .total_samples = perf_report.total_samples,
            .sampling_rate_hz = perf_report.sampling_rate,
            .hot_functions = hot_functions,
            .hot_locations = hot_locations,
            .bottlenecks = bottlenecks,
            .metrics = calculateMetrics(parsed_data, hot_functions)
        };
    }
    
private:
    std::string generatePerfReport(const std::string& perf_file,
                                  const std::string& binary,
                                  const std::string& symbols) {
        std::string cmd = "perf report -i " + perf_file;
        
        if (!binary.empty()) {
            cmd += " --kallsyms=" + binary;
        }
        
        if (!symbols.empty()) {
            cmd += " --dump-raw-stack";
        }
        
        cmd += " --stdio";
        
        return execCommand(cmd);
    }
    
    std::vector<HotFunctionInfo> identifyHotFunctions(const PerfReportData& data) {
        std::vector<HotFunctionInfo> hot_functions;
        
        // Group samples by function
        std::map<std::string, FunctionStats> function_stats;
        
        for (const auto& sample : data.samples) {
            std::string func_name = sample.function_name;
            if (!func_name.empty()) {
                function_stats[func_name].samples++;
                function_stats[func_name].duration += sample.duration;
                function_stats[func_name].call_sites++;
            }
        }
        
        // Sort by sample count
        std::vector<FunctionStats> sorted_stats;
        for (const auto& [func, stats] : function_stats) {
            sorted_stats.push_back({func, stats});
        }
        
        std::sort(sorted_stats.begin(), sorted_stats.end(),
            [](const FunctionStats& a, const FunctionStats& b) {
                return a.stats.samples > b.stats.samples;
            });
        
        // Top 10 hot functions
        for (size_t i = 0; i < std::min(sorted_stats.size(), size_t(10)); ++i) {
            hot_functions.push_back({
                .function_name = sorted_stats[i].name,
                .sample_count = sorted_stats[i].stats.samples,
                .total_duration_ms = sorted_stats[i].stats.duration,
                .call_sites = sorted_stats[i].stats.call_sites,
                .avg_call_duration_ms = 
                    sorted_stats[i].stats.samples > 0 ? 
                    sorted_stats[i].stats.duration / sorted_stats[i].stats.samples : 0
            });
        }
        
        return hot_functions;
    }
    
    std::vector<HotSourceLocationInfo> mapToSourceLocations(
        const std::vector<HotFunctionInfo>& hot_functions,
        const std::string& binary_path,
        const std::string& symbol_path) {
        
        std::vector<HotSourceLocationInfo> source_locations;
        
        // Extract symbols and map to source
        std::map<uint64_t, SymbolInfo> symbols = extractSymbols(binary_path, symbol_path);
        
        for (const auto& hot_func : hot_functions) {
            // Find symbol for this function
            auto symbol = findSymbolByName(symbols, hot_func.function_name);
            
            if (symbol) {
                // Map to source location using DWARF info or source mapping
                auto source_location = mapToSourceLocation(symbol, hot_func);
                
                source_locations.push_back({
                    .function_name = hot_func.function_name,
                    .source_file = source_location.file_path,
                    .source_line = source_location.line_number,
                    .symbol_addr = symbol.address,
                    .cpu_time_ms = hot_func.total_duration_ms,
                    .sample_count = hot_func.sample_count,
                    .percentage_of_total = 
                        (hot_func.sample_count / hot_functions[0].sample_count) * 100.0
                });
            }
        }
        
        return source_locations;
    }
    
    std::vector<BottleneckInfo> identifyBottlenecks(
        const std::vector<HotSourceLocationInfo>& hot_locations) {
        
        std::vector<BottleneckInfo> bottlenecks;
        
        // Analyze hot locations to identify bottlenecks
        for (const auto& location : hot_locations) {
            BottleneckInfo bottleneck;
            bottleneck.source_file = location.source_file;
            bottleneck.line_number = location.source_line;
            bottleneck.function_name = location.function_name;
            
            // Determine bottleneck type
            if (location.cpu_time_ms > 5.0) {  // > 5ms
                bottleneck.type = BottleneckType::CPU_INTENSIVE;
                bottleneck.severity = Severity::CRITICAL;
            } else if (location.cpu_time_ms > 2.0) {  // > 2ms
                bottleneck.type = BottleneckType::CPU_INTENSIVE;
                bottleneck.severity = Severity::HIGH;
            } else if (location.cpu_time_ms > 1.0) {  // > 1ms
                bottleneck.type = BottleneckType::CPU_INTENSIVE;
                bottleneck.severity = Severity::MEDIUM;
            } else {
                bottleneck.type = BottleneckType::CPU_INTENSIVE;
                bottleneck.severity = Severity::LOW;
            }
            
            bottleneck.impact_ms = location.cpu_time_ms;
            bottleneck.sample_count = location.sample_count;
            bottleneck.impact_percentage = location.percentage_of_total;
            
            bottlenecks.push_back(bottleneck);
        }
        
        // Sort by impact
        std::sort(bottlenecks.begin(), bottlenecks.end(),
            [](const BottleneckInfo& a, const BottleneckInfo& b) {
                return a.impact_ms > b.impact_ms;
            });
        
        return bottlenecks;
    }
};
```

### 2. Source Code Analysis

```cpp
class SourceCodeAnalyzer {
public:
    struct CodeAnalysisResult {
        std::string source_file;
        std::vector<CodeIssue> issues;
        OptimizationSuggestions suggestions;
        SafetyImpact safety_impact;
    };
    
    CodeAnalysisResult analyzeSourceCode(const std::string& source_file,
                                        size_t line_number,
                                        const std::vector<HotSourceLocationInfo>& hot_locations) {
        
        // Read source code
        std::string source_code = readSourceFile(source_file);
        
        // Analyze the code around the hot location
        auto issues = analyzeCodeAroundLine(source_code, line_number);
        
        // Generate optimization suggestions
        auto suggestions = generateOptimizationSuggestions(issues, line_number);
        
        // Evaluate safety impact
        auto safety_impact = evaluateSafetyImpact(suggestions);
        
        return {
            .source_file = source_file,
            .issues = issues,
            .suggestions = suggestions,
            .safety_impact = safety_impact
        };
    }
    
private:
    std::vector<CodeIssue> analyzeCodeAroundLine(const std::string& source_code,
                                                 size_t line_number) {
        std::vector<CodeIssue> issues;
        
        // Extract context around the line
        auto context = extractCodeContext(source_code, line_number, 20);
        
        // Check for common performance issues
        issues.push_back(checkForInefficientLoops(context, line_number));
        issues.push_back(checkForMemoryAllocationsInLoop(context, line_number));
        issues.push_back(checkForStringOperationsInLoop(context, line_number));
        issues.push_back(checkForUnnecessaryCopies(context, line_number));
        issues.push_back(checkForLockContention(context, line_number));
        issues.push_back(checkForCacheUnfriendlyAccess(context, line_number));
        
        // Remove null issues
        issues.erase(std::remove_if(issues.begin(), issues.end(),
            [](const CodeIssue& issue) { return issue.severity == Severity::NONE; }),
            issues.end());
        
        return issues;
    }
    
    OptimizationSuggestions generateOptimizationSuggestions(
        const std::vector<CodeIssue>& issues,
        size_t line_number) {
        
        OptimizationSuggestions suggestions;
        
        for (const auto& issue : issues) {
            switch (issue.issue_type) {
                case IssueType::INEFFICIENT_LOOP:
                    suggestions.push_back({
                        .type = SuggestionType::OPTIMIZE_LOOP,
                        .description = "Consider loop unrolling or vectorization",
                        .estimated_improvement = "15-30%",
                        .priority = Priority::HIGH,
                        .risk_level = RiskLevel::LOW
                    });
                    break;
                    
                case IssueType::MEMORY_ALLOCATION_IN_LOOP:
                    suggestions.push_back({
                        .type = SuggestionType::REUSE_MEMORY_POOL,
                        .description = "Move memory allocation outside the loop",
                        .estimated_improvement = "20-50%",
                        .priority = Priority::CRITICAL,
                        .risk_level = RiskLevel::LOW
                    });
                    break;
                    
                case IssueType::STRING_OPERATION_IN_LOOP:
                    suggestions.push_back({
                        .type = SuggestionType::USE_STRING_VIEW,
                        .description = "Use std::string_view or const char* to avoid copies",
                        .estimated_improvement = "10-25%",
                        .priority = Priority::HIGH,
                        .risk_level = RiskLevel::LOW
                    });
                    break;
                    
                case IssueType::UNNECESSARY_COPIES:
                    suggestions.push_back({
                        .type = SuggestionType::USE_MOVE_SEMANTICS,
                        .description = "Use move semantics or pass by const reference",
                        .estimated_improvement = "10-20%",
                        .priority = Priority::MEDIUM,
                        .risk_level = RiskLevel::LOW
                    });
                    break;
                    
                case IssueType::CACHE_UNFRIENDLY_ACCESS:
                    suggestions.push_back({
                        .type = SuggestionType::REORDER_DATA_STRUCTURE,
                        .description = "Reorganize data for better cache locality",
                        .estimated_improvement = "15-35%",
                        .priority = Priority::HIGH,
                        .risk_level = RiskLevel::MEDIUM
                    });
                    break;
            }
        }
        
        return suggestions;
    }
};
```

### 3. Performance Problem Identification

```cpp
class PerformanceProblemIdentifier {
public:
    struct ProblemIdentified {
        std::string problem_id;
        ProblemType problem_type;
        std::string description;
        std::string source_file;
        size_t line_number;
        Severity severity;
        EstimatedImpact estimated_impact;
        RecommendedOptimization recommended_optimization;
        SafetyCompliance safety_compliance;
    };
    
    std::vector<ProblemIdentified> identifyProblems(
        const PerfAnalysisResult& perf_result,
        const std::vector<CodeAnalysisResult>& code_analyses) {
        
        std::vector<ProblemIdentified> problems;
        
        // Combine perf analysis and source code analysis
        for (const auto& bottleneck : perf_result.bottlenecks) {
            // Find corresponding code analysis
            for (const auto& code_analysis : code_analyses) {
                if (code_analysis.source_file == bottleneck.source_file) {
                    ProblemIdentified problem;
                    problem.problem_id = generateProblemId();
                    problem.problem_type = ProblemType::CPU_BOTTLENECK;
                    problem.description = formatProblemDescription(bottleneck);
                    problem.source_file = bottleneck.source_file;
                    problem.line_number = bottleneck.line_number;
                    problem.severity = bottleneck.severity;
                    problem.estimated_impact = {
                        .cpu_time_saved_ms = bottleneck.impact_ms * 0.3,  // Conservative estimate
                        .latency_improvement = "30%"
                    };
                    problem.recommended_optimization = generateOptimizationForBottleneck(bottleneck);
                    problem.safety_compliance = evaluateSafetyCompliance(
                        problem.recommended_optimization, bottleneck.severity);
                    problems.push_back(problem);
                }
            }
        }
        
        return problems;
    }
    
private:
    RecommendedOptimization generateOptimizationForBottleneck(
        const BottleneckInfo& bottleneck) {
        
        RecommendedOptimization optimization;
        optimization.action_type = OptimizationAction::REFACTOR;
        optimization.steps = generateRefactoringSteps(bottleneck);
        optimization.validation_required = true;
        optimization.estimated_improvement = calculateImprovement(bottleneck);
        optimization.complexity = EstimateComplexity(bottleneck);
        
        return optimization;
    }
    
    std::vector<std::string> generateRefactoringSteps(
        const BottleneckInfo& bottleneck) {
        
        std::vector<std::string> steps;
        
        // Generate specific refactoring steps based on bottleneck type
        if (bottleneck.function_name.find("astar_search") != std::string::npos) {
            steps = {
                "Implement bidirectional A* search",
                "Pre-compute heuristic values",
                "Use priority queue with better heap implementation",
                "Add dead-reckoning for initial path estimate",
                "Implement progressive deepening for iterative improvement"
            };
        } else if (bottleneck.function_name.find("perception") != std::string::npos) {
            steps = {
                "Implement batch processing for sensor data",
                "Use zero-copy techniques for image data",
                "Apply model quantization for inference",
                "Optimize tensor layout for SIMD",
                "Implement asynchronous pipeline for data processing"
            };
        } else {
            steps = {
                "Analyze function for common optimization opportunities",
                "Consider algorithmic improvements",
                "Evaluate data structure alternatives",
                "Check for unnecessary copies",
                "Verify cache-friendly access patterns"
            };
        }
        
        return steps;
    }
};
```

## Usage

### Analyze Perf File

```bash
# Analyze a perf report
./auto-optimize.sh --analyze-perf \
    --perf-file /path/to/perf.data \
    --binary /path/to/autonomous_parking_binary \
    --symbols /path/to/symbols

# Output will include:
# - Hot functions and their locations
# - Identified bottlenecks
# - Optimization recommendations
# - Code analysis with specific line numbers
```

### Generate Analysis Report

```bash
./auto-optimize.sh --report \
    --perf-file /path/to/perf.data \
    --output analysis_report.md \
    --include-code-analysis \
    --include-safety-assessment
```

### Output Format

```markdown
# Performance Analysis Report

## Analysis Summary
- **Analysis ID**: rpt_20260415_001
- **Timestamp**: 2026-04-15T19:07:00Z
- **Total Samples**: 15234
- **Sampling Rate**: 1000 Hz

## Hot Functions (Top 5)

| Rank | Function | Samples | Duration (ms) | % of Total |
|------|----------|---------|---------------|------------|
| 1 | `path_planning::astar_search` | 4521 | 18.7 | 29.7% |
| 2 | `perception::camera_processing` | 3102 | 12.3 | 20.4% |
| 3 | `control::pid_loop` | 2856 | 8.2 | 18.7% |
| 4 | `sensor_fusion::multi_sensor` | 2145 | 9.5 | 14.1% |
| 5 | `planning::trajectory_opt` | 1890 | 6.8 | 12.4% |

## Identified Bottlenecks

### Critical: A* Path Planning
**File**: `src/path_planning/astar_search.cpp`
**Line**: 142
**CPU Time**: 18.7ms (29.7% of total)

**Issues Detected**:
1. ❌ Inefficient priority queue implementation
2. ❌ Repeated heuristic calculations
3. ❌ Unnecessary memory allocations in loop

**Code Context**:
```cpp
// Line 142-150
for (const auto& neighbor : neighbors) {
    double heuristic = calculateHeuristic(neighbor, goal);  // ❌ Repeated calculation
    double f_score = g_score + heuristic;  // ❌ Can be optimized
    
    // ❌ New memory allocation in loop
    auto node = std::make_shared<Node>(neighbor);
    open_set.insert(node);  // Priority queue insertion is O(log n)
}
```

**Recommended Optimizations**:
1. ✅ **Pre-compute heuristics**: Store heuristic values in a lookup table
   - Expected improvement: 25-35%
   - Effort: Low
   - Risk: Low

2. ✅ **Use better priority queue**: Implement custom heap with better locality
   - Expected improvement: 15-20%
   - Effort: Medium
   - Risk: Low

3. ✅ **Reduce allocations**: Reuse node objects from memory pool
   - Expected improvement: 10-15%
   - Effort: Medium
   - Risk: Low

**Safety Impact**: No impact on functional safety (ASIL-D)
**ISO 26262 Compliance**: ✓ Maintained

### High: Camera Processing
**File**: `src/perception/camera_processor.cpp`
**Line**: 87
**CPU Time**: 12.3ms (20.4% of total)

**Issues Detected**:
1. ❌ Memory allocations in processing loop
2. ❌ Unnecessary image copies
3. ⚠️ Cache-unfriendly data layout

**Code Context**:
```cpp
// Line 87-95
for (const auto& frame : frames) {
    cv::Mat processed = cv::Mat::zeros(frame.size(), frame.type());  // ❌ Allocation
    processImage(frame, processed);  // ❌ Copy operation
    features.push_back(extractFeatures(processed));  // ❌ Another copy
}
```

**Recommended Optimizations**:
1. ✅ **Memory pooling**: Pre-allocate buffers
   - Expected improvement: 30-40%
   - Effort: Medium
   - Risk: Low

2. ✅ **Zero-copy techniques**: Use view-based processing
   - Expected improvement: 15-25%
   - Effort: Medium
   - Risk: Low

3. ✅ **SIMD optimization**: Use OpenCV optimized functions
   - Expected improvement: 20-30%
   - Effort: Low
   - Risk: Low

**Safety Impact**: No impact on critical safety functions
**ISO 26262 Compliance**: ✓ Maintained

## Overall Recommendations

| Priority | Optimization | Expected Improvement | Effort | Risk |
|----------|-------------|---------------------|--------|------|
| CRITICAL | A* pre-compute heuristics | 25-35% | Low | Low |
| HIGH | Camera memory pooling | 30-40% | Medium | Low |
| HIGH | PID loop SIMD optimization | 20-30% | Low | Low |
| MEDIUM | Sensor fusion batch processing | 15-25% | Medium | Low |
| LOW | Trajectory optimization refinement | 10-15% | High | Medium |

## Estimated Total Improvement
- **CPU Time Reduction**: 35-50%
- **Latency Improvement**: 25-40%
- **Real-time Compliance**: ✓ Will meet < 50ms requirement

## Safety Compliance
- **ISO 26262 ASIL-D**: ✓ All optimizations maintain safety requirements
- **Critical Functions**: ✓ Priority preserved
- **Real-time Requirements**: ✓ All improvements support real-time constraints
