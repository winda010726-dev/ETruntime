# Monitoring Module / 监控模块

## Overview / 概述

This module provides comprehensive runtime monitoring capabilities for autonomous parking C++ systems. It collects and analyzes performance metrics in real-time.

本模块为自动泊车 C++ 系统提供全面的 runtime 监控能力，用于实时采集和分析性能指标。

## Monitoring Capabilities

### 1. CPU Usage Monitoring

```cpp
class CpuUsageMonitor {
public:
    struct CpuMetrics {
        double current_usage;      // Current CPU usage percentage
        double peak_usage;         // Peak CPU usage during monitoring
        double avg_usage;          // Average CPU usage
        std::vector<double> core_distribution; // Per-core usage
        std::vector<ProcessCpuUsage> process_list; // Per-process usage
    };
    
    CpuMetrics startMonitoring(const std::string& app_name, size_t duration_seconds) {
        auto start_time = std::chrono::steady_clock::now();
        auto end_time = start_time + std::chrono::seconds(duration_seconds);
        
        std::vector<CpuSample> samples;
        
        while (std::chrono::steady_clock::now() < end_time) {
            auto sample = collectCpuSample();
            samples.push_back(sample);
            
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        }
        
        return analyzeSamples(samples);
    }
    
private:
    CpuSample collectCpuSample() {
        CpuSample sample;
        
        // Get total CPU usage
        sample.total_usage = getOverallCpuUsage();
        
        // Get per-core usage
        sample.core_usage = getPerCoreUsage();
        
        // Get process list
        sample.process_list = getTopProcessesByCpu();
        
        sample.timestamp = std::chrono::steady_clock::now();
        
        return sample;
    }
    
    CpuMetrics analyzeSamples(const std::vector<CpuSample>& samples) {
        CpuMetrics metrics;
        metrics.core_distribution.resize(samples[0].core_usage.size());
        
        double total_usage_sum = 0.0;
        double peak_usage = 0.0;
        
        for (const auto& sample : samples) {
            total_usage_sum += sample.total_usage;
            peak_usage = std::max(peak_usage, sample.total_usage);
            
            for (size_t i = 0; i < sample.core_usage.size(); ++i) {
                metrics.core_distribution[i] += sample.core_usage[i];
            }
        }
        
        metrics.current_usage = samples.back().total_usage;
        metrics.peak_usage = peak_usage;
        metrics.avg_usage = total_usage_sum / samples.size();
        
        // Calculate per-core averages
        for (auto& core_usage : metrics.core_distribution) {
            core_usage /= samples.size();
        }
        
        // Collect top processes
        metrics.process_list = samples.back().process_list;
        
        return metrics;
    }
};
```

### 2. Memory Usage Monitoring

```cpp
class MemoryUsageMonitor {
public:
    struct MemoryMetrics {
        size_t used_bytes;         // Currently used memory
        size_t peak_bytes;         // Peak memory usage
        size_t available_bytes;    // Available memory
        size_t swap_used;          // Swap space used
        size_t page_faults;        // Page fault count
        bool memory_leak_detected; // Leak detection status
        std::vector<MemoryPoolStatus> pool_status; // Memory pool status
    };
    
    MemoryMetrics startMonitoring(size_t duration_seconds) {
        auto start_time = std::chrono::steady_clock::now();
        auto end_time = start_time + std::chrono::seconds(duration_seconds);
        
        std::vector<MemorySample> samples;
        std::vector<MemoryAllocationInfo> allocations;
        
        while (std::chrono::steady_clock::now() < end_time) {
            auto sample = collectMemorySample();
            samples.push_back(sample);
            
            if (sample.is_anomaly) {
                allocations.push_back(analyzeAllocation(sample));
            }
            
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        }
        
        return analyzeSamples(samples, allocations);
    }
    
private:
    MemorySample collectMemorySample() {
        MemorySample sample;
        
        // Get memory stats from /proc/meminfo or similar
        sample.used_bytes = getUsedMemory();
        sample.available_bytes = getAvailableMemory();
        sample.peak_bytes = getPeakMemory();
        sample.swap_used = getSwapUsage();
        
        // Detect memory leaks
        sample.is_anomaly = detectMemoryLeak(sample.used_bytes);
        
        sample.timestamp = std::chrono::steady_clock::now();
        
        return sample;
    }
    
    bool detectMemoryLeak(size_t current_used, size_t previous_used) {
        // Check for continuous memory growth
        if (current_used > previous_used + 1024 * 1024) {  // > 1MB increase
            // Check if memory is not being released
            static size_t last_known_usage = current_used;
            if (current_used - last_known_usage > 5 * 1024 * 1024) {  // > 5MB unreleased
                return true;
            }
            last_known_usage = current_used;
        }
        return false;
    }
    
    MemoryMetrics analyzeSamples(const std::vector<MemorySample>& samples,
                                const std::vector<MemoryAllocationInfo>& allocations) {
        MemoryMetrics metrics;
        metrics.peak_bytes = 0;
        
        for (const auto& sample : samples) {
            metrics.used_bytes = sample.used_bytes;
            metrics.peak_bytes = std::max(metrics.peak_bytes, sample.peak_bytes);
            metrics.page_faults += sample.page_faults;
        }
        
        metrics.available_bytes = samples.back().available_bytes;
        metrics.swap_used = samples.back().swap_used;
        metrics.memory_leak_detected = !allocations.empty();
        metrics.pool_status = analyzeMemoryPools(allocations);
        
        return metrics;
    }
};
```

### 3. Latency Monitoring

```cpp
class LatencyMonitor {
public:
    struct LatencyMetrics {
        double perception_latency_ms;      // Perception module latency
        double planning_latency_ms;        // Planning module latency
        double control_latency_ms;         // Control module latency
        double end_to_end_latency_ms;      // End-to-end latency
        double p50_latency_ms;             // 50th percentile latency
        double p99_latency_ms;             // 99th percentile latency
        std::vector<LatencyBottleneck> bottlenecks;
    };
    
    LatencyMetrics monitorLatency(const std::vector<Module>& modules,
                                 size_t duration_seconds) {
        auto start_time = std::chrono::steady_clock::now();
        auto end_time = start_time + std::chrono::seconds(duration_seconds);
        
        std::vector<LatencySample> samples;
        
        while (std::chrono::steady_clock::now() < end_time) {
            auto sample = collectLatencySamples(modules);
            samples.push_back(sample);
            
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        
        return analyzeLatencySamples(samples);
    }
    
private:
    LatencySample collectLatencySamples(const std::vector<Module>& modules) {
        LatencySample sample;
        
        for (const auto& module : modules) {
            sample.latencies[module.name] = module.measureLatency();
        }
        
        // Calculate end-to-end latency
        double total = 0.0;
        for (const auto& [name, latency] : sample.latencies) {
            total += latency;
        }
        sample.end_to_end_latency = total;
        
        sample.timestamp = std::chrono::steady_clock::now();
        
        return sample;
    }
    
    LatencyMetrics analyzeLatencySamples(
        const std::vector<LatencySample>& samples) {
        
        LatencyMetrics metrics;
        std::map<std::string, std::vector<double>> latencies_by_module;
        
        for (const auto& sample : samples) {
            for (const auto& [module_name, latency] : sample.latencies) {
                latencies_by_module[module_name].push_back(latency);
            }
            metrics.end_to_end_latency_ms += sample.end_to_end_latency;
        }
        
        // Calculate percentiles for each module
        for (const auto& [module_name, latencies] : latencies_by_module) {
            std::sort(latencies.begin(), latencies.end());
            size_t p50_idx = latencies.size() * 0.50;
            size_t p99_idx = latencies.size() * 0.99;
            
            if (module_name == "perception") {
                metrics.perception_latency_ms = latencies.back();
                metrics.p50_latency_ms = latencies[p50_idx];
                metrics.p99_latency_ms = latencies[p99_idx];
            } else if (module_name == "planning") {
                metrics.planning_latency_ms = latencies.back();
            } else if (module_name == "control") {
                metrics.control_latency_ms = latencies.back();
            }
            
            // Identify bottlenecks
            if (latencies.back() > 20.0) {  // > 20ms is a bottleneck
                metrics.bottlenecks.push_back({
                    .module_name = module_name,
                    .latency_ms = latencies.back(),
                    .p99_latency_ms = latencies[p99_idx],
                    .severity = Severity::HIGH
                });
            }
        }
        
        metrics.end_to_end_latency_ms /= samples.size();
        
        return metrics;
    }
};
```

### 4. Sensor Data Processing Monitoring

```cpp
class SensorProcessingMonitor {
public:
    struct SensorMetrics {
        double camera_processing_ms;      // Camera processing latency
        double radar_processing_ms;       // Radar processing latency
        double ultrasonic_processing_ms;  // Ultrasonic processing latency
        double sensor_fusion_latency_ms;  // Sensor fusion latency
        double data_throughput_mbps;      // Data throughput
        std::vector<SensorLatencyHistory> history;
    };
    
    SensorMetrics monitorSensorProcessing(
        const std::vector<SensorDevice>& sensors,
        size_t duration_seconds) {
        
        auto start_time = std::chrono::steady_clock::now();
        auto end_time = start_time + std::chrono::seconds(duration_seconds);
        
        std::vector<SensorSample> samples;
        
        while (std::chrono::steady_clock::now() < end_time) {
            auto sample = collectSensorSamples(sensors);
            samples.push_back(sample);
            
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
        }
        
        return analyzeSensorSamples(samples);
    }
    
private:
    SensorSample collectSensorSamples(const std::vector<SensorDevice>& sensors) {
        SensorSample sample;
        
        for (const auto& sensor : sensors) {
            sample.processing_times[sensor.id] = sensor.measureProcessingTime();
            sample.data_sizes[sensor.id] = sensor.getDataSize();
        }
        
        sample.timestamp = std::chrono::steady_clock::now();
        
        return sample;
    }
    
    SensorMetrics analyzeSensorSamples(
        const std::vector<SensorSample>& samples) {
        
        SensorMetrics metrics;
        double total_camera_time = 0.0;
        double total_radar_time = 0.0;
        double total_ultrasonic_time = 0.0;
        double total_data = 0.0;
        size_t sample_count = 0;
        
        for (const auto& sample : samples) {
            for (const auto& [sensor_id, processing_time] : sample.processing_times) {
                if (sensor_id.starts_with("camera")) {
                    total_camera_time += processing_time;
                } else if (sensor_id.starts_with("radar")) {
                    total_radar_time += processing_time;
                } else if (sensor_id.starts_with("ultrasonic")) {
                    total_ultrasonic_time += processing_time;
                }
            }
            
            for (const auto& [sensor_id, data_size] : sample.data_sizes) {
                total_data += data_size;
            }
            
            sample_count++;
        }
        
        if (sample_count > 0) {
            metrics.camera_processing_ms = total_camera_time / sample_count;
            metrics.radar_processing_ms = total_radar_time / sample_count;
            metrics.ultrasonic_processing_ms = total_ultrasonic_time / sample_count;
            metrics.data_throughput_mbps = (total_data * 8) / (sample_count * 1000000.0);
        }
        
        // Estimate sensor fusion latency
        metrics.sensor_fusion_latency_ms = 
            (metrics.camera_processing_ms + metrics.radar_processing_ms + 
             metrics.ultrasonic_processing_ms) / 3.0;
        
        return metrics;
    }
};
```

## Usage Examples

### Basic CPU Monitoring

```cpp
CpuUsageMonitor cpu_monitor;
auto cpu_metrics = cpu_monitor.startMonitoring("autonomous_parking_system", 60);

// Output:
// Current CPU: 65.5%
// Peak CPU: 89.2%
// Average CPU: 58.3%
// Core distribution: [45.2%, 78.1%, 62.4%, 89.1%]
```

### Memory Leak Detection

```cpp
MemoryUsageMonitor mem_monitor;
auto mem_metrics = mem_monitor.startMonitoring(300);  // 5 minutes

if (mem_metrics.memory_leak_detected) {
    // Analyze allocations
    std::vector<MemoryAllocationInfo> leaks = mem_metrics.pool_status;
    
    for (const auto& leak : leaks) {
        std::cout << "Memory leak detected:\n";
        std::cout << "  Size: " << leak.size << " bytes\n";
        std::cout << "  Location: " << leak.source_file << ":" << leak.line_number << "\n";
    }
}
```

### End-to-End Latency Monitoring

```cpp
LatencyMonitor latency_monitor;
auto latency_metrics = latency_monitor.monitorLatency({
    .name = "perception",
    .name = "planning",
    .name = "control"
}, 120);

// Output:
// Perception latency: 12.3ms
// Planning latency: 18.7ms
// Control latency: 8.2ms
// End-to-end latency: 39.2ms
// P50 latency: 35.8ms
// P99 latency: 52.1ms
```

## Best Practices

### 1. Low-Overhead Monitoring

- Use sampling instead of continuous monitoring in production
- Keep sampling interval >= 100ms to reduce overhead
- Use non-blocking collection methods

### 2. Threshold Alerting

```cpp
class MonitoringAlerts {
public:
    bool checkAlerts(const CpuMetrics& cpu_metrics) {
        if (cpu_metrics.current_usage > 90.0) {
            return triggerAlert("CRITICAL", "CPU usage above 90%");
        }
        if (cpu_metrics.peak_usage > 95.0) {
            return triggerAlert("WARNING", "CPU peak above 95%");
        }
        return false;
    }
    
    bool checkAlerts(const MemoryMetrics& mem_metrics) {
        if (mem_metrics.used_bytes > 480 * 1024 * 1024) {  // 480MB
            return triggerAlert("CRITICAL", "Memory usage above 480MB");
        }
        if (mem_metrics.memory_leak_detected) {
            return triggerAlert("ERROR", "Memory leak detected");
        }
        return false;
    }
    
    bool checkAlerts(const LatencyMetrics& lat_metrics) {
        if (lat_metrics.end_to_end_latency_ms > 50.0) {
            return triggerAlert("CRITICAL", "End-to-end latency > 50ms");
        }
        if (lat_metrics.p99_latency_ms > 60.0) {
            return triggerAlert("WARNING", "P99 latency > 60ms");
        }
        return false;
    }
};
```

### 3. Continuous Monitoring in Production

```cpp
class ProductionMonitoringService {
public:
    void startContinuousMonitoring() {
        // Start monitoring threads
        cpu_monitor_thread_ = std::thread(&CpuUsageMonitor::continuousMonitoring,
                                         &cpu_monitor_, 1000);  // 1 second interval
        memory_monitor_thread_ = std::thread(&MemoryUsageMonitor::continuousMonitoring,
                                            &memory_monitor_, 5000);  // 5 second interval
        latency_monitor_thread_ = std::thread(&LatencyMonitor::continuousMonitoring,
                                             &latency_monitor_, 100);  // 100ms interval
        
        // Start alert checker
        alert_checker_thread_ = std::thread(&MonitoringAlerts::continuousAlertChecking,
                                           &alert_checker_, 1000);
    }
    
    void stopMonitoring() {
        cpu_monitor_thread_.join();
        memory_monitor_thread_.join();
        latency_monitor_thread_.join();
        alert_checker_thread_.join();
    }
    
private:
    CpuUsageMonitor cpu_monitor_;
    MemoryUsageMonitor memory_monitor_;
    LatencyMonitor latency_monitor_;
    MonitoringAlerts alert_checker_;
    std::thread cpu_monitor_thread_;
    std::thread memory_monitor_thread_;
    std::thread latency_monitor_thread_;
    std::thread alert_checker_thread_;
};
```

## License

MIT License - See LICENSE file for details.
