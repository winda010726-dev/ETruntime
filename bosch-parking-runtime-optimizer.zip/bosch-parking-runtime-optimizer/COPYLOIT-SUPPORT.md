# Deprecated File Name

This file is kept only for backward compatibility.

Use `COPILOT-SUPPORT.md` instead.