# Copilot Instructions For Bosch Parking Runtime Optimization

You are working in a C++ codebase where runtime behavior, determinism, and safety matter.

你正在一个关注 runtime 行为、确定性和安全性的 C++ 代码库中工作。

## Primary Goals / 主要目标

- Find measurable runtime bottlenecks before proposing code changes. / 在提出代码修改前，先定位可测量的 runtime 瓶颈。
- Prefer low-risk optimizations that preserve behavior. / 优先选择保持行为不变的低风险优化。
- Focus on worst-case latency, blocking behavior, unnecessary copies, allocator pressure, and cache-unfriendly patterns. / 重点关注最坏时延、阻塞行为、不必要拷贝、分配器压力和 cache 不友好模式。
- Treat safety-relevant checks, diagnostics, and fallback behavior as non-optional unless the user explicitly asks to revisit them. / 除非用户明确要求，否则不要弱化安全相关检查、诊断和 fallback 行为。

## How To Respond / 回复方式

- Start with findings and likely root causes. / 先给出 findings 和可能根因。
- Distinguish observation from hypothesis. / 区分事实观察和假设推断。
- Distinguish measured facts from source-level interpretation whenever profiling data exists. / 只要存在 profiling 数据，就必须区分“测量事实”和“源码层推断”。
- When suggesting code changes, explain why each one helps. / 给出代码修改建议时，要解释每项修改为什么有效。
- Include a validation plan: benchmarks, replay, tests, or trace checks. / 需要附带验证方案，例如 benchmark、replay、测试或 trace 检查。
- Call out safety or determinism risks when they exist. / 存在安全或确定性风险时，必须明确指出。

Preferred output structure when analyzing hotspots: / 热点分析时推荐输出结构：

1. hotspot overview / 热点总览
2. measured facts / 测量事实
3. source-level interpretation / 源码层解释
4. root-cause category / 根因分类
5. quick wins / 即时修复
6. deeper optimizations / 深度优化
7. expected gain / 预期收益
8. validation plan / 验证方案
9. safety and regression risks / 安全与回归风险

## Optimization Priorities / 优化优先级

1. Remove unnecessary work.
2. Reduce copies and allocations on hot paths.
3. Improve algorithmic complexity and data locality.
4. Reduce lock contention, blocking, and jitter.
5. Only then consider lower-level micro-optimizations.

## Constraints / 约束

- Preserve externally visible behavior unless the user asks for a behavior change. / 除非用户要求改变行为，否则保持外部可见行为不变。
- Prefer simple, reviewable changes. / 优先简单、易评审的修改。
- Do not invent profiling data. / 不要编造 profiling 数据。
- If evidence is missing, say what should be measured. / 如果证据不足，要明确说明应该测什么。
- If no runtime evidence exists, label the result as static hotspot analysis rather than confirmed hotspot analysis. / 如果没有运行时证据，必须标注为“静态热点分析”，而不是“确认热点分析”。

## Perf Evidence Workflow / perf 证据工作流

- If the user provides a perf-data path, inspect the artifact layout before reading source deeply. / 如果用户直接给了 perf 数据路径，先检查产物布局，再深入源码。
- Prefer `.fold`, flamegraph summaries, `perf_top.log`, and other compact evidence before opening `.unfold` or oversized raw reports. / 优先读取 `.fold`、火焰图摘要、`perf_top.log` 等紧凑证据，再尝试 `.unfold` 或超大原始报告。
- Aggregate symbols across relevant scenarios or time windows to avoid overfitting to a single sample. / 先按场景或时间窗口聚合符号，避免只根据单个样本下结论。
- When the question names a specific stage such as the final maneuver, compare candidate recording windows explicitly and state why one window best matches that stage. / 当问题指向“最后一把”等特定阶段时，要显式对比不同录制窗口，并说明为什么某个窗口最符合该阶段。
- If a file is too large for the available tools, say so and switch to smaller derived artifacts instead of stalling. / 如果文件过大超出工具能力，要明确说明，并切换到更小的派生产物，而不是停滞。

## Domain Context / 领域上下文

- Typical pipeline: perception -> planning -> control -> post-compute/reporting / 典型链路：perception -> planning -> control -> post-compute/reporting
- Typical goals: end-to-end latency below 50 ms, predictable runtime, bounded memory growth / 典型目标：端到端时延低于 50 ms、runtime 可预测、内存增长有上界
- Typical concerns: hot loops, heap churn, repeated conversions, expensive logging, synchronization overhead, replay-time regressions / 典型关注点：热循环、heap 抖动、重复转换、昂贵日志、同步开销和 replay 退化

## Root-Cause Categories / 根因分类

- Algorithm hotspot / 算法热点: excessive complexity, repeated computation, avoidable full scans
- Memory bottleneck / 内存瓶颈: cache misses, poor locality, fragmentation, allocator churn, false sharing
- System-call overhead / 系统调用开销: frequent kernel transitions, file I/O, sleep/wakeup, allocation calls
- Lock contention / 锁竞争: coarse locks, long critical sections, contention under load, priority inversion
- Compiler or build issue / 编译或构建问题: missing optimization flags, failed inlining, debug-heavy build settings

## Anti-Patterns To Check Explicitly / 需要显式检查的反模式

- busy-wait loops / 忙等循环
- repeated container clear and refill / 容器反复清空再回填
- per-cycle logging on hot paths / 热路径中的周期性日志
- repeated large object copies / 重复的大对象拷贝
- heap allocations inside hot loops / 热循环中的堆分配
- repeated conversions and reformatting / 重复转换和重格式化
- kernel-heavy paths caused by syscall frequency / 系统调用过多导致的内核态占比升高
- drawing conclusions from a single perf capture without checking adjacent windows or comparable cases / 只看单个 perf 窗口、未对比相邻窗口或同类 case 就下结论