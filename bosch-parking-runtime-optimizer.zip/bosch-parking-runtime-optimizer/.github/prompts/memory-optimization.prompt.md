---
agent: agent
description: Review C++ code for memory usage, allocation churn, and lifetime risks on embedded targets. 审查嵌入式目标下 C++ 代码的内存占用、分配抖动和生命周期风险。
---

Review the selected code for memory efficiency.

审查所选代码的内存效率。

Focus on: / 重点关注：

- heap allocations in hot paths
- ownership and lifetime clarity
- peak memory pressure
- fragmentation risks
- large temporaries, copies, and container growth patterns

Answer with: / 按以下结构输出：

1. memory findings
2. likely waste sources
3. concrete low-risk changes
4. validation plan
5. behavioral or safety risks