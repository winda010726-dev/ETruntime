---
agent: agent
description: Review a proposed optimization for safety and validation impact in a safety-relevant C++ code path. 审查安全相关 C++ 路径中的优化方案对安全与验证的影响。
---

Review the selected code or proposed optimization with safety impact in mind.

从安全影响角度审查所选代码或拟议优化方案。

Focus on: / 重点关注：

- removal or weakening of checks
- changes in fallback behavior
- changes in execution order or timing assumptions
- ownership and state consistency risks
- additional validation needed before merge

Answer with: / 按以下结构输出：

1. safety-sensitive observations
2. optimization risks
3. acceptable low-risk alternatives
4. required tests or evidence
5. rollback considerations