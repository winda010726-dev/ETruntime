---
agent: agent
description: Review C++ code for worst-case latency, jitter, and deadline risks in runtime-sensitive parking logic. 审查 runtime 敏感泊车逻辑中的最坏时延、抖动和 deadline 风险。
---

Review the selected code for real-time risks.

审查所选代码中的实时性风险。

Focus on: / 重点关注：

- critical path length
- blocking and synchronization
- jitter sources
- priority inversion risk
- logging, allocation, and conversion work on time-critical paths
- syscall-heavy sections and runtime scheduling artifacts

Assume the target is deterministic behavior and an end-to-end latency budget below 50 ms unless the repository says otherwise.

除非仓库另有说明，否则默认目标是确定性行为和低于 50 ms 的端到端时延预算。

Answer with: / 按以下结构输出：

1. critical-path overview
2. measured facts or static evidence
3. worst-case risk drivers
4. quick wins
5. deeper optimizations
6. expected gain
7. validation plan
8. determinism and safety risks