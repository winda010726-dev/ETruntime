---
agent: agent
description: Analyze a C++ module for runtime bottlenecks in an autonomous parking system. 分析自动泊车系统中 C++ 模块的 runtime 瓶颈。
---

Analyze the selected code or files for runtime bottlenecks.

分析所选代码或文件中的 runtime 瓶颈。

If profiling evidence is not provided, clearly mark the result as static hotspot analysis.

如果没有提供 profiling 证据，请明确标注结果为静态热点分析。

Focus on: / 重点关注：

- repeated work and redundant computations
- avoidable copies and conversions
- hot-loop allocations
- lock contention or blocking behavior
- branch-heavy or cache-unfriendly patterns
- worst-case latency risk, not only average runtime
- compiler or build issues that can create unexpected hotspots

Classify each major hotspot as one of: / 每个主要热点都要归类为以下类型之一：

- algorithm hotspot / 算法热点
- memory bottleneck / 内存瓶颈
- system-call overhead / 系统调用开销
- lock contention / 锁竞争
- compiler or build issue / 编译或构建问题

Answer with: / 按以下结构输出：

1. hotspot overview
2. measured facts or static evidence
3. source-level interpretation
4. root-cause category
5. quick wins
6. deeper optimizations
7. expected gain
8. validation plan
9. regression and safety risks