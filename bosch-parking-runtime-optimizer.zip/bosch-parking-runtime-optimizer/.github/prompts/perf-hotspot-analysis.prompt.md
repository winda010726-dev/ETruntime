---
agent: agent
description: Analyze perf evidence together with source code, rank hotspots, classify root causes, and propose prioritized runtime optimizations. 结合 perf 证据与源码分析，排序热点、分类根因，并给出分级 runtime 优化建议。
---

Analyze the provided perf evidence and related source code together.

结合提供的 perf 证据和相关源码进行联合分析。

Inputs may include: / 输入可以包括：

- perf data path
- perf report text
- perf script output
- flamegraph summary
- relevant source files or modules

If the input is a perf-data directory, first identify available artifacts and choose the smallest high-value evidence set.

如果输入是 perf 数据目录，先识别可用产物，并优先选择体量小但信息密度高的证据集。

Step 1. Hotspot overview / 第一步：热点总览

- list the Top 10 to Top 20 hotspot functions when evidence allows
- mark user-space vs kernel-space time when visible
- identify whether the hotspot looks compute-bound, memory-bound, syscall-heavy, lock-related, or build-related
- if multiple recording windows exist, compare them and state which one most likely corresponds to the user-mentioned stage
- when multiple similar cases exist, prefer aggregated hotspot ranking before case-specific drill-down

Step 2. Source analysis / 第二步：源码分析

- locate each hotspot in the source tree
- inspect loops, recursion, allocations, memory-access patterns, logging, syscalls, and synchronization
- call out anti-patterns such as busy-wait, repeated clear/refill, frequent allocation, repeated conversions, and per-cycle logging

Step 3. Root-cause diagnosis / 第三步：根因诊断

Classify each hotspot as one of: / 将每个热点分类为：

- algorithm hotspot / 算法热点
- memory bottleneck / 内存瓶颈
- system-call overhead / 系统调用开销
- lock contention / 锁竞争
- compiler or build issue / 编译或构建问题

Step 4. Optimization plan / 第四步：优化方案

For each major hotspot provide: / 对每个主要热点给出：

- quick wins / 即时修复
- deeper optimizations / 深度优化
- expected gain / 预期收益
- validation plan / 验证方案
- safety and regression risks / 安全与回归风险

Answer with: / 按以下结构输出：

1. hotspot overview table
2. detailed analysis per hotspot
3. quick wins
4. deeper optimizations
5. expected gain
6. validation and measurement plan
7. safety and regression risks

If evidence is incomplete, say exactly what is missing and what should be measured next.

如果证据不完整，请明确指出缺失内容，以及下一步应该测量什么。

If large files cannot be opened directly, fall back to `.fold`, summary logs, or aggregated symbol counts and state that limitation clearly.

如果超大文件无法直接打开，应回退到 `.fold`、摘要日志或聚合后的符号统计，并明确说明这一限制。