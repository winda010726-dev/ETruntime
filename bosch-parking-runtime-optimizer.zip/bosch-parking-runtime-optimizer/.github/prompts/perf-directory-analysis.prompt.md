---
agent: agent
description: Analyze a perf-data directory by identifying the right recording window, aggregating hotspots across cases, mapping them to source, and producing prioritized optimization advice. 面向 perf 数据目录的分析模板：先判断录制窗口，再聚合热点、映射源码，并输出按优先级排序的优化建议。
---

Analyze the provided perf-data directory as a structured evidence set rather than as a single report.

把提供的 perf 数据目录当作“结构化证据集”来分析，而不是当作单个报告文件处理。

Use this prompt when the input is a directory containing decoded perf artifacts such as:

- `perf_record_01.fold`
- `perf_record_02.fold`
- `.svg` flamegraph inputs or outputs
- `perf_top.log`
- cpu or memory summary logs

在输入是包含如下产物的目录时使用本 prompt：

- `perf_record_01.fold`
- `perf_record_02.fold`
- `.svg` 火焰图输入或输出
- `perf_top.log`
- CPU 或内存摘要日志

Work in this order.

按以下顺序工作。

Step 1. Artifact layout / 第一步：产物布局

- enumerate available subdirectories, scenarios, cases, and recording windows
- identify which artifacts are compact and high-value first
- prefer `.fold`, summarized logs, and flamegraph summaries before raw oversized files
- if a file is too large to open directly, state that clearly and switch to derived evidence

Step 2. Window selection / 第二步：窗口判断

- if the user names a stage such as the final maneuver, compare available recording windows explicitly
- explain why the chosen window best matches the asked stage
- if the stage cannot be determined confidently, say so and list the competing windows

Step 3. Aggregated hotspot ranking / 第三步：聚合热点排名

- aggregate repeated symbols across comparable cases before drilling into a single file
- prefer Top 10 to Top 20 aggregated functions or symbol groups
- separate user-space and kernel-space time when visible
- classify each major hotspot as algorithm, memory, syscall, lock contention, or build/compiler related

Step 4. Source mapping / 第四步：源码映射

- map the dominant measured hotspots to source files and functions
- inspect loops, retries, allocations, copies, smoothing, collision checking, logging, and conversions on the hot path
- distinguish measured facts from source-level interpretation

Step 5. Priority recommendations / 第五步：优先级建议

- give quick wins first
- then give deeper optimizations
- explain why each recommendation is likely to help the measured hotspot
- call out latency, memory, determinism, and safety tradeoffs

Required output template / 固定输出模板

Use exactly this structure in the answer.

回答时固定使用以下结构。

1. Window judgment / 窗口判断

- candidate windows
- selected window
- evidence for the selection
- confidence and uncertainty

2. Aggregated hotspot table / 聚合热点表

- rank
- function or symbol group
- aggregated evidence
- hotspot category
- initial interpretation

3. Source mapping / 源码映射

For each major hotspot include:

- source file and function
- what the code is doing on the hot path
- likely root cause
- why the measured data supports that interpretation

4. Priority recommendations / 优先级建议

- P0: quickest low-risk actions
- P1: medium-effort optimizations with expected impact
- P2: deeper refactors or algorithmic changes

5. Validation plan / 验证方案

- how to rerun measurement
- what metrics to compare
- what regressions or safety checks must be verified

Rules / 规则

- do not draw conclusions from a single perf capture if adjacent windows or comparable cases exist
- do not invent missing evidence
- do not open huge raw files first when compact derived artifacts exist
- if aggregation is impossible, explain why and continue with the best available subset
- when the evidence points to allocator churn or copy pressure, call that out explicitly instead of only naming planner functions

If the user asks for the cause of high runtime at a specific stage, the answer must explicitly separate:

- measured evidence from perf artifacts
- inferred source-level cause
- proposed optimization priority

当用户问某一阶段 runtime 高的原因时，回答中必须显式区分：

- perf 产物中的测量证据
- 源码层面的推断原因
- 优化优先级建议