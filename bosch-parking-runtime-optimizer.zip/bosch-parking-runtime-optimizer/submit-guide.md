# Distribution Guide / 分发指南

## Goal / 目标

Distribute this pack so any developer can use the same GitHub Copilot customization for runtime-sensitive C++ work.

分发这套包，使任意开发者都能在 runtime 敏感的 C++ 项目中使用同一套 GitHub Copilot 定制能力。

## Recommended Distribution Options / 推荐分发方式

### Option 1: Publish This Repository / 方案一：发布整个仓库

Publish the repository as a normal Git repository and tell users to copy the `.github` folder into their target repository.

将该仓库作为普通 Git 仓库发布，并让使用者把 `.github` 文件夹复制到目标仓库中。

### Option 2: Ship As An Internal Template / 方案二：作为内部模板分发

Use this repository as a template or subtree for teams that build parking or embedded C++ software.

将该仓库作为模板或 subtree，供泊车或嵌入式 C++ 团队复用。

### Option 3: Package Only The Copilot Assets / 方案三：仅打包 Copilot 资产

If you do not want to distribute the full documentation, ship only:

如果不想分发完整文档，只分发以下文件即可：

- `.github/copilot-instructions.md`
- `.github/agents/bosch-parking-runtime-optimizer.agent.md`
- `.github/prompts/*.prompt.md`

## Do Not Assume / 不要假设

- user-specific home directories / 用户私有 home 目录
- OpenClaw or ClawHub / OpenClaw 或 ClawHub
- custom agent runtimes / 自定义 agent 运行时
- proprietary slash commands / 私有 slash 命令

## Recommended Repository Additions / 建议补充的仓库文件

- `CONTRIBUTING.md`
- `CHANGELOG.md`
- `.gitignore`
- examples showing prompt usage in real repositories

## Validation Before Distribution / 分发前校验

1. Confirm the `.github` files are present. / 确认 `.github` 文件齐全。
2. Confirm the prompt files use repo-agnostic wording. / 确认 prompt 文件使用与仓库无关的措辞。
3. Confirm examples do not depend on proprietary APIs. / 确认示例不依赖私有 API。
4. Confirm the runtime script is marked optional. / 确认 runtime 脚本被标记为可选项。
5. Confirm docs tell users how to copy the assets into any repository. / 确认文档明确说明如何将资产复制到任意仓库。