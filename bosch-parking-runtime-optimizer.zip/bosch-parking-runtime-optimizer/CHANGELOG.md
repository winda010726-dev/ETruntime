# Changelog

All notable changes to this repository will be documented in this file.

本仓库的重要变更会记录在此文件中。

The format is loosely based on Keep a Changelog.

格式参考 Keep a Changelog，但保持简洁。

## [Unreleased]

### Added

- Added a dedicated perf-directory analysis prompt for decoded perf-data folders: `.github/prompts/perf-directory-analysis.prompt.md`.
- Added a fixed analysis template for:
  - window judgment
  - aggregated hotspot table
  - source mapping
  - priority recommendations
  - validation plan
- Added explicit perf-evidence workflow guidance for directory-based profiler inputs in `.github/copilot-instructions.md`.

### Changed

- Updated `.github/agents/bosch-parking-runtime-optimizer.agent.md` to prefer `.fold`, summary logs, and window comparison before deep source analysis when the input is a perf-data directory.
- Updated `.github/prompts/perf-hotspot-analysis.prompt.md` so it handles multi-window and multi-case perf directories more consistently.
- Updated `.github/copilot-settings.json` to include the new `perf-directory-analysis.prompt.md` file in the bundle metadata.
- Updated `README.md` and `SKILL.md` to document when to use the perf directory prompt versus the general perf hotspot prompt.

### Packaging

- Regenerated the upload-ready Copilot customization bundle zip with the latest `.github` assets.

## [2.0.0]

### Added

- Introduced the repository-agnostic GitHub Copilot customization pack under `.github/`.
- Added a dedicated runtime optimizer agent mode for autonomous parking C++ analysis.
- Added reusable prompts for:
  - bottleneck analysis
  - perf hotspot analysis
  - memory optimization
  - real-time review
  - ISO 26262-oriented safety review
- Added standalone documentation for installation, usage, reporting, and distribution.

### Notes

- This pack is designed to be copied into other repositories without relying on proprietary runtimes or slash commands.