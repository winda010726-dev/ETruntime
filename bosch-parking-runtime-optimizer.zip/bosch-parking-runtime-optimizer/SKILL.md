# Bosch Parking Runtime Optimizer

GitHub Copilot skill pack for runtime performance analysis and optimization of autonomous parking C++ systems.

用于自动泊车 C++ 系统 runtime 性能分析与优化的 GitHub Copilot skill 包。

## Purpose / 目标

This pack gives GitHub Copilot a focused operating mode for:

这个包为 GitHub Copilot 提供面向 runtime 优化的聚焦工作模式：

- CPU, memory, latency, and thread bottleneck analysis / CPU、内存、时延和线程瓶颈分析
- Perf-assisted hotspot analysis with measured evidence / 基于 perf 实测证据的热点分析
- Real-time optimization for parking pipelines / 面向泊车链路的实时性优化
- Safety-aware recommendations for ISO 26262 style workflows / 面向 ISO 26262 风格流程的安全感知优化建议
- Embedded memory and scheduling tradeoff reviews / 嵌入式内存与调度权衡分析
- Review and refactoring guidance for performance-critical C++ code / 面向性能关键 C++ 代码的审查与重构建议

## Copilot Compatibility / Copilot 兼容性

This repository is organized to work with GitHub Copilot in VS Code by shipping reusable customization assets under `.github/`:

- `.github/copilot-instructions.md`: baseline behavior for Copilot in this domain
- `.github/agents/bosch-parking-runtime-optimizer.agent.md`: a dedicated agent mode
- `.github/prompts/*.prompt.md`: reusable prompts for common optimization tasks

The pack is repository-agnostic. It does not assume OpenClaw, ClawHub, or any proprietary agent runtime.

该包与具体仓库无关，不依赖 OpenClaw、ClawHub 或任何私有 agent 运行时。

## What Copilot Should Optimize For / Copilot 应优先优化的目标

- End-to-end latency target: less than 50 ms where required / 端到端时延目标：有要求时应低于 50 ms
- Memory budget: less than 512 MB where applicable / 内存预算：适用场景下低于 512 MB
- Deterministic runtime behavior over synthetic micro-benchmarks / 优先保证确定性 runtime，而不是只追求微基准分数
- Safety-critical behavior must not regress / 安全关键行为不得退化
- Recommendations should prefer measurable, low-risk changes first / 优先给出可量化、低风险的优化建议

## Suggested Workflows / 建议工作流

### 1. Runtime Bottleneck Review

Use the agent mode or the bottleneck prompt when a module is slow, CPU-heavy, or misses timing targets.

当模块运行缓慢、CPU 占用高或未满足时序目标时，使用 agent 模式或 bottleneck prompt。

Expected output: / 期望输出：

- hotspot summary
- suspected root cause
- code-level improvement options
- validation plan

### 1A. Perf-Assisted Hotspot Review

Use the perf hotspot prompt when you have `perf report`, `perf script`, or other profiler evidence.

当你已经有 `perf report`、`perf script` 或其他 profiler 证据时，使用 perf 热点分析 prompt。

Expected output: / 期望输出：

- Top-N hotspot overview table
- measured facts vs source-level interpretation
- root-cause category per hotspot
- quick wins and deeper optimizations
- expected gain and validation steps

### 1B. Perf Directory Review

Use the perf directory prompt when the input is a decoded perf-data directory rather than a ready-made report.

当输入是 perf 解码目录而不是现成报告时，使用 perf 目录分析 prompt。

Expected output: / 期望输出：

- recording window judgment
- aggregated hotspot table across comparable cases or windows
- source mapping for dominant hotspots
- prioritized optimization recommendations
- validation plan

### 2. Memory Optimization Review

Use the memory prompt when memory growth, fragmentation, or allocator pressure is suspected.

当怀疑存在内存增长、碎片化或分配器压力时，使用 memory prompt。

Expected output: / 期望输出：

- allocation pattern review
- leak and fragmentation risks
- ownership and lifetime issues
- embedded-safe recommendations

### 3. Real-Time Review

Use the real-time prompt when the parking stack has deadline misses, jitter, or priority inversion risks.

当泊车链路存在 deadline miss、抖动或优先级反转风险时，使用 real-time prompt。

Expected output: / 期望输出：

- critical path breakdown
- blocking and synchronization risks
- scheduling recommendations
- test cases for latency verification

### 4. Safety-Aware Optimization Review

Use the ISO 26262 prompt before changing logic in safety-relevant code paths.

在修改安全相关路径中的逻辑前，使用 ISO 26262 prompt。

Expected output: / 期望输出：

- affected safety assumptions
- review boundaries
- required regression coverage
- rollback considerations

## Installation For Any Developer / 面向任意开发者的安装方式

Copy this repository, or only its `.github` folder, into any target C++ repository.

可以把整个仓库，或仅把 `.github` 文件夹，复制到任意目标 C++ 仓库中。

Minimum setup: / 最小安装步骤：

1. Copy `.github/copilot-instructions.md`
2. Copy `.github/agents/bosch-parking-runtime-optimizer.agent.md`
3. Copy any prompt files you want from `.github/prompts/`
4. Keep the domain docs if you want Copilot and humans to reference them during reviews

Recommended prompt choice: / 推荐 prompt 选择：

- use `perf-hotspot-analysis.prompt.md` for report text, perf script output, or hotspot summaries
- use `perf-directory-analysis.prompt.md` for decoded perf directories with multiple windows or cases

Optional runtime tooling: / 可选 runtime 工具：

- `utils/auto-optimize.sh`
- Linux profiling tools such as `perf`, `pidstat`, `valgrind`, and `pmap`

## Non-Goals / 非目标

- It does not register real slash commands in GitHub Copilot / 不会为 GitHub Copilot 注册真实的 slash 命令
- It does not depend on any private service / 不依赖任何私有服务
- It does not auto-apply optimizations without code review / 不会绕过代码评审自动应用优化

## Repository Contents / 仓库内容

- `README.md`: installation and usage guide
- `copilot-skills.md`: natural-language capability catalog for Copilot users
- `copilot-commands.json`: machine-readable capability manifest
- `COPILOT-SUPPORT.md`: Copilot integration notes
- `monitoring.md`: monitoring domain notes
- `performance-analysis.md`: perf-driven analysis notes
- `optimization-strategies.md`: optimization strategy notes
- `apa-specific.md`: parking-specific considerations
- `reporting.md`: reporting guidance
- `utils/auto-optimize.sh`: optional profiling helper script

## Best Practices / 最佳实践

1. Start with read-only analysis before editing code. / 先做只读分析，再考虑修改代码。
2. Ask Copilot to justify the root cause before suggesting changes. / 让 Copilot 先说明根因，再给出修改建议。
3. Prefer algorithmic and data movement fixes before low-level tuning. / 优先做算法和数据流层面的优化，再考虑底层微调。
4. Re-check timing, memory, and safety assumptions after each change. / 每次修改后重新检查时延、内存和安全假设。
5. Keep benchmarks and test evidence close to each optimization. / 每项优化都应配套 benchmark 或测试证据。

## Safety Constraints / 安全约束

- Do not trade safety behavior for lower latency without explicit review. / 未经明确评审，不要用安全行为换取更低时延。
- Do not recommend relaxed checks in safety-critical paths as a default. / 不要默认在安全关键路径中放松检查。
- Any optimization that changes control flow, scheduling, or ownership should include validation guidance. / 任何改变控制流、调度或所有权的优化都应包含验证建议。

## License / 许可证

MIT License. See `LICENSE`.