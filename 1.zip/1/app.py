# # app.py
# import os
# import uuid
# import threading
# import shutil
# from datetime import datetime
# from flask import Flask, request, jsonify, render_template, send_from_directory, abort
# from werkzeug.utils import secure_filename
# from flask import current_app

# from config import Config
# from models import db, AnalysisTask
# from utils import allowed_file, extract_archive, run_report_generator




# app = Flask(__name__)
# app.config.from_object(Config)
# # 限制最大上传大小 1GB
# app.config['MAX_CONTENT_LENGTH'] = 1024 * 1024 * 1024

# db.init_app(app)

# os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
# os.makedirs(app.config['TEMP_FOLDER'], exist_ok=True)
# os.makedirs(app.config['REPORTS_DIR'], exist_ok=True)

# with app.app_context():
#     db.create_all()

# def _run_analysis_task(task_id, input_path, json_file_path, output_dir):
#     with app.app_context():
#         task = AnalysisTask.query.get(task_id)
#         if not task:
#             return
#         task.status = 'RUNNING'
#         db.session.commit()

#         try:
#             real_input = input_path

#             # 自动解压压缩包
#             if input_path.endswith(('.zip', '.tar', '.tar.gz', '.tgz')):
#                 extract_dir = os.path.join(app.config['TEMP_FOLDER'], f"task_{task_id}")
#                 extract_archive(input_path, extract_dir)

#                 sub_dirs = [d for d in os.listdir(extract_dir) if os.path.isdir(os.path.join(extract_dir, d))]
#                 files = [f for f in os.listdir(extract_dir) if os.path.isfile(os.path.join(extract_dir, f))]
#                 if len(sub_dirs) == 1 and len(files) == 0:
#                     real_input = os.path.join(extract_dir, sub_dirs[0])
#                 else:
#                     real_input = extract_dir

#             # 自动加载默认JSON
#             if not json_file_path or not os.path.exists(json_file_path):
#                 json_file_path = app.config['DEFAULT_DOMAIN_LOOKUP']

#             # 【调用新分析脚本】
#             result_dir = run_report_generator(
#                 input_dir=real_input,
#                 json_file=json_file_path,
#                 output_dir=output_dir,
#                 script_path=app.config['GENERATE_SCRIPT']
#             )

#             task.output_dir = result_dir
#             task.status = 'COMPLETED'
#             task.completed_at = datetime.utcnow()

#         except Exception as e:
#             task.status = 'FAILED'
#             task.error_message = str(e)
#         finally:
#             db.session.commit()

# @app.route('/')
# def index():
#     return render_template('index.html')

# @app.route('/tasks')
# def tasks_list():
#     return render_template('tasks.html')

# @app.route('/task/<task_id>')
# def task_detail(task_id):
#     task = AnalysisTask.query.get(task_id)
#     if not task:
#         abort(404)
#     return render_template('task_detail.html', task=task)

# # # ===================== API =====================
# # @app.route('/api/tasks', methods=['POST'])
# # def create_task():
# #     task_name = request.form.get('task_name', '未命名')
# #     uploaded_file = request.files.get('input_file')
# #     manual_path = request.form.get('input_dir', '').strip()

# #     input_path = None
# #     json_file_path = None

# #     if uploaded_file and uploaded_file.filename != '':
# #         if not allowed_file(uploaded_file.filename, app.config['ALLOWED_EXTENSIONS']):
# #             return jsonify({'error': '仅支持 zip, tar, tar.gz, json'}), 400

# #         filename = secure_filename(uploaded_file.filename)
# #         temp_id = str(uuid.uuid4())
# #         saved_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{temp_id}_{filename}")
# #         uploaded_file.save(saved_path)

# #         if filename.endswith('.json'):
# #             json_file_path = saved_path
# #             if not manual_path:
# #                 return jsonify({'error': '请填写数据路径'}), 400
# #             input_path = manual_path
# #         else:
# #             input_path = saved_path
# #             json_file_path = None
# #     else:
# #         if not manual_path:
# #             return jsonify({'error': '请上传文件或填写路径'}), 400
# #         input_path = manual_path

# #     # 加载JSON配置
# #     json_file = request.files.get('json_file')
# #     if json_file and json_file.filename.endswith('.json'):
# #         fn = secure_filename(json_file.filename)
# #         json_file_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{str(uuid.uuid4())}_{fn}")
# #         json_file.save(json_file_path)
# #     else:
# #         default_json = app.config['DEFAULT_DOMAIN_LOOKUP']
# #         if os.path.exists(default_json):
# #             json_file_path = default_json

# #     # 创建任务
# #     task_id = str(uuid.uuid4())
# #     output_dir = os.path.join(app.config['REPORTS_DIR'], f"task_{task_id}")

# #     task = AnalysisTask(
# #         id=task_id,
# #         task_name=task_name,
# #         input_dir=input_path,
# #         json_file=json_file_path,
# #         output_dir=output_dir,
# #         status='PENDING'
# #     )
# #     db.session.add(task)
# #     db.session.commit()

# #     # 后台执行
# #     threading.Thread(
# #         target=_run_analysis_task,
# #         args=(task_id, input_path, json_file_path, output_dir),
# #         daemon=True
# #     ).start()

# #     return jsonify({'task_id': task_id, 'status': 'PENDING'}), 202

# # ===================== 批量任务 API =====================
# @app.route('/api/batch_tasks', methods=['POST'])
# def create_batch_tasks():
#     task_name_prefix = request.form.get('task_name_prefix', '批量任务')
#     uploaded_files = request.files.getlist('input_files')  # 多文件
#     json_file_path = None

#     # 处理JSON文件
#     json_file = request.files.get('json_file')
#     if json_file and json_file.filename.endswith('.json'):
#         fn = secure_filename(json_file.filename)
#         json_file_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{str(uuid.uuid4())}_{fn}")
#         json_file.save(json_file_path)
#     else:
#         default_json = app.config['DEFAULT_DOMAIN_LOOKUP']
#         if os.path.exists(default_json):
#             json_file_path = default_json

#     task_ids = []
#     task_names = []

#     # 第一步：先把所有文件保存好，创建PENDING任务（不执行）
#     for uploaded_file in uploaded_files:
#         if not uploaded_file or uploaded_file.filename == '':
#             continue

#         if not allowed_file(uploaded_file.filename, app.config['ALLOWED_EXTENSIONS']):
#             continue

#         # 保存文件
#         filename = secure_filename(uploaded_file.filename)
#         temp_id = str(uuid.uuid4())
#         saved_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{temp_id}_{filename}")
#         uploaded_file.save(saved_path)

#         # 任务名 = 压缩包文件名
#         task_name = f"{task_name_prefix} - {filename}"

#         # 创建任务
#         task_id = str(uuid.uuid4())
#         output_dir = os.path.join(app.config['REPORTS_DIR'], f"task_{task_id}")

#         task = AnalysisTask(
#             id=task_id,
#             task_name=task_name,
#             input_dir=saved_path,
#             json_file=json_file_path,
#             output_dir=output_dir,
#             status='PENDING'  # 只创建，不运行
#         )
#         db.session.add(task)

#         task_ids.append(task_id)
#         task_names.append(task_name)

#     # 统一提交数据库
#     db.session.commit()

#     # 第二步：用一个后台线程，顺序执行所有任务（一次只跑一个！）
#     def run_batch_sequentially(task_id_list):
#         with app.app_context():
#             for tid in task_id_list:
#                 try:
#                     task = AnalysisTask.query.get(tid)
#                     if not task or task.status != 'PENDING':
#                         continue
                    
#                     # 顺序执行，不会同时跑
#                     _run_analysis_task(tid, task.input_dir, task.json_file, task.output_dir)
#                 except Exception:
#                     continue

#     # 启动一个线程，按顺序跑
#     threading.Thread(
#         target=run_batch_sequentially,
#         args=(task_ids,),
#         daemon=True
#     ).start()

#     return jsonify({
#         'task_ids': task_ids,
#         'task_names': task_names,
#         'count': len(task_ids)
#     }), 202



# @app.route('/api/tasks/<task_id>', methods=['GET'])
# def get_task(task_id):
#     task = AnalysisTask.query.get(task_id)
#     if not task:
#         return jsonify({'error': 'Not found'}), 404
#     return jsonify(task.to_dict())

# @app.route('/api/tasks', methods=['GET'])
# def list_tasks():
#     page = request.args.get('page', 1, type=int)
#     per_page = request.args.get('per_page', 20, type=int)
#     pagination = AnalysisTask.query.order_by(AnalysisTask.created_at.desc()).paginate(page=page, per_page=per_page)
#     return jsonify({
#         'tasks': [t.to_dict() for t in pagination.items],
#         'total': pagination.total
#     })

# @app.route('/api/tasks/<task_id>', methods=['DELETE'])
# def delete_task(task_id):
#     task = AnalysisTask.query.get(task_id)
#     if not task:
#         return jsonify({'error': 'Not found'}), 404

#     if task.output_dir and os.path.exists(task.output_dir):
#         shutil.rmtree(task.output_dir)
#     if task.input_dir and os.path.exists(task.input_dir):
#         if os.path.isfile(task.input_dir):
#             os.remove(task.input_dir)

#     db.session.delete(task)
#     db.session.commit()
#     return jsonify({'success': True})

# @app.route('/reports/<task_id>/<path:filename>')
# def serve_report(task_id, filename):
#     task = AnalysisTask.query.get(task_id)
    
#     if not task or not task.output_dir or task.status != 'COMPLETED':
#         abort(404)
    
#     # 基础目录：c:\...\reports\task_uuid
#     base_dir = os.path.realpath(task.output_dir)
    
#     # 尝试 1：直接匹配路径 (例如根目录下的 index.html)
#     target_path = os.path.realpath(os.path.join(base_dir, filename))
    
#     # 尝试 2：如果找不到，且分析脚本生成了深层子目录 (如日志所示)
#     if not os.path.exists(target_path):
#         # 遍历 task_id 目录，寻找实际包含报告的子目录
#         subdirs = [d for d in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, d))]
#         for sd in subdirs:
#             potential_path = os.path.realpath(os.path.join(base_dir, sd, filename))
#             if os.path.exists(potential_path):
#                 target_path = potential_path
#                 # 重新定位目录以供 send_from_directory 使用
#                 return send_from_directory(os.path.join(base_dir, sd), filename)

#     # 安全检查
#     if not target_path.startswith(base_dir):
#         abort(403)
        
#     if not os.path.isfile(target_path):
#         # 如果还是找不到，尝试列出目录下所有 HTML 
#         # (这步是关键：如果请求的是 /，我们返回搜到的第一个 HTML)
#         if filename in ['', 'index.html']:
#             for root, dirs, files in os.walk(base_dir):
#                 for f in files:
#                     if f.endswith('.html'):
#                         return send_from_directory(root, f)
#         abort(404)
        
#     # 默认返回
#     return send_from_directory(os.path.dirname(target_path), os.path.basename(target_path))


# if __name__ == '__main__':
#     app.run(debug=True, host='0.0.0.0', port=5000)


import os
import uuid
import shutil
import threading
import queue
from datetime import datetime
from flask import Flask, request, jsonify, render_template, send_from_directory, abort
from werkzeug.utils import secure_filename
import math
from config import Config
from models import db, AnalysisTask
from utils import allowed_file, extract_archive, run_report_generator


app = Flask(__name__)
app.config.from_object(Config)
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024

db.init_app(app)

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['TEMP_FOLDER'], exist_ok=True)
os.makedirs(app.config['REPORTS_DIR'], exist_ok=True)

with app.app_context():
    try:
        db.create_all()
    except Exception:
        pass
    with db.engine.connect() as conn:
        try:
            conn.execute(db.text(
                "ALTER TABLE tasks ADD COLUMN task_prefix VARCHAR(100) DEFAULT ''"
            ))
            conn.commit()
        except Exception:
            pass

# =====================================================
#  任务队列：一次只跑一个任务，避免多个分析同时抢资源
# =====================================================
task_queue = queue.Queue()


def _task_worker():
    while True:
        task_id, input_path, json_file_path, output_dir = task_queue.get()
        try:
            _run_analysis_task(task_id, input_path, json_file_path, output_dir)
        except Exception:
            pass
        finally:
            task_queue.task_done()


worker_thread = threading.Thread(target=_task_worker, daemon=True)
worker_thread.start()


def _run_analysis_task(task_id, input_path, json_file_path, output_dir):
    extract_dir = None
    with app.app_context():
        task = AnalysisTask.query.get(task_id)
        if not task:
            return
        task.status = 'RUNNING'
        db.session.commit()

        try:
            real_input = input_path

            if input_path.endswith(('.zip', '.tar', '.tar.gz', '.tgz')):
                extract_dir = os.path.join(
                    app.config['TEMP_FOLDER'], f"task_{task_id}")
                extract_archive(input_path, extract_dir)

                sub_dirs = [d for d in os.listdir(extract_dir)
                            if os.path.isdir(os.path.join(extract_dir, d))]
                files = [f for f in os.listdir(extract_dir)
                         if os.path.isfile(os.path.join(extract_dir, f))]
                if len(sub_dirs) == 1 and len(files) == 0:
                    real_input = os.path.join(extract_dir, sub_dirs[0])
                else:
                    real_input = extract_dir

            if not json_file_path or not os.path.exists(json_file_path):
                json_file_path = app.config['DEFAULT_DOMAIN_LOOKUP']

            result_dir = run_report_generator(
                input_dir=real_input,
                json_file=json_file_path,
                output_dir=output_dir,
                script_path=app.config['GENERATE_SCRIPT']
            )

            task.output_dir = result_dir
            task.status = 'COMPLETED'
            task.completed_at = datetime.utcnow()

        except Exception as e:
            task.status = 'FAILED'
            task.error_message = str(e)
        finally:
            db.session.commit()
            # 清理临时文件释放磁盘
            if extract_dir and os.path.exists(extract_dir):
                shutil.rmtree(extract_dir, ignore_errors=True)
            if input_path and os.path.isfile(input_path):
                try:
                    os.remove(input_path)
                except OSError:
                    pass


# ===================== 页面路由 =====================

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/tasks')
def tasks_list():
    return render_template('tasks.html')


@app.route('/task/<task_id>')
def task_detail(task_id):
    task = AnalysisTask.query.get(task_id)
    if not task:
        abort(404)
    return render_template('task_detail.html', task=task)


# ===================== 批量任务 API =====================

@app.route('/api/batch_tasks', methods=['POST'])
def create_batch_tasks():
    task_name_prefix = request.form.get('task_name_prefix', '批量任务')
    uploaded_files = request.files.getlist('input_files')
    json_file_path = None

    json_file = request.files.get('json_file')
    if json_file and json_file.filename.endswith('.json'):
        fn = secure_filename(json_file.filename)
        json_file_path = os.path.join(
            app.config['UPLOAD_FOLDER'], f"{uuid.uuid4()}_{fn}")
        json_file.save(json_file_path)
    else:
        default_json = app.config['DEFAULT_DOMAIN_LOOKUP']
        if os.path.exists(default_json):
            json_file_path = default_json

    task_ids = []
    task_names = []

    for uploaded_file in uploaded_files:
        if not uploaded_file or uploaded_file.filename == '':
            continue
        if not allowed_file(uploaded_file.filename, app.config['ALLOWED_EXTENSIONS']):
            continue

        filename = secure_filename(uploaded_file.filename)
        temp_id = str(uuid.uuid4())
        saved_path = os.path.join(
            app.config['UPLOAD_FOLDER'], f"{temp_id}_{filename}")
        uploaded_file.save(saved_path)

        task_name = f"{task_name_prefix} - {filename}"
        task_id = str(uuid.uuid4())
        output_dir = os.path.join(app.config['REPORTS_DIR'], f"task_{task_id}")

        task = AnalysisTask(
            id=task_id,
            task_name=task_name,
            task_prefix=task_name_prefix,
            input_dir=saved_path,
            json_file=json_file_path,
            output_dir=output_dir,
            status='PENDING'
        )
        db.session.add(task)
        task_ids.append(task_id)
        task_names.append(task_name)

    db.session.commit()

    # 放入队列，一个一个执行
    for tid in task_ids:
        t = AnalysisTask.query.get(tid)
        task_queue.put((tid, t.input_dir, t.json_file, t.output_dir))

    return jsonify({
        'task_ids': task_ids,
        'task_names': task_names,
        'count': len(task_ids),
        'queue_size': task_queue.qsize()
    }), 202


# ===================== 任务查询 API =====================

@app.route('/api/tasks/<task_id>', methods=['GET'])
def get_task(task_id):
    task = AnalysisTask.query.get(task_id)
    if not task:
        return jsonify({'error': 'Not found'}), 404
    return jsonify(task.to_dict())


# @app.route('/api/tasks', methods=['GET'])
# def list_tasks():
#     page = request.args.get('page', 1, type=int)
#     per_page = request.args.get('per_page', 20, type=int)
#     pagination = AnalysisTask.query.order_by(
#         AnalysisTask.created_at.desc()
#     ).paginate(page=page, per_page=per_page)
#     return jsonify({
#         'tasks': [t.to_dict() for t in pagination.items],
#         'total': pagination.total
#     })



@app.route('/api/tasks', methods=['GET'])
def list_tasks():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    status = request.args.get('status', '', type=str).strip()
    prefix = request.args.get('prefix', '', type=str).strip()

    query = AnalysisTask.query

    if status:
        query = query.filter(AnalysisTask.status == status)
    if prefix:
        query = query.filter(AnalysisTask.task_prefix == prefix)

    total = query.count()
    pages = max(1, math.ceil(total / per_page))
    if page > pages:
        page = pages
    if page < 1:
        page = 1

    tasks = query.order_by(
        AnalysisTask.created_at.desc()
    ).offset((page - 1) * per_page).limit(per_page).all()

    # 查询所有不重复的前缀，供前端下拉框使用
    all_prefixes = db.session.query(
        AnalysisTask.task_prefix
    ).filter(
        AnalysisTask.task_prefix != '',
        AnalysisTask.task_prefix.isnot(None)
    ).distinct().order_by(AnalysisTask.task_prefix).all()

    return jsonify({
        'tasks': [t.to_dict() for t in tasks],
        'total': total,
        'page': page,
        'pages': pages,
        'per_page': per_page,
        'has_prev': page > 1,
        'has_next': page < pages,
        'prefixes': [p[0] for p in all_prefixes],
    })


@app.route('/api/tasks/<task_id>', methods=['DELETE'])
def delete_task(task_id):
    task = AnalysisTask.query.get(task_id)
    if not task:
        return jsonify({'error': 'Not found'}), 404

    if task.output_dir and os.path.exists(task.output_dir):
        shutil.rmtree(task.output_dir)
    if task.input_dir and os.path.exists(task.input_dir):
        if os.path.isfile(task.input_dir):
            os.remove(task.input_dir)

    db.session.delete(task)
    db.session.commit()
    return jsonify({'success': True})


# ===================== 报告文件服务 =====================

@app.route('/reports/<task_id>/<path:filename>')
def serve_report(task_id, filename):
    task = AnalysisTask.query.get(task_id)
    if not task or not task.output_dir or task.status != 'COMPLETED':
        abort(404)

    base_dir = os.path.realpath(task.output_dir)
    target_path = os.path.realpath(os.path.join(base_dir, filename))

    if not os.path.exists(target_path):
        subdirs = [d for d in os.listdir(base_dir)
                    if os.path.isdir(os.path.join(base_dir, d))]
        for sd in subdirs:
            potential = os.path.realpath(os.path.join(base_dir, sd, filename))
            if os.path.exists(potential):
                return send_from_directory(os.path.join(base_dir, sd), filename)

    if not target_path.startswith(base_dir):
        abort(403)

    if not os.path.isfile(target_path):
        if filename in ['', 'index.html']:
            for root, dirs, files in os.walk(base_dir):
                for f in files:
                    if f.endswith('.html'):
                        return send_from_directory(root, f)
        abort(404)

    return send_from_directory(
        os.path.dirname(target_path), os.path.basename(target_path))


if __name__ == '__main__':
    # use_reloader=False 关键！防止文件写入触发 Flask 重启
    app.run(debug=True, host='0.0.0.0', port=5000,
            threaded=True, use_reloader=False)