#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse
import os
import re

import pandas as pd
from bs4 import BeautifulSoup

MEMORY_COLS = ["stack", "heap", "bss", "lib", "shm", "binary", "anon", "reserved"]


def parse_size_to_mb(s: str):
    """Parse sizes like '1677M', '252M', '1234K', '1.5G' to MB (float)."""
    if s is None:
        return None
    s = s.strip()
    m = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*([KkMmGg])?", s)
    if not m:
        return None
    val = float(m.group(1))
    unit = m.group(2)
    if not unit:
        # assume MB if no suffix? but safer: treat as MB
        return val
    unit = unit.upper()
    if unit == "K":
        return val / 1024.0
    if unit == "M":
        return val
    if unit == "G":
        return val * 1024.0
    return val


def extract_top_memory(top_txt_path):
    """
    Scan top text and return the first occurrence of Memory line:
      e.g. "Memory: 1677M total, 252M avail, page size 4K"
    returns dict {total_mb, avail_mb, page_size_kb (int or None)}
    """
    total_mb = None
    avail_mb = None
    page_kb = None
    with open(top_txt_path, encoding="utf-8", errors="ignore") as f:
        for line in f:
            if "Memory:" in line:
                m_total = re.search(r"([0-9]+(?:\.[0-9]+)?\s*[KkMmGg])\s*total", line)
                m_avail = re.search(r"([0-9]+(?:\.[0-9]+)?\s*[KkMmGg])\s*avail", line)
                m_page = re.search(r"page size\s*([0-9]+)\s*([Kk])", line)
                if m_total:
                    total_mb = parse_size_to_mb(m_total.group(1))
                else:
                    # try fallback numeric without suffix
                    m_total2 = re.search(r"Memory:\s*([0-9]+)", line)
                    if m_total2:
                        total_mb = float(m_total2.group(1))
                if m_avail:
                    avail_mb = parse_size_to_mb(m_avail.group(1))
                if m_page:
                    page_kb = int(m_page.group(1))
                # break on first found
                if total_mb is not None:
                    break
    if total_mb is None:
        raise ValueError(f"Could not parse total memory from {top_txt_path}")
    if avail_mb is None:
        # if no avail found, set 0 to be safe
        avail_mb = 0.0
    return {"total_mb": float(total_mb), "avail_mb": float(avail_mb), "page_kb": page_kb}


def read_pmap_pivot(report_dir, processed_xlsx):
    """
    Try to read domain_pivot.xlsx in report_dir first (produced by pmap plot script).
    If not exist, read processed_xlsx and compute total by summing MEMORY_COLS across rows.
    Returns pmap_total_mb (float).
    """
    pivot_path = os.path.join(report_dir, "domain_pivot.xlsx")
    if os.path.exists(pivot_path):
        try:
            xl = pd.read_excel(pivot_path, sheet_name=0, index_col=0)
            # Try Sum(KB) column first (some variants)
            if "Sum(KB)" in xl.columns:
                val_kb = xl.loc["Grand Total", "Sum(KB)"] if "Grand Total" in xl.index else xl["Sum(KB)"].sum()
                return float(val_kb) / 1024.0
            # else sum across MEMORY_COLS for Grand Total row
            if "Grand Total" in xl.index:
                row = xl.loc["Grand Total"]
                # sum numeric values (assume KB)
                total_kb = 0.0
                for c in row.index:
                    try:
                        total_kb += float(row[c])
                    except Exception:
                        pass
                # if the values are in KB, convert to MB
                return float(total_kb) / 1024.0
        except Exception as e:
            # fallback
            pass

    # fallback: try processed_xlsx (raw per-process rows)
    if processed_xlsx and os.path.exists(processed_xlsx):
        try:
            xls = pd.ExcelFile(processed_xlsx)
            # pick first sheet that has any of MEMORY_COLS
            for sheet in xls.sheet_names:
                df = pd.read_excel(xls, sheet_name=sheet)
                cols_lower = [c.lower() for c in df.columns]
                # normalize
                df.columns = [c.lower() for c in df.columns]
                # if domain or pid_name present, assume this is the right sheet
                if any(col in df.columns for col in MEMORY_COLS):
                    total_kb = 0.0
                    for c in MEMORY_COLS:
                        if c in df.columns:
                            # ensure numeric
                            total_kb += pd.to_numeric(df[c], errors="coerce").fillna(0).sum()
                    return float(total_kb) / 1024.0
        except Exception:
            pass

    return None


def make_html(report_dir, out_basename, rows):
    html_path = os.path.join(report_dir, out_basename + ".html")
    csv_path = os.path.join(report_dir, out_basename + ".csv")

    # CSV
    import csv

    with open(csv_path, "w", newline="", encoding="utf-8") as cf:
        writer = csv.writer(cf)
        writer.writerow(["Category", "Size(MB)", "Description"])
        for r in rows:
            writer.writerow([r[0], f"{r[1]:.2f}" if isinstance(r[1], (int, float)) else r[1], r[2]])

    # HTML table via BeautifulSoup
    table_html = (
        '<table class="table"><thead><tr><th>Category</th><th>Size (MB)</th><th>Description</th></tr></thead><tbody>'
    )
    for r in rows:
        size_s = f"{r[1]:.2f}" if isinstance(r[1], (int, float)) else str(r[1])
        table_html += f"<tr><td>{r[0]}</td><td style='text-align:right'>{size_s}</td><td>{r[2]}</td></tr>"
    table_html += "</tbody></table>"

    style = """
    <style>
    body {font-family: Arial, sans-serif; margin: 20px;}
    h2 {background-color:#2b5797;color:white;padding:8px;}
    .table {border-collapse: collapse; width: 100%;}
    .table th, .table td {border: 1px solid #ddd; padding: 8px;}
    .table th {background:#4CAF50;color:white;text-align:left;}
    </style>
    """

    header = f"<html><head><meta charset='utf-8'><title>Top vs PMAP Comparison</title>{style}</head><body>"
    header += "<h2>TOP Memory Summary & PMAP Comparison</h2>"
    body = table_html
    footer = "</body></html>"

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(header + body + footer)

    return html_path, csv_path


def main():
    parser = argparse.ArgumentParser(description="Analyze top txt and compare with pmap results")
    parser.add_argument("-t", "--top", required=True, help="Top output text file")
    parser.add_argument("-p", "--processed", required=True, help="Processed xlsx (from pmap_postProcess.py)")
    parser.add_argument("-o", "--output", required=True, help="Report directory (pmap_report)")
    parser.add_argument(
        "-r", "--reserved", type=float, default=94.0, help="Reserved memory not detected by pmap (MB). Default 94 MB"
    )
    args = parser.parse_args()

    top_txt = args.top
    processed = args.processed
    report_dir = args.output
    reserved_mb = float(args.reserved)

    os.makedirs(report_dir, exist_ok=True)

    mem = extract_top_memory(top_txt)
    total_mb = mem["total_mb"]
    avail_mb = mem["avail_mb"]
    used_mb = total_mb - avail_mb

    # read pmap-derived total (MB)
    pmap_total_mb = read_pmap_pivot(report_dir, processed)
    if pmap_total_mb is None:
        # if not found, we still proceed with zeros
        pmap_total_mb = 0.0

    kernel_mb = used_mb - pmap_total_mb - reserved_mb
    # ensure not negative
    if kernel_mb < 0:
        kernel_mb = 0.0

    rows = [
        ("total", total_mb, "total memory measured by command 'top'"),
        ("available", avail_mb, "avail memory measured by command 'top'"),
        ("used", used_mb, "total - available"),
        ("used memory by top", used_mb, "from top parsed result"),
        ("used memory detected by pmap", pmap_total_mb, "sum from pmap results (MB)"),
        ("reserved memory not detected by pmap", reserved_mb, "fixed reserved length (MB)"),
        ("kernel memory usage", kernel_mb, "= used - pmap - reserved"),
    ]

    html_path, csv_path = make_html(report_dir, "99_Top_Pmap_Comparison", rows)
    print("Top analysis written:", html_path)
    print("CSV written:", csv_path)
    print("")
    for r in rows:
        print(f"{r[0]:35s} {r[1]:10.2f}  {r[2]}")

    return 0


if __name__ == "__main__":
    main()
