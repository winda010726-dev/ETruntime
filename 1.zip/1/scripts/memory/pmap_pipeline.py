# # # # #!/usr/bin/env python3
# # # # # -*- coding: utf-8 -*-
# # # # import argparse
# # # # import os
# # # # import subprocess
# # # # import sys

# # # # SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
                             
# # # # def find_file_by_ext(directory, ext):
# # # #     for f in os.listdir(directory):
# # # #         if f.endswith(ext):
# # # #             return os.path.join(directory, f)
# # # #     return None


# # # # def main():
# # # #     parser = argparse.ArgumentParser(description="Run full pmap pipeline: tar -> processed.xlsx -> report")
# # # #     parser.add_argument(
# # # #         "-i", "--input", required=True, help="Directory containing collected files (.tar and optional top_trace.txt)"
# # # #     )
# # # #     parser.add_argument("-j", "--json", required=True, help="Domain lookup JSON file")
# # # #     parser.add_argument("-l", "--limits", required=False, help="Smoketest limits JSON file")
# # # #     parser.add_argument("-o", "--output", default="./", help="Output directory (default: current)")
# # # #     args = parser.parse_args()

# # # #     input_dir = os.path.abspath(args.input)
# # # #     output_base = os.path.abspath(args.output)
# # # #     json_path = os.path.abspath(args.json)
# # # #     # 修复：limits参数可选，为空时不加载
# # # #     limits_path = os.path.abspath(args.limits) if args.limits else None


# # # #     tar_path = find_file_by_ext(input_dir, "pmap_collection.tar")
# # # #     if not tar_path:
# # # #         print(f"Error: No .tar file found in {input_dir}")
# # # #         sys.exit(1)
# # # #     # print(f"Found tar file: {tar_path}")

# # # #     top_txt = find_file_by_ext(input_dir, "top_trace.txt")
# # # #     if not top_txt:
# # # #         print("No top_trace.txt found, will skip top comparison")

# # # #     postprocess_script = os.path.join(os.path.dirname(__file__), "pmap_postProcess.py")
# # # #     cmd1 = [sys.executable, postprocess_script, "-i", tar_path, "-j", json_path, "-o", output_base]
# # # #     subprocess.run(cmd1, check=True)

# # # #     # Determine output folder name
# # # #     tar_basename = os.path.basename(tar_path).replace(".tar", "")
# # # #     analyzed_dir = os.path.join(output_base, f"Analyzed_Output_{tar_basename}")

# # # #     # Find the _processed.xlsx file
# # # #     processed_xlsx = None
# # # #     if os.path.exists(analyzed_dir):
# # # #         for f in os.listdir(analyzed_dir):
# # # #             if f.endswith("_processed.xlsx"):
# # # #                 processed_xlsx = os.path.join(analyzed_dir, f)
# # # #                 break

# # # #     if not processed_xlsx:
# # # #         print("Error: Cannot find processed Excel (_processed.xlsx). Check Step 1 output.")
# # # #         sys.exit(1)

# # # #     ion_txt = find_file_by_ext(input_dir, "ion_usage.txt")
# # # #     if not ion_txt:
# # # #         print("No ion_usage.txt found, will skip ION analysis")

# # # #     asinfo_txt = find_file_by_ext(input_dir, "syspage_asinfo.txt")
# # # #     if not asinfo_txt:
# # # #         print("No syspage_asinfo.txt found, will skip ASINFO section")

# # # #     plot_script = os.path.join(os.path.dirname(__file__), "pmap_postprocess_plot.py")
# # # #     report_dir = os.path.join(analyzed_dir, "pmap_report")
# # # #     os.makedirs(report_dir, exist_ok=True)

# # # #     cmd2 = [sys.executable, plot_script, "-i", processed_xlsx, "-o", report_dir, "-l", limits_path]

# # # #     if top_txt:
# # # #         cmd2 += ["-t", top_txt]
# # # #     if ion_txt:
# # # #         cmd2 += ["--ion", ion_txt]
# # # #     if asinfo_txt:
# # # #         cmd2 += ["--asinfo", asinfo_txt]

# # # #     subprocess.run(cmd2, check=True)

# # # #     default_json_name = "pmaps_report_default.json"
# # # #     target_json_path = os.path.join(analyzed_dir, default_json_name)

# # # #     if os.path.exists(target_json_path):
# # # #         print(f"Cleaning up existing JSON report to avoid conflicts: {target_json_path}")
# # # #         try:
# # # #             os.remove(target_json_path)
# # # #         except OSError as e:
# # # #             print(f"Warning: Failed to remove old JSON report: {e}")

# # # #     extract_script = os.path.join(os.path.dirname(__file__), "pmap_autoProcess.py")
# # # #     cmd_extract = [
# # # #         sys.executable,
# # # #         extract_script,
# # # #         "-i",
# # # #         input_dir,
# # # #         "-u",
# # # #         "NA",
# # # #         "-o",
# # # #         analyzed_dir,
# # # #         "-l",
# # # #         limits_path,
# # # #         "--skip-postprocess",
# # # #     ]
# # # #     subprocess.run(cmd_extract, check=True)


# # # # if __name__ == "__main__":
# # # #     main()
# # # #!/usr/bin/env python3
# # # # -*- coding: utf-8 -*-
# # # import argparse
# # # import os
# # # import subprocess
# # # import sys

# # # # 🔥 固定：当前脚本的目录（相对路径核心）
# # # SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
# # # # 🔥 固定：limits 文件相对路径（和本脚本放在同一文件夹）
# # # LIMITS_FILE = os.path.join(SCRIPT_DIR, "smoketest_limits.json")

# # # def find_file_by_ext(directory, ext):
# # #     for f in os.listdir(directory):
# # #         if f.endswith(ext):
# # #             return os.path.join(directory, f)
# # #     return None

# # # def main():
# # #     parser = argparse.ArgumentParser(description="Run full pmap pipeline: tar -> processed.xlsx -> report")
# # #     parser.add_argument(
# # #         "-i", "--input", required=True, help="Directory containing collected files (.tar and optional top_trace.txt)"
# # #     )
# # #     parser.add_argument("-j", "--json", required=True, help="Domain lookup JSON file")
# # #     # ✅ 已删除：-l/--limits 参数（固定文件，不需要传参）
# # #     parser.add_argument("-o", "--output", default="./", help="Output directory (default: current)")
# # #     args = parser.parse_args()

# # #     input_dir = os.path.abspath(args.input)
# # #     output_base = os.path.abspath(args.output)
# # #     json_path = os.path.abspath(args.json)
    
# # #     # ✅ 永久固定 limits 路径，永远不为 None
# # #     limits_path = LIMITS_FILE

# # #     tar_path = find_file_by_ext(input_dir, "pmap_collection.tar")
# # #     if not tar_path:
# # #         print(f"Error: No .tar file found in {input_dir}")
# # #         sys.exit(1)

# # #     top_txt = find_file_by_ext(input_dir, "top_trace.txt")
# # #     ion_txt = find_file_by_ext(input_dir, "ion_usage.txt")
# # #     asinfo_txt = find_file_by_ext(input_dir, "syspage_asinfo.txt")

# # #     postprocess_script = os.path.join(SCRIPT_DIR, "pmap_postProcess.py")
# # #     cmd1 = [sys.executable, postprocess_script, "-i", tar_path, "-j", json_path, "-o", output_base]
# # #     subprocess.run(cmd1, check=True)

# # #     tar_basename = os.path.basename(tar_path).replace(".tar", "")
# # #     analyzed_dir = os.path.join(output_base, f"Analyzed_Output_{tar_basename}")

# # #     processed_xlsx = None
# # #     if os.path.exists(analyzed_dir):
# # #         for f in os.listdir(analyzed_dir):
# # #             if f.endswith("_processed.xlsx"):
# # #                 processed_xlsx = os.path.join(analyzed_dir, f)
# # #                 break

# # #     if not processed_xlsx:
# # #         print("Error: Cannot find processed Excel (_processed.xlsx). Check Step 1 output.")
# # #         sys.exit(1)

# # #     plot_script = os.path.join(SCRIPT_DIR, "pmap_postprocess_plot.py")
# # #     report_dir = os.path.join(analyzed_dir, "pmap_report")
# # #     os.makedirs(report_dir, exist_ok=True)

# # #     cmd2 = [sys.executable, plot_script, "-i", processed_xlsx, "-o", report_dir, "-l", limits_path]
# # #     if top_txt:
# # #         cmd2 += ["-t", top_txt]
# # #     if ion_txt:
# # #         cmd2 += ["--ion", ion_txt]
# # #     if asinfo_txt:
# # #         cmd2 += ["--asinfo", asinfo_txt]
# # #     subprocess.run(cmd2, check=True)

# # #     default_json_name = "pmaps_report_default.json"
# # #     target_json_path = os.path.join(analyzed_dir, default_json_name)
# # #     if os.path.exists(target_json_path):
# # #         try:
# # #             os.remove(target_json_path)
# # #         except OSError:
# # #             pass

# # #     extract_script = os.path.join(SCRIPT_DIR, "pmap_autoProcess.py")
# # #     cmd_extract = [
# # #         sys.executable, extract_script,
# # #         "-i", input_dir, "-u", "NA", "-o", analyzed_dir,
# # #         "-l", limits_path, "--skip-postprocess",
# # #     ]
# # #     subprocess.run(cmd_extract, check=True)

# # # if __name__ == "__main__":
# # #     main()
# # #!/usr/bin/env python3
# # # -*- coding: utf-8 -*-
# # import argparse
# # import os
# # import subprocess
# # import sys

# # # 🔥 固定脚本所在目录
# # SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


# # def find_file_by_ext(directory, ext):
# #     for f in os.listdir(directory):
# #         if f.endswith(ext):
# #             return os.path.join(directory, f)
# #     return None

# # def main():
# #     parser = argparse.ArgumentParser(description="Run full pmap pipeline: tar -> processed.xlsx -> report")
# #     parser.add_argument("-i", "--input", required=True, help="Input data directory")
# #     parser.add_argument("-j", "--json", required=True, help="Domain lookup JSON")
# #     # ✅ 保留 -l 参数，但优先使用固定的正确 limits 文件
# #     parser.add_argument("-l", "--limits", help="Smoketest limits JSON (optional, auto use built-in)")
# #     parser.add_argument("-o", "--output", default="./", help="Output directory")
# #     args = parser.parse_args()

# #     input_dir = os.path.abspath(args.input)
# #     output_base = os.path.abspath(args.output)
# #     json_path = os.path.abspath(args.json)

# #     # 只保留这一行！完全信任外部传入的 -l 参数！
# #     limits_path = os.path.abspath(args.limits)


# #     # 确保文件存在
# #     if not os.path.exists(limits_path):
# #         print(f"ERROR: limits.json not found at {limits_path}")
# #         sys.exit(1)

# #     # 找到数据文件
# #     tar_path = find_file_by_ext(input_dir, "pmap_collection.tar")
# #     if not tar_path:
# #         print(f"Error: No pmap_collection.tar in {input_dir}")
# #         sys.exit(1)

# #     top_txt = find_file_by_ext(input_dir, "top_trace.txt")
# #     ion_txt = find_file_by_ext(input_dir, "ion_usage.txt")
# #     asinfo_txt = find_file_by_ext(input_dir, "syspage_asinfo.txt")

# #     # ====================== 步骤1：解析 tar ======================
# #     postprocess_script = os.path.join(SCRIPT_DIR, "pmap_postProcess.py")
# #     cmd1 = [
# #         sys.executable, postprocess_script,
# #         "-i", tar_path,
# #         "-j", json_path,
# #         "-o", output_base
# #     ]
# #     subprocess.run(cmd1, check=True)

# #     # 找到解析后的 Excel
# #     tar_basename = os.path.basename(tar_path).replace(".tar", "")
# #     analyzed_dir = os.path.join(output_base, f"Analyzed_Output_{tar_basename}")
# #     processed_xlsx = None
# #     if os.path.exists(analyzed_dir):
# #         for f in os.listdir(analyzed_dir):
# #             if f.endswith("_processed.xlsx"):
# #                 processed_xlsx = os.path.join(analyzed_dir, f)
# #                 break

# #     if not processed_xlsx:
# #         print("Error: _processed.xlsx not generated!")
# #         sys.exit(1)

# #     # ====================== 步骤2：绘图报告 ======================
# #     plot_script = os.path.join(SCRIPT_DIR, "pmap_postprocess_plot.py")
# #     report_dir = os.path.join(analyzed_dir, "pmap_report")
# #     os.makedirs(report_dir, exist_ok=True)

# #     cmd2 = [
# #         sys.executable, plot_script,
# #         "-i", processed_xlsx,
# #         "-o", report_dir,
# #         "-l", limits_path  # ✅ 必传！
# #     ]
# #     if top_txt:
# #         cmd2 += ["-t", top_txt]
# #     if ion_txt:
# #         cmd2 += ["--ion", ion_txt]
# #     if asinfo_txt:
# #         cmd2 += ["--asinfo", asinfo_txt]

# #     subprocess.run(cmd2, check=True)

# #     # ====================== 步骤3：提取JSON ======================
# #     default_json = os.path.join(analyzed_dir, "pmaps_report_default.json")
# #     if os.path.exists(default_json):
# #         try:
# #             os.remove(default_json)
# #         except:
# #             pass

# #     extract_script = os.path.join(SCRIPT_DIR, "pmap_autoProcess.py")
# #     cmd_extract = [
# #         sys.executable, extract_script,
# #         "-i", input_dir,
# #         "-u", "NA",
# #         "-o", analyzed_dir,
# #         "-l", limits_path,  # ✅ 必传！
# #         "--skip-postprocess"
# #     ]
# #     subprocess.run(cmd_extract, check=True)

# # if __name__ == "__main__":
# #     main()

# #!/usr/bin/env python3
# # -*- coding: utf-8 -*-
# import argparse
# import os
# import subprocess
# import sys
# import platform  # 导入用于调试的模块

# # 🔥 固定脚本所在目录
# SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


# def find_file_by_ext(directory, ext):
#     for f in os.listdir(directory):
#         if f.endswith(ext):
#             return os.path.join(directory, f)
#     return None

# def main():
#     # ====================== [DEBUG START] 环境上下文检查 ======================
#     print("\n" + "="*20 + " ENVIRONMENT DEBUG " + "="*20)
#     print(f"DEBUG: Python Version: {sys.version}")
#     print(f"DEBUG: Default Encoding: {sys.getdefaultencoding()}")
#     print(f"DEBUG: File System Encoding: {sys.getfilesystemencoding()}")
#     print(f"DEBUG: Current Work Dir (CWD): {os.getcwd()}")
#     print(f"DEBUG: Script Dir (SCRIPT_DIR): {SCRIPT_DIR}")
#     print(f"DEBUG: Raw sys.argv: {sys.argv}")
#     print("="*59 + "\n")
#     # ====================== [DEBUG END] ======================

#     parser = argparse.ArgumentParser(description="Run full pmap pipeline: tar -> processed.xlsx -> report")
#     parser.add_argument("-i", "--input", required=True, help="Input data directory")
#     parser.add_argument("-j", "--json", required=True, help="Domain lookup JSON")
#     parser.add_argument("-l", "--limits", help="Smoketest limits JSON")
#     parser.add_argument("-o", "--output", default="./", help="Output directory")
#     args = parser.parse_args()

#     input_dir = os.path.abspath(args.input)
#     output_base = os.path.abspath(args.output)
#     json_path = os.path.abspath(args.json)
    
#     # 确保 limits 参数被正确处理
#     if args.limits:
#         limits_path = os.path.abspath(args.limits)
#     else:
#         # 如果没传 -l，尝试在脚本同级目录找默认的
#         limits_path = os.path.join(SCRIPT_DIR, "smoketest_limits.json")

#     print(f"DEBUG: Final Limits Path: {limits_path}")

#     # 确保文件存在
#     if not os.path.exists(limits_path):
#         print(f"ERROR: limits.json not found at {limits_path}")
#         sys.exit(1)

#     # 找到数据文件
#     tar_path = find_file_by_ext(input_dir, "pmap_collection.tar")
#     if not tar_path:
#         print(f"Error: No pmap_collection.tar in {input_dir}")
#         sys.exit(1)

#     top_txt = find_file_by_ext(input_dir, "top_trace.txt")
#     ion_txt = find_file_by_ext(input_dir, "ion_usage.txt")
#     asinfo_txt = find_file_by_ext(input_dir, "syspage_asinfo.txt")

#     # ====================== 步骤1：解析 tar ======================
#     postprocess_script = os.path.join(SCRIPT_DIR, "pmap_postProcess.py")
#     cmd1 = [
#         sys.executable, postprocess_script,
#         "-i", tar_path,
#         "-j", json_path,
#         "-o", output_base
#     ]
#     print(f"DEBUG: Executing Step 1: {' '.join(cmd1)}")
#     subprocess.run(cmd1, check=True)

#     # 找到解析后的 Excel
#     tar_basename = os.path.basename(tar_path).replace(".tar", "")
#     analyzed_dir = os.path.join(output_base, f"Analyzed_Output_{tar_basename}")
#     processed_xlsx = None
#     if os.path.exists(analyzed_dir):
#         for f in os.listdir(analyzed_dir):
#             if f.endswith("_processed.xlsx"):
#                 processed_xlsx = os.path.join(analyzed_dir, f)
#                 break

#     if not processed_xlsx:
#         print(f"Error: _processed.xlsx not found in {analyzed_dir}!")
#         sys.exit(1)

#     # ====================== 步骤2：绘图报告 ======================
#     plot_script = os.path.join(SCRIPT_DIR, "pmap_postprocess_plot.py")
#     report_dir = os.path.join(analyzed_dir, "pmap_report")
#     os.makedirs(report_dir, exist_ok=True)

#     cmd2 = [
#         sys.executable, plot_script,
#         "-i", processed_xlsx,
#         "-o", report_dir,
#         "-l", limits_path
#     ]
#     if top_txt: cmd2 += ["-t", top_txt]
#     if ion_txt: cmd2 += ["--ion", ion_txt]
#     if asinfo_txt: cmd2 += ["--asinfo", asinfo_txt]

#     print(f"DEBUG: Executing Step 2: {' '.join(cmd2)}")
#     subprocess.run(cmd2, check=True)

#     # ====================== 步骤3：提取JSON ======================
#     default_json = os.path.join(analyzed_dir, "pmaps_report_default.json")
#     if os.path.exists(default_json):
#         try:
#             os.remove(default_json)
#         except:
#             pass

#     extract_script = os.path.join(SCRIPT_DIR, "pmap_autoProcess.py")
#     cmd_extract = [
#         sys.executable, extract_script,
#         "-i", input_dir,
#         "-u", "NA",
#         "-o", analyzed_dir,
#         "-l", limits_path,
#         "--skip-postprocess"
#     ]
#     print(f"DEBUG: Executing Step 3: {' '.join(cmd_extract)}")
#     subprocess.run(cmd_extract, check=True)

# if __name__ == "__main__":
#     main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse
import os
import subprocess
import sys

# 🔥 固定脚本所在目录
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(SCRIPT_DIR)

def find_file_by_ext(directory, ext):
    """根据后缀名在目录中查找文件"""
    if not os.path.exists(directory):
        return None
    for f in os.listdir(directory):
        if f.endswith(ext):
            return os.path.join(directory, f)
    return None

def main():
    # ====================== [环境上下文检查] ======================
    print("\n" + "="*20 + " ENVIRONMENT DEBUG " + "="*20)
    print(f"DEBUG: Python Version: {sys.version}")
    print(f"DEBUG: Current Work Dir (CWD): {os.getcwd()}")
    print(f"DEBUG: Script Dir (SCRIPT_DIR): {SCRIPT_DIR}")
    print("="*59 + "\n")

    parser = argparse.ArgumentParser(description="Run full pmap pipeline: tar -> processed.xlsx -> report")
    parser.add_argument("-i", "--input", required=True, help="Input data directory")
    parser.add_argument("-j", "--json", required=True, help="Domain lookup JSON")
    parser.add_argument("-l", "--limits", help="Smoketest limits JSON")
    parser.add_argument("-o", "--output", default="./", help="Output directory")
    args = parser.parse_args()

    input_dir = os.path.abspath(args.input)
    output_base = os.path.abspath(args.output)
    json_path = os.path.abspath(args.json)
    
    # 确保 limits 参数被正确处理
    if args.limits:
        limits_path = os.path.abspath(args.limits)
    else:
        # 如果没传 -l，默认在脚本同级目录找
        limits_path = os.path.join(SCRIPT_DIR, "smoketest_limits.json")

    # 检查核心文件是否存在
    if not os.path.exists(limits_path):
        print(f"ERROR: limits.json not found at {limits_path}")
        sys.exit(1)
    if not os.path.exists(json_path):
        print(f"ERROR: domain_lookup.json not found at {json_path}")
        sys.exit(1)

    # 找到原始数据文件
    tar_path = find_file_by_ext(input_dir, "pmap_collection.tar")
    if not tar_path:
        print(f"Error: No pmap_collection.tar in {input_dir}")
        sys.exit(1)

    top_txt = find_file_by_ext(input_dir, "top_trace.txt")
    ion_txt = find_file_by_ext(input_dir, "ion_usage.txt")
    asinfo_txt = find_file_by_ext(input_dir, "syspage_asinfo.txt")

    # ====================== 步骤1：解析 tar ======================
    postprocess_script = os.path.join(SCRIPT_DIR, "pmap_postProcess.py")
    cmd1 = [
        sys.executable, postprocess_script,
        "-i", tar_path,
        "-j", json_path,
        "-o", output_base
    ]
    print(f"DEBUG: Executing Step 1 (Parsing tar): {' '.join(cmd1)}")
    subprocess.run(cmd1, check=True)

    # 确定解析后的 Excel 路径
    tar_basename = os.path.basename(tar_path).replace(".tar", "")
    analyzed_dir = os.path.join(output_base, f"Analyzed_Output_{tar_basename}")
    
    processed_xlsx = None
    if os.path.exists(analyzed_dir):
        for f in os.listdir(analyzed_dir):
            if f.endswith("_processed.xlsx"):
                processed_xlsx = os.path.join(analyzed_dir, f)
                break

    if not processed_xlsx:
        print(f"Error: _processed.xlsx not found in {analyzed_dir}! Step 1 failed to generate Excel.")
        sys.exit(1)

    # ====================== 步骤2：绘图报告 ======================
    plot_script = os.path.join(SCRIPT_DIR, "pmap_postprocess_plot.py")
    report_dir = os.path.join(analyzed_dir, "pmap_report")
    os.makedirs(report_dir, exist_ok=True)

    cmd2 = [
        sys.executable, plot_script,
        "-i", processed_xlsx,
        "-o", report_dir,
        "-l", limits_path
    ]
    if top_txt: cmd2 += ["-t", top_txt]
    if ion_txt: cmd2 += ["--ion", ion_txt]
    if asinfo_txt: cmd2 += ["--asinfo", asinfo_txt]

    print(f"DEBUG: Executing Step 2 (Plotting): {' '.join(cmd2)}")
    subprocess.run(cmd2, check=True)

    # ====================== 步骤3：提取JSON (核心修复点) ======================
    # 💡 修复：在执行 Step 3 前，清理 Analyzed 目录下所有旧的 JSON，防止 "File already exists"
    if os.path.exists(analyzed_dir):
        print(f"DEBUG: Cleaning up existing JSON files in {analyzed_dir} to avoid conflicts...")
        for file in os.listdir(analyzed_dir):
            if file.endswith(".json"):
                file_path = os.path.join(analyzed_dir, file)
                try:
                    os.remove(file_path)
                    print(f"  Removed: {file}")
                except Exception as e:
                    print(f"  Warning: Could not remove {file}: {e}")

    extract_script = os.path.join(SCRIPT_DIR, "pmap_autoProcess.py")
    cmd_extract = [
        sys.executable, extract_script,
        "-i", input_dir,
        "-u", "NA",
        "-o", analyzed_dir,
        "-l", limits_path,
        "--skip-postprocess"
    ]
    print(f"DEBUG: Executing Step 3 (Extracting Final JSON): {' '.join(cmd_extract)}")
    subprocess.run(cmd_extract, check=True)

    print("\n" + "="*20 + " ANALYSIS COMPLETED SUCCESSFULLY " + "="*20 + "\n")

if __name__ == "__main__":
    main()