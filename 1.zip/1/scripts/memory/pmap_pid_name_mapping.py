#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import csv
import glob
import os
import re
import shutil
import tarfile
from pathlib import Path
import tempfile


def extract_tar_file(tar_path, extract_dir):
    """Extract tar file"""
    try:
        with tarfile.open(tar_path, "r") as tar:
            tar.extractall(extract_dir)
        # print(f"Successfully extracted to: {extract_dir}")
        return True
    except Exception as e:
        print(f"Extraction failed: {e}")
        return False


def parse_process_names(csv_file):
    """Parse process names CSV file"""
    process_map = {}
    try:
        with open(csv_file, "r", encoding="utf-8", errors="ignore") as f:
            # Read all lines and parse manually
            lines = f.readlines()

            # Skip the first two lines (header and separator)
            for line in lines[2:]:
                line = line.strip()
                if not line:
                    continue

                # Manually parse the line to handle spaces
                parts = line.split('"')
                if len(parts) >= 3:
                    # First part is PID
                    pid_part = parts[0].strip()
                    pid = pid_part.split()[0] if pid_part else ""

                    # Second part is process_name
                    process_name = parts[1].strip() if len(parts) > 1 else ""

                    # Third part is cmdline_name
                    cmdline_name = parts[3].strip() if len(parts) > 3 else ""

                    if pid and pid.isdigit():
                        # Prefer cmdline name, if not available use process_name
                        # If neither is available, use PID directly later
                        preferred_name = cmdline_name if cmdline_name else process_name

                        if preferred_name:
                            # Clean invalid characters from filename
                            safe_name = re.sub(r'[<>:"/\\|?*]', "_", preferred_name)
                            safe_name = safe_name.replace(" ", "_")
                            safe_name = safe_name.strip("._")
                            process_map[pid] = safe_name

        print(f"Successfully parsed {len(process_map)} process information")
        return process_map

    except Exception as e:
        print(f"Failed to parse process names file: {e}")
        return {}


def rename_pmap_files(extract_dir, process_map):
    """Rename pmap files"""
    renamed_count = 0
    error_count = 0
    no_name_files = []  # Store list of files without process names

    # Find all pmap txt files
    pmap_files = glob.glob(os.path.join(extract_dir, "pid_*_pmap.txt"))
    # print(f"Found {len(pmap_files)} pmap files")

    for pmap_file in pmap_files:
        try:
            # Extract PID from filename
            filename = os.path.basename(pmap_file)
            match = re.match(r"pid_(\d+)_pmap\.txt", filename)

            if not match:
                print(f"Invalid filename format: {filename}")
                error_count += 1
                continue

            pid = match.group(1)

            # Get process name, use PID directly if not found
            if pid in process_map:
                process_name = process_map[pid]
            else:
                process_name = pid
                no_name_files.append(pid)  # Record PID without process name

            # Build new filename (remove pid_ prefix)
            new_filename = f"{pid}_{process_name}.txt"
            new_filepath = os.path.join(extract_dir, new_filename)

            # Rename file
            os.rename(pmap_file, new_filepath)
            renamed_count += 1

            # if renamed_count % 50 == 0:
            #     print(f"Renamed {renamed_count} files...")

        except Exception as e:
            print(f"Error renaming file {filename}: {e}")
            error_count += 1

    return renamed_count, error_count, no_name_files


def main():
    # Set command line arguments
    parser = argparse.ArgumentParser(description="Rename pmap files tool")
    parser.add_argument("-i", "--input", required=True, help="Input tar file path")
    parser.add_argument(
        "-o", "--output", default="pid_renamed_results", help="Output directory path (default: pid_renamed_results)"
    )
    args = parser.parse_args()

    tar_file_path = args.input
    output_dir = args.output
    extract_dir = tempfile.mkdtemp(prefix="pmap_extract_")
    # extract_dir = "extracted_data_temp"

    # Create output directory
    os.makedirs(output_dir, exist_ok=True)

    # Check if file exists
    if not os.path.exists(tar_file_path):
        print(f"Error: File {tar_file_path} does not exist")
        return

    # Clean up temporary directory (if exists)
    if os.path.exists(extract_dir):
        shutil.rmtree(extract_dir)

    # Create temporary directory
    os.makedirs(extract_dir, exist_ok=True)

    # Extract file
    if not extract_tar_file(tar_file_path, extract_dir):
        # Clean up temporary directory
        shutil.rmtree(extract_dir)
        return

    # Parse process names
    csv_file = os.path.join(extract_dir, "process_names.csv")
    if not os.path.exists(csv_file):
        print("Error: Cannot find process_names.csv file")
        # Clean up temporary directory
        shutil.rmtree(extract_dir)
        return

    process_map = parse_process_names(csv_file)

    # Rename files
    renamed_count, error_count, no_name_files = rename_pmap_files(extract_dir, process_map)

    print(f"\n=== Renaming Results ===")
    print(f"Successfully renamed: {renamed_count} files")
    print(f"Failed: {error_count} files")

    # Print files without process names
    if no_name_files:
        print(f"\n=== Files without process names ({len(no_name_files)} files) ===")
        # Display 10 PIDs per line
        for i in range(0, len(no_name_files), 10):
            print(", ".join(no_name_files[i : i + 10]))

        # Save to file
        no_name_file = os.path.join(output_dir, "no_process_name_pids.txt")
        with open(no_name_file, "w", encoding="utf-8") as f:
            f.write("PIDs without process names:\n")
            for pid in no_name_files:
                f.write(f"{pid}\n")
        # print(f"\nPIDs without process names saved to: {no_name_file}")
    else:
        print("\nAll files found corresponding process names")

    # Move renamed files to output directory
    renamed_files = glob.glob(os.path.join(extract_dir, "*.txt"))
    renamed_files = [f for f in renamed_files if "process_names" not in os.path.basename(f)]

    moved_count = 0
    for file_path in renamed_files:
        try:
            filename = os.path.basename(file_path)
            shutil.move(file_path, os.path.join(output_dir, filename))
            moved_count += 1
        except Exception as e:
            print(f"Error moving file {filename}: {e}")

    # print(f"Moved {moved_count} files to: {output_dir}")

    # Automatically clean up temporary files
    shutil.rmtree(extract_dir)

    # print(f"\nProcessing completed! Renamed files saved in: {output_dir}")


if __name__ == "__main__":
    main()
