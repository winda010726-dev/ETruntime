#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse
import json
import os
from datetime import datetime

import numpy as np
import pandas as pd


def get_ci_metadata(artifact_url_arg):
    """Collects build metadata from pipeline environment variables."""
    software_version = os.getenv("ASW_FILENAME") or "NA"
    commit_id = os.getenv("ASW_COMMIT_ID") or "NA"
    branch_name = os.getenv("BRANCH_NAME") or "NA"
    build_trigger = os.getenv("WORKFLOW_NAME") or "NA"
    environment_type = os.getenv("ENVIRONMENT_TYPE") or "NA"
    release_url = os.getenv("BINARY_ARTIFACTORY_PATH") or artifact_url_arg or "NA"
    build_datetime = os.getenv("ASW_BUILD_DATETIME") or datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")

    tags = []
    for env_key in ["AOS_VERSION", "BUILD_CONFIG"]:
        val = os.getenv(env_key)
        if val:
            tags.append(val)

    return {
        "softwareVersion": software_version,
        "buildDateTime": build_datetime,
        "commitId": commit_id,
        "branchName": branch_name,
        "buildTrigger": build_trigger,
        "environmentType": environment_type,
        "tags": tags,
        "releaseArtifactsUrl": release_url,
    }


def convert_numpy_types(obj):
    """Convert NumPy data types to native Python types for JSON serializability."""
    if isinstance(obj, (np.integer, int)):
        return int(obj)
    elif isinstance(obj, (np.floating, float)):
        return float(obj)
    elif isinstance(obj, dict):
        return {k: convert_numpy_types(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_numpy_types(v) for v in obj]
    return obj


def process_excel_to_json(input_file, artifact_url, domain_config_path=None):
    """Parse memory statistics from Excel and generate JSON reports with budget and domain breakdowns."""
    df = pd.read_excel(input_file, sheet_name="Sheet1")
    Categories = ["stack", "heap", "bss", "lib", "shm", "binary", "anon", "reserved"]

    metadata = get_ci_metadata(artifact_url)

    budgets = {}
    if domain_config_path and os.path.exists(domain_config_path):
        try:
            with open(domain_config_path, "r") as f:
                budgets = json.load(f).get("smoketest_limits", {}).get("common_domain_limits_mb", {})
        except:
            pass

    total_ion_kb = 0
    ion_json_path = os.path.join(os.path.dirname(input_file), "ion_memory.json")
    if os.path.exists(ion_json_path):
        try:
            with open(ion_json_path, "r") as f:
                total_ion_kb = sum(h.get("heap_total (KB)", 0) for h in json.load(f))
        except:
            pass

    detailed_details = {}
    summary_breakdown = {}

    for domain in [d for d in df["domain"].unique() if pd.notna(d)]:
        domain_data = df[df["domain"] == domain]
        actual_kb = {cat: int(domain_data[cat].sum()) if cat in domain_data.columns else 0 for cat in Categories}

        detailed_details[domain] = {}
        for cat, val in actual_kb.items():
            if val > 0:
                detailed_details[domain][cat] = {
                    "Total": val,
                    "Processes": {k: int(v) for k, v in domain_data.groupby("pid_name")[cat].sum().items() if v > 0},
                }

        total_kb = sum(actual_kb.values())
        actual_mb = round(total_kb / 1024, 2)
        budget_mb = float(budgets.get(domain, 0.0))
        summary_breakdown[domain] = {
            "Actual_KB": {**actual_kb, "TOTAL": total_kb},
            "Budget_MB": budget_mb,
            "Actual_MB": actual_mb,
            "Diff_MB": round(budget_mb - actual_mb, 2),
        }

    summary_report = {"memory_statistics_dynamic_summary": {**metadata, "Summary": summary_breakdown}}

    detailed_report = {"memory_statistics_dynamic_detailed": {**metadata, "DomainDetails": detailed_details}}

    file_suffix = artifact_url.rsplit("_", 2)[-1].replace(".tar.gz", "") if artifact_url != "NA" else "default"

    with open(f"pmaps_report_{file_suffix}_summary.json", "w") as f:
        json.dump(convert_numpy_types(summary_report), f, indent=4)
    with open(f"pmaps_report_{file_suffix}_detailed.json", "w") as f:
        json.dump(convert_numpy_types(detailed_report), f, indent=4)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--input", required=True)
    parser.add_argument("-u", "--url", required=True)
    parser.add_argument("-l", "--limits", required=False)
    parser.add_argument("-j", "--json", required=False)
    args = parser.parse_args()
    process_excel_to_json(args.input, args.url, args.limits or args.json)
