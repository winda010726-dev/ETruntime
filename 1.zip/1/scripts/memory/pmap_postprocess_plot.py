#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import matplotlib

matplotlib.use("Agg")

import argparse
import json
import os
import re
import subprocess
import sys

import matplotlib.pyplot as plt
import pandas as pd
from bs4 import BeautifulSoup
from matplotlib.ticker import FuncFormatter

MEMORY_COLS = ["stack", "heap", "bss", "lib", "shm", "binary", "anon", "reserved"]


def ensure_outdir(path):
    os.makedirs(path, exist_ok=True)
    return os.path.abspath(path)


def load_processed_excel(path):
    """Load the memory data from Excel and normalize column names to lowercase."""
    try:
        df = pd.read_excel(path, sheet_name="Sheet1")
        df.columns = [c.lower() for c in df.columns]
        return df
    except:
        xls = pd.ExcelFile(path)
        df = pd.read_excel(xls, sheet_name=xls.sheet_names[0])
        df.columns = [c.lower() for c in df.columns]
        return df


def coerce_memory_columns(df):
    """Ensure all memory-related columns are numeric and fill missing values with 0."""
    for col in MEMORY_COLS:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
        else:
            df[col] = 0
    return df


def build_domain_pivot(df):
    """Group memory usage by domain and append a 'Grand Total' row."""
    pivot = df.groupby("domain")[MEMORY_COLS].sum()
    grand = pivot.sum(axis=0).to_frame().T
    grand.index = ["Grand Total"]
    pivot = pd.concat([pivot, grand])
    return pivot


def human_fmt_k(x, pos):
    """Format plot axis labels with thousands separators."""
    if x >= 1000:
        return f"{int(x):,}"
    return f"{int(x)}"


def plot_domain_chart(pivot_df, out_png):
    """Generate a stacked bar chart showing memory types per domain."""
    fig, ax = plt.subplots(figsize=(12, max(4, len(pivot_df) * 0.4)))
    pivot_df_no_total = pivot_df.drop(index=["Grand Total"], errors="ignore")
    pivot_df_no_total[MEMORY_COLS].plot(kind="bar", stacked=True, ax=ax)
    ax.set_title("Memory Usage by Domain (KB)")
    ax.set_ylabel("KB")
    ax.legend(title="Memory Type", bbox_to_anchor=(1.02, 1), loc="upper left")
    ax.yaxis.set_major_formatter(FuncFormatter(human_fmt_k))
    plt.tight_layout()
    fig.savefig(out_png)
    plt.close(fig)


def extend_with_sum(df):
    """Calculate and add 'Sum(KB)' and 'Sum(MB)' columns to the DataFrame."""
    if "Sum(KB)" not in df.columns:
        df["Sum(KB)"] = df.sum(axis=1)
        df["Sum(MB)"] = (df["Sum(KB)"] / 1024).round(2)
    return df


def plot_domain_pie(df_domain, domain_name, out_png, size=4):
    """Create a pie chart showing the memory type breakdown for a specific domain."""
    sums = df_domain[MEMORY_COLS].sum()
    total = sums.sum()
    labels = [f"{col} - {sums[col] / total * 100:.1f}% ({int(sums[col])} KB)" for col in sums.index]

    plt.figure(figsize=(size, size))
    wedges, texts = plt.pie(sums, startangle=90, wedgeprops=dict(width=0.5))
    plt.title(f"{domain_name} Memory")
    plt.legend(wedges, labels, loc="center left", bbox_to_anchor=(1, 0.5), fontsize=8)
    plt.tight_layout()
    plt.savefig(out_png)
    plt.close()


def plot_total_pie(pivot_df, out_png, size=6):
    """Create a pie chart showing the memory distribution across all domains."""
    pivot_no_total = pivot_df.drop(index=["Grand Total"], errors="ignore")
    sums = extend_with_sum(pivot_df)["Sum(KB)"][:-1]
    total = sums.sum()
    labels = [f"{domain} - {sums[domain] / total * 100:.1f}% ({int(sums[domain])} KB)" for domain in sums.index]

    plt.figure(figsize=(size, size))
    wedges, texts = plt.pie(sums, startangle=90, wedgeprops=dict(width=0.5))
    plt.title("Total Memory Usage by Domain")
    plt.legend(wedges, labels, loc="center left", bbox_to_anchor=(1, 0.5), fontsize=10)
    plt.tight_layout()
    plt.savefig(out_png)
    plt.close()


def export_html_table(df, title, out_html, back_link=False):
    """Convert a DataFrame into a styled HTML table file."""
    df = extend_with_sum(df)
    df_to_show = df.copy()
    df_to_show["Sum(MB)"] = df_to_show["Sum(MB)"].map(lambda x: f"{x:.2f}")
    for col in df_to_show.columns:
        if col != "Sum(MB)":
            df_to_show[col] = df_to_show[col].map(lambda x: f"{int(x)}")

    html = df_to_show.to_html(classes="table table-bordered table-striped", escape=False)
    soup = BeautifulSoup(html, "html.parser")

    style = """
    <style>
    body {font-family: Arial, sans-serif; margin: 30px;}
    h2 {background-color: #2b5797; color: white; padding: 10px;}
    table {border-collapse: collapse; width: 100%;}
    th, td {border: 1px solid #dddddd; text-align: right; padding: 8px;}
    tr:nth-child(even) {background-color: #f2f2f2;}
    th {background-color: #4CAF50; color: white;}
    .total {font-weight: bold; background-color: #ffe699;}
    a.back-link {display:block; margin-bottom:10px; font-size:14px;}
    </style>
    """

    back_html = ""
    body_html = f"<html><head>{style}</head><body>{back_html}<h2>{title}</h2>{str(soup)}</body></html>"
    with open(out_html, "w", encoding="utf-8") as f:
        f.write(body_html)


def parse_ion_usage(ion_usage_path, json_path=None):
    """Parse ION heap usage from a text file and generate both HTML and JSON outputs."""
    if not os.path.exists(ion_usage_path):
        return ""

    with open(ion_usage_path, "r", encoding="utf-8") as f:
        lines = [l.rstrip() for l in f]

    ion_sections = []
    current = None

    def push_current():
        if current and "heap_name" in current:
            ion_sections.append(current)

    for line in lines:
        m = re.match(r"\/memory\/ram\/(ion_[a-zA-Z0-9_]+)\s+heap total size\s+(\d+)", line)
        if m:
            push_current()
            raw_bytes = int(m.group(2))
            current = {
                "heap_name": m.group(1),
                "heap_total (KB)": int(raw_bytes / 1024),
                "heap_total (MB)": round(raw_bytes / 1024 / 1024, 2),
                "clients": [],
                "total_alloc": None,
            }
            continue

        if current and line.startswith("/memory/ram/"):
            parts = line.split()
            if len(parts) >= 4:
                client = parts[1]
                size_str = parts[-1]
                if size_str.endswith("MB"):
                    size = float(size_str.replace("MB", ""))
                else:
                    size = 0.0
                current["clients"].append((client, size))
            continue

        if current and "total orphaned" in line:
            continue
        if current and line.strip().startswith("total") and line.strip() != "total orphaned":
            parts = line.split()
            if parts[-1].isdigit():
                current["total_alloc"] = int(parts[-1])
            continue

    push_current()

    if json_path and ion_sections:
        with open(json_path, "w", encoding="utf-8") as jf:
            json.dump(ion_sections, jf, indent=4, ensure_ascii=False)
        print(f"ION JSON generated: {json_path}")

    html = ""
    for sec in ion_sections:
        heap = sec["heap_name"]
        heap_total_mb = sec["heap_total (MB)"]
        total_alloc_mb = (sec["total_alloc"] or 0) / 1024 / 1024

        html += f"""
        <h2>{heap}</h2>
         <table class="table table-bordered table-striped" style="width: auto; max-width: 600px;">
        <thead>
            <tr>
                <th style="text-align:left">Item </th>
                <th style="text-align:right">Size (MB)</th>
            </tr>
        </thead>
        <tbody>
            <tr><td><b>Heap Total Size</b></td><td>{heap_total_mb:.2f}</td></tr>
            <tr><td><b>Total Allocated</b></td><td>{total_alloc_mb:.2f}</td></tr>
        """

        for client, size in sec["clients"]:
            html += f"<tr><td>{client}</td><td>{size:.2f}</td></tr>"

        html += "</tbody></table><br><br>"

    return html


def parse_syspage_asinfo(filepath):
    """Parse the system address information (asinfo) text file into an HTML table."""
    if not os.path.exists(filepath):
        print(f"[DEBUG] ASINFO File NOT FOUND at: {filepath}")
        return ""
    rows = []
    line_count = 0
    match_count = 0

    try:
        with open(filepath, "r", encoding="utf-8") as f:
            for line in f:
                line_count += 1
                stripped_line = line.strip()
                if not stripped_line:
                    continue
                match = re.search(r"^[0-9a-fA-F]+\)\s+([0-9a-fA-F-]+)\s+o:[0-9a-fA-F]+\s+(.+)", stripped_line)

                if match:
                    addr_range = match.group(1)
                    name = match.group(2)
                    rows.append((addr_range, name))
                    match_count += 1
                else:
                    pass
    except Exception as e:
        print(f"[DEBUG] Error reading ASINFO file: {e}")
        return ""

    # print(f"[DEBUG] ASINFO Parsing Finished. Total Lines: {line_count}, Matched Rows: {match_count}")

    if not rows:
        print("[DEBUG] Warning: ASINFO file existed but no valid rows were parsed.")
        return ""

    html = """
    <table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th style="text-align:left">Address Range</th>
            <th style="text-align:left">Name</th>
        </tr>
    </thead>
    <tbody>
    """

    for addr, name in rows:
        html += f"<tr><td style='text-align:left'>{addr}</td><td style='text-align:left'>{name}</td></tr>"

    html += "</tbody></table>"
    return html


def generate_summary_html(
    per_domain_list,
    overview_chart_png,
    total_pie_png,
    out_html,
    grand_total_df=None,
    top_html=None,
    ion_html="",
    asinfo_html="",
    budget_html="",
):
    """Assemble all charts, tables, and sub-reports into a final master HTML report."""

    style = """
    <style>
    body {font-family: Arial, sans-serif; margin: 30px;}
    h1,h2 {background-color: #2b5797; color: white; padding: 10px;}
    table {border-collapse: collapse; width: 100%;}
    th, td {border: 1px solid #dddddd; text-align: right; padding: 8px;}
    tr:nth-child(even) {background-color: #f2f2f2;}
    th {background-color: #4CAF50; color: white;}
    .total {font-weight: bold; background-color: #ffe699;}
    a.back-link {display:block; margin-bottom:10px; font-size:14px;}
    </style>
    """

    with open(out_html, "w", encoding="utf-8") as out:
        out.write(f"<html><head><title>Memory Usage Report</title>{style}</head><body>")

        out.write("<h1>Memory Usage Summary Report</h1>")

        # Contents
        out.write("<h2>Contents</h2><ul>")
        out.write('<li><a href="#overview">01 Overview</a></li>')
        out.write('<li><a href="#perdomain">02 Memory Usage Per Domain</a><ul>')
        for idx, (domain, html_path, pie_png) in enumerate(per_domain_list, start=1):
            num = f"{idx:02d}"
            file_name = os.path.basename(html_path)
            out.write(f'<li><a href="{file_name}">{num} {domain}</a></li>')
        out.write("</ul></li>")
        if ion_html:
            out.write('<li><a href="#ion_usage">03 ION Memory Usage</a></li>')
        if asinfo_html:
            out.write('<li><a href="#asinfo">04 System Address Info</a></li>')
        if budget_html:
            out.write('<li><a href="#budget">05 Budget Comparison</a></li>')
        out.write("</ul><hr>")

        # 01 Overview
        out.write('<h1 id="overview">01 Overview</h1>')
        if os.path.exists(overview_chart_png) or os.path.exists(total_pie_png):
            out.write('<div style="display:flex; align-items:flex-start; gap:20px;">')
            if os.path.exists(overview_chart_png):
                out.write(
                    f'<div style="flex:1;"><img src="{os.path.basename(overview_chart_png)}" alt="Memory Usage by Domain" style="width:100%; height:400px; object-fit:contain;"></div>'
                )
            if os.path.exists(total_pie_png):
                out.write(
                    f'<div style="flex:1;"><img src="{os.path.basename(total_pie_png)}" alt="Total Memory Usage Pie" style="width:100%; height:400px; object-fit:contain;"></div>'
                )
            out.write("</div><br>")

        if grand_total_df is not None:
            df_show = extend_with_sum(grand_total_df).copy()
            df_show["Sum(MB)"] = df_show["Sum(MB)"].map(lambda x: f"{x:.2f}")
            for col in MEMORY_COLS + ["Sum(KB)"]:
                if col in df_show.columns:
                    df_show[col] = df_show[col].map(lambda x: f"{int(x)}")
            html_table = df_show.to_html(classes="table table-bordered table-striped", escape=False)
            soup = BeautifulSoup(html_table, "html.parser")
            for row in soup.find_all("tr"):
                first_cell = row.find(["th", "td"])
                if first_cell and "Grand Total" in first_cell.text:
                    row["class"] = row.get("class", []) + ["total"]
            out.write(str(soup) + "<br>")

        out.write('<div style="display:flex; flex-wrap:wrap;">')
        for domain, html_path, pie_png in per_domain_list:
            if os.path.exists(pie_png):
                out.write('<div style="flex:0 0 33%; text-align:center; margin-bottom:20px;">')
                out.write(
                    f'<img src="{os.path.basename(pie_png)}" alt="{domain} Pie" style="max-width:90%;height:auto;">'
                )
                out.write(f"<div>{domain}</div>")
                out.write("</div>")
        out.write("</div><hr>")

        # 02 Memory Usage Per Domain
        out.write('<h1 id="perdomain">02 Memory Usage Per Domain</h1>')
        for idx, (domain, html_path, pie_png) in enumerate(per_domain_list, start=1):
            out.write(f'<h2><a href="{os.path.basename(html_path)}">{domain}</a></h2>')

        # 03 ION Memory Usage
        if ion_html:
            out.write('<h1 id="ion_usage">03 ION Memory Usage</h1>')
            out.write(ion_html)

        # 04 System Address Info
        if asinfo_html:
            out.write('<h1 id="asinfo">04 System Address Info</h1>')
            out.write(asinfo_html)

        if budget_html:
            out.write('<h1 id="budget">05 Budget Comparison</h1>')
            out.write(budget_html)

        out.write("</body></html>")


def parse_budget_usage(pivot_df, budget_json_path, ion_json_path):
    """Compare actual memory usage against defined budget limits and generate a status table."""
    if not budget_json_path or not os.path.exists(budget_json_path):
        return ""

    try:
        with open(budget_json_path, "r") as f:
            data = json.load(f)
            budgets = data.get("smoketest_limits", {}).get("common_domain_limits_mb", {})
    except:
        return ""

    clean_pivot = pivot_df.drop(index=["Grand Total"], errors="ignore")
    actuals_kb = clean_pivot[MEMORY_COLS].sum(axis=1).to_dict()

    total_ion_kb = 0
    if ion_json_path and os.path.exists(ion_json_path):
        try:
            with open(ion_json_path, "r") as f:
                ion_data = json.load(f)
                total_ion_kb = sum(heap.get("heap_total (KB)", 0) for heap in ion_data)
        except:
            pass

    # if "Horizon" in actuals_kb:
    #     actuals_kb["Horizon"] = max(0, actuals_kb["Horizon"] - total_ion_kb)
    # actuals_kb["ION"] = total_ion_kb

    html = """
    <table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th style="text-align:left">Domain</th>
            <th>Budget (MB)</th>
            <th>Actual (MB)</th>
            <th>Diff (MB)</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
    """

    all_domains = sorted(set(list(budgets.keys()) + list(actuals_kb.keys())))

    for dom in all_domains:
        budget_mb = budgets.get(dom, 0)
        actual_mb = round(actuals_kb.get(dom, 0) / 1024, 2)
        diff_mb = round(budget_mb - actual_mb, 2)

        if actual_mb <= 0:
            continue
        if budget_mb == 0 and actual_mb == 0:
            continue

        status = "OK" if diff_mb >= 0 else "OVER"
        color = "#4CAF50" if status == "OK" else "#f44336"

        html += f"""
        <tr>
            <td style="text-align:left">{dom}</td>
            <td>{budget_mb:.2f}</td>
            <td>{actual_mb:.2f}</td>
            <td>{diff_mb:.2f}</td>
            <td style="color:white; background-color:{color}; font-weight:bold; text-align:center">{status}</td>
        </tr>
        """
    html += "</tbody></table>"
    return html


def main():
    parser = argparse.ArgumentParser(description="Generate memory usage report (pmap style, runtime-format)")
    parser.add_argument("-i", "--input", required=True, help="Input processed Excel file")
    parser.add_argument("-o", "--output", default="./pmap_memory_report", help="Output directory")
    parser.add_argument("-t", "--top", required=False, help="Optional: top output file to analyze and compare")
    parser.add_argument("--ion", required=False, help="Optional: ion usage file to include in report")
    parser.add_argument("--asinfo", required=False, help="Optional: syspage_asinfo.txt path")
    parser.add_argument("-l", "--limits", required=False, help="Smoketest limits JSON file")

    args = parser.parse_args()

    df = load_processed_excel(args.input)
    df = coerce_memory_columns(df)

    df = df[df["domain"] != "ram_budget_config (mb)"]

    active_domains = df.groupby("domain")[MEMORY_COLS].sum().sum(axis=1)
    active_domains = active_domains[active_domains > 0].index
    df = df[df["domain"].isin(active_domains)]

    out_dir = ensure_outdir(args.output)

    input_dir = os.path.dirname(os.path.abspath(args.input))
    # print(f"[DEBUG] Input Directory determined as: {input_dir}")

    pivot = build_domain_pivot(df)
    pivot_excel = os.path.join(out_dir, "domain_pivot.xlsx")
    pivot.to_excel(pivot_excel, sheet_name="domain_pivot")

    # stacked bar chart
    chart_png = os.path.join(out_dir, "Memory_Usage_by_Domain_Bar.png")
    plot_domain_chart(pivot, chart_png)

    # total pie chart
    total_pie_png = os.path.join(out_dir, "Memory_Usage_by_Domain_Pie.png")
    plot_total_pie(pivot, total_pie_png)

    # Generate per-domain breakdowns with pie
    per_domain_htmls = []
    for idx, domain in enumerate(df["domain"].dropna().unique(), start=1):
        df_domain = df[df["domain"] == domain]
        pivot_d = df_domain.groupby("pid_name")[MEMORY_COLS].sum().fillna(0)

        domain_num = f"{idx:02d}"
        pie_png = os.path.join(out_dir, f"{domain_num}_{domain}_pie.png")
        plot_domain_pie(df_domain, domain, pie_png)

        domain_html = os.path.join(out_dir, f"{domain_num}_{domain}_Memory.html")
        export_html_table(pivot_d, f"{domain} Memory (KB)", domain_html)

        per_domain_htmls.append((domain, domain_html, pie_png))

    # ION Usage Parsing
    if args.ion:
        ion_usage_path = args.ion
    else:
        ion_usage_path = os.path.join(input_dir, "ion_usage.txt")
    ion_json_output = os.path.join(out_dir, "ion_memory.json")
    ion_html = parse_ion_usage(ion_usage_path, json_path=ion_json_output)
    budget_html = parse_budget_usage(pivot, args.limits, ion_json_output)

    # ASINFO Parsing
    if args.asinfo:
        asinfo_path = args.asinfo
    else:
        asinfo_path = os.path.join(input_dir, "syspage_asinfo.txt")

    # print(f"[DEBUG] Expecting ASINFO file at: {asinfo_path}")
    asinfo_html = parse_syspage_asinfo(asinfo_path)

    summary_html = os.path.join(out_dir, "00_Memory_Usage_Report.html")
    generate_summary_html(
        per_domain_list=per_domain_htmls,
        overview_chart_png=chart_png,
        total_pie_png=total_pie_png,
        out_html=summary_html,
        grand_total_df=pivot,
        ion_html=ion_html,
        asinfo_html=asinfo_html,
        budget_html=budget_html,
    )

    print(f"All reports generated under: {out_dir}")


if __name__ == "__main__":
    main()
