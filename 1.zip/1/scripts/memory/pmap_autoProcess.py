#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse
import glob
import os
import shutil
import subprocess
import sys
from pathlib import Path


def stem_all(path: str) -> str:
    name = os.path.basename(path)
    while "." in name:
        name, _ = name.rsplit(".", 1)
    return name


def print_usage_example():
    print("\nExample usage:")
    print(
        "  python3 pmap_autoProcess.py -i pmap_folder_or_tar -o output_folder -u https://example.com -l /path/to/smoketest_limits.json"
    )


def check_file_exists(filepath, description):
    if not os.path.exists(filepath):
        print(f"Error: {description} {filepath} Not exist")
        return False
    return True


def parse_arguments():
    parser = argparse.ArgumentParser(
        description="pmap post-processing tool - Automatic analyze pmap data",
        add_help=False,
        formatter_class=argparse.RawTextHelpFormatter,
    )

    required = parser.add_argument_group("Mandatory arguments")
    required.add_argument(
        "-i", "--input", required=True, metavar="PATH", help="Input folder path or pmap_collection.tar"
    )
    required.add_argument(
        "-o", "--output", required=True, metavar="PATH", help="Output directory path for storing analysis results"
    )
    required.add_argument(
        "-u", "--url", required=True, metavar="URL", help="URL of the tested SW, for version and commit info"
    )
    required.add_argument("-l", "--limits", required=False, metavar="PATH", help="Path to smoketest_limits.json file")

    optional = parser.add_argument_group("Optional arguments")
    optional.add_argument("-h", "--help", action="help", help="Print this help info and exit")
    optional.add_argument(
        "--skip-postprocess",
        action="store_true",
        help="Skip calling pmap_postProcess.py (useful if Excel already generated)",
    )

    return parser


def main():
    parser = parse_arguments()
    try:
        args = parser.parse_args()
    except argparse.ArgumentError:
        print("Error: Missing mandatory argument")
        print_usage_example()
        sys.exit(1)

    input_file = args.input
    output_dir = args.output
    url = args.url
    limits_path = args.limits

    if os.path.isdir(input_file):
        tar_file = os.path.join(input_file, "pmap_collection.tar")
        if os.path.exists(tar_file):
            input_file = tar_file
            # print(f"Found pmap_collection.tar in directory: {input_file}")
        else:
            print(f"Error: pmap_collection.tar not found in directory {input_file}")
            sys.exit(1)
    elif os.path.isfile(input_file) and input_file.endswith(".tar"):
        print(f"Using input tar file: {input_file}")
    else:
        print(f"Error: Invalid input '{input_file}', must be a directory or .tar file")
        sys.exit(1)

    output_dir_name = f"Analyzed_Output_{stem_all(os.path.basename(input_file.rstrip('/')))}"

    SCRIPT_PATH = Path(__file__).resolve().parent
    CMD_PATH = Path.cwd()

    excel_path = os.path.join(output_dir, f"{output_dir_name}_extract_domain_processed.xlsx")

    scripts = [os.path.join(SCRIPT_PATH, "pmap_postProcess.py"), os.path.join(SCRIPT_PATH, "extract_pmap_json.py")]

    for script in scripts:
        if not check_file_exists(script, "Dependency script"):
            sys.exit(1)

    if not check_file_exists(input_file, "Input folder or tar file"):
        sys.exit(1)
    if not check_file_exists(limits_path, "Limits JSON file"):
        sys.exit(1)

    try:
        if not args.skip_postprocess:
            print("\nCall pmap_postProcess.py...")
            script1_cmd = [sys.executable, scripts[0], "-i", input_file, "-j", limits_path, "-o", output_dir]
            subprocess.run(script1_cmd, check=True)
            if not check_file_exists(excel_path, "Middle file"):
                sys.exit(1)
        # else:
        #     print("Skipping pmap_postProcess.py as requested (--skip-postprocess)")

        # print("Call extract_pmap_json.py...")
        script2_cmd = [sys.executable, scripts[1], "-i", excel_path, "-u", url, "-l", limits_path]
        subprocess.run(script2_cmd, check=True)

        moved_files = []
        for report_file in glob.glob("pmaps_report*.json"):
            # print(f"Moving {report_file} to {output_dir}")
            shutil.move(report_file, output_dir)
            moved_files.append(os.path.join(output_dir, report_file))

        report_files = glob.glob(os.path.join(output_dir, "pmaps_report*.json"))
        if report_files:
            # print("All Post-Process done!")
            print(f"JSON reports are in: {output_dir}")
            for rf in report_files:
                print(f"  - {os.path.basename(rf)}")
            sys.exit(0)
        else:
            print("Error: Json report file name started with 'pmaps_report' was not found")
            print(f"Checked directory: {output_dir}")
            sys.exit(1)

    except subprocess.CalledProcessError as e:
        print(f"Script processing failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Unknown error occurred: {e}")
        sys.exit(1)


if __name__ == "__main__":
    if len(sys.argv) == 1:
        parse_arguments().print_help()
        print_usage_example()
        sys.exit(1)
    main()
