# -*- coding: utf-8 -*-
import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile

import pandas as pd


def print_usage_example():
    print("\nExample usage:")
    print("  python3 pmap_postProcess.py -i pmap_collection.tar -j domain_lookup_qnx_J6B.json -o output_folder_path")


def extract_process_key(process_name):
    """Get key identification of process"""
    for keyword in ["prebuilt_activity_qnx8_bin_noviroc_lnk", "prebuilt_gateway_qnx8_bin_noviroc_lnk"]:
        if keyword in process_name.lower():
            return process_name.split(keyword)[0].strip("-_")
    return process_name


def build_domain_map(json_path):
    """Create domain mapping table"""
    with open(json_path) as f:
        return {process: domain for domain, processes in json.load(f).items() for process in processes}


def match_domain(process_name, domain_map):
    """Accurate mapping for domains"""
    search_key = extract_process_key(process_name)

    for stored_process in domain_map:
        if stored_process.lower() == search_key.lower():
            return domain_map[stored_process]

    return "Unknown"


def hex_to_dec(hex_str):
    """Change Hex value into DEC"""
    hex_str = hex_str.replace("0x", "")
    if len(hex_str) <= 10:
        return int(hex_str, 16)
    else:
        left_part = hex_str[:-8]
        right_part = hex_str[-8:]
        return int(left_part, 16) * (16**8) + int(right_part, 16)


def parse_memory_file(file_path, json_path):
    """Process single file"""
    data = []
    filename = os.path.basename(file_path).replace(".txt", "")

    if "_" in filename:
        pid, process_name = filename.split("_", 1)
    else:
        pid, process_name = filename, filename

    domain_map = build_domain_map(json_path)
    default_domain_name = match_domain(process_name, domain_map)

    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("vaddr,size") or line.startswith("#"):
                continue

            parts = [p.strip() for p in line.split(",")]
            if len(parts) >= 14:
                try:
                    path_val = parts[12]
                    size_hex = parts[1]
                    size_byte = hex_to_dec(size_hex)
                    size_kb = size_byte / 1024

                    if "ram/ion_" in path_val.lower():
                        current_row_domain = "ION"
                    else:
                        current_row_domain = default_domain_name

                    data.append(
                        {
                            "vaddr": parts[0],
                            "size": size_hex,
                            "flags": parts[2],
                            "prot": parts[3],
                            "maxprot": parts[4],
                            "dev": parts[5],
                            "ino": parts[6],
                            "offset": parts[7],
                            "rsv": parts[8],
                            "guardsize": parts[9],
                            "refcnt": parts[10],
                            "mapcnt": parts[11],
                            "path": path_val,
                            "asinfo": parts[13],
                            "size_byte": size_byte,
                            "size_kb": size_kb,
                            "pid": pid,
                            "domain": current_row_domain,
                            "pid_name": process_name,
                        }
                    )
                except Exception as e:
                    print(f"Process failed {file_path}: {line} -> {str(e)}")
    return data


def run_analysis_script(output_file):
    """Execute pmap_analysis.py with generated Excel file"""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    analysis_script = os.path.join(script_dir, "pmap_analysis.py")

    if not os.path.exists(analysis_script):
        print(f"Warning: Analysis script not found at {analysis_script}")
        return False

    try:
        result = subprocess.run(
            [sys.executable, analysis_script, output_file],
            check=True,
        )
        return True
    except subprocess.CalledProcessError as e:
        print(f"Processing step 3: Analysis script failed with error:\n{e.stderr}")
        return False


def run_pmap_mapping_script(tar_file_path, output_dir):
    """Execute pmap_pid_name_mapping.py to process tar file"""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    mapping_script = os.path.join(script_dir, "pmap_pid_name_mapping.py")

    if not os.path.exists(mapping_script):
        print(f"Error: Mapping script not found at {mapping_script}")
        return None

    # Create a rename file subdirectories in the output directory
    renamed_files_dir = tempfile.mkdtemp(prefix="pmap_renamed_")

    try:
        result = subprocess.run(
            [sys.executable, mapping_script, "-i", tar_file_path, "-o", renamed_files_dir],
            check=True,
            # capture_output=True,
            # text=True,
        )

        # Check if mapping was successful
        if os.path.exists(renamed_files_dir) and any(f.endswith(".txt") for f in os.listdir(renamed_files_dir)):
            return renamed_files_dir
        else:
            print("Error: Mapping script did not produce any output files")
            return None

    except subprocess.CalledProcessError as e:
        print(f"Processing step 1: Mapping script failed with error:\n{e.stderr}")
        shutil.rmtree(renamed_files_dir, ignore_errors=True)
        return None
    except Exception as e:
        print(f"Processing step 1: Unexpected error: {e}")
        shutil.rmtree(renamed_files_dir, ignore_errors=True)
        return None


def process_pmap_files(input_dir, json_path, output_dir):
    """Process the renamed pmap files"""
    if not os.path.isdir(input_dir):
        print(f"Error: {input_dir} is not a valid directory")
        return False

    txt_files = [f for f in os.listdir(input_dir) if f.endswith(".txt") and not f.startswith("process_names")]

    if not txt_files:
        print(f"Folder {input_dir} has no .txt files")
        return False

    all_data = []
    processed_count = 0
    for txt_file in txt_files:
        file_path = os.path.join(input_dir, txt_file)
        file_data = parse_memory_file(file_path, json_path)
        all_data.extend(file_data)
        processed_count += 1

    if all_data:
        df = pd.DataFrame(all_data)

        domain_map = build_domain_map(json_path)

        numeric_pids = df[df["pid_name"].str.isdigit()]["pid"].unique()
        for pid in numeric_pids:
            pid_mask = df["pid"] == pid
            if df[pid_mask]["path"].str.contains("ksh", na=False).any():
                df.loc[pid_mask, "pid_name"] = "ksh"
                df.loc[pid_mask, "domain"] = df.loc[pid_mask, "pid_name"].apply(lambda x: match_domain(x, domain_map))

        output_basename = os.path.basename(output_dir.rstrip("/\\"))
        output_file = os.path.join(output_dir, f"{output_basename}_extract_domain.xlsx")
        # === DIAGNOSTIC: Domain Assignment Summary ===
        print("\n" + "="*60)
        print("DOMAIN ASSIGNMENT DIAGNOSTIC")
        print(f"  domain_lookup.json path: {json_path}")
        print(f"  domain_lookup.json size: {os.path.getsize(json_path)} bytes")
        print(f"  Total domains in JSON: {len(set(domain_map.values()))}")
        print(f"  Total processes in JSON: {len(domain_map)}")
        print(f"\n  Domain distribution in result:")
        for domain, count in df["domain"].value_counts().items():
            print(f"    {domain}: {count} processes")
        unknown_procs = df[df["domain"] == "Unknown"]["pid_name"].unique()
        if len(unknown_procs) > 0:
            print(f"\n  Unknown processes ({len(unknown_procs)}):")
            for p in sorted(unknown_procs)[:30]:
                key = extract_process_key(p)
                print(f"    '{p}' -> key='{key}'")
        print("="*60 + "\n")
        df.to_excel(output_file, index=False)
        return output_file
    else:
        print("No valid data processed")
        return False


def main():
    parser = argparse.ArgumentParser(description="Process memory map files and extract domain information")
    parser.add_argument("-i", "--input", required=True, help="Input tar file path containing pmap data")
    parser.add_argument("-j", "--json", required=True, help="JSON file for domain mapping")
    parser.add_argument(
        "-o", "--output", default="./", help="Base output directory for analyzed results (default: current directory)"
    )

    args = parser.parse_args()

    if not os.path.exists(args.input):
        print(f"Error: {args.input} does not exist")
        sys.exit(1)

    if not os.path.exists(args.json):
        print(f"Error: {args.json} does not exist")
        sys.exit(1)

    tar_basename = os.path.basename(args.input).replace(".tar", "")
    main_output_dir = os.path.join(args.output, f"Analyzed_Output_{tar_basename}")
    os.makedirs(main_output_dir, exist_ok=True)

    processed_dir = run_pmap_mapping_script(args.input, main_output_dir)

    if not processed_dir:
        print("Failed to process tar file with mapping script")
        sys.exit(1)

    try:
        excel_file = process_pmap_files(processed_dir, args.json, main_output_dir)
        if processed_dir and os.path.exists(processed_dir):
            shutil.rmtree(processed_dir, ignore_errors=True)

        if excel_file:
            if run_analysis_script(excel_file):
                processed_excel = excel_file.replace("_extract_domain.xlsx", "_extract_domain_processed.xlsx")
            else:
                print("Processing completed with analysis script warnings")
        else:
            print("Processing failed at step 2")

    except Exception as e:
        print(f"Processing failed with error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    if len(sys.argv) == 1:
        print_usage_example()
        sys.exit(1)
    main()
