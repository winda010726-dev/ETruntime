import argparse
import os
import sys
from collections import defaultdict

import openpyxl
from openpyxl.utils import get_column_letter


def process_private_memory_tags(ws, row, m_text, s_value):
    """Process {stack}/{heap}/{bss} labels"""
    if "{stack}" in m_text:
        ws[f"T{row}"] = s_value
    if "{heap}" in m_text:
        ws[f"U{row}"] = s_value
    if "{bss}" in m_text:
        ws[f"V{row}"] = s_value


def count_so_occurrences(ws):
    """Collect the present time of '.so' text in M column"""
    so_counts = defaultdict(int)
    for row in range(2, ws.max_row + 1):
        path_cell = ws[f"M{row}"].value
        prot_cell = ws[f"D{row}"].value
        if path_cell and ".so" in str(path_cell) and prot_cell == "0x05":
            so_counts[str(path_cell)] += 1
    return so_counts


def process_lib(ws, so_counts):
    """Process the dulplicated '.so' text and calculate value of column Q"""
    for row in range(2, ws.max_row + 1):
        path_cell = ws[f"M{row}"].value
        size_kb_value = ws[f"P{row}"].value
        prot_cell = ws[f"D{row}"].value

        if path_cell and size_kb_value and ".so" in str(path_cell) and prot_cell == "0x05":
            full_text = str(path_cell)
            count = so_counts[full_text]
            if count > 0:
                ws[f"W{row}"] = round(size_kb_value / count, 2)

        if path_cell and size_kb_value and ".so" in str(path_cell) and (prot_cell == "0x01" or prot_cell == "0x03"):
            ws[f"W{row}"] = size_kb_value


def process_shm(ws):
    """Process [shmem] text and calculate value in Q column"""
    for row in range(2, ws.max_row + 1):
        path_cell = ws[f"M{row}"].value
        size_kb_value = ws[f"P{row}"].value
        prot_cell = ws[f"D{row}"].value

        if path_cell and size_kb_value and "dev/shmem" in str(path_cell) and prot_cell == "0x03":
            ws[f"X{row}"] = size_kb_value


def process_data(ws):
    """Process [data] text and calculate value in Q column"""
    for row in range(2, ws.max_row + 1):
        offset_cell = ws[f"H{row}"].value
        path_cell = ws[f"M{row}"].value
        size_kb_value = ws[f"P{row}"].value
        prot_cell = ws[f"D{row}"].value
        is_data = 1

        if "{stack}" in str(path_cell):
            is_data = 0
        if "{heap}" in str(path_cell):
            is_data = 0
        if "{bss}" in str(path_cell):
            is_data = 0
        if ".so" in str(path_cell):
            is_data = 0
        if "/dev/shm" in str(path_cell):
            is_data = 0
        if "**anonymous**" in str(path_cell):
            is_data = 0
        if "**unlinked**" in str(path_cell):
            is_data = 0
        if "ram/ion_" in str(path_cell):
            is_data = 0
        if "00000000b2400000" in str(offset_cell):
            is_data = 0

        if path_cell and size_kb_value and is_data == 1:
            ws[f"Y{row}"] = size_kb_value


def process_anon(ws):
    for row in range(2, ws.max_row + 1):
        path_cell = ws[f"M{row}"].value
        size_kb_value = ws[f"P{row}"].value

        if path_cell and size_kb_value and "**anonymous**" in str(path_cell):
            ws[f"Z{row}"] = size_kb_value


def process_unlink(ws):
    for row in range(2, ws.max_row + 1):
        path_cell = ws[f"M{row}"].value
        size_kb_value = ws[f"P{row}"].value

        if path_cell and size_kb_value and "**unlinked**" in str(path_cell):
            ws[f"AB{row}"] = size_kb_value


def process_reserved(ws):
    for row in range(2, ws.max_row + 1):
        path_cell = ws[f"M{row}"].value
        offset_cell = ws[f"H{row}"].value
        size_kb_value = ws[f"P{row}"].value

        if path_cell and size_kb_value and "ram/ion_" in str(path_cell):
            ws[f"AA{row}"] = size_kb_value
        if offset_cell and size_kb_value and "00000000b2400000" in str(offset_cell):
            ws[f"AA{row}"] = size_kb_value


def add_sum_columns(ws):
    """Add Sum(KB) and Sum(MB) columns after reserved/unlink columns"""
    last_col = ws.max_column
    sum_kb_col = last_col + 1
    sum_mb_col = last_col + 2

    ws.cell(row=1, column=sum_kb_col, value="Sum(KB)")
    ws.cell(row=1, column=sum_mb_col, value="Sum(MB)")

    for row in range(2, ws.max_row + 1):
        total_kb = 0.0
        for col_letter in ["T", "U", "V", "W", "X", "Y", "Z", "AA", "AB"]:  # stack ~ unlink
            val = ws[f"{col_letter}{row}"].value
            if isinstance(val, (int, float)):
                total_kb += val

        ws.cell(row=row, column=sum_kb_col, value=round(total_kb, 2))
        ws.cell(row=row, column=sum_mb_col, value=round(total_kb / 1024, 2))


def process_pmap_extract_excel_file(ws):
    """Process single sheet"""
    try:
        start_col = 20  # column of stack
        for i, name in enumerate(["stack", "heap", "bss", "lib", "shm", "binary", "anon", "reserved", "unlink"]):
            col_letter = get_column_letter(start_col + i)
            ws[f"{col_letter}1"] = name

        so_counts = count_so_occurrences(ws)

        for row in range(2, ws.max_row + 1):
            path_cell = ws[f"M{row}"].value
            size_kb_value = ws[f"P{row}"].value

            if path_cell and size_kb_value:
                m_text = str(path_cell).lower()
                process_private_memory_tags(ws, row, m_text, size_kb_value)

        process_lib(ws, so_counts)
        process_shm(ws)
        process_data(ws)
        process_anon(ws)
        process_reserved(ws)
        process_unlink(ws)
        add_sum_columns(ws)

    except Exception as e:
        print(f"Error when process work sheet: {str(e)}")
        raise  # Reraise error which can be captured by upper layer


def Calculate_mem_size(file_path):
    output_path = file_path.replace(".xlsx", "_processed.xlsx")
    try:
        wb = openpyxl.load_workbook(file_path)

        first_sheet = wb.sheetnames[0]
        ws = wb[first_sheet]
        process_pmap_extract_excel_file(ws)

        wb.save(output_path)
        return output_path

    except Exception as e:
        print(f"Process failed: {str(e)}", file=sys.stderr)
        sys.exit(1)


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 pmap_analysis.py pmap_extract_domain.xlsx")
        sys.exit(1)

    pmap_extract_domain_excel = sys.argv[1]

    temp_file = Calculate_mem_size(pmap_extract_domain_excel)


if __name__ == "__main__":
    main()
