# # #!/usr/bin/env python3
# # # -*- coding: utf-8 -*-
# # import argparse
# # import glob
# # import os
# # import shutil
# # import subprocess
# # import sys
# # import time
# # from datetime import datetime
# # from html import escape

# # from bs4 import BeautifulSoup

# # # Page style
# # STYLE_TOP = """
# # <style>
# # body {font-family: Arial, sans-serif; margin: 20px 40px; color: #333;}
# # .title {font-size: 28px; font-weight: bold; margin-bottom: 25px; color: #000;}
# # .level1 {font-size: 20px; font-weight: bold; margin: 15px 0 5px 0;}
# # .level1::before {content: "• "; color: #0b66c3;}
# # .level2 {font-size: 16px; margin-left: 25px; margin-top: 8px;}
# # .level2::before {content: "→ "; color: #666;}
# # a {color: #0b66c3; text-decoration: none;}
# # a:hover {text-decoration: underline;}
# # ul {list-style-type: none; padding-left: 0;}
# # </style>
# # """

# # # Navigation snippet style
# # NAV_STYLE = """
# # <style>
# # .report-nav {
# #   font-family: Arial, sans-serif;
# #   font-size: 13px;
# #   margin-bottom: 15px;
# #   padding: 10px 15px;
# #   background: #f8f9fa;
# #   border-left: 5px solid #0b66c3;
# #   border-radius: 4px;
# # }
# # .report-nav a { color: #0b66c3; text-decoration: none; font-weight: bold; }
# # .report-nav .sep { color: #999; margin: 0 8px; }
# # </style>
# # """


# # def log_step(msg, status="INFO"):
# #     """Prints a timestamped message with a status prefix."""
# #     now = datetime.now().strftime("%H:%M:%S")
# #     color_map = {
# #         "RUN": "\033[94m[ RUN ]\033[0m",
# #         "DONE": "\033[92m[ OK  ]\033[0m",
# #         "FAIL": "\033[91m[FAIL ]\033[0m",
# #         "INFO": "[ INFO ]",
# #         "BATCH": "\033[95m[BATCH]\033[0m",
# #         "ZIP": "\033[96m[ ZIP ]\033[0m",
# #     }
# #     print(f"{now} {color_map.get(status, '[ INFO ]')} {msg}")


# # def fix_timestamps_for_zip(root_dir):
# #     """ZIP format doesn't support mtime < 1980. This updates old timestamps to 1980-01-01."""
# #     min_ts = time.mktime((1980, 1, 1, 0, 0, 0, 0, 0, 0))
# #     for dirpath, dirnames, filenames in os.walk(root_dir):
# #         for name in filenames + dirnames:
# #             full_path = os.path.join(dirpath, name)
# #             try:
# #                 if os.path.getmtime(full_path) < min_ts:
# #                     os.utime(full_path, (min_ts, min_ts))
# #             except Exception:
# #                 pass


# # def ensure_outdir(path):
# #     """Creates directory if it doesn't exist and returns absolute path."""
# #     os.makedirs(path, exist_ok=True)
# #     return os.path.abspath(path)


# # def run_pipeline(name, script_path, input_dir, json_file, output_dir, limits_file=None):
# #     """Executes a specific analysis sub-script via subprocess."""
# #     script_abs = os.path.abspath(script_path)
# #     if not os.path.exists(script_abs):
# #         log_step(f"Script missing: {script_path}", "FAIL")
# #         return False

# #     cmd = [sys.executable, script_abs, "-i", input_dir, "-o", output_dir]
# #     if json_file:
# #         cmd.extend(["-j", json_file])
# #     if limits_file:
# #         cmd.extend(["-l", limits_file])

# #     log_step(f"Starting {name} analysis...", "RUN")
# #     try:
# #         subprocess.run(cmd, check=True)
# #         log_step(f"{name} completed successfully.", "DONE")
# #         return True
# #     except subprocess.CalledProcessError:
# #         log_step(f"{name} analysis failed.", "FAIL")
# #         return False


# # def find_file_recursive(root_dir, pattern_fn):
# #     """Searches for a single file matching pattern_fn recursively."""
# #     if not root_dir:
# #         return None
# #     for dirpath, _, filenames in os.walk(root_dir):
# #         for fn in filenames:
# #             full = os.path.join(dirpath, fn)
# #             if pattern_fn(full):
# #                 return full
# #     return None


# # def find_all_files_recursive(root_dir, pattern_fn):
# #     """Returns a sorted list of all files matching pattern_fn recursively."""
# #     out = []
# #     if not root_dir:
# #         return out
# #     for dirpath, _, filenames in os.walk(root_dir):
# #         for fn in filenames:
# #             full = os.path.join(dirpath, fn)
# #             if pattern_fn(full):
# #                 out.append(full)
# #     return sorted(out)


# # def inject_nav_into_html(html_path, home_path, parent_name=None, parent_path=None):
# #     """
# #     Injects a navigation breadcrumb bar at the top of generated HTML reports.
# #     """
# #     try:
# #         with open(html_path, "r", encoding="utf-8") as f:
# #             content = f.read()
# #         soup = BeautifulSoup(content, "html.parser")
# #         if soup.find(class_="report-nav"):
# #             return

# #         # Calculate relative paths for links
# #         current_dir = os.path.dirname(html_path)
# #         home_rel = os.path.relpath(home_path, current_dir).replace(os.path.sep, "/")
# #         crumbs = [f'<a href="{escape(home_rel)}">🏠 System Resource Report Home</a>']

# #         if parent_path and parent_name:
# #             p_rel = os.path.relpath(parent_path, current_dir).replace(os.path.sep, "/")
# #             crumbs.append(f'<span class="sep">/</span><a href="{escape(p_rel)}">{escape(parent_name)}</a>')

# #         title = soup.title.string if soup.title else os.path.basename(html_path)
# #         crumbs.append(f'<span class="sep">/</span><span>{escape(title)}</span>')

# #         nav_div = soup.new_tag("div", attrs={"class": "report-nav"})
# #         nav_div.append(BeautifulSoup(NAV_STYLE + f"<div>{' '.join(crumbs)}</div>", "html.parser"))

# #         if soup.body:
# #             soup.body.insert(0, nav_div)
# #         else:
# #             soup.insert(0, nav_div)

# #         with open(html_path, "w", encoding="utf-8") as f:
# #             f.write(str(soup))
# #     except Exception:
# #         pass


# # def build_top_level_report(out_base, summary_links):
# #     """
# #     Generates the main index.html for the resource report.
# #     """
# #     top_html = os.path.join(out_base, "System_Resource_Report.html")
# #     with open(top_html, "w", encoding="utf-8") as f:
# #         f.write(f"<html><head><title>System Resource Report</title>{STYLE_TOP}</head><body>")
# #         f.write('<div class="title">System Resource Report</div><li class="level1">Performance Dashboards</li><ul>')
# #         for name, path in summary_links.items():
# #             if path:
# #                 rel = os.path.relpath(path, out_base).replace(os.path.sep, "/")
# #                 f.write(f'<li class="level2"><a href="{rel}">{name}</a></li>')
# #             else:
# #                 f.write(f'<li class="level2" style="color:gray;">{name} (No Data)</li>')
# #         f.write("</ul></body></html>")
# #     return top_html


# # def process_single_dataset(input_dir, json_file, limits_file, output_arg):
# #     """
# #     Core logic to process one raw data directory and generate a specific report.
# #     """
# #     name = os.path.basename(os.path.normpath(input_dir))
# #     folder_name = (
# #         name.replace("System_Resource_Raw_Data", "System_Resource_Report", 1)
# #         if "System_Resource_Raw_Data" in name
# #         else f"System_Resource_Report_{name}"
# #     )

# #     out_base = ensure_outdir(os.path.join(output_arg, folder_name))
# #     log_step(f"Processing: {name} -> {out_base}")

# #     # Sub-task configurations
# #     tasks = [
# #         ("Memory", "memory/pmap_pipeline.py", os.path.join(out_base, "memory"), json_file, limits_file),
# #         ("CPU/Runtime", "runtime/runtime_pipeline.py", os.path.join(out_base, "runtime"), json_file, None),
# #         (
# #             "DDR Bandwidth",
# #             "ram_bandwidth/ram_bandwidth_pipeline.py",
# #             os.path.join(out_base, "ddr_bandwidth"),
# #             None,
# #             None,
# #         ),
# #     ]

# #     results = {}
# #     for task_name, script, out_dir, j_file, l_file in tasks:
# #         ensure_outdir(out_dir)
# #         if run_pipeline(task_name, script, input_dir, j_file, out_dir, l_file):
# #             results[task_name] = out_dir

# #     # Link HTML reports
# #     summary_pages = {
# #         "Memory Usage": find_file_recursive(
# #             results.get("Memory"), lambda p: "Memory_Usage_Report" in p and p.endswith(".html")
# #         ),
# #         "CPU Runtime": find_file_recursive(
# #             results.get("CPU/Runtime"), lambda p: "Runtime_Memory_Report" in p and p.endswith(".html")
# #         ),
# #         "DDR Bandwidth": find_file_recursive(
# #             results.get("DDR Bandwidth"), lambda p: "Bandwidth_Summary" in p and p.endswith(".html")
# #         ),
# #     }

# #     top_report = build_top_level_report(out_base, summary_pages)

# #     for label, s_page in summary_pages.items():
# #         if s_page:
# #             inject_nav_into_html(s_page, top_report)
# #             for detail in find_all_files_recursive(
# #                 os.path.dirname(s_page), lambda p: p.endswith(".html") and os.path.abspath(p) != os.path.abspath(s_page)
# #             ):
# #                 inject_nav_into_html(detail, top_report, parent_name=label, parent_path=s_page)
# #     return top_report


# # def main():
# #     """Entry point: parses arguments, initializes output, and runs processing."""
# #     parser = argparse.ArgumentParser(description="System Resource Analysis Pipeline")
# #     parser.add_argument("-i", "--input", help="Single input directory")
# #     parser.add_argument("-j", "--json", help="Domain lookup JSON")
# #     parser.add_argument("-l", "--limits", help="Thresholds JSON")
# #     parser.add_argument("-o", "--output", default="./System_Resource_Report", help="Output root directory")
# #     parser.add_argument("-a", "--all_path", help="Batch mode: parent directory to scan")
# #     parser.add_argument("-z", "--zip", action="store_true", help="ZIP the total output folder")
# #     parser.add_argument("--no-timestamp", action="store_true", help="Disable timestamp in output dir")
# #     args = parser.parse_args()

# #     # 1. Initialize total output directory (Clean & Create)
# #     output_root = os.path.abspath(args.output)
# #     if os.path.exists(output_root):
# #         log_step(f"Cleaning existing output directory: {output_root}", "INFO")
# #         shutil.rmtree(output_root)
# #     ensure_outdir(output_root)

# #     # 2. Identify target directories
# #     target_dirs = []
# #     if args.all_path:
# #         pattern = os.path.join(args.all_path, "*System_Resource_Raw_Data*")
# #         target_dirs = sorted([d for d in glob.glob(pattern) if os.path.isdir(d)])
# #         if not target_dirs:
# #             log_step("No matching folders found.", "FAIL")
# #             sys.exit(1)
# #         log_step(f"Batch Mode: Found {len(target_dirs)} directories.", "BATCH")
# #     elif args.input:
# #         target_dirs = [args.input]
# #     else:
# #         parser.print_help()
# #         sys.exit(1)

# #     # 3. Process each dataset
# #     final_reports = []
# #     for directory in target_dirs:
# #         print(f"\n{'-' * 30} SUB-TASK START {'-' * 30}")
# #         report_path = process_single_dataset(directory, args.json, args.limits, output_root)
# #         final_reports.append(report_path)

# #     # 4. Final ZIP (of the total folder)
# #     if args.zip:
# #         print(f"\n{'-' * 30} COMPRESSION {'-' * 30}")
# #         log_step(f"Creating total archive for: {output_root}", "ZIP")
# #         try:
# #             fix_timestamps_for_zip(output_root)
# #             zip_file = shutil.make_archive(output_root, "zip", output_root)
# #             log_step(f"Archive created: {zip_file}", "DONE")
# #         except Exception as e:
# #             log_step(f"Compression failed: {e}", "FAIL")

# #     print(f"\n{'=' * 75}\n ALL ANALYSIS COMPLETED\n Total Processed: {len(final_reports)}")
# #     for r in final_reports:
# #         print(f" -> {r}")
# #     print(f"{'=' * 75}\n")


# # if __name__ == "__main__":
# #     main()

# #!/usr/bin/env python3
# # -*- coding: utf-8 -*-
# import argparse
# import glob
# import os
# import shutil
# import subprocess
# import sys
# import time
# from datetime import datetime
# from html import escape

# from bs4 import BeautifulSoup

# # Page style
# STYLE_TOP = """
# <style>
# body {font-family: Arial, sans-serif; margin: 20px 40px; color: #333;}
# .title {font-size: 28px; font-weight: bold; margin-bottom: 25px; color: #000;}
# .level1 {font-size: 20px; font-weight: bold; margin: 15px 0 5px 0;}
# .level1::before {content: "• "; color: #0b66c3;}
# .level2 {font-size: 16px; margin-left: 25px; margin-top: 8px;}
# .level2::before {content: "→ "; color: #666;}
# a {color: #0b66c3; text-decoration: none;}
# a:hover {text-decoration: underline;}
# ul {list-style-type: none; padding-left: 0;}
# </style>
# """

# # Navigation snippet style
# NAV_STYLE = """
# <style>
# .report-nav {
#   font-family: Arial, sans-serif;
#   font-size: 13px;
#   margin-bottom: 15px;
#   padding: 10px 15px;
#   background: #f8f9fa;
#   border-left: 5px solid #0b66c3;
#   border-radius: 4px;
# }
# .report-nav a { color: #0b66c3; text-decoration: none; font-weight: bold; }
# .report-nav .sep { color: #999; margin: 0 8px; }
# </style>
# """


# def log_step(msg, status="INFO"):
#     """Prints a timestamped message with a status prefix."""
#     now = datetime.now().strftime("%H:%M:%S")
#     color_map = {
#         "RUN": "\033[94m[ RUN ]\033[0m",
#         "DONE": "\033[92m[ OK  ]\033[0m",
#         "FAIL": "\033[91m[FAIL ]\033[0m",
#         "INFO": "[ INFO ]",
#         "BATCH": "\033[95m[BATCH]\033[0m",
#         "ZIP": "\033[96m[ ZIP ]\033[0m",
#     }
#     print(f"{now} {color_map.get(status, '[ INFO ]')} {msg}")


# def fix_timestamps_for_zip(root_dir):
#     """ZIP format doesn't support mtime < 1980."""
#     min_ts = time.mktime((1980, 1, 1, 0, 0, 0, 0, 0, 0))
#     for dirpath, dirnames, filenames in os.walk(root_dir):
#         for name in filenames + dirnames:
#             full_path = os.path.join(dirpath, name)
#             try:
#                 if os.path.getmtime(full_path) < min_ts:
#                     os.utime(full_path, (min_ts, min_ts))
#             except Exception:
#                 pass


# def ensure_outdir(path):
#     """Creates directory if it doesn't exist and returns absolute path."""
#     os.makedirs(path, exist_ok=True)
#     return os.path.abspath(path)


# def run_pipeline(name, script_path, input_dir, json_file, output_dir, limits_file=None):
#     """Executes a specific analysis sub-script via subprocess."""
#     script_abs = os.path.abspath(script_path)
#     if not os.path.exists(script_abs):
#         log_step(f"Script missing: {script_path}", "FAIL")
#         return False

#     # 核心修改点：确保所有路径为绝对路径，并打印执行命令
#     cmd = [sys.executable, script_abs, "-i", os.path.abspath(input_dir), "-o", os.path.abspath(output_dir)]
#     if json_file:
#         cmd.extend(["-j", os.path.abspath(json_file)])
#     if limits_file:
#         cmd.extend(["-l", os.path.abspath(limits_file)])

#     # 【重要调试信息】在控制台打印完整命令，对比命令行和Web的参数差异
#     log_step(f"EXEC_CMD: {' '.join(cmd)}", "INFO")

#     log_step(f"Starting {name} analysis...", "RUN")
#     try:
#         subprocess.run(cmd, check=True)
#         log_step(f"{name} completed successfully.", "DONE")
#         return True
#     except subprocess.CalledProcessError:
#         log_step(f"{name} analysis failed.", "FAIL")
#         return False


# def find_file_recursive(root_dir, pattern_fn):
#     if not root_dir: return None
#     for dirpath, _, filenames in os.walk(root_dir):
#         for fn in filenames:
#             full = os.path.join(dirpath, fn)
#             if pattern_fn(full): return full
#     return None


# def find_all_files_recursive(root_dir, pattern_fn):
#     out = []
#     if not root_dir: return out
#     for dirpath, _, filenames in os.walk(root_dir):
#         for fn in filenames:
#             full = os.path.join(dirpath, fn)
#             if pattern_fn(full): out.append(full)
#     return sorted(out)


# def inject_nav_into_html(html_path, home_path, parent_name=None, parent_path=None):
#     try:
#         with open(html_path, "r", encoding="utf-8") as f:
#             content = f.read()
#         soup = BeautifulSoup(content, "html.parser")
#         if soup.find(class_="report-nav"): return

#         current_dir = os.path.dirname(html_path)
#         home_rel = os.path.relpath(home_path, current_dir).replace(os.path.sep, "/")
#         crumbs = [f'<a href="{escape(home_rel)}">🏠 System Resource Report Home</a>']

#         if parent_path and parent_name:
#             p_rel = os.path.relpath(parent_path, current_dir).replace(os.path.sep, "/")
#             crumbs.append(f'<span class="sep">/</span><a href="{escape(p_rel)}">{escape(parent_name)}</a>')

#         title = soup.title.string if soup.title else os.path.basename(html_path)
#         crumbs.append(f'<span class="sep">/</span><span>{escape(title)}</span>')

#         nav_div = soup.new_tag("div", attrs={"class": "report-nav"})
#         nav_div.append(BeautifulSoup(NAV_STYLE + f"<div>{' '.join(crumbs)}</div>", "html.parser"))

#         if soup.body: soup.body.insert(0, nav_div)
#         else: soup.insert(0, nav_div)

#         with open(html_path, "w", encoding="utf-8") as f:
#             f.write(str(soup))
#     except Exception: pass


# def build_top_level_report(out_base, summary_links):
#     top_html = os.path.join(out_base, "System_Resource_Report.html")
#     with open(top_html, "w", encoding="utf-8") as f:
#         f.write(f"<html><head><title>System Resource Report</title>{STYLE_TOP}</head><body>")
#         f.write('<div class="title">System Resource Report</div><li class="level1">Performance Dashboards</li><ul>')
#         for name, path in summary_links.items():
#             if path:
#                 rel = os.path.relpath(path, out_base).replace(os.path.sep, "/")
#                 f.write(f'<li class="level2"><a href="{rel}">{name}</a></li>')
#             else:
#                 f.write(f'<li class="level2" style="color:gray;">{name} (No Data)</li>')
#         f.write("</ul></body></html>")
#     return top_html


# def process_single_dataset(input_dir, json_file, limits_file, output_arg):
#     name = os.path.basename(os.path.normpath(input_dir))
#     folder_name = (
#         name.replace("System_Resource_Raw_Data", "System_Resource_Report", 1)
#         if "System_Resource_Raw_Data" in name
#         else f"System_Resource_Report_{name}"
#     )

#     out_base = ensure_outdir(os.path.join(output_arg, folder_name))
#     log_step(f"Processing Data Folder: {os.path.abspath(input_dir)}")

#     tasks = [
#         ("Memory", "memory/pmap_pipeline.py", os.path.join(out_base, "memory"), json_file, limits_file),
#         ("CPU/Runtime", "runtime/runtime_pipeline.py", os.path.join(out_base, "runtime"), json_file, None),
#         ("DDR Bandwidth", "ram_bandwidth/ram_bandwidth_pipeline.py", os.path.join(out_base, "ddr_bandwidth"), None, None),
#     ]

#     results = {}
#     for task_name, script, out_dir, j_file, l_file in tasks:
#         ensure_outdir(out_dir)
#         if run_pipeline(task_name, script, input_dir, j_file, out_dir, l_file):
#             results[task_name] = out_dir

#     summary_pages = {
#         "Memory Usage": find_file_recursive(results.get("Memory"), lambda p: "Memory_Usage_Report" in p and p.endswith(".html")),
#         "CPU Runtime": find_file_recursive(results.get("CPU/Runtime"), lambda p: "Runtime_Memory_Report" in p and p.endswith(".html")),
#         "DDR Bandwidth": find_file_recursive(results.get("DDR Bandwidth"), lambda p: "Bandwidth_Summary" in p and p.endswith(".html")),
#     }

#     top_report = build_top_level_report(out_base, summary_pages)

#     for label, s_page in summary_pages.items():
#         if s_page:
#             inject_nav_into_html(s_page, top_report)
#             for detail in find_all_files_recursive(os.path.dirname(s_page), lambda p: p.endswith(".html") and os.path.abspath(p) != os.path.abspath(s_page)):
#                 inject_nav_into_html(detail, top_report, parent_name=label, parent_path=s_page)
#     return top_report


# def main():
#     parser = argparse.ArgumentParser(description="System Resource Analysis Pipeline")
#     parser.add_argument("-i", "--input", help="Single input directory")
#     parser.add_argument("-j", "--json", help="Domain lookup JSON")
#     parser.add_argument("-l", "--limits", help="Thresholds JSON")
#     parser.add_argument("-o", "--output", default="./System_Resource_Report", help="Output root directory")
#     parser.add_argument("-a", "--all_path", help="Batch mode: parent directory to scan")
#     parser.add_argument("-z", "--zip", action="store_true", help="ZIP the total output folder")
#     args = parser.parse_args()

#     # 1. 绝对路径初始化，打印当前配置，防止 Web 路径混淆
#     output_root = os.path.abspath(args.output)
#     if args.json:
#         args.json = os.path.abspath(args.json)
#         log_step(f"Domain Lookup JSON: {args.json}")
    
#     # 注意：在 Web 模式下，不建议直接 shutil.rmtree(output_root)，因为 task_id 目录是唯一的
#     # 我们只在目录不存在时创建它
#     ensure_outdir(output_root)

#     # 2. 识别目录：针对 Web 模式优化 glob 匹配
#     target_dirs = []
#     if args.all_path:
#         # 同时尝试匹配包含关键字的目录和普通目录
#         search_path = os.path.join(args.all_path, "*")
#         all_sub_items = sorted(glob.glob(search_path))
#         target_dirs = [d for d in all_sub_items if os.path.isdir(d)]
        
#         if not target_dirs:
#             log_step("No directories found in all_path.", "FAIL")
#             sys.exit(1)
#         log_step(f"Batch Mode: Found {len(target_dirs)} folders.", "BATCH")
#     elif args.input:
#         target_dirs = [args.input]
#     else:
#         parser.print_help()
#         sys.exit(1)

#     # 3. 执行任务
#     final_reports = []
#     for directory in target_dirs:
#         print(f"\n{'-' * 30} SUB-TASK START {'-' * 30}")
#         report_path = process_single_dataset(directory, args.json, args.limits, output_root)
#         final_reports.append(report_path)

#     # 4. ZIP 压缩
#     if args.zip:
#         print(f"\n{'-' * 30} COMPRESSION {'-' * 30}")
#         try:
#             fix_timestamps_for_zip(output_root)
#             zip_file = shutil.make_archive(output_root, "zip", output_root)
#             log_step(f"Archive created: {zip_file}", "DONE")
#         except Exception as e:
#             log_step(f"Compression failed: {e}", "FAIL")

#     print(f"\n{'=' * 75}\n ALL ANALYSIS COMPLETED\n Total Processed: {len(final_reports)}")
#     for r in final_reports:
#         print(f" -> {r}")
#     print(f"{'=' * 75}\n")


# if __name__ == "__main__":
#     main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse
import glob
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime
from html import escape

from bs4 import BeautifulSoup

# Page style
STYLE_TOP = """
<style>
body {font-family: Arial, sans-serif; margin: 20px 40px; color: #333;}
.title {font-size: 28px; font-weight: bold; margin-bottom: 25px; color: #000;}
.level1 {font-size: 20px; font-weight: bold; margin: 15px 0 5px 0;}
.level1::before {content: "• "; color: #0b66c3;}
.level2 {font-size: 16px; margin-left: 25px; margin-top: 8px;}
.level2::before {content: "→ "; color: #666;}
a {color: #0b66c3; text-decoration: none;}
a:hover {text-decoration: underline;}
ul {list-style-type: none; padding-left: 0;}
</style>
"""

# Navigation snippet style
NAV_STYLE = """
<style>
.report-nav {
  font-family: Arial, sans-serif;
  font-size: 13px;
  margin-bottom: 15px;
  padding: 10px 15px;
  background: #f8f9fa;
  border-left: 5px solid #0b66c3;
  border-radius: 4px;
}
.report-nav a { color: #0b66c3; text-decoration: none; font-weight: bold; }
.report-nav .sep { color: #999; margin: 0 8px; }
</style>
"""


def log_step(msg, status="INFO"):
    """Prints a timestamped message with a status prefix."""
    now = datetime.now().strftime("%H:%M:%S")
    color_map = {
        "RUN": "\033[94m[ RUN ]\033[0m",
        "DONE": "\033[92m[ OK  ]\033[0m",
        "FAIL": "\033[91m[FAIL ]\033[0m",
        "INFO": "[ INFO ]",
        "BATCH": "\033[95m[BATCH]\033[0m",
        "ZIP": "\033[96m[ ZIP ]\033[0m",
    }
    print(f"{now} {color_map.get(status, '[ INFO ]')} {msg}")


def fix_timestamps_for_zip(root_dir):
    """ZIP format doesn't support mtime < 1980."""
    min_ts = time.mktime((1980, 1, 1, 0, 0, 0, 0, 0, 0))
    for dirpath, dirnames, filenames in os.walk(root_dir):
        for name in filenames + dirnames:
            full_path = os.path.join(dirpath, name)
            try:
                if os.path.getmtime(full_path) < min_ts:
                    os.utime(full_path, (min_ts, min_ts))
            except Exception:
                pass


def ensure_outdir(path):
    """Creates directory if it doesn't exist and returns absolute path."""
    os.makedirs(path, exist_ok=True)
    return os.path.abspath(path)


def run_pipeline(name, script_path, input_dir, json_file, output_dir, limits_file=None):
    """Executes a specific analysis sub-script via subprocess."""
    script_abs = os.path.abspath(script_path)
    if not os.path.exists(script_abs):
        log_step(f"Script missing: {script_path}", "FAIL")
        return False

    # 所有路径强制转为绝对路径，避免相对路径报错
    cmd = [sys.executable, script_abs, "-i", os.path.abspath(input_dir), "-o", os.path.abspath(output_dir)]
    if json_file:
        cmd.extend(["-j", os.path.abspath(json_file)])
    if limits_file:
        cmd.extend(["-l", os.path.abspath(limits_file)])

    log_step(f"EXEC_CMD: {' '.join(cmd)}", "INFO")

    log_step(f"Starting {name} analysis...", "RUN")
    try:
        subprocess.run(cmd, check=True)
        log_step(f"{name} completed successfully.", "DONE")
        return True
    except subprocess.CalledProcessError:
        log_step(f"{name} analysis failed.", "FAIL")
        return False


def find_file_recursive(root_dir, pattern_fn):
    if not root_dir: return None
    for dirpath, _, filenames in os.walk(root_dir):
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            if pattern_fn(full): return full
    return None


def find_all_files_recursive(root_dir, pattern_fn):
    out = []
    if not root_dir: return out
    for dirpath, _, filenames in os.walk(root_dir):
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            if pattern_fn(full): out.append(full)
    return sorted(out)


def inject_nav_into_html(html_path, home_path, parent_name=None, parent_path=None):
    try:
        with open(html_path, "r", encoding="utf-8") as f:
            content = f.read()
        soup = BeautifulSoup(content, "html.parser")
        if soup.find(class_="report-nav"): return

        current_dir = os.path.dirname(html_path)
        home_rel = os.path.relpath(home_path, current_dir).replace(os.path.sep, "/")
        crumbs = [f'<a href="{escape(home_rel)}">🏠 System Resource Report Home</a>']

        if parent_path and parent_name:
            p_rel = os.path.relpath(parent_path, current_dir).replace(os.path.sep, "/")
            crumbs.append(f'<span class="sep">/</span><a href="{escape(p_rel)}">{escape(parent_name)}</a>')

        title = soup.title.string if soup.title else os.path.basename(html_path)
        crumbs.append(f'<span class="sep">/</span><span>{escape(title)}</span>')

        nav_div = soup.new_tag("div", attrs={"class": "report-nav"})
        nav_div.append(BeautifulSoup(NAV_STYLE + f"<div>{' '.join(crumbs)}</div>", "html.parser"))

        if soup.body: soup.body.insert(0, nav_div)
        else: soup.insert(0, nav_div)

        with open(html_path, "w", encoding="utf-8") as f:
            f.write(str(soup))
    except Exception: pass


def build_top_level_report(out_base, summary_links):
    top_html = os.path.join(out_base, "System_Resource_Report.html")
    with open(top_html, "w", encoding="utf-8") as f:
        f.write(f"<html><head><title>System Resource Report</title>{STYLE_TOP}</head><body>")
        f.write('<div class="title">System Resource Report</div><li class="level1">Performance Dashboards</li><ul>')
        for name, path in summary_links.items():
            if path:
                rel = os.path.relpath(path, out_base).replace(os.path.sep, "/")
                f.write(f'<li class="level2"><a href="{rel}">{name}</a></li>')
            else:
                f.write(f'<li class="level2" style="color:gray;">{name} (No Data)</li>')
        f.write("</ul></body></html>")
    return top_html


def process_single_dataset(input_dir, json_file, limits_file, output_arg):
    name = os.path.basename(os.path.normpath(input_dir))
    folder_name = (
        name.replace("System_Resource_Raw_Data", "System_Resource_Report", 1)
        if "System_Resource_Raw_Data" in name
        else f"System_Resource_Report_{name}"
    )

    out_base = ensure_outdir(os.path.join(output_arg, folder_name))
    log_step(f"Processing Data Folder: {os.path.abspath(input_dir)}")

    tasks = [
        ("Memory", "memory/pmap_pipeline.py", os.path.join(out_base, "memory"), json_file, os.path.join(os.path.dirname(__file__), "memory", "smoketest_limits.json")),
        #("Memory", "memory/pmap_pipeline.py", os.path.join(out_base, "memory"), json_file, "memory/smoketest_limits.json"),
        ("CPU/Runtime", "runtime/runtime_pipeline.py", os.path.join(out_base, "runtime"), json_file, None),
        ("DDR Bandwidth", "ram_bandwidth/ram_bandwidth_pipeline.py", os.path.join(out_base, "ddr_bandwidth"), None, None),
    ]

    results = {}
    for task_name, script, out_dir, j_file, l_file in tasks:
        ensure_outdir(out_dir)
        if run_pipeline(task_name, script, input_dir, j_file, out_dir, l_file):
            results[task_name] = out_dir

    summary_pages = {
        "Memory Usage": find_file_recursive(results.get("Memory"), lambda p: "Memory_Usage_Report" in p and p.endswith(".html")),
        "CPU Runtime": find_file_recursive(results.get("CPU/Runtime"), lambda p: "Runtime_Memory_Report" in p and p.endswith(".html")),
        "DDR Bandwidth": find_file_recursive(results.get("DDR Bandwidth"), lambda p: "Bandwidth_Summary" in p and p.endswith(".html")),
    }

    top_report = build_top_level_report(out_base, summary_pages)

    for label, s_page in summary_pages.items():
        if s_page:
            inject_nav_into_html(s_page, top_report)
            for detail in find_all_files_recursive(os.path.dirname(s_page), lambda p: p.endswith(".html") and os.path.abspath(p) != os.path.abspath(s_page)):
                inject_nav_into_html(detail, top_report, parent_name=label, parent_path=s_page)
    return top_report


def main():
    parser = argparse.ArgumentParser(description="System Resource Analysis Pipeline")
    parser.add_argument("-i", "--input", help="Single input directory")
    parser.add_argument("-j", "--json", help="Domain lookup JSON")
    parser.add_argument("-l", "--limits", help="Thresholds JSON")
    parser.add_argument("-o", "--output", default="./System_Resource_Report", help="Output root directory")
    parser.add_argument("-a", "--all_path", help="Batch mode: parent directory to scan")
    parser.add_argument("-z", "--zip", action="store_true", help="ZIP the total output folder")
    # ✅ 修复核心问题：添加缺失的 --no-timestamp 参数
    parser.add_argument("--no-timestamp", action="store_true", help="Disable timestamp in output dir")
    args = parser.parse_args()

    # 绝对路径初始化
    output_root = os.path.abspath(args.output)
    if args.json:
        args.json = os.path.abspath(args.json)
        log_step(f"Domain Lookup JSON: {args.json}")
    
    # ✅ 优化：Web 模式下不删除已有目录（避免误删 Task 唯一目录）
    ensure_outdir(output_root)

    # 识别目标目录
    target_dirs = []
    if args.all_path:
        search_path = os.path.join(args.all_path, "*")
        all_sub_items = sorted(glob.glob(search_path))
        target_dirs = [d for d in all_sub_items if os.path.isdir(d)]
        
        if not target_dirs:
            log_step("No directories found in all_path.", "FAIL")
            sys.exit(1)
        log_step(f"Batch Mode: Found {len(target_dirs)} folders.", "BATCH")
    elif args.input:
        target_dirs = [args.input]
    else:
        parser.print_help()
        sys.exit(1)

    # 执行任务
    final_reports = []
    for directory in target_dirs:
        print(f"\n{'-' * 30} SUB-TASK START {'-' * 30}")
        report_path = process_single_dataset(directory, args.json, args.limits, output_root)
        final_reports.append(report_path)

    # ZIP 压缩
    if args.zip:
        print(f"\n{'-' * 30} COMPRESSION {'-' * 30}")
        try:
            fix_timestamps_for_zip(output_root)
            zip_file = shutil.make_archive(output_root, "zip", output_root)
            log_step(f"Archive created: {zip_file}", "DONE")
        except Exception as e:
            log_step(f"Compression failed: {e}", "FAIL")

    print(f"\n{'=' * 75}\n ALL ANALYSIS COMPLETED\n Total Processed: {len(final_reports)}")
    for r in final_reports:
        print(f" -> {r}")
    print(f"{'=' * 75}\n")


if __name__ == "__main__":
    main()

