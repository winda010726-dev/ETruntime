#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import matplotlib

matplotlib.use("Agg")

import argparse
import glob
import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

STYLE = """
<style>
body {font-family: Arial, sans-serif; margin: 20px;}
h1,h2 {background-color: #2b5797; color: white; padding: 10px;}
.table {border-collapse: collapse; width: 100%;}
.table th, .table td {border: 1px solid #dddddd; text-align: right; padding: 6px;}
.table tr:nth-child(even) {background-color: #f9f9f9;}
.table th {background-color: #4CAF50; color: white; text-align: center;}
.img-box img {max-width:100%; height:auto; display:block; margin-bottom:20px;}
</style>
"""


def ensure_outdir(path):
    os.makedirs(path, exist_ok=True)
    return os.path.abspath(path)


def parse_file(filename):
    times = []
    input_bytes = []
    output_bytes = []
    input_packets = []
    output_packets = []

    with open(filename, "r") as f:
        for line in f:
            parts = line.split()
            if len(parts) >= 10 and parts[0].isdigit():
                in_packets = int(parts[0])
                in_bytes = int(parts[3])
                out_packets = int(parts[4])
                out_bytes = int(parts[6])

                times.append(len(times) + 1)
                input_bytes.append(in_bytes)
                output_bytes.append(out_bytes)
                input_packets.append(in_packets)
                output_packets.append(out_packets)

    return times, input_bytes, output_bytes, input_packets, output_packets


def plot_range_line(series_read, series_write, series_sum, out_png, title=None, ymin=0):
    series_read_plot = np.array(series_read) / 1024 / 1024
    series_write_plot = np.array(series_write) / 1024 / 1024
    series_sum_plot = (np.array(series_read) + np.array(series_write)) / 1024 / 1024

    fig, ax = plt.subplots(figsize=(12, 4))
    ax.plot(series_read_plot, label="Input", color="blue", linewidth=1.5)
    ax.plot(series_write_plot, label="Output", color="red", linewidth=1.5)
    ax.plot(series_sum_plot, label="Total", color="green", linewidth=1.5)
    ax.set_xlabel("Time")
    ax.set_xticks([])
    ax.set_ylabel("Bandwidth Usage (MB/s)")
    if title:
        ax.set_title(title)
    ax.grid(True, linestyle="--", alpha=0.5)
    ax.legend(frameon=False)
    ax.set_ylim(bottom=ymin)
    plt.tight_layout()
    fig.savefig(out_png)
    plt.close(fig)


def safe_name(s):
    import re

    return re.sub(r"[^0-9A-Za-z_\-]+", "_", s)


def process_file(input_file, output_dir):
    times, in_bytes, out_bytes, _, _ = parse_file(input_file)

    range_name = os.path.splitext(os.path.basename(input_file))[0]
    nic_name = range_name.replace("_bandwidth", "")
    safe_range = safe_name(range_name)

    png_path = os.path.join(output_dir, f"{safe_range}.png")
    plot_range_line(in_bytes, out_bytes, np.array(in_bytes) + np.array(out_bytes), png_path, title=range_name)

    stats_table = pd.DataFrame(
        [
            {
                "NIC": nic_name,
                "Metric": "Bandwidth Usage (MB/s)",
                "Input Avg": np.mean(in_bytes) / 1024 / 1024,
                "Input Max": np.max(in_bytes) / 1024 / 1024,
                "Output Avg": np.mean(out_bytes) / 1024 / 1024,
                "Output Max": np.max(out_bytes) / 1024 / 1024,
                "Total Avg": np.mean(np.array(in_bytes) + np.array(out_bytes)) / 1024 / 1024,
                "Total Max": np.max(np.array(in_bytes) + np.array(out_bytes)) / 1024 / 1024,
            }
        ]
    )
    return (range_name, png_path), stats_table


def generate_summary_html(per_range_list, stats_table, out_html):
    with open(out_html, "w", encoding="utf-8") as out:
        out.write(f"<html><head><meta charset='utf-8'>{STYLE}</head><body>")
        out.write("<h1>ETH Traffic Report</h1>")
        out.write("<h2>Statistics Summary</h2>")
        out.write(stats_table.to_html(classes="table", float_format="%.2f", index=False, border=0))
        out.write("<h2>NIC Bandwidth Graphs</h2>")
        for rname, png in per_range_list:
            out.write(f'<div class="img-box"><img src="{os.path.basename(png)}" alt="{rname}"></div>')

        out.write("</body></html>")


def main():
    parser = argparse.ArgumentParser(description="Generate ETH traffic summary report.")
    parser.add_argument("-i", "--input", required=True, help="Input folder containing ETH bandwidth txt files")
    parser.add_argument("-o", "--output", default="./output", help="Output directory")
    args = parser.parse_args()

    input_dir = args.input
    output_dir = ensure_outdir(args.output)

    txt_files = sorted(glob.glob(os.path.join(input_dir, "eth_dwceqos*_bandwidth.txt")))
    if not txt_files:
        print(f"No matching TXT files in {input_dir}")
        return

    per_range_list = []
    stats_tables = []
    for txt_file in txt_files:
        per_range, stats_table = process_file(txt_file, output_dir)
        per_range_list.append(per_range)
        stats_tables.append(stats_table)

    stats_combined = pd.concat(stats_tables, ignore_index=True)
    summary_html = os.path.join(output_dir, "ETH_Summary.html")
    generate_summary_html(per_range_list, stats_combined, summary_html)
    # print(f"Generated summary report at: {summary_html}")


if __name__ == "__main__":
    main()
