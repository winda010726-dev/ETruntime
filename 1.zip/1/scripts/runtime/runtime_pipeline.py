#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import matplotlib

matplotlib.use("Agg")

import argparse
import base64
import io
import json
import os
import re
import shutil
import sys
from copy import copy

import dataframe_image as dfi
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pypandoc
from bs4 import BeautifulSoup
from openpyxl import load_workbook
from openpyxl.drawing.image import Image
from openpyxl.styles import Alignment, Font
from openpyxl.utils import get_column_letter

plt.rcParams["svg.fonttype"] = "none"
html_counter = 1


def get_kdmips_factor(input_dir):
    """Detect hardware version from version.txt and set the KDMIPS conversion factor."""
    version_path = os.path.join(input_dir, "version.txt")
    kdmips_factor = 23

    if os.path.exists(version_path):
        try:
            with open(version_path, "r", encoding="utf-8") as f:
                content = f.read()
                match = re.search(r"Board_Name:\s*(\S+)", content)
                if match:
                    board_name = match.group(1).strip()
                    print(f"Detected Board_Name: {board_name}")
                    if "MPC4_2B" in board_name:
                        kdmips_factor = 27
                    elif "MPC4_1B" in board_name:
                        kdmips_factor = 23
                    else:
                        print(f"Unknown board version in {board_name}, using default 23")
        except Exception as e:
            print(f"Warning: Failed to parse version.txt: {e}")
    else:
        print("Warning: version.txt not found, using default KDMIPS factor: 23")

    print(f"KDMIPS factor set to: {kdmips_factor}")
    return kdmips_factor


def export_html_table(
    df, title, output_dir, file_suffix=None, index=False, extra_html=None, header_bg="#4CAF50", add_prefix=True
):
    """Export a DataFrame to a styled HTML table file."""
    global html_counter
    if output_dir is not None:
        os.makedirs(output_dir, exist_ok=True)

    prefix = f"{html_counter:02d}_" if add_prefix and file_suffix else ""
    if file_suffix:
        file_suffix = prefix + file_suffix
        html_path = os.path.join(output_dir, file_suffix)
    else:
        html_path = None

    html = df.to_html(classes="table table-bordered table-striped", escape=False, index=index)
    soup = BeautifulSoup(html, "html.parser")

    style = f"""
    <style>
    body {{font-family: Arial, sans-serif; margin: 30px;}}
    h2 {{background-color: #2b5797; color: white; padding: 10px; border-radius: 8px;}}
    table {{border-collapse: collapse; width: 100%;}}
    th, td {{border: 1px solid #dddddd; text-align: right; padding: 8px;}}
    tr:nth-child(even) {{background-color: #f9f9f9;}}
    th {{background-color: {header_bg}; color: white;}}
    a.back-link {{display:block; margin-bottom:10px; font-size:14px;}}
    .total {{font-weight: bold; background-color: #ffe699;}}
    </style>
    """

    extra = extra_html or ""

    for row in soup.find_all("tr"):
        first_cell = row.find(["th", "td"])
        if first_cell and first_cell.text.strip() in ("0", "Total"):
            row["class"] = row.get("class", []) + ["total"]

    body_html = f"<html><head>{style}</head><body>{''}<h2>{title}</h2>{extra}{str(soup)}</body></html>"

    if html_path:
        with open(html_path, "w", encoding="utf-8") as f:
            f.write(body_html)
        html_counter += 1
        return html_path
    else:
        return body_html


def write_csv_to_xlsx(csv_file: str, xlsx_file: str):
    """Clean raw CSV logs (remove timer skips/errors) and save formatted data to Excel."""
    with open(csv_file, "r", encoding="utf-8") as f:
        raw_lines = f.readlines()

    lines_after_timer_filter = []
    skip_count = 0
    for line in raw_lines:
        if skip_count > 0:
            skip_count -= 1
            continue
        if "Timer skip!" in line:
            skip_count = 1
            continue
        lines_after_timer_filter.append(line)

    error_pattern = re.compile(r"Failed to (?:open|get|find)[^;\n]+")

    final_csv_rows = []
    current_row_buffer = ""

    for line in lines_after_timer_filter:
        clean_line = error_pattern.sub("", line).strip()
        if not clean_line:
            continue

        is_new_cycle_start = clean_line.startswith("cycle;") or re.match(r"^\d+;", clean_line)

        if is_new_cycle_start:
            if current_row_buffer:
                final_csv_rows.append(current_row_buffer)
            current_row_buffer = clean_line
        else:
            if current_row_buffer:
                if not current_row_buffer.endswith(";") and not clean_line.startswith(";"):
                    current_row_buffer += ";" + clean_line
                else:
                    current_row_buffer += clean_line
            else:
                current_row_buffer = clean_line

    if current_row_buffer:
        final_csv_rows.append(current_row_buffer)

    valid_data = [r + "\n" for r in final_csv_rows if ";" in r and "Failed" not in r]

    if not valid_data:
        raise ValueError(f"No valid data produced after cleaning {csv_file}. Please check the log content.")

    tmp_csv = csv_file + ".clean"
    with open(tmp_csv, "w", encoding="utf-8") as f:
        f.writelines(valid_data)

    def _to_number_if_possible(val):
        if pd.isna(val):
            return val
        if isinstance(val, (int, float, np.integer, np.floating)):
            return val
        if isinstance(val, str):
            s = val.strip()
            if s == "":
                return val
            if re.fullmatch(r"[+-]?\d+(\.\d+)?", s):
                try:
                    return int(s) if "." not in s else float(s)
                except:
                    return val
        return val

    df = pd.read_csv(tmp_csv, header=None, dtype=str)
    df = df.map(_to_number_if_possible)
    df.to_excel(xlsx_file, index=False, header=False)


def split_origin_firstcol(sheet):
    """Process the Origin sheet by splitting the first column (semicolon-separated) into multiple columns."""
    max_row = sheet.max_row
    new_data = []
    for r in range(1, max_row + 1):
        cell_value = sheet.cell(row=r, column=1).value
        if cell_value is None:
            new_data.append([])
        else:
            parts = str(cell_value).split(";")
            new_data.append(parts)

    sheet.delete_rows(1, max_row)

    def _to_number_if_possible_simple(val):
        if val is None:
            return val
        if isinstance(val, (int, float, np.integer, np.floating)):
            return val
        s = str(val).strip()
        if s == "":
            return s
        if re.fullmatch(r"[+-]?\d+(\.\d+)?", s):
            try:
                return int(s) if "." not in s else float(s)
            except:
                return s
        return s

    for r_idx, row_data in enumerate(new_data, start=1):
        for c_idx, val in enumerate(row_data, start=1):
            sheet.cell(row=r_idx, column=c_idx, value=_to_number_if_possible_simple(val))


def create_static_sheet_from_origin(wb, origin_sheet):
    """Transpose data from the Origin sheet into a new Static sheet for easier statistical analysis."""
    static_sheet = wb.create_sheet("Static")
    max_row, max_col = origin_sheet.max_row, origin_sheet.max_column
    for r in range(1, max_row + 1):
        for c in range(1, max_col + 1):
            val = origin_sheet.cell(row=r, column=c).value
            if val is not None:
                try:
                    val = float(val)
                except:
                    pass
            static_sheet.cell(row=c, column=r, value=val)
    return static_sheet


def step6_static_prepare(static_sheet):
    """Prepare the Static sheet layout by deleting redundant rows and inserting columns for calculation."""
    static_sheet.delete_rows(1)
    static_sheet.delete_rows(1)
    static_sheet.insert_rows(1)
    static_sheet.insert_cols(1)
    static_sheet.insert_cols(3, amount=10)
    max_row_static = static_sheet.max_row
    max_col_static = static_sheet.max_column
    data_start_col = 13
    last_data_row = max(
        r
        for r in range(2, max_row_static + 1)
        if any(static_sheet.cell(row=r, column=c).value not in (None, "") for c in range(1, max_col_static + 1))
    )
    return max_row_static, max_col_static, data_start_col, last_data_row


def compute_kdmips_from_values(values, kdmips_factor=23):
    """Calculate Hist99, Average, Max, Min, and the resulting KDMIPS load from raw time values."""
    if not values:
        return [None] * 10  # C..L
    hist99 = float(np.percentile(values, 99))
    avg = float(np.mean(values))
    maxv = float(np.max(values))
    minv = float(np.min(values))

    g_val = hist99 / 250_000_000 * 100  # Hist99 % of 1 J6B Core
    h_val = g_val / 400 * kdmips_factor
    i_val = avg / 250_000_000 * 100  # Avg % of 1 J6B Core
    j_val = i_val / 400 * kdmips_factor
    k_val = maxv / 250_000_000 * 100 / 400 * kdmips_factor
    l_val = maxv / 250_000_000 * 100  # MAX % of 1 J6B Core
    return hist99, avg, maxv, minv, g_val, h_val, i_val, j_val, k_val, l_val


def write_formulas_and_formats(static_sheet, data_start_col, max_col_static, last_data_row):
    """Apply statistical formulas (PERCENTILE, AVERAGE) and cell formatting to the Static sheet."""
    for row in range(2, last_data_row + 1):
        row_str = str(row)
        last_col_letter = get_column_letter(max_col_static)

        static_sheet.cell(
            row=row,
            column=3,
            value=f"=PERCENTILE({get_column_letter(data_start_col)}{row_str}:{last_col_letter}{row_str},0.99)",
        )
        static_sheet.cell(
            row=row,
            column=4,
            value=f"=AVERAGE({get_column_letter(data_start_col)}{row_str}:{last_col_letter}{row_str})",
        )
        static_sheet.cell(
            row=row, column=5, value=f"=MAX({get_column_letter(data_start_col)}{row_str}:{last_col_letter}{row_str})"
        )
        static_sheet.cell(
            row=row, column=6, value=f"=MIN({get_column_letter(data_start_col)}{row_str}:{last_col_letter}{row_str})"
        )

        for col in range(3, 7):
            static_sheet.cell(row=row, column=col).number_format = "0"
        for col in range(7, 13):
            static_sheet.cell(row=row, column=col).number_format = "0.00"


def write_headers_and_lookup(static_sheet, json_path, last_data_row):
    """Add table headers and map each Process to its corresponding Cluster (Domain) using a JSON lookup."""
    column_names = [
        "Cluster from Lookup",
        "Process",
        "Hist99 Time",
        "Avg Time",
        "Max Time",
        "Min Time",
        "Hist99 % of 1 J6B Core",
        "Hist99 KDMIPS",
        "Avg % of 1 J6B Core",
        "Avg KDMIPS",
        "Max KDMIPS",
        "MAX % of 1 J6B Core",
    ]

    for col_idx, name in enumerate(column_names, start=1):
        cell = static_sheet.cell(row=1, column=col_idx, value=name)
        cell.font = Font(bold=True)
        cell.alignment = Alignment(wrap_text=True)

    if json_path and os.path.exists(json_path):
        with open(json_path, "r") as f:
            domain_lookup = json.load(f)

        for row in range(2, last_data_row + 1):
            b_val = static_sheet.cell(row=row, column=2).value
            found_domain = "NA"
            if b_val:
                b_val_clean = b_val.split("<")[0]
                for domain, names in domain_lookup.items():
                    if b_val_clean in names:
                        found_domain = domain
                        break
            static_sheet.cell(row=row, column=1, value=found_domain)


def move_abnormal_rows(static_sheet, data_start_col, max_col_static):
    """Identify and move high-load rows (>600% CPU) to a separate 'Abnormal' sheet."""
    rows_to_move = []
    max_row_static = static_sheet.max_row
    for row in range(2, max_row_static + 1):
        data_values = [
            float(static_sheet.cell(row=row, column=col).value or 0)
            for col in range(data_start_col, max_col_static + 1)
        ]
        if data_values:
            c_val_num = sorted(data_values)[int(len(data_values) * 0.99) - 1]
        else:
            c_val_num = 0
        g_val_num = c_val_num / 250_000_000 * 100
        i_val_num = (sum(data_values) / len(data_values)) / 250_000_000 * 100 if data_values else 0
        l_val_num = max(data_values) / 250_000_000 * 100 if data_values else 0
        if g_val_num > 600 or i_val_num > 600 or l_val_num > 600:
            rows_to_move.append(row)
    if not rows_to_move:
        return None
    abnormal_sheet = static_sheet.parent.create_sheet("Abnormal")

    for col in range(1, 13):
        src = static_sheet.cell(row=1, column=col)
        dest = abnormal_sheet.cell(row=1, column=col, value=src.value)
        dest.font = copy(src.font)
        dest.alignment = copy(src.alignment)
        dest.number_format = src.number_format

    for idx, orig_row in enumerate(rows_to_move, start=2):
        for col in range(1, max_col_static + 1):
            val = static_sheet.cell(orig_row, col).value
            if isinstance(val, str) and val.startswith("="):
                val = re.sub(r"([A-Z]+)(\d+)", lambda m: f"{m.group(1)}{idx}", val)
            dest = abnormal_sheet.cell(idx, col, val)
            src = static_sheet.cell(orig_row, col)
            dest.font = copy(src.font)
            dest.alignment = copy(src.alignment)
            dest.number_format = src.number_format
    for row_idx in sorted(rows_to_move, reverse=True):
        static_sheet.delete_rows(row_idx)
    return abnormal_sheet


def compute_and_write_values(static_sheet, data_start_col, max_col_static, kdmips_factor=23):
    """Iterate through the Static sheet to calculate and write final statistical results to cells."""
    max_row_static = static_sheet.max_row
    for row in range(2, max_row_static + 1):
        values = []
        for col in range(data_start_col, max_col_static + 1):
            v = static_sheet.cell(row=row, column=col).value
            try:
                if v is not None:
                    values.append(float(v))
            except:
                pass
        res = compute_kdmips_from_values(values, kdmips_factor=kdmips_factor)
        hist99, avg, maxv, minv, g_val, h_val, i_val, j_val, k_val, l_val = res

        for col, val in zip(range(3, 13), [hist99, avg, maxv, minv, g_val, h_val, i_val, j_val, k_val, l_val]):
            cell = static_sheet.cell(row=row, column=col, value=val)
            cell.number_format = "0" if col <= 6 else "0.00"


def add_total_row(df, sum_cols):
    """Add a summary 'Total' row to a DataFrame for specific columns."""
    df_copy = df.copy()
    columns = df_copy.columns.tolist()

    total_data = {}
    for col in columns:
        if col in sum_cols:
            total_data[col] = df_copy[col].sum()
        elif col == "No.":
            total_data[col] = 0
        else:
            total_data[col] = "Total"

    df_total = pd.DataFrame([total_data], columns=columns)

    if "No." in df_copy.columns:
        df_copy["No."] = range(1, len(df_copy) + 1)

    df_new = pd.concat([df_total, df_copy], ignore_index=True)
    return df_new


def add_top_trace_plot(output_dir, extra_html="", top_trace_dir=None):
    """Parse top_trace.txt and plot real-time CPU usage across 4 cores for the HTML report."""
    if top_trace_dir is None:
        top_trace_dir = output_dir
    txt_path = os.path.join(top_trace_dir, "top_trace.txt")
    if not os.path.exists(txt_path):
        return extra_html

    cpu_data = {0: [], 1: [], 2: [], 3: []}
    timestamps = []

    with open(txt_path, "r") as f:
        lines = f.readlines()

    current_snapshot_cpus = set()

    for line in lines:
        if line.startswith("---") and "Executing:" in line:
            timestamps.append(line.strip().split("Executing:")[0].replace("---", "").strip())
            current_snapshot_cpus = set()

        elif line.startswith("CPU  "):
            parts = line.split()
            if len(parts) >= 3:
                try:
                    cpu_id_str = parts[1].replace(":", "")
                    if cpu_id_str.isdigit():
                        cpu_id = int(cpu_id_str)
                        idle_curr = float(parts[2].replace("%", ""))
                        usage = 100.0 - idle_curr
                        cpu_data[cpu_id].append(usage)
                        current_snapshot_cpus.add(cpu_id)
                except (ValueError, IndexError):
                    continue

    min_len = len(timestamps)
    for i in range(4):
        min_len = min(min_len, len(cpu_data[i]))

    timestamps = timestamps[:min_len]
    for i in range(4):
        cpu_data[i] = cpu_data[i][:min_len]

    SKIP_POINTS = 2
    if len(timestamps) > SKIP_POINTS:
        timestamps = timestamps[SKIP_POINTS:]
        for cpu_id in cpu_data:
            cpu_data[cpu_id] = cpu_data[cpu_id][SKIP_POINTS:]
    else:
        print(f"Warning: Not enough data points to skip {SKIP_POINTS} samples.")
        if len(timestamps) == 0:
            return extra_html

    fig, ax = plt.subplots(figsize=(14, 7), dpi=100)
    colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728"]
    for cpu_id in range(4):
        ax.plot(cpu_data[cpu_id], label=f"CPU {cpu_id}", color=colors[cpu_id], linewidth=1.5)

    ax.set_xlabel("Time (Timeline)")
    ax.set_ylabel("CPU Usage (%)")
    ax.set_title("Top CPU Usage (Real-time)")
    ax.set_ylim(0, 105)
    ax.legend(loc="upper right")
    ax.grid(True, linestyle="--", alpha=0.6)

    ax.set_xticks([])

    plt.tight_layout()
    plot_file1 = os.path.join(output_dir, "Top_Trace.png")
    plt.savefig(plot_file1, dpi=100)
    plt.close(fig)

    with open(plot_file1, "rb") as f:
        encoded_img = base64.b64encode(f.read()).decode("utf-8")
        extra_html += f'<h3>Real-time CPU Usage (from Top)</h3><img src="data:image/png;base64,{encoded_img}" />'

    return extra_html


def pivot_and_chart(static_sheet, wb, output_dir, extra_html=""):
    """Generate pivot tables, KDMIPS bar charts by domain, and an overview HTML summary."""
    top_trace_html = add_top_trace_plot(output_dir, "")
    if top_trace_html:
        extra_html = top_trace_html + extra_html
    data_iter = static_sheet.values
    cols = next(data_iter)
    df = pd.DataFrame(data_iter, columns=cols)

    for col in ["Hist99 KDMIPS", "Avg KDMIPS", "Max KDMIPS"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df_grouped = df.groupby(["Cluster from Lookup", "Process"], as_index=False)[
        ["Hist99 KDMIPS", "Avg KDMIPS", "Max KDMIPS"]
    ].mean()

    if "Pivot" in wb.sheetnames:
        del wb["Pivot"]
    ws_pivot = wb.create_sheet("Pivot")
    rows_out = [df_grouped.columns.tolist()] + df_grouped.values.tolist()
    for r_idx, row in enumerate(rows_out, start=1):
        for c_idx, val in enumerate(row, start=1):
            cell = ws_pivot.cell(r_idx, c_idx, val)
            if r_idx > 1 and c_idx in (3, 4, 5):
                cell.number_format = "0.00"

    df_cluster = df.groupby("Cluster from Lookup")[["Hist99 KDMIPS", "Avg KDMIPS", "Max KDMIPS"]].sum()
    domains = df_cluster.index
    n_groups = len(domains)
    n_bars = len(df_cluster.columns)
    bar_width = 0.25
    gap = 0.07
    x = np.arange(n_groups) * 1.5
    fig, ax = plt.subplots(figsize=(14, 7))
    for i, col in enumerate(df_cluster.columns):
        offset = i * (bar_width + gap) - (n_bars - 1) * (bar_width + gap) / 2
        bars = ax.bar(x + offset, df_cluster[col], width=bar_width, label=col)
        ax.bar_label(bars, fmt="%.2f", padding=3)
    ax.set_xticks(x)
    ax.set_xticklabels(domains)
    plt.ylabel("KDMIPS")
    plt.title("CPU Usage by Domain")
    plt.legend()
    plt.tight_layout()
    chart_file = os.path.join(output_dir, "Runtime Overview.png")
    plt.savefig(chart_file, dpi=100)
    plt.close(fig)

    img = Image(chart_file)
    ws_pivot.add_image(img, "G2")

    if os.path.exists(chart_file):
        with open(chart_file, "rb") as f:
            chart_b64 = base64.b64encode(f.read()).decode("utf-8")
        extra_html += f"<h3>CPU Usage by Domain</h3>"
        extra_html += f'<img src="data:image/png;base64,{chart_b64}" style="max-width:100%;"/>'

    df_grouped = df_grouped.sort_values("Hist99 KDMIPS", ascending=False).reset_index(drop=True)
    df_grouped.index = df_grouped.index + 1
    df_grouped.index.name = "No."

    df_grouped = add_total_row(df_grouped, ["Hist99 KDMIPS", "Avg KDMIPS", "Max KDMIPS"])

    fmt_cols = ["Hist99 KDMIPS", "Avg KDMIPS", "Max KDMIPS"]
    for c in fmt_cols:
        if c in df_grouped.columns:
            df_grouped[c] = df_grouped[c].apply(lambda x: float(np.round(x, 2)) if pd.notnull(x) else x)

    overview_html = export_html_table(
        df_grouped, title="Runtime Overview", output_dir=None, file_suffix=None, extra_html=extra_html
    )

    return df, df_grouped, overview_html


def export_domain_tables(df_grouped, output_dir):
    """Split and export the grouped statistics into individual HTML reports per Domain."""
    os.makedirs(output_dir, exist_ok=True)
    for domain, df_domain in df_grouped.groupby("Cluster from Lookup"):
        if str(domain).strip().lower() == "total":
            continue

        df_domain = df_domain.sort_values("Hist99 KDMIPS", ascending=False).reset_index(drop=True)
        df_domain.index = df_domain.index + 1
        df_domain.index.name = "No."
        df_domain = add_total_row(df_domain, ["Hist99 KDMIPS", "Avg KDMIPS", "Max KDMIPS"])

        export_html_table(
            df_domain, title=domain, output_dir=output_dir, file_suffix=f"{domain}_Runtime.html", index=True
        )


def abnormal_pivot_and_image(wb, static_sheet, data_start_col, max_col_static, output_dir, kdmips_factor=23):
    """Generate a specific pivot table and report for the data in the Abnormal sheet."""
    if "Abnormal" not in wb.sheetnames:
        return
    abnormal_sheet = wb["Abnormal"]
    data_iter = abnormal_sheet.values
    cols = next(data_iter)
    df_abn = pd.DataFrame(data_iter, columns=cols)
    raw_cols = df_abn.columns[data_start_col - 1 : max_col_static]

    def compute_kdmips_from_row(row):
        vals = pd.to_numeric(row[list(raw_cols)], errors="coerce").dropna().values
        if vals.size == 0:
            return pd.Series([np.nan, np.nan, np.nan], index=["Hist99 KDMIPS", "Avg KDMIPS", "Max KDMIPS"])
        hist99 = float(np.percentile(vals, 99))
        avg = float(np.mean(vals))
        maxv = float(np.max(vals))
        hist99_kdmips = hist99 / 250_000_000 * 100 / 400 * kdmips_factor
        avg_kdmips = avg / 250_000_000 * 100 / 400 * kdmips_factor
        max_kdmips = maxv / 250_000_000 * 100 / 400 * kdmips_factor
        return pd.Series([hist99_kdmips, avg_kdmips, max_kdmips], index=["Hist99 KDMIPS", "Avg KDMIPS", "Max KDMIPS"])

    df_abn_k = df_abn.apply(compute_kdmips_from_row, axis=1)
    df_abn[["Hist99 KDMIPS", "Avg KDMIPS", "Max KDMIPS"]] = df_abn_k

    df_abn_grouped = df_abn.groupby(["Cluster from Lookup", "Process"], as_index=False)[
        ["Hist99 KDMIPS", "Avg KDMIPS", "Max KDMIPS"]
    ].mean()

    df_abn_grouped = df_abn_grouped.sort_values("Hist99 KDMIPS", ascending=False).reset_index(drop=True)
    df_abn_grouped.index = df_abn_grouped.index + 1
    df_abn_grouped.index.name = "No."

    df_abn_grouped = add_total_row(df_abn_grouped, ["Hist99 KDMIPS", "Avg KDMIPS", "Max KDMIPS"])

    if "PivotAbnormal" in wb.sheetnames:
        del wb["PivotAbnormal"]
    ws_abn = wb.create_sheet("PivotAbnormal")
    rows_out = [df_abn_grouped.reset_index().columns.tolist()] + df_abn_grouped.reset_index().values.tolist()
    for r_idx, row in enumerate(rows_out, start=1):
        for c_idx, val in enumerate(row, start=1):
            cell = ws_abn.cell(r_idx, c_idx, val)
            if r_idx > 1 and c_idx in (4, 5, 6):
                cell.number_format = "0.00"

    export_html_table(
        df_abn_grouped,
        title="Abnormal CPU Usage (Pivot Table)",
        output_dir=output_dir,
        file_suffix="pivot_abnormal_table.html",
        index=True,
        header_bg="#f2f2f2",
    )


def convert_html_to_word(html_path, output_dir):
    """Convert the generated HTML report to a Word (.docx) document using Pandoc."""
    docx_path = os.path.join(output_dir, "00_Runtime_Memory_Report.docx")
    html_content = open(html_path, encoding="utf-8").read()
    pypandoc.convert_text(html_content, "docx", format="html", outputfile=docx_path, extra_args=["--standalone"])
    # print(f"Word report generated: {docx_path}")


def generate_summary_html(output_dir, overview_html=None):
    """Parse command-line arguments for input path, JSON lookup path, and output directory."""
    summary_html = os.path.join(output_dir, "00_Runtime_Memory_Report.html")

    html_files = [f for f in os.listdir(output_dir) if f.endswith(".html") and f != os.path.basename(summary_html)]
    html_files.sort()

    domain_files = [f for f in html_files if "_table" not in f and "pivot" not in f]

    style = """
    <style>
    body {font-family: Arial, sans-serif; margin: 30px;}
    h1,h2 {background-color: #2b5797; color: white; padding: 10px; border-radius: 8px;}
    table {border-collapse: collapse; width: 100%;}
    th, td {border: 1px solid #dddddd; text-align: right; padding: 8px;}
    tr:nth-child(even) {background-color: #f9f9f9;}
    th {background-color: #4CAF50; color: white;}
    a.back-link {display:block; margin-bottom:10px; font-size:14px;}
    .total {font-weight: bold; background-color: #ffe699;}
    </style>
    """

    with open(summary_html, "w", encoding="utf-8") as out:
        out.write(f"<html><head><title>Runtime Memory Usage Report</title>{style}</head><body>")
        out.write("<h1>Runtime Memory Summary Report</h1>")
        out.write("<h2>Contents</h2><ul>")

        for idx, f in enumerate(domain_files, start=1):
            name = re.sub(r"^\d+_", "", f)
            name = name.replace("_Runtime", "").replace(".html", "")
            out.write(f'<li><a href="{f}">{idx:02d} {name}</a></li>')

        out.write("</ul><hr>")

        if overview_html:
            soup = BeautifulSoup(overview_html, "html.parser")
            for row in soup.find_all("tr"):
                first_cell = row.find(["th", "td"])
                if first_cell and first_cell.text.strip() in ("0", "Total"):
                    row["class"] = row.get("class", []) + ["total"]
            body = soup.find("body")
            if body:
                out.write(str(body))
            else:
                out.write(overview_html)
            out.write("<hr>")

        for f in domain_files:
            with open(os.path.join(output_dir, f), "r", encoding="utf-8") as sub:
                soup = BeautifulSoup(sub.read(), "html.parser")

                for row in soup.find_all("tr"):
                    first_cell = row.find(["th", "td"])
                    if first_cell and first_cell.text.strip() in ("0", "Total"):
                        row["class"] = row.get("class", []) + ["total"]
                body = soup.find("body")
                if body:
                    out.write(str(body))
                else:
                    out.write(sub.read())
                out.write("<hr>")

        out.write("</body></html>")

    return summary_html


def parse_args():
    parser = argparse.ArgumentParser(description="CPU runtime post process")

    parser.add_argument(
        "-i",
        "--input",
        dest="input_path",
        required=True,
        help="Input CSV file or directory containing runtime_log*.csv",
    )

    parser.add_argument(
        "-j",
        "--json",
        dest="json_path",
        default=None,
        help="Path to domain_lookup.json (optional, default: script directory)",
    )

    parser.add_argument(
        "-o",
        "--output",
        dest="output_dir",
        default=None,
        help="Custom output directory (optional, default: script_dir/output)",
    )

    return parser.parse_args()


def resolve_input_csv(input_path: str):
    """Locate the input file or find the most recent runtime_log*.csv in a directory."""
    if os.path.isfile(input_path):
        return input_path
    if os.path.isdir(input_path):
        csv_candidates = [
            os.path.join(input_path, f)
            for f in os.listdir(input_path)
            if f.startswith("runtime_log") and f.endswith(".csv")
        ]

        if not csv_candidates:
            raise FileNotFoundError(f"No runtime_log*.csv found in {input_path}")
        return max(csv_candidates, key=os.path.getmtime)

    raise FileNotFoundError(f"Input path does not exist: {input_path}")


def runtime_process(input_path, json_path=None, output_dir=None):
    """Main execution flow: orchestrates log cleaning, calculation, charting, and report generation."""
    script_dir = os.path.dirname(os.path.abspath(__file__))

    if os.path.isfile(input_path):
        csv_file = input_path
        input_dir = os.path.dirname(input_path)
    else:
        input_dir = input_path
        csv_file = resolve_input_csv(input_path)

    kdmips_factor = get_kdmips_factor(input_dir)

    if output_dir is None:
        output_dir = os.path.join(script_dir, "output")
    os.makedirs(output_dir, exist_ok=True)

    if json_path is None:
        json_path = os.path.join(script_dir, "domain_lookup.json")

    base_name = os.path.basename(csv_file)
    file_name, _ = os.path.splitext(base_name)
    xlsx_file = os.path.join(output_dir, f"{file_name}.xlsx")

    write_csv_to_xlsx(csv_file, xlsx_file)
    wb = load_workbook(xlsx_file)
    sheet = wb.active
    sheet.title = "Origin"
    sheet.delete_rows(1)
    split_origin_firstcol(sheet)
    static_sheet = create_static_sheet_from_origin(wb, sheet)
    max_row_static, max_col_static, data_start_col, last_data_row = step6_static_prepare(static_sheet)
    write_formulas_and_formats(static_sheet, data_start_col, max_col_static, last_data_row)
    write_headers_and_lookup(static_sheet, json_path, last_data_row)

    move_abnormal_rows(static_sheet, data_start_col, max_col_static)
    compute_and_write_values(static_sheet, data_start_col, max_col_static, kdmips_factor=kdmips_factor)

    top_trace_path = os.path.join(input_dir, "top_trace.txt")
    if os.path.exists(top_trace_path):
        # print(f"Found top_trace.txt at: {top_trace_path}")
        shutil.copy2(top_trace_path, os.path.join(output_dir, "top_trace.txt"))
    else:
        print(f"Warning: top_trace.txt not found at {top_trace_path}")

    df, df_grouped, overview_html = pivot_and_chart(static_sheet, wb, output_dir)
    export_domain_tables(df_grouped, output_dir)

    abnormal_pivot_and_image(wb, static_sheet, data_start_col, max_col_static, output_dir, kdmips_factor=kdmips_factor)

    wb.save(xlsx_file)

    report_html_path = generate_summary_html(output_dir, overview_html=overview_html)
    convert_html_to_word(report_html_path, output_dir)

    # print(f"CPU usage post process done! KDMIPS Base: {kdmips_factor}. Output file: {xlsx_file}")


if __name__ == "__main__":
    args = parse_args()
    runtime_process(input_path=args.input_path, json_path=args.json_path, output_dir=args.output_dir)
