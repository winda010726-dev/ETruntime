#!/bin/bash

# Usage: ./get_bandwidth.sh <input_file.csv>

INPUT="$1"
if [[ ! -f "$INPUT" ]]; then
  echo "Usage: $0 <csv_file>"
  exit 1
fi

awk '
BEGIN {
    FS="|"   # Revert to pipe separator for main data parsing
    print "==================== Input File Statistics ===================="
    print "All numbers are in MiB/s"
    # Parse enabled subsystems from the input file
    enabled_subsys = "?"
    period = "?"
    nblocks = 0
    while ((getline line < ARGV[1]) > 0) {
        # Remove leading/trailing spaces, commas, quotes, carriage returns
        gsub(/^\s+|\s+$/, "", line)
        gsub(/[",\r\n]+$/, "", line)
        if (line ~ /subsys enabled:/) {
            sub(/.*subsys enabled:[ \t]*/, "", line)
            gsub(/[\t ]+$/, "", line)
            gsub(/[",\r\n]+$/, "", line)
            enabled_subsys = line
        }
        if (line ~ /period:/) {
            match(line, /period:[ ]*([0-9]+)/, arr)
            if (arr[1] != "") period = arr[1]
        }
        if (line ~ /^ *Read\|/ || line ~ /^ *Write\|/) nblocks++
    }
    close(ARGV[1])
    print "Enabled subsystems: " enabled_subsys
    print "Measurement period: " period " us"
    print "Number of measurement blocks: " int(nblocks/2)  # Each block has Read+Write
    print "=============================================================="
}
function norm(s) {
    gsub(/^[ \t\r\n,]+/, "", s)
    gsub(/[ \t\r\n,]+$/, "", s)
    return tolower(s)
}
function json_sanitize(s) {
    gsub(/\t+/, " ", s)           # Replace tabs with spaces
    gsub(/[\x00-\x09\x0B\x0C\x0E-\x1F]+/, "", s) # Remove other control chars
    return s
}
/Perf\(MiB\/s\)/ {
    split("", header)
    split("", range_names)
    for(i=2; i<=NF; i++) {
        field_clean = $i
        header[i]=field_clean
        field_norm = norm(field_clean)
        if (field_norm ~ /range[_ ]*sum$/ || field_norm ~ /^bandwidth$/ || field_norm ~ /^range[0-9]+:/) {
            range_names[i]=field_clean
        }
    }
    next
}
# Extract Read or Write values
/^[ \t]*Read\|/ || /^[ \t]*Write\|/ {
    type=$1
    gsub(/^[ \t]+|[ \t]+$/, "", type)
    for(i=2; i<=NF; i++) {
        gsub(/^[ \t]+|[ \t]+$/, "", $i)
        if (i == NF) gsub(/[\r\n]+$/, "", $i)
        if (range_names[i] != "") {
            values[type,range_names[i]] = (values[type,range_names[i]] == "" ? $i : values[type,range_names[i]] " " $i)
        }
    }
    next
}
END {
    # --- Aggregated data across all ranges ---
    # Find the index of Range_sum (sum of all channels) and Bandwidth
    range_sum_idx = -1
    bandwidth_idx = -1
    for (i in range_names) {
        field_norm = norm(range_names[i])
        if (field_norm ~ /range[_ ]*sum$/) {
            range_sum_idx = i
        }
        if (field_norm ~ /^bandwidth$/) {
            bandwidth_idx = i
        }
    }
    if (range_sum_idx == -1 && bandwidth_idx == -1) {
        print "No Range_sum or Bandwidth found for aggregation!"
        exit
    }
    if (range_sum_idx == -1) {
        print "Warning: No Range_sum found for aggregation! Only Bandwidth will be used."
    }
    if (bandwidth_idx == -1) {
        print "Warning: No Bandwidth found for aggregation! Only Range_sum will be used."
    }
    # --- Aggregated Data (on Range_sum) ---
    if (range_sum_idx != -1) {
        split(values["Read",range_names[range_sum_idx]], read_sums, " ")
        split(values["Write",range_names[range_sum_idx]], write_sums, " ")
        nblocks = length(read_sums)
        peak_read = min_read = sum_read = read_sums[1]+0
        peak_read_block = min_read_block = avg_read_block = 1
        for (i=1; i<=nblocks; i++) {
            v = read_sums[i]+0
            sum_read += v
            if (v > peak_read) { peak_read = v; peak_read_block = i }
            if (v < min_read) { min_read = v; min_read_block = i }
        }
        avg_read = sum_read / nblocks
        min_avg_diff = -1
        for (i=1; i<=nblocks; i++) {
            v = read_sums[i]+0
            diff = (v-avg_read); if (diff<0) diff=-diff
            if (min_avg_diff==-1 || diff<min_avg_diff) { min_avg_diff=diff; avg_read_block=i }
        }
        peak_write = min_write = sum_write = write_sums[1]+0
        peak_write_block = min_write_block = avg_write_block = 1
        for (i=1; i<=nblocks; i++) {
            v = write_sums[i]+0
            sum_write += v
            if (v > peak_write) { peak_write = v; peak_write_block = i }
            if (v < min_write) { min_write = v; min_write_block = i }
        }
        avg_write = sum_write / nblocks
        min_avgw_diff = -1
        for (i=1; i<=nblocks; i++) {
            v = write_sums[i]+0
            diff = (v-avg_write); if (diff<0) diff=-diff
            if (min_avgw_diff==-1 || diff<min_avgw_diff) { min_avgw_diff=diff; avg_write_block=i }
        }
        print""
        print "==================== Aggregated Data (on Range_sum) ===================="
        printf("Peak Read: %d (block %d)\n", peak_read, peak_read_block)
        printf("Min Read: %d (block %d)\n", min_read, min_read_block)
        printf("Average Read: %.2f (block %d)\n", avg_read, avg_read_block)
        printf("Peak Write: %d (block %d)\n", peak_write, peak_write_block)
        printf("Min Write: %d (block %d)\n", min_write, min_write_block)
        printf("Average Write: %.2f (block %d)\n", avg_write, avg_write_block)
        print "=============================================================="
        print""
    }
    # --- Aggregated Data (on Bandwidth) ---
    if (bandwidth_idx != -1) {
        split(values["Read",range_names[bandwidth_idx]], read_bw, " ")
        split(values["Write",range_names[bandwidth_idx]], write_bw, " ")
        nblocks_bw = length(read_bw)
        peak_read_bw = min_read_bw = sum_read_bw = read_bw[1]+0
        peak_read_block_bw = min_read_block_bw = avg_read_block_bw = 1
        for (i=1; i<=nblocks_bw; i++) {
            v = read_bw[i]+0
            sum_read_bw += v
            if (v > peak_read_bw) { peak_read_bw = v; peak_read_block_bw = i }
            if (v < min_read_bw) { min_read_bw = v; min_read_block_bw = i }
        }
        avg_read_bw = sum_read_bw / nblocks_bw
        min_avg_diff_bw = -1
        for (i=1; i<=nblocks_bw; i++) {
            v = read_bw[i]+0
            diff = (v-avg_read_bw); if (diff<0) diff=-diff
            if (min_avg_diff_bw==-1 || diff<min_avg_diff_bw) { min_avg_diff_bw=diff; avg_read_block_bw=i }
        }
        peak_write_bw = min_write_bw = sum_write_bw = write_bw[1]+0
        peak_write_block_bw = min_write_block_bw = avg_write_block_bw = 1
        for (i=1; i<=nblocks_bw; i++) {
            v = write_bw[i]+0
            sum_write_bw += v
            if (v > peak_write_bw) { peak_write_bw = v; peak_write_block_bw = i }
            if (v < min_write_bw) { min_write_bw = v; min_write_block_bw = i }
        }
        avg_write_bw = sum_write_bw / nblocks_bw
        min_avgw_diff_bw = -1
        for (i=1; i<=nblocks_bw; i++) {
            v = write_bw[i]+0
            diff = (v-avg_write_bw); if (diff<0) diff=-diff
            if (min_avgw_diff_bw==-1 || diff<min_avgw_diff_bw) { min_avgw_diff_bw=diff; avg_write_block_bw=i }
        }
        print "==================== Aggregated Data (on Bandwidth) ===================="
        printf("Peak Read: %d (block %d)\n", peak_read_bw, peak_read_block_bw)
        printf("Min Read: %d (block %d)\n", min_read_bw, min_read_block_bw)
        printf("Average Read: %.2f (block %d)\n", avg_read_bw, avg_read_block_bw)
        printf("Peak Write: %d (block %d)\n", peak_write_bw, peak_write_block_bw)
        printf("Min Write: %d (block %d)\n", min_write_bw, min_write_block_bw)
        printf("Average Write: %.2f (block %d)\n", avg_write_bw, avg_write_block_bw)
        print "=============================================================="
        print""
    }
    print "==================== Details ===================="
    # Per-range stats
    for (i in range_names) {
        range = range_names[i]
        if (range == "") continue
        range_norm = norm(range)
        range_lookup = ""
        for (j in range_names) {
            test_norm = norm(range_names[j])
            if (test_norm == range_norm) {
                range_lookup = range_names[j]
                break
            }
        }
        print range
        for (ti=1; ti<=2; ti++) {
            t = (ti==1 ? "Read" : "Write")
            vals = values[t,range_lookup]
            print t ": " (vals == "" ? "-" : vals)
            # Compute min, avg, max
            n=0; sum=0; minv=""; maxv=""; arrlen=0
            split(vals, arr, " ")
            arrlen=length(arr)
            for (j=1; j<=arrlen; j++) {
                val = arr[j]
                val = norm(val)
                if (val ~ /^-?[0-9]+$/) {
                    v=val+0
                    if (minv=="" || v<minv) minv=v
                    if (maxv=="" || v>maxv) maxv=v
                    sum+=v
                    n++
                }
            }
            if (n>0) {
                avg = sum/n
                printf("  min: %d, avg: %.2f, max: %d\n", minv, avg, maxv)
            } else {
                print "  min: -, avg: -, max: -"
            }
        }
        print ""
    }

    # Prepare JSON output
    # Replace tabs with spaces for JSON validity
    enabled_subsys_json = json_sanitize(enabled_subsys)
    json = "{\n"
    json = json "  \"input_file_statistics\": {\n"
    json = json "    \"enabled_subsystems\": \"" enabled_subsys_json "\",\n"
    json = json "    \"measurement_period_us\": " period ",\n"
    json = json "    \"number_of_blocks\": " nblocks ",\n"
    json = json "    \"unit\": \"MiB/s\"\n"
    json = json "  },\n"

    # Aggregated Data (on Range_sum)
    json = json "  \"aggregated_data_range_sum\": {\n"
    json = json "    \"read\": {\n"
    json = json "      \"peak\": " peak_read ",\n"
    json = json "      \"peak_block\": " peak_read_block ",\n"
    json = json "      \"min\": " min_read ",\n"
    json = json "      \"min_block\": " min_read_block ",\n"
    json = json "      \"avg\": " avg_read ",\n"
    json = json "      \"avg_block\": " avg_read_block "\n"
    json = json "    },\n"
    json = json "    \"write\": {\n"
    json = json "      \"peak\": " peak_write ",\n"
    json = json "      \"peak_block\": " peak_write_block ",\n"
    json = json "      \"min\": " min_write ",\n"
    json = json "      \"min_block\": " min_write_block ",\n"
    json = json "      \"avg\": " avg_write ",\n"
    json = json "      \"avg_block\": " avg_write_block "\n"
    json = json "    }\n"
    json = json "  },\n"

    # Aggregated Data (on Bandwidth)
    json = json "  \"aggregated_data_bandwidth\": {\n"
    json = json "    \"read\": {\n"
    json = json "      \"peak\": " peak_read_bw ",\n"
    json = json "      \"peak_block\": " peak_read_block_bw ",\n"
    json = json "      \"min\": " min_read_bw ",\n"
    json = json "      \"min_block\": " min_read_block_bw ",\n"
    json = json "      \"avg\": " avg_read_bw ",\n"
    json = json "      \"avg_block\": " avg_read_block_bw "\n"
    json = json "    },\n"
    json = json "    \"write\": {\n"
    json = json "      \"peak\": " peak_write_bw ",\n"
    json = json "      \"peak_block\": " peak_write_block_bw ",\n"
    json = json "      \"min\": " min_write_bw ",\n"
    json = json "      \"min_block\": " min_write_block_bw ",\n"
    json = json "      \"avg\": " avg_write_bw ",\n"
    json = json "      \"avg_block\": " avg_write_block_bw "\n"
    json = json "    }\n"
    json = json "  },\n"

    # Details
    json = json "  \"details\": [\n"
    first_range = 1
    for (i in range_names) {
        range = range_names[i]
        if (range == "") continue
        range_norm = norm(range)
        range_lookup = ""
        for (j in range_names) {
            test_norm = norm(range_names[j])
            if (test_norm == range_norm) {
                range_lookup = range_names[j]
                break
            }
        }
        if (!first_range) json = json ",\n"
        first_range = 0
        json = json "    {\n"
        json = json "      \"range\": \"" json_sanitize(range) "\""
        for (ti=1; ti<=2; ti++) {
            t = (ti==1 ? "Read" : "Write")
            vals = values[t,range_lookup]
            n=0; sum=0; minv=""; maxv=""; arrlen=0
            split(vals, arr, " ")
            arrlen=length(arr)
            json = json ",\n      \"" tolower(t) "\": {\n"
            json = json "        \"values\": ["
            for (j=1; j<=arrlen; j++) {
                val = arr[j]
                val = norm(val)
                if (val ~ /^-?[0-9]+$/) {
                    if (j>1) json = json ", "
                    json = json val
                }
            }
            json = json "],\n"
            for (j=1; j<=arrlen; j++) {
                val = arr[j]
                val = norm(val)
                if (val ~ /^-?[0-9]+$/) {
                    v=val+0
                    if (minv=="" || v<minv) minv=v
                    if (maxv=="" || v>maxv) maxv=v
                    sum+=v
                    n++
                }
            }
            if (n>0) {
                avg = sum/n
                json = json "        \"min\": " minv ",\n"
                json = json "        \"avg\": " avg ",\n"
                json = json "        \"max\": " maxv "\n"
                json = json "      }"
            } else {
                json = json "        \"min\": null,\n"
                json = json "        \"avg\": null,\n"
                json = json "        \"max\": null\n"
                json = json "      }"
            }
        }
        json = json "\n    }"
    }
    json = json "\n  ]\n"
    json = json "}\n"
    # Write to file
    out = "bandwidth_report.json"
    print json > out
    close(out)
}
' "$INPUT"
