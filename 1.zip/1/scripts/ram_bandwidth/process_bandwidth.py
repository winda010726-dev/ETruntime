import argparse
import re
from collections import OrderedDict

import pandas as pd
import xlsxwriter


def parse_headers(header_line):
    headers = []
    for part in header_line.split("|")[1:-1]:
        match = re.search(r"(Range\d+):(.*)", part.strip())
        if match:
            headers.append((match.group(1), match.group(2).strip()))
    return headers


def parse_data_line(line, range_headers, timestamp):
    """Parse performance values from a single data row and map them to ranges."""
    parts = [x.strip() for x in line.split("|")]
    if len(parts) < len(range_headers) + 3:
        return None

    operation = parts[0]
    data = OrderedDict()
    for i, (range_num, range_name) in enumerate(range_headers):
        try:
            data[f"{range_num}:{range_name}"] = float(parts[i + 1].replace(",", "")) if parts[i + 1] else 0.0
        except ValueError:
            data[f"{range_num}:{range_name}"] = 0.0

    data["Range_sum"] = float(parts[-2].replace(",", "")) if parts[-2] else 0.0
    data["Bandwidth"] = float(parts[-1].replace(",", "")) if parts[-1] else 0.0
    data["Timestamp"] = timestamp
    return operation, data


def process_file(input_file):
    """Read the log file and extract all performance data into a structured DataFrame."""
    results = []
    range_headers = []
    in_data_section = False
    current_timestamp = None
    timestamp_counter = 0

    with open(input_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            if line.startswith("Elapsed time["):
                timestamp_counter += 1
                current_timestamp = timestamp_counter
                continue

            if "Range1:" in line and "Perf(MiB/s)" in line:
                range_headers = parse_headers(line)
                in_data_section = True
                continue

            if in_data_section and line.startswith(("Read|", "Write|")):
                parsed = parse_data_line(line, range_headers, current_timestamp)
                if parsed:
                    operation, data = parsed
                    data["Operation"] = operation
                    results.append(data)

    if not results:
        raise ValueError("No valid data found")

    return pd.DataFrame(results), range_headers


def create_overview_sheet(writer, df, range_headers):
    """Generate a summary sheet in Excel showing all metrics in a single table."""
    # Prepare data for overview sheet
    overview_data = []

    # Group by Timestamp and Operation
    grouped = df.groupby(["Timestamp", "Operation"])

    for (timestamp, operation), group in grouped:
        row_data = {"Timestamp": timestamp, "Category": operation}

        # Add all range columns
        for range_num, range_name in range_headers:
            col_name = f"{range_num}:{range_name}"
            row_data[col_name] = group[col_name].iloc[0] if col_name in group else 0.0

        # Add Range_sum and Bandwidth
        row_data["Range_sum"] = group["Range_sum"].iloc[0]
        row_data["Bandwidth"] = group["Bandwidth"].iloc[0]

        overview_data.append(row_data)

    # Convert to DataFrame
    overview_df = pd.DataFrame(overview_data)

    # Reorder columns to put Range_sum and Bandwidth at the end
    cols = ["Timestamp", "Category"] + [f"{num}:{name}" for num, name in range_headers] + ["Range_sum", "Bandwidth"]
    overview_df = overview_df[cols]

    # Write to overview sheet
    overview_df.to_excel(writer, sheet_name="Overview", index=False)

    # Format the overview sheet
    workbook = writer.book
    worksheet = writer.sheets["Overview"]

    # Auto-adjust column widths
    for i, col in enumerate(overview_df.columns):
        max_len = max(overview_df[col].astype(str).map(len).max(), len(str(col)))
        worksheet.set_column(i, i, max_len + 2)


def sanitize_sheet_name(name):
    """Clean range names to comply with Excel's worksheet naming restrictions."""
    # Replace illegal characters with underscores
    illegal_chars = r"[]:*?/\\"
    for char in illegal_chars:
        name = name.replace(char, "_")
    # Ensure that the name does not start or end with a single quotation mark
    name = name.strip("'")
    # Truncate to 31 characters
    return name[:31]


def generate_excel_with_charts(df, range_headers, output_path):
    """Create the final Excel workbook with data tables, statistics, and line charts."""
    with pd.ExcelWriter(output_path, engine="xlsxwriter") as writer:
        workbook = writer.book

        # Create overview sheet first
        create_overview_sheet(writer, df, range_headers)

        # Process regular ranges
        for range_num, range_name in range_headers:
            full_range_name = f"{range_num}:{range_name}"
            # Prepare data
            range_df = df[["Operation", full_range_name, "Timestamp"]]

            # Create pivot table
            pivot_df = range_df.pivot(index="Timestamp", columns="Operation", values=full_range_name)
            pivot_df = pivot_df.reset_index()

            # Calculate statistics
            stats_data = {
                "Statistic": ["Max", "Min", "Average", "Count"],
                "Read": [
                    pivot_df["Read"].max(),
                    pivot_df["Read"].min(),
                    pivot_df["Read"].mean(),
                    len(pivot_df["Read"].dropna()),
                ],
                "Write": [
                    pivot_df["Write"].max(),
                    pivot_df["Write"].min(),
                    pivot_df["Write"].mean(),
                    len(pivot_df["Write"].dropna()),
                ],
            }
            stats_df = pd.DataFrame(stats_data)

            sheet_name = sanitize_sheet_name(full_range_name)
            start_row = 1  # Leave room for headers

            # Write data table
            pivot_df.to_excel(writer, sheet_name=sheet_name, startrow=start_row, index=False)
            worksheet = writer.sheets[sheet_name]

            # Write statistics title
            stats_title = "Performance Statistics"
            worksheet.write(start_row + len(pivot_df) + 2, 0, stats_title)

            # Write statistics data
            stats_df.to_excel(
                writer, sheet_name=sheet_name, startrow=start_row + len(pivot_df) + 3, index=False, header=True
            )

            # Create chart
            chart = workbook.add_chart({"type": "line"})

            # Add Read data
            chart.add_series(
                {
                    "name": "Read",
                    "categories": [sheet_name, start_row + 1, 0, start_row + len(pivot_df), 0],
                    "values": [sheet_name, start_row + 1, 1, start_row + len(pivot_df), 1],
                    "line": {"color": "#4E79A7", "width": 2},
                }
            )

            # Add Write data
            chart.add_series(
                {
                    "name": "Write",
                    "categories": [sheet_name, start_row + 1, 0, start_row + len(pivot_df), 0],
                    "values": [sheet_name, start_row + 1, 2, start_row + len(pivot_df), 2],
                    "line": {"color": "#E15759", "width": 2, "dash_type": "round_dot"},
                }
            )

            # Configure chart
            chart.set_title({"name": f"{full_range_name} Read/Write Performance"})
            chart.set_x_axis({"name": "Time Sequence"})
            chart.set_y_axis(
                {
                    "name": "Performance(MiB/s)",
                    "min": 0,
                    "max": max(pivot_df["Read"].max(), pivot_df["Write"].max()) * 1.1,
                }
            )

            # Insert chart
            worksheet.insert_chart("E2", chart)

            # Auto-adjust column width
            for i, col in enumerate(pivot_df.columns):
                max_len = max(pivot_df[col].astype(str).map(len).max(), len(str(col)))
                worksheet.set_column(i, i, max_len + 2)

        # Process Range_sum and Bandwidth
        special_metrics = ["Range_sum", "Bandwidth"]
        for metric in special_metrics:
            # Prepare data
            metric_df = df[["Operation", metric, "Timestamp"]]

            # Create pivot table
            pivot_df = metric_df.pivot(index="Timestamp", columns="Operation", values=metric)
            pivot_df = pivot_df.reset_index()

            # Calculate statistics
            stats_data = {
                "Statistic": ["Max", "Min", "Average", "Count"],
                "Read": [
                    pivot_df["Read"].max(),
                    pivot_df["Read"].min(),
                    pivot_df["Read"].mean(),
                    len(pivot_df["Read"].dropna()),
                ],
                "Write": [
                    pivot_df["Write"].max(),
                    pivot_df["Write"].min(),
                    pivot_df["Write"].mean(),
                    len(pivot_df["Write"].dropna()),
                ],
            }
            stats_df = pd.DataFrame(stats_data)

            # Use the cleaned worksheet name
            sheet_name = sanitize_sheet_name(metric)
            start_row = 1  # Leave room for headers

            # Write data table
            pivot_df.to_excel(writer, sheet_name=sheet_name, startrow=start_row, index=False)
            worksheet = writer.sheets[sheet_name]

            # Write statistics title
            stats_title = "Performance Statistics"
            worksheet.write(start_row + len(pivot_df) + 2, 0, stats_title)

            # Write statistics data
            stats_df.to_excel(
                writer, sheet_name=sheet_name, startrow=start_row + len(pivot_df) + 3, index=False, header=True
            )

            # Create chart
            chart = workbook.add_chart({"type": "line"})

            # Add Read data
            chart.add_series(
                {
                    "name": "Read",
                    "categories": [sheet_name, start_row + 1, 0, start_row + len(pivot_df), 0],
                    "values": [sheet_name, start_row + 1, 1, start_row + len(pivot_df), 1],
                    "line": {"color": "#4E79A7", "width": 2},
                }
            )

            # Add Write data
            chart.add_series(
                {
                    "name": "Write",
                    "categories": [sheet_name, start_row + 1, 0, start_row + len(pivot_df), 0],
                    "values": [sheet_name, start_row + 1, 2, start_row + len(pivot_df), 2],
                    "line": {"color": "#E15759", "width": 2, "dash_type": "round_dot"},
                }
            )

            # Configure chart
            chart.set_title({"name": f"{metric} Read/Write Performance"})
            chart.set_x_axis({"name": "Time Sequence"})
            chart.set_y_axis(
                {
                    "name": "Performance(MiB/s)",
                    "min": 0,
                    "max": max(pivot_df["Read"].max(), pivot_df["Write"].max()) * 1.1,
                }
            )

            # Insert chart
            worksheet.insert_chart("E2", chart)

            # Auto-adjust column width
            for i, col in enumerate(pivot_df.columns):
                max_len = max(pivot_df[col].astype(str).map(len).max(), len(str(col)))
                worksheet.set_column(i, i, max_len + 2)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", help="Input log file path")
    parser.add_argument("-o", "--output", help="Output Excel file path")
    args = parser.parse_args()

    try:
        df, range_headers = process_file(args.input)
        output_path = args.output if args.output else args.input.replace(".csv", "_with_charts.xlsx")

        generate_excel_with_charts(df, range_headers, output_path)
        print(f"Analysis completed. Report generated: {output_path}")

    except Exception as e:
        print(f"Processing failed: {str(e)}")


if __name__ == "__main__":
    main()
