#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import matplotlib

matplotlib.use("Agg")

import argparse
import datetime
import glob
import os
import re
import sys

import matplotlib.pyplot as plt
import pandas as pd
from bs4 import BeautifulSoup
from matplotlib.ticker import FuncFormatter

plt.rcParams.update({"figure.autolayout": True})

STYLE = """
<style>
body {font-family: Arial, sans-serif; margin: 20px;}
h1,h2 {background-color: #2b5797; color: white; padding: 10px;}
.table {border-collapse: collapse; width: 100%;}
.table th, .table td {border: 1px solid #dddddd; text-align: right; padding: 6px;}
.table tr:nth-child(even) {background-color: #f9f9f9;}
.table th {background-color: #4CAF50; color: white; text-align: center;}
.table { width: auto; }
.back-link {display:block; margin-bottom:10px; font-size:14px;}
.section {margin-bottom: 30px;}
.range-card {flex: 0 0 100%; padding:10px; box-sizing:border-box;}
.range-grid {display:flex; flex-wrap:wrap; gap:10px;}
.img-box img {max-width:100%; height:auto; display:block;}
</style>
"""


def ensure_outdir(path):
    os.makedirs(path, exist_ok=True)
    return os.path.abspath(path)


def human_fmt(x, pos):
    """Format large numbers with thousands separators for plot axes."""
    try:
        xi = int(round(x))
        return f"{xi:,}"
    except Exception:
        return str(x)


def parse_bw_txt(path):
    """Parse raw bandwidth text logs into DataFrames for Read, Write, and Sum values."""
    with open(path, encoding="utf-8", errors="ignore") as f:
        text = f.read()

    lines = text.splitlines()
    samples_read = []
    samples_write = []
    samples_sum = []
    header_cols = None
    i = 0
    n = len(lines)
    sample_idx = 0

    # pattern: header line contains 'Perf(MiB/s)' and then '|' separated columns
    while i < n:
        line = lines[i]
        if "Perf(MiB/s)" in line:
            # header line is this line (or maybe the following lines combined), extract columns by '|'
            header_line = line
            # sometimes header may be split; but we try to extract from this line anyway
            cols = [c.strip() for c in header_line.split("|") if c.strip()]
            # normalize columns: remove possible leading 'Perf(MiB/s)' token
            if cols and cols[0].startswith("Perf"):
                cols = cols[1:]
            header_cols = cols

            # next lines should contain Read and Write rows; find them
            read_vals = None
            write_vals = None

            # scan forward a few lines to find "Read|" and "Write|"
            j = i + 1
            while j < min(n, i + 12):
                l = lines[j].strip()
                if l.startswith("Read") or l.startswith("Read|") or l.startswith("Read "):
                    # split by '|' and map to columns
                    parts = [p.strip() for p in lines[j].split("|")]
                    # remove leading 'Read' token
                    if parts and parts[0].startswith("Read"):
                        parts = parts[1:]
                    read_vals = parts
                elif l.startswith("Write") or l.startswith("Write|") or l.startswith("Write "):
                    parts = [p.strip() for p in lines[j].split("|")]
                    if parts and parts[0].startswith("Write"):
                        parts = parts[1:]
                    write_vals = parts
                j += 1

            if read_vals is None or write_vals is None:
                # incomplete sample — skip
                # advance and continue
                i += 1
                continue

            # If header_cols length and read/write length mismatch, try to align by taking min length
            L = min(len(header_cols), len(read_vals), len(write_vals))

            combined_read = {}
            combined_write = {}
            combined_sum = {}

            for k in range(L):
                col = header_cols[k]

                # convert read/write numeric text to float, tolerate non-number by 0
                def tof(s):
                    if s is None:
                        return 0.0
                    s = s.replace(",", "").strip()
                    # sometimes there are trailing words; keep numeric prefix
                    m = re.match(r"[-+]?\d+(\.\d+)?", s)
                    if not m:
                        return 0.0
                    try:
                        return float(m.group(0))
                    except:
                        return 0.0

                r = tof(read_vals[k]) if k < len(read_vals) else 0.0
                w = tof(write_vals[k]) if k < len(write_vals) else 0.0

                combined_read[col] = r
                combined_write[col] = w
                combined_sum[col] = r + w  # Sum of Read and Write

            sample_idx += 1
            combined_read["_sample_index"] = sample_idx
            combined_write["_sample_index"] = sample_idx
            combined_sum["_sample_index"] = sample_idx

            samples_read.append(combined_read)
            samples_write.append(combined_write)
            samples_sum.append(combined_sum)

            # move i forward to j
            i = j
        else:
            i += 1

    if not samples_read:
        raise ValueError(f"No samples parsed from {path} - check file format.")

    # unify header columns from parsed samples (some samples may be shorter)
    first_keys = []
    if header_cols:
        first_keys = header_cols.copy()
    else:
        first_keys = [k for k in samples_read[0].keys() if k != "_sample_index"]

    # Build DataFrames for Read, Write and Sum separately
    df_read_rows = []
    for s in samples_read:
        row = {k: s.get(k, 0.0) for k in first_keys}
        row["_sample_index"] = s.get("_sample_index", None)
        df_read_rows.append(row)

    df_write_rows = []
    for s in samples_write:
        row = {k: s.get(k, 0.0) for k in first_keys}
        row["_sample_index"] = s.get("_sample_index", None)
        df_write_rows.append(row)

    df_sum_rows = []
    for s in samples_sum:
        row = {k: s.get(k, 0.0) for k in first_keys}
        row["_sample_index"] = s.get("_sample_index", None)
        df_sum_rows.append(row)

    df_read = pd.DataFrame(df_read_rows)
    df_write = pd.DataFrame(df_write_rows)
    df_sum = pd.DataFrame(df_sum_rows)

    # ensure numeric
    for c in first_keys:
        df_read[c] = pd.to_numeric(df_read[c], errors="coerce").fillna(0.0)
        df_write[c] = pd.to_numeric(df_write[c], errors="coerce").fillna(0.0)
        df_sum[c] = pd.to_numeric(df_sum[c], errors="coerce").fillna(0.0)

    return df_read, df_write, df_sum, first_keys


def parse_bw_csv(path):
    with open(path, encoding="utf-8", errors="ignore") as f:
        text = f.read()
    return parse_bw_txt(text_path=path)


def plot_overview_max(df_read, df_write, df_sum, cols, out_png):
    """Generate a bar chart showing the maximum Read, Write, and Sum values for each range."""
    # Calculate max values in the input-order
    max_read = [df_read[c].max() for c in cols]
    max_write = [df_write[c].max() for c in cols]
    max_sum = [df_sum[c].max() for c in cols]

    x = range(len(cols))
    width = 0.25  # width of each bar

    fig, ax = plt.subplots(figsize=(16, max(4, len(cols) * 0.35)))

    # Three bars side-by-side
    ax.bar([i - width for i in x], max_read, width=width, label="Read Max", color="blue", alpha=0.7)
    ax.bar([i for i in x], max_write, width=width, label="Write Max", color="red", alpha=0.7)
    ax.bar([i + width for i in x], max_sum, width=width, label="Sum Max", color="green", alpha=0.7)

    ax.set_title("Bandwidth per Range (MiB/s) — Read, Write and Sum MAX")
    ax.set_ylabel("Bandwidth Usage (MiB/s)")
    ax.yaxis.set_major_formatter(FuncFormatter(human_fmt))

    # X tick labels follow input order
    ax.set_xticks(x)
    ax.set_xticklabels(cols, rotation=45, ha="right")
    ax.legend()
    plt.tight_layout()
    fig.savefig(out_png)
    plt.close(fig)


def plot_range_line(series_read, series_write, series_sum, out_png, title=None, ymin=0):
    """Plot a time-series line chart showing bandwidth trends for a specific range."""
    series_read_plot = pd.to_numeric(series_read, errors="coerce").fillna(0.0).clip(lower=ymin)
    series_write_plot = pd.to_numeric(series_write, errors="coerce").fillna(0.0).clip(lower=ymin)
    series_sum_plot = pd.to_numeric(series_sum, errors="coerce").fillna(0.0).clip(lower=ymin)

    fig, ax = plt.subplots(figsize=(12, 4))

    series_read_plot.plot(kind="line", ax=ax, label="Read", color="blue", linewidth=1.5)
    series_write_plot.plot(kind="line", ax=ax, label="Write", color="red", linewidth=1.5)
    series_sum_plot.plot(kind="line", ax=ax, label="Sum", color="green", linewidth=1.5)

    ax.set_xlabel("Time")
    ax.set_xticks([])
    ax.set_ylabel("Bandwidth Usage (MiB/s)")
    if title:
        ax.set_title(title)
    ax.yaxis.set_major_formatter(FuncFormatter(human_fmt))
    ax.grid(True, linestyle="--", linewidth=0.5, alpha=0.6)
    ax.legend()

    # set y-limits with ymin
    ymax = max(
        series_read_plot.max() if len(series_read_plot) > 0 else ymin + 1,
        series_write_plot.max() if len(series_write_plot) > 0 else ymin + 1,
        series_sum_plot.max() if len(series_sum_plot) > 0 else ymin + 1,
    )
    ax.set_ylim(bottom=ymin, top=max(ymax * 1.05, ymin + 1))

    plt.tight_layout()
    fig.savefig(out_png)
    plt.close(fig)


def export_range_page(
    range_name, csv_read_path, csv_write_path, csv_sum_path, png_path, out_html, back_href="00_Bandwidth_Summary.html"
):
    """Generate an individual HTML page for a range, including its chart and data table."""
    # read csv to create a small table
    df_read = pd.read_csv(csv_read_path)
    df_write = pd.read_csv(csv_write_path)
    df_sum = pd.read_csv(csv_sum_path)

    # Combine Read, Write and Sum data for display
    df_combined = pd.DataFrame(
        {
            "sample_index": df_read["sample_index"],
            "read_value": df_read["value"],
            "write_value": df_write["value"],
            "sum_value": df_sum["value"],
        }
    )

    # format table to HTML
    df_display = df_combined.copy()
    df_display["read_value"] = df_display["read_value"].map(lambda x: f"{x:.2f}")
    df_display["write_value"] = df_display["write_value"].map(lambda x: f"{x:.2f}")
    df_display["sum_value"] = df_display["sum_value"].map(lambda x: f"{x:.2f}")

    html_table = df_display.to_html(classes="table", index=False, float_format="%.2f", border=0)
    soup = BeautifulSoup(html_table, "html.parser")

    with open(out_html, "w", encoding="utf-8") as f:
        f.write("<html><head><meta charset='utf-8'>")
        f.write(STYLE)
        f.write(f"</head><body>")
        # f.write(f'<a href="{back_href}" class="back-link">&larr; Back to Summary</a>')
        f.write(f"<h2>{range_name} — Bandwidth over samples</h2>")

        # image (already created)
        f.write(
            f'<div class="img-box"><img src="{os.path.basename(png_path)}" alt="{range_name} line chart"></div><br>'
        )

        # include data table for this range page
        f.write(str(soup))
        f.write("</body></html>")


def generate_summary_html(per_range_list, overview_png, out_html, df_summary_read, df_summary_write, df_summary_sum):
    """
    per_range_list: [(range_name, page_filename, thumbnail_filename), ...]
    df_summary_read: DataFrame where row is max Read values
    df_summary_write: DataFrame where row is max Write values
    df_summary_sum: DataFrame where row is max Sum values
    """
    with open(out_html, "w", encoding="utf-8") as out:
        out.write("<html><head><meta charset='utf-8'>")
        out.write(STYLE)
        out.write("</head><body>")
        out.write("<h1>DDR Bandwidth Report</h1>")

        # Contents
        out.write("<h2>Contents</h2><ul>")
        for idx, (rname, page, thumb) in enumerate(per_range_list, start=1):
            display_idx = f"{idx:02d}"
            out.write(f'<li><a href="{os.path.basename(page)}">{display_idx} {rname}</a></li>')
        out.write("</ul><hr>")

        # Overview chart
        out.write("<h2>Overview (max per range)</h2>")
        if os.path.exists(overview_png):
            out.write(
                f'<div style="width:100%; overflow:auto;"><img src="{os.path.basename(overview_png)}" alt="Overview" style="max-width:100%; height:auto;"></div><br>'
            )

        # Summary table: Max Read values
        out.write("<h2>Max Read values (MiB/s) by Range</h2>")
        out.write(df_summary_read.to_html(classes="table", float_format="%.2f"))

        # Summary table: Max Write values
        out.write("<h2>Max Write values (MiB/s) by Range</h2>")
        out.write(df_summary_write.to_html(classes="table", float_format="%.2f"))

        # Summary table: Max Sum values
        out.write("<h2>Max Sum values (MiB/s) by Range</h2>")
        out.write(df_summary_sum.to_html(classes="table", float_format="%.2f"))

        # Range grid (thumbnails)
        out.write("<h2>Ranges</h2>")
        out.write('<div class="range-grid">')
        for idx, (rname, page, thumb) in enumerate(per_range_list, start=1):
            out.write('<div class="range-card">')
            display_idx = f"{idx:02d}"
            out.write(
                f'<h3 style="font-size:14px;margin:0 0 6px 0;"><a href="{os.path.basename(page)}">{display_idx} {rname}</a></h3>'
            )
            # if thumbnail exists show it else show nothing
            if thumb and os.path.exists(os.path.join(os.path.dirname(out_html), os.path.basename(thumb))):
                out.write(
                    f'<div class="img-box"><a href="{os.path.basename(page)}"><img src="{os.path.basename(thumb)}" alt="{rname}"></a></div>'
                )
            out.write("</div>")
        out.write("</div><hr>")

        out.write("</body></html>")


def safe_name(s: str) -> str:
    return re.sub(r"[^0-9A-Za-z_\-]+", "_", s)


def main():
    parser = argparse.ArgumentParser(description="Generate DDR bandwidth HTML report")
    parser.add_argument("-i", "--input", required=True, help="Input txt file (bandwidth output)")
    parser.add_argument("-o", "--output", default="./bw_report", help="Output directory")
    args = parser.parse_args()

    out_dir = ensure_outdir(args.output)

    input_path = args.input
    if os.path.isdir(input_path):
        csv_files = sorted(glob.glob(os.path.join(input_path, "*bandwidth_log*.csv")))
        if not csv_files:
            print(f"No matching CSV files in {input_path}")
            sys.exit(1)

        df_read_all, df_write_all, df_sum_all, cols_all = None, None, None, None
        for csv_file in csv_files:
            df_read, df_write, df_sum, cols = parse_bw_txt(csv_file)
            if df_read_all is None:
                df_read_all, df_write_all, df_sum_all, cols_all = df_read, df_write, df_sum, cols
            else:
                df_read_all = pd.concat([df_read_all, df_read], ignore_index=True)
                df_write_all = pd.concat([df_write_all, df_write], ignore_index=True)
                df_sum_all = pd.concat([df_sum_all, df_sum], ignore_index=True)
        df_read, df_write, df_sum, cols = df_read_all, df_write_all, df_sum_all, cols_all
    else:
        try:
            df_read, df_write, df_sum, cols = parse_bw_txt(input_path)
        except Exception as e:
            print("Error parsing input:", e)
            sys.exit(1)

    # keep only Range columns (exclude 'Range_sum'/'Bandwidth' if you want, but include them)
    # Use all parsed cols
    value_cols = cols.copy()

    # Save raw dataframes
    raw_read_csv = os.path.join(out_dir, "raw_samples_read.csv")
    raw_write_csv = os.path.join(out_dir, "raw_samples_write.csv")
    raw_sum_csv = os.path.join(out_dir, "raw_samples_sum.csv")
    df_read.to_csv(raw_read_csv, index=False)
    df_write.to_csv(raw_write_csv, index=False)
    df_sum.to_csv(raw_sum_csv, index=False)

    # Build per-range CSVs & pages
    per_range_list = []

    for idx, col in enumerate(value_cols, start=1):
        # create series for Read, Write and Sum
        ser_read = df_read[col]
        ser_write = df_write[col]
        ser_sum = df_sum[col]

        # save csv: columns sample_index, value
        range_safe = safe_name(col)
        csv_read_path = os.path.join(out_dir, f"{range_safe}_read.csv")
        csv_write_path = os.path.join(out_dir, f"{range_safe}_write.csv")
        csv_sum_path = os.path.join(out_dir, f"{range_safe}_sum.csv")

        df_export_read = pd.DataFrame({"sample_index": df_read["_sample_index"], "value": ser_read})
        df_export_write = pd.DataFrame({"sample_index": df_write["_sample_index"], "value": ser_write})
        df_export_sum = pd.DataFrame({"sample_index": df_sum["_sample_index"], "value": ser_sum})

        df_export_read.to_csv(csv_read_path, index=False)
        df_export_write.to_csv(csv_write_path, index=False)
        df_export_sum.to_csv(csv_sum_path, index=False)

        # determine filenames: pages start from 01_, summary will be 00_
        page_basename = f"{idx:02d}_{range_safe}.html"
        page_path = os.path.join(out_dir, page_basename)

        # plot line (main image) ensure y starts from 0
        png_path = os.path.join(out_dir, f"{range_safe}.png")
        title = f"{col} — bandwidth over samples (MiB/s)"

        plot_range_line(
            df_export_read.set_index("sample_index")["value"],
            df_export_write.set_index("sample_index")["value"],
            df_export_sum.set_index("sample_index")["value"],
            png_path,
            title=title,
            ymin=0,
        )

        # also produce a small thumbnail for grid (smaller png)
        thumb_path = os.path.join(out_dir, f"{range_safe}.thumbnail.png")
        try:
            # create a small version by replotting with smaller size
            plot_range_line(
                df_export_read.set_index("sample_index")["value"],
                df_export_write.set_index("sample_index")["value"],
                df_export_sum.set_index("sample_index")["value"],
                thumb_path,
                title=col,
                ymin=0,
            )
        except Exception:
            # ignore thumbnail errors
            thumb_path = None

        # per-range page
        export_range_page(
            col, csv_read_path, csv_write_path, csv_sum_path, png_path, page_path, back_href="00_Bandwidth_Summary.html"
        )
        per_range_list.append((col, page_path, thumb_path))

    # Overview (max per range)
    overview_png = os.path.join(out_dir, "overview_max.png")
    plot_overview_max(df_read, df_write, df_sum, value_cols, overview_png)

    # Summary tables: max per column for Read, Write and Sum
    max_series_read = df_read[value_cols].max()
    max_series_write = df_write[value_cols].max()
    max_series_sum = df_sum[value_cols].max()

    df_summary_read = pd.DataFrame(max_series_read).T
    df_summary_write = pd.DataFrame(max_series_write).T
    df_summary_sum = pd.DataFrame(max_series_sum).T

    # write summary html (00_Bandwidth_Summary.html)
    summary_html = os.path.join(out_dir, "00_Bandwidth_Summary.html")
    generate_summary_html(per_range_list, overview_png, summary_html, df_summary_read, df_summary_write, df_summary_sum)


if __name__ == "__main__":
    main()
