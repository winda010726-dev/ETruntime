import matplotlib

matplotlib.use("Agg")

import json
import os
import re

import matplotlib.pyplot as plt

# Path to the JSON report (update if needed)
REPORT_PATH = os.path.join(os.path.dirname(__file__), "last_results", "bandwidth_report.json")


def load_json_without_input_file_statistics(path):
    with open(path, "r") as f:
        content = f.read()
    # Remove the input_file_statistics object using regex (robust to whitespace and newlines)
    content = re.sub(r'"input_file_statistics"\s*:\s*\{[^\}]*\},?', "", content, flags=re.DOTALL)
    return json.loads(content)


data = load_json_without_input_file_statistics(REPORT_PATH)

unit = "MiB/s"  # Use a default unit for all plots


def plot_per_block(range_name, read_vals, write_vals, unit):
    plt.figure(figsize=(10, 5))
    plt.plot(read_vals, marker="o", label="Read")
    plt.plot(write_vals, marker="s", label="Write")
    plt.title(f"{range_name.strip()} Bandwidth per Block")
    plt.xlabel("Block Index")
    plt.ylabel(unit)
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    fname = f"bandwidth_per_block_{range_name.strip().replace(' ', '_').replace(':', '_').lower()}.png"
    plt.savefig(fname)
    plt.show()
    print(f"Saved: {fname}")


def plot_aggregated_bar(title, stats, unit):
    labels = ["Min", "Avg", "Max"]
    read = [stats["read"].get("min", 0), stats["read"].get("avg", 0), stats["read"].get("max", 0)]
    write = [stats["write"].get("min", 0), stats["write"].get("avg", 0), stats["write"].get("max", 0)]
    x = range(len(labels))
    width = 0.35
    plt.figure(figsize=(7, 4))
    plt.bar(x, read, width, label="Read")
    plt.bar([i + width for i in x], write, width, label="Write")
    plt.xticks([i + width / 2 for i in x], labels)
    plt.ylabel(unit)
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    fname = f"bandwidth_aggregated_{title.strip().replace(' ', '_').lower()}.png"
    plt.savefig(fname)
    plt.show()
    print(f"Saved: {fname}")


def plot_stat_across_ranges(details, stat, unit):
    names = [d["range"].strip() for d in details]
    read_vals = [d["read"].get(stat, 0) for d in details]
    write_vals = [d["write"].get(stat, 0) for d in details]
    plt.figure(figsize=(12, 5))
    plt.bar(names, read_vals, width=0.4, label="Read", align="center")
    plt.bar(names, write_vals, width=0.4, label="Write", align="edge")
    plt.xticks(rotation=90)
    plt.ylabel(unit)
    plt.title(f"{stat.capitalize()} Value per Range")
    plt.legend()
    plt.tight_layout()
    fname = f"bandwidth_{stat}_per_range.png"
    plt.savefig(fname)
    plt.show()
    print(f"Saved: {fname}")


# Plot Bandwidth per block
for detail in data["details"]:
    if detail["range"].strip().lower() == "bandwidth":
        plot_per_block("Bandwidth", detail["read"]["values"], detail["write"]["values"], unit)
        break

# Plot Range_sum per block
for detail in data["details"]:
    if detail["range"].strip().lower() == "range_sum":
        plot_per_block("Range_sum", detail["read"]["values"], detail["write"]["values"], unit)
        break

# Plot aggregated stats for Bandwidth and Range_sum
plot_aggregated_bar("Aggregated Bandwidth", data["aggregated_data_bandwidth"], unit)
plot_aggregated_bar("Aggregated Range_sum", data["aggregated_data_range_sum"], unit)

# Plot min, avg, max for each range (including Bandwidth)
plot_stat_across_ranges(data["details"], "min", unit)
plot_stat_across_ranges(data["details"], "avg", unit)
plot_stat_across_ranges(data["details"], "max", unit)

# Optionally, plot all ranges (comment out if not needed)
# for detail in data['details']:
#     plot_per_block(detail['range'], detail['read']['values'], detail['write']['values'], unit)
