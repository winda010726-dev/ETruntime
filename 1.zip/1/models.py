from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class AnalysisTask(db.Model):
    __tablename__ = 'tasks'

    id = db.Column(db.String(36), primary_key=True)
    task_name = db.Column(db.String(128), default='未命名')
    task_prefix = db.Column(db.String(100), default='')
    input_dir = db.Column(db.String(512), nullable=False)
    json_file = db.Column(db.String(512))
    output_dir = db.Column(db.String(512))
    status = db.Column(db.String(20), default='PENDING')
    error_message = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)

    def to_dict(self):
        return {
            'id': self.id,
            'task_name': self.task_name,
            'task_prefix': self.task_prefix or '',
            'input_dir': self.input_dir,
            'json_file': self.json_file,
            'output_dir': self.output_dir,
            'status': self.status,
            'error_message': self.error_message,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
        }