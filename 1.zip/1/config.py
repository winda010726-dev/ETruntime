import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-key-change-in-production'
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))

    # 上传目录
    UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
    # 临时解压目录
    TEMP_FOLDER = os.path.join(BASE_DIR, 'tmp')

    DEFAULT_DOMAIN_LOOKUP = os.path.join(BASE_DIR, 'domain_lookup.json')

    # 报告存储根目录
    REPORTS_DIR = os.path.join(BASE_DIR, 'reports')

    # 允许上传的文件扩展名（压缩包和JSON）
    ALLOWED_EXTENSIONS = {'tar', 'gz', 'zip', 'json'}

    # 报告生成脚本路径（修改后的统一脚本）
    GENERATE_SCRIPT = os.path.join(BASE_DIR, 'scripts', 'generate_report.py')

    # SQLite 数据库
    SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(BASE_DIR, 'tasks.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # 最大上传文件大小（100MB）
    MAX_CONTENT_LENGTH = 100 * 1024 * 1024
