# import os
# import shutil
# import tarfile
# import zipfile
# import subprocess
# import sys
# import uuid
# from werkzeug.utils import secure_filename

# def allowed_file(filename, allowed_extensions):
#     return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions

# def extract_archive(archive_path, extract_to):
#     """解压 tar.gz, tar, zip 文件到指定目录"""
#     os.makedirs(extract_to, exist_ok=True)
#     if archive_path.endswith('.tar.gz') or archive_path.endswith('.tgz'):
#         with tarfile.open(archive_path, 'r:gz') as tar:
#             tar.extractall(extract_to)
#     elif archive_path.endswith('.tar'):
#         with tarfile.open(archive_path, 'r:') as tar:
#             tar.extractall(extract_to)
#     elif archive_path.endswith('.zip'):
#         with zipfile.ZipFile(archive_path, 'r') as zip_ref:
#             zip_ref.extractall(extract_to)
#     else:
#         raise ValueError(f"Unsupported archive type: {archive_path}")

# def run_report_generator(input_dir, json_file, output_dir, script_path):
#     cmd = [sys.executable, script_path, '-i', input_dir, '-o', output_dir, '--no-timestamp']
#     if json_file and os.path.exists(json_file):
#         cmd.extend(['-j', json_file])
#     print(f"Running: {' '.join(cmd)}")
#     script_dir = os.path.dirname(os.path.abspath(script_path))
#     result = subprocess.run(cmd, cwd=script_dir, capture_output=True, text=True)
#     print("=== STDOUT ===")
#     print(result.stdout)
#     print("=== STDERR ===")
#     print(result.stderr)
#     if result.returncode != 0:
#         raise Exception(f"报告生成失败 (returncode {result.returncode})\nSTDERR: {result.stderr}")
#     return output_dir

import os
import tarfile
import zipfile
import subprocess
import sys


def allowed_file(filename, allowed_extensions):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions


def extract_archive(archive_path, extract_to):
    os.makedirs(extract_to, exist_ok=True)
    if archive_path.endswith('.tar.gz') or archive_path.endswith('.tgz'):
        with tarfile.open(archive_path, 'r:gz') as tar:
            tar.extractall(extract_to)
    elif archive_path.endswith('.tar'):
        with tarfile.open(archive_path, 'r:') as tar:
            tar.extractall(extract_to)
    elif archive_path.endswith('.zip'):
        with zipfile.ZipFile(archive_path, 'r') as zip_ref:
            zip_ref.extractall(extract_to)
    else:
        raise ValueError(f"Unsupported archive type: {archive_path}")


def run_report_generator(input_dir, json_file, output_dir, script_path):
    cmd = [sys.executable, script_path, '-i', input_dir, '-o', output_dir, '--no-timestamp']
    if json_file and os.path.exists(json_file):
        cmd.extend(['-j', json_file])

    print(f"Running: {' '.join(cmd)}")
    script_dir = os.path.dirname(os.path.abspath(script_path))

    # 低优先级运行，不抢占系统资源
    # stdout/stderr 写到 PIPE 但不缓冲全部内容（用 Popen 流式读取）
    CREATE_FLAGS = 0
    if sys.platform == 'win32':
        CREATE_FLAGS = 0x00004000  # BELOW_NORMAL_PRIORITY_CLASS

    proc = subprocess.Popen(
        cmd,
        cwd=script_dir,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        creationflags=CREATE_FLAGS,
    )

    stdout, stderr = proc.communicate()

    print("=== STDOUT (last 2000 chars) ===")
    print(stdout.decode('utf-8', errors='replace')[-2000:])
    if stderr:
        print("=== STDERR (last 1000 chars) ===")
        print(stderr.decode('utf-8', errors='replace')[-1000:])

    if proc.returncode != 0:
        raise Exception(
            f"报告生成失败 (returncode {proc.returncode})\n"
            f"STDERR: {stderr.decode('utf-8', errors='replace')[:500]}")

    return output_dir