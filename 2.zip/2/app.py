import os
import uuid
import threading
import json
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename
from models import db, AnalysisTask
from config import Config
from analyzer import run_analysis
from flask import render_template

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

with app.app_context():
    db.create_all()
def _run_analysis_task(task_id, file_paths, scene_group, scene_name, trace_id, top_n, excel_path):
    with app.app_context():
        task = AnalysisTask.query.get(task_id)
        task.status = 'RUNNING'
        db.session.commit()
        try:
            # 调用新的 run_analysis
            result = run_analysis(
                file_paths=file_paths,
                scene_group=scene_group,
                scene_name=scene_name,
                trace_id=trace_id,
                top_n=top_n,
                excel_paths=[excel_path] if excel_path else None
            )
            # 保存 result 到数据库
            task.result_summary = json.dumps(result, default=str)
            task.status = 'COMPLETED'
            task.completed_at = datetime.utcnow()
        except Exception as e:
            task.status = 'FAILED'
            task.error_message = str(e)
        db.session.commit()

@app.route('/report')
def report():
    """查看分析报告页面"""
    return render_template('dashboard.html')
@app.route('/api/tasks', methods=['POST'])
def create_task():
    # 获取表单参数
    task_name = request.form.get('task_name', '未命名')
    scene_group = request.form.get('scene_group', '')
    scene_name = request.form.get('scene_name', '')
    trace_id = request.form.get('trace_id', '')  # 新增字段
    hardware_type = request.form.get('hardware_type', '')
    algorithm_version = request.form.get('algorithm_version', '')
    top_n = request.form.get('top_n', 10, type=int)

    # 获取上传文件 + Excel文件
    files = request.files.getlist('files')
    excel_file = request.files.get('excel_file')  # 新增Excel文件接收
    
    if not files:
        return jsonify({'error': 'No files uploaded'}), 400

    task_id = str(uuid.uuid4())
    saved_paths = []
    
    # 保存普通上传文件
    for file in files:
        if file.filename == '':
            continue
        filename = secure_filename(file.filename)
        save_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{task_id}_{filename}")
        file.save(save_path)
        saved_paths.append(save_path)

    # 保存 Excel 文件
    excel_path = None
    if excel_file and excel_file.filename != '':
        excel_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{task_id}_excel.xlsx")
        excel_file.save(excel_path)

    # 保存任务到数据库（包含所有字段）
    task = AnalysisTask(
        id=task_id,
        task_name=task_name,
        scene_group=scene_group,
        scene_name=scene_name,
        trace_id=trace_id,  # 新增
        hardware_type=hardware_type,
        algorithm_version=algorithm_version,
        top_n=top_n,
        excel_path=excel_path,  # 新增（模型需添加此字段）
        status='PENDING'
    )
    db.session.add(task)
    db.session.commit()

    # 启动后台任务，传递所有需要的参数
    thread = threading.Thread(
        target=_run_analysis_task,
        args=(task_id, saved_paths, scene_group, scene_name, trace_id, top_n, excel_path)
    )
    thread.daemon = True
    thread.start()

    return jsonify({'task_id': task_id, 'status': 'PENDING'}), 202


@app.route('/api/tasks/<task_id>', methods=['GET'])
def get_task(task_id):
    task = AnalysisTask.query.get(task_id)
    if not task:
        return jsonify({'error': 'Task not found'}), 404
    return jsonify(task.to_dict())

@app.route('/api/tasks', methods=['GET'])
def list_tasks():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    tasks = AnalysisTask.query.order_by(AnalysisTask.created_at.desc()).paginate(page=page, per_page=per_page)
    return jsonify({
        'tasks': [t.to_dict() for t in tasks.items],
        'total': tasks.total,
        'pages': tasks.pages,
        'page': page
    })

@app.route('/')
def index():
    """首页 - 上传任务"""
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8080)