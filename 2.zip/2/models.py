from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class AnalysisTask(db.Model):
    id = db.Column(db.String(36), primary_key=True)
    task_name = db.Column(db.String(128))
    scene_group = db.Column(db.String(64))
    scene_name = db.Column(db.String(128))
    hardware_type = db.Column(db.String(16))
    algorithm_version = db.Column(db.String(32))
    status = db.Column(db.String(16), default='PENDING')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    result_summary = db.Column(db.Text)   # 存储 JSON 结果
    error_message = db.Column(db.Text)
    trace_id = db.Column(db.String(128))
    excel_path = db.Column(db.String(256))
    top_n = db.Column(db.Integer, default=10)

    def to_dict(self):
        return {
            'id': self.id,
            'task_name': self.task_name,
            'scene_group': self.scene_group,
            'scene_name': self.scene_name,
            'hardware_type': self.hardware_type,
            'algorithm_version': self.algorithm_version,
            'status': self.status,
            'created_at': self.created_at.isoformat(),
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'result_summary': json.loads(self.result_summary) if self.result_summary else None,
            'error_message': self.error_message
        }