#!/usr/bin/env python3
from __future__ import annotations

import argparse
import glob
import json
import re
import statistics
import zipfile
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, Iterator, List, Optional, Sequence, Set, Tuple
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape as xml_escape


NOISE_SYMBOLS: Set[str] = {
    "[[kernel.kallsyms]]",
    "[unknown]",
    "thread_start",
    "start_thread",
    "__libc_start_main@@GLIBC_2.34",
    "__libc_start_main",
    "__libc_start_call_main",
    "_start",
    "_dl_start",
    "_dl_sysdep_start",
    "dl_main",
}

DIRECT_CONTEXT_SUBSTRINGS: Tuple[str, ...] = (
    "static fusion",
    "static_fusion",
    "nfm",
    "psd",
    "pmp",
    "rbp_eb",
    "rbp_ooc",
    "rbp_pp",
    "rbp",
    "mot",
    "rbp_mot",
    "apafct",
    "apahmi",
    "parkhmi",
    "hmi",
    "parkctl",
    "ctlfault",
    "ctlrunnable",
    "pfc",
    "aci",
    "vme",
    "vhm",
    "coolmaster",
    "ussper",
    "pdc",
    "mee",
    "maa",
    "mca",
    "infra",
    "ooc",
    "pp",
    "eb",
    "emergency",
    "brake",
    "apaplanning",
    "planning",
    "request",
)

QUICK_LINE_HINTS: Tuple[str, ...] = (
    "static fusion",
    "static_fusion",
    "staticfusion",
    "nfm",
    "psd",
    "pmp",
    "rbp_eb",
    "rbp_ooc",
    "rbp_pp",
    "rbp",
    "mot",
    "rbp_mot",
    "apafct",
    "rbpapahmi",
    "apahmi",
    "parkhmi",
    "pmphmi",
    "hmiconvert",
    "hmirange",
    "parkctl",
    "apafctctl",
    "ctlfault",
    "ctlfaultevent",
    "ctlrunnable",
    "ctlonupdate",
    "pfc",
    "aci",
    "vme",
    "vhm",
    "coolmaster",
    "ussper",
    "pdc",
    "mee",
    "maa",
    "mca",
    "infra",
    "ooc",
    "pp",
    "eb",
    "emergency",
    "brake",
    "apaplanning",
    "planningrequest",
    "planning_request",
    "planning request",
)

OVERHEAD_PATTERNS: Tuple[Tuple[str, re.Pattern[str]], ...] = (
    ("ipc_io", re.compile(r"iox::|senderport|receiverport|sharedchunk|allocatechunk|reservechunk|getchunk|samplereader|lightweightinbox", re.I)),
    ("logging", re.compile(r"mplog|logging_|log_message|staticlogmessageregistration|setthreadcontext", re.I)),
    ("memory", re.compile(r"operator new|malloc|_int_malloc|free|decrement\b|sharedpointer", re.I)),
    ("serialization", re.compile(r"serialize|mergefrom|getmetadata|internalserialize|protobuf", re.I)),
    ("synchronization", re.compile(r"pthread_|mutex|futex|lock_wait|cond_wait|cond_timedwait", re.I)),
)

MODULE_PATTERNS: Tuple[Tuple[str, re.Pattern[str]], ...] = (
    ("static_fusion", re.compile(r"static[ _:-]*fusion|staticfusion", re.I)),
    ("nfm", re.compile(r"(^|[^a-z])nfm([^a-z]|$)", re.I)),
    ("psd", re.compile(r"(^|[^a-z])psd([^a-z]|$)", re.I)),
    ("pmp", re.compile(r"(^|[^a-z])pmp([^a-z]|$)", re.I)),
    ("rbp_eb", re.compile(r"rbp::eb|rbp_eb|(^|[^a-z])eb([^a-z]|$)|emergency.*brake|brake.*emergency", re.I)),
    ("rbp_ooc", re.compile(r"rbp::ooc|rbp_ooc|(^|[^a-z])ooc([^a-z]|$)", re.I)),
    ("rbp_pp", re.compile(r"rbp::pp|rbp_pp|(^|[^a-z])pp([^a-z]|$)", re.I)),
    ("rbp_mot", re.compile(r"rbp::mot|rbp_mot|(^|[^a-z])mot([^a-z]|$)", re.I)),
    ("parkhmi", re.compile(r"rbpapahmi|apahmi|parkhmi|pmphmi|hmiConvert|HMIRange|RbpApahmi|Apahmi_onUpdate|Apahmi_onUpdateFunctor|RunContext.*Apahmi|Apahmi_RunContext|::hmi::|(^|[^a-z])hmi([^a-z]|$)", re.I)),
    ("parkctl", re.compile(r"parkctl|apafctctl|ApaFctCtl|CtlFaultEvent|CtlFaultEventListStruct|CtlRunnable|Ctl_onUpdate|Rbp.*Ctl.*RunContext|Rbp.*Ctl.*Functor|(^|[^a-z])ctlfault([^a-z]|$)", re.I)),
    ("pfc", re.compile(r"rbp::pfc|rb::cn::pfc|rbp::mca::pfc|rbp::ccp::pfc|(^|[^a-z])pfc([^a-z]|$)|CPfc|PfControl|Apactl|Motctl", re.I)),
    ("apafct", re.compile(r"rbpapafct|apafct", re.I)),
    ("aci", re.compile(r"rbcnaci|(^|[^a-z])aci([^a-z]|$)", re.I)),
    ("vme", re.compile(r"rbp::vme|(^|[^a-z])vme([^a-z]|$)|(^|[^a-z])vhm([^a-z]|$)|CVhm|VhmState|RbpVhm|vhm_", re.I)),
    ("ussper", re.compile(r"rbpussper|rbp::ussper|(^|[^a-z])ussper([^a-z]|$)", re.I)),
    ("pdc", re.compile(r"rbppdc|rbp::pdc|(^|[^a-z])pdc([^a-z]|$)", re.I)),
    ("mee", re.compile(r"(^|[^a-z])mee([^a-z]|$)", re.I)),
    ("maa", re.compile(r"(^|[^a-z])maa([^a-z]|$)", re.I)),
    ("mca", re.compile(r"rbpmca|rbp::mca|(^|[^a-z])mca([^a-z]|$)", re.I)),
    ("rbp_infra", re.compile(r"rbpinfra|rbp::infra|(^|[^a-z])infra([^a-z]|$)|coolmaster|RbpCoolMaster", re.I)),
    ("apaplanning", re.compile(r"apa[ _:-]*planning|apaplanning", re.I)),
    ("planning_request", re.compile(r"planning[ _:-]*request|request[ _:-]*planning", re.I)),
    ("rbp_others", re.compile(r"\brbp(?![-_:/a-z0-9]*vis)[-_:/a-z0-9:]*", re.I)),
)

EXCLUDED_MODULE_PATTERNS: Tuple[re.Pattern[str], ...] = (
    re.compile(r"rbp[-_:/a-z0-9]*vis", re.I),
    re.compile(r"/asw/bin/rbp-vis", re.I),
    re.compile(r"(^|[^a-z])vis([^a-z]|$)", re.I),
    re.compile(r"::vis(::|$)", re.I),
    re.compile(r"vis::", re.I),
)

EXPLICIT_PARKING_RE = re.compile(
    r"static[ _:-]*fusion|nfm|psd|pmp|rbp|mot|rbp_mot|rbp_eb|rbp_ooc|rbp_pp|apafct|apahmi|parkhmi|hmi|parkctl|ctlfault|ctlrunnable|pfc|aci|vme|vhm|ussper|pdc|mee|maa|mca|infra|coolmaster|emergency.*brake|apaplanning|planning[ _:-]*request|ooc|pp|eb",
    re.I,
)

CONTEXTUAL_RE = re.compile(
    r"trajectory|planner|motion_planner|prediction|trajpred|iox::|senderport|receiverport|sharedchunk|allocatechunk|reservechunk|getchunk|samplereader|serialize|mergefrom|getmetadata|internalserialize|mplog|logging_|log_message|malloc|operator new|pthread_|mutex|futex",
    re.I,
)

GENERIC_MODULES: Set[str] = {"rbp_others"}

XLSX_NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
XLSX_REL_NS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
SCRIPT_DIR_PLACEHOLDER = "${SCRIPT_DIR}"
CURRENT_DIR_PLACEHOLDER = "${CURRENT_DIR}"
CWD_PLACEHOLDER = "${CWD}"


@dataclass
class PerfSample:
    group: str
    scene: str
    run: str
    path: Path


@dataclass
class ExcelSceneMeta:
    source_file: str
    sheet: str
    scene_id: str
    title: str
    summary: str
    traces: List[str] = field(default_factory=list)


@dataclass
class ScenarioReport:
    group: str
    scene: str
    files: List[str]
    total_samples: int
    parking_samples: int
    module_inventory: List[str]
    top_modules: List[Dict[str, object]]
    top_functions: List[Dict[str, object]]
    module_functions: List[Dict[str, object]]
    warnings: List[str]
    excel_matches: List[ExcelSceneMeta]
    run_summaries: List[Dict[str, object]] = field(default_factory=list)
    trace_ids: List[str] = field(default_factory=list)
    trace_mapping_enabled: bool = False


def replace_path_placeholders(value: str, current_dir: Path, script_dir: Path) -> str:
    replaced = str(value)
    replaced = replaced.replace(CURRENT_DIR_PLACEHOLDER, str(current_dir))
    replaced = replaced.replace(CWD_PLACEHOLDER, str(current_dir))
    replaced = replaced.replace(SCRIPT_DIR_PLACEHOLDER, str(script_dir))
    return replaced


def has_glob_pattern(value: str) -> bool:
    return any(token in value for token in ("*", "?", "["))


def expand_cli_path(value: str, current_dir: Path, script_dir: Path) -> Path:
    replaced = replace_path_placeholders(value, current_dir, script_dir)
    path = Path(replaced)
    if not path.is_absolute():
        path = current_dir / path
    return path


def expand_cli_paths(
    values: Sequence[str],
    current_dir: Path,
    script_dir: Path,
    *,
    files_only: bool = False,
    dirs_only: bool = False,
) -> List[Path]:
    resolved: List[Path] = []
    seen: Set[Path] = set()
    for value in values:
        replaced = replace_path_placeholders(value, current_dir, script_dir)
        candidate = Path(replaced)
        pattern = str(candidate if candidate.is_absolute() else current_dir / candidate)
        matches = [Path(item) for item in glob.glob(pattern, recursive=True)] if has_glob_pattern(pattern) else [Path(pattern)]
        for match in sorted(matches):
            path = match.resolve()
            if not path.exists():
                continue
            if files_only and not path.is_file():
                continue
            if dirs_only and not path.is_dir():
                continue
            if path in seen:
                continue
            seen.add(path)
            resolved.append(path)
    return resolved


def is_generated_runtime_output(path: Path) -> bool:
    return path.name.lower().startswith("parking_runtime_")


def discover_repo_root(current_dir: Path, script_dir: Path, explicit_value: str) -> Optional[Path]:
    candidates = expand_cli_paths([explicit_value], current_dir, script_dir, dirs_only=True)
    if candidates:
        return candidates[0]
    return None


def hotspot_level(top_modules: Sequence[Dict[str, object]], warnings: Sequence[str]) -> str:
    top = top_modules[0] if top_modules else None
    ratio_value = float(top.get("inclusive_ratio_total", 0.0)) if isinstance(top, dict) else 0.0
    if ratio_value >= 0.12 or len(warnings) >= 3:
        return "高"
    if ratio_value >= 0.06 or len(warnings) >= 1:
        return "中"
    return "低"


def summarize_metric_series(values: Sequence[int], totals: Sequence[int], labels: Sequence[str]) -> Dict[str, object]:
    if not values or not totals or not labels:
        return {
            "run_count": 0,
            "avg_samples": 0.0,
            "max_samples": 0,
            "min_samples": 0,
            "avg_ratio_total": 0.0,
            "max_ratio_total": 0.0,
            "min_ratio_total": 0.0,
            "max_label": "",
            "min_label": "",
        }
    ratios = [ratio(value, total) for value, total in zip(values, totals)]
    max_index = max(range(len(values)), key=lambda index: (values[index], ratios[index]))
    min_index = min(range(len(values)), key=lambda index: (values[index], ratios[index]))
    return {
        "run_count": len(values),
        "avg_samples": statistics.fmean(values),
        "max_samples": max(values),
        "min_samples": min(values),
        "avg_ratio_total": statistics.fmean(ratios),
        "max_ratio_total": max(ratios),
        "min_ratio_total": min(ratios),
        "max_label": labels[max_index],
        "min_label": labels[min_index],
    }


def collect_trace_ids(excel_matches: Sequence[ExcelSceneMeta]) -> List[str]:
    trace_ids: List[str] = []
    seen: Set[str] = set()
    for meta in excel_matches:
        for trace in meta.traces:
            normalized = str(trace).strip()
            if not normalized or normalized in seen:
                continue
            trace_ids.append(normalized)
            seen.add(normalized)
    return trace_ids


def attach_trace_mapping(run_summaries: Sequence[Dict[str, object]], excel_matches: Sequence[ExcelSceneMeta]) -> Tuple[List[Dict[str, object]], List[str], bool]:
    trace_ids = collect_trace_ids(excel_matches)
    mapping_enabled = bool(run_summaries) and len(trace_ids) == len(run_summaries)
    enriched: List[Dict[str, object]] = []
    for index, item in enumerate(run_summaries):
        enriched_item = dict(item)
        enriched_item["trace_id"] = trace_ids[index] if mapping_enabled else ""
        enriched_item["trace_mapped"] = mapping_enabled
        enriched.append(enriched_item)
    return enriched, trace_ids, mapping_enabled


def add_trace_fields(raw: Dict[str, object], run_summaries: Sequence[Dict[str, object]]) -> None:
    trace_by_label: Dict[str, str] = {}
    for item in run_summaries:
        label = str(item.get("label", ""))
        trace_id = str(item.get("trace_id", ""))
        if label and trace_id and label not in trace_by_label:
            trace_by_label[label] = trace_id

    for module_item in cast_list(raw["top_modules"]):
        max_run = str(module_item.get("max_run", ""))
        min_run = str(module_item.get("min_run", ""))
        module_item["max_trace"] = trace_by_label.get(max_run, "")
        module_item["min_trace"] = trace_by_label.get(min_run, "")

    for function_item in cast_list(raw["top_functions"]):
        max_run = str(function_item.get("max_run", ""))
        min_run = str(function_item.get("min_run", ""))
        function_item["max_trace"] = trace_by_label.get(max_run, "")
        function_item["min_trace"] = trace_by_label.get(min_run, "")

    for module_entry in cast_list(raw["module_functions"]):
        for function_item in cast_list(module_entry.get("functions", [])):
            max_label = str(function_item.get("max_label", ""))
            min_label = str(function_item.get("min_label", ""))
            function_item["max_trace"] = trace_by_label.get(max_label, "")
            function_item["min_trace"] = trace_by_label.get(min_label, "")


def simplify_run_summaries(run_summaries: Sequence[Dict[str, object]]) -> List[Dict[str, object]]:
    simplified: List[Dict[str, object]] = []
    for item in run_summaries:
        total_samples = int(item.get("total_samples", 0) or 0)
        parking_samples = int(item.get("parking_samples", 0) or 0)
        simplified.append({
            "label": str(item.get("label", "")),
            "file_name": str(item.get("file_name", "")),
            "source_path": str(item.get("source_path", "")),
            "total_samples": total_samples,
            "parking_samples": parking_samples,
            "parking_ratio": ratio(parking_samples, total_samples),
            "trace_id": str(item.get("trace_id", "")),
            "trace_mapped": bool(item.get("trace_mapped", False)),
        })
    return simplified


def build_global_summary(raw_reports: Dict[Tuple[str, str], Dict[str, object]]) -> Dict[str, List[Dict[str, object]]]:
    scenario_keys = list(sorted(raw_reports.keys()))
    scenario_labels = [f"{group} / {scene}" for group, scene in scenario_keys]
    scenario_totals = [int(raw_reports[key]["total_samples"]) for key in scenario_keys]

    modules_seen: Set[str] = set()
    functions_seen: Set[Tuple[str, str]] = set()
    for key in scenario_keys:
        modules_seen.update(raw_reports[key]["module_inclusive"].keys())
        functions_seen.update(raw_reports[key]["function_exclusive"].keys())

    global_modules: List[Dict[str, object]] = []
    for module_name in sorted(modules_seen):
        values = [int(raw_reports[key]["module_inclusive"].get(module_name, 0)) for key in scenario_keys]
        stats = summarize_metric_series(values, scenario_totals, scenario_labels)
        present_values = [value for value in values if value > 0]
        present_ratios = [ratio(value, total) for value, total in zip(values, scenario_totals) if value > 0]
        global_modules.append({
            "module": module_name,
            "scenario_count": len(scenario_keys),
            "present_scenario_count": sum(1 for value in values if value > 0),
            "avg_samples_all": stats["avg_samples"],
            "avg_samples_present": statistics.fmean(present_values) if present_values else 0.0,
            "max_samples": stats["max_samples"],
            "min_samples": stats["min_samples"],
            "avg_ratio_total_all": stats["avg_ratio_total"],
            "avg_ratio_total_present": statistics.fmean(present_ratios) if present_ratios else 0.0,
            "max_ratio_total": stats["max_ratio_total"],
            "min_ratio_total": stats["min_ratio_total"],
            "max_scene": stats["max_label"],
            "min_scene": stats["min_label"],
        })

    global_functions: List[Dict[str, object]] = []
    for module_name, function_name in sorted(functions_seen):
        values = [int(raw_reports[key]["function_exclusive"].get((module_name, function_name), 0)) for key in scenario_keys]
        stats = summarize_metric_series(values, scenario_totals, scenario_labels)
        present_values = [value for value in values if value > 0]
        present_ratios = [ratio(value, total) for value, total in zip(values, scenario_totals) if value > 0]
        global_functions.append({
            "module": module_name,
            "function": function_name,
            "scenario_count": len(scenario_keys),
            "present_scenario_count": sum(1 for value in values if value > 0),
            "avg_samples_all": stats["avg_samples"],
            "avg_samples_present": statistics.fmean(present_values) if present_values else 0.0,
            "max_samples": stats["max_samples"],
            "min_samples": stats["min_samples"],
            "avg_ratio_total_all": stats["avg_ratio_total"],
            "avg_ratio_total_present": statistics.fmean(present_ratios) if present_ratios else 0.0,
            "max_ratio_total": stats["max_ratio_total"],
            "min_ratio_total": stats["min_ratio_total"],
            "max_scene": stats["max_label"],
            "min_scene": stats["min_label"],
        })

    global_modules.sort(key=lambda item: (-float(item["max_ratio_total"]), -float(item["avg_ratio_total_all"]), str(item["module"])))
    global_functions.sort(key=lambda item: (-float(item["max_ratio_total"]), -float(item["avg_ratio_total_all"]), str(item["module"]), str(item["function"])))
    return {
        "modules": global_modules,
        "functions": global_functions,
    }


def normalize_process_name(name: str) -> str:
    if name.startswith(":-1____"):
        return "[idle]"
    match = re.match(r"^(\d+)-(.+)$", name)
    if match:
        name = match.group(2)
    name = re.sub(r"/(\d+)$", "", name)
    name = re.sub(r"-(\d+)$", "", name)
    return name


def parse_folded_line(line: str) -> Tuple[List[str], int]:
    line = line.strip()
    if not line or line.startswith("#"):
        return [], 0
    try:
        stack_part, count_part = line.rsplit(" ", 1)
        return stack_part.split(";"), int(count_part)
    except ValueError:
        return line.split(";"), 1


def parse_sample_count(line: str) -> int:
    stripped = line.strip()
    if not stripped or stripped.startswith("#"):
        return 0
    try:
        return int(stripped.rsplit(" ", 1)[1])
    except (IndexError, ValueError):
        return 0


def trim_call_tree(
    nodes: Sequence[Dict[str, object]],
    *,
    max_nodes: int = 80,
    max_depth: int = 5,
    max_children: int = 6,
) -> List[Dict[str, object]]:
    budget = [max_nodes]

    def clone(node_list: Sequence[Dict[str, object]], depth: int) -> List[Dict[str, object]]:
        if budget[0] <= 0 or depth > max_depth:
            return []
        result: List[Dict[str, object]] = []
        for node in list(node_list)[:max_children]:
            if budget[0] <= 0:
                break
            budget[0] -= 1
            copied: Dict[str, object] = {
                "name": str(node.get("name", "")),
                "samples": int(node.get("samples", 0) or 0),
                "ratio_total": float(node.get("ratio_total", 0.0) or 0.0),
            }
            children = node.get("children", [])
            if isinstance(children, list):
                copied_children = clone(cast_list(children), depth + 1)
                if copied_children:
                    copied["children"] = copied_children
            result.append(copied)
        return result

    return clone(nodes, 1)


def build_compact_html_payload(payload: Dict[str, object]) -> Dict[str, object]:
    compact_scenarios: List[Dict[str, object]] = []
    for scenario in cast_list_of_dict(payload.get("scenarios", [])):
        top_modules = [dict(item) for item in cast_list(scenario.get("top_modules", []))[:12]]
        top_functions: List[Dict[str, object]] = []
        for item in cast_list(scenario.get("top_functions", []))[:12]:
            copied = dict(item)
            copied["call_tree"] = trim_call_tree(cast_list(item.get("call_tree", [])))
            top_functions.append(copied)

        module_functions: List[Dict[str, object]] = []
        for entry in cast_list(scenario.get("module_functions", []))[:8]:
            copied_entry = {
                "module": str(entry.get("module", "")),
                "functions": [],
            }
            for func in cast_list(entry.get("functions", []))[:8]:
                copied_func = dict(func)
                copied_func.pop("call_tree", None)
                copied_entry["functions"].append(copied_func)
            module_functions.append(copied_entry)

        compact_scenarios.append({
            "group": str(scenario.get("group", "")),
            "scene": str(scenario.get("scene", "")),
            "files": list(scenario.get("files", []))[:12],
            "total_samples": int(scenario.get("total_samples", 0) or 0),
            "parking_samples": int(scenario.get("parking_samples", 0) or 0),
            "parking_ratio": float(scenario.get("parking_ratio", 0.0) or 0.0),
            "module_inventory": list(scenario.get("module_inventory", [])),
            "top_modules": top_modules,
            "top_functions": top_functions,
            "module_functions": module_functions,
            "warnings": list(scenario.get("warnings", []))[:20],
            "excel_matches": [
                {
                    "sheet": str(meta.get("sheet", "")),
                    "scene_id": str(meta.get("scene_id", "")),
                    "summary": str(meta.get("summary", "")),
                    "traces": list(meta.get("traces", []))[:20],
                }
                for meta in cast_list_of_dict(scenario.get("excel_matches", []))[:8]
            ],
            "run_summaries": [dict(item) for item in cast_list(scenario.get("run_summaries", []))[:20]],
            "trace_ids": list(scenario.get("trace_ids", []))[:30],
            "trace_mapping_enabled": bool(scenario.get("trace_mapping_enabled", False)),
        })

    global_stats_obj = payload.get("global_stats", {})
    global_stats = global_stats_obj if isinstance(global_stats_obj, dict) else {}
    compact_global_stats = {
        "modules": [dict(item) for item in cast_list(global_stats.get("modules", []))[:80]],
        "functions": [dict(item) for item in cast_list(global_stats.get("functions", []))[:80]],
    }

    return {
        "generated_at": str(payload.get("generated_at", "")),
        "perf_root": str(payload.get("perf_root", "")),
        "excel": list(payload.get("excel", [])),
        "repo_root": str(payload.get("repo_root", "")),
        "scenario_count": int(payload.get("scenario_count", 0) or 0),
        "global_stats": compact_global_stats,
        "scenarios": compact_scenarios,
    }


def excel_column_name(index: int) -> str:
    name = ""
    current = index
    while current > 0:
        current, remainder = divmod(current - 1, 26)
        name = chr(65 + remainder) + name
    return name


def sanitize_xml_text(value: object) -> str:
    text = str(value)
    text = re.sub(r"[^\u0009\u000A\u000D\u0020-\uD7FF\uE000-\uFFFD]", "", text)
    return xml_escape(text)


def xlsx_cell_xml(cell_ref: str, value: object) -> str:
    if isinstance(value, bool):
        return f'<c r="{cell_ref}" t="b"><v>{1 if value else 0}</v></c>'
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return f'<c r="{cell_ref}"><v>{value}</v></c>'
    text = sanitize_xml_text(value)
    return f'<c r="{cell_ref}" t="inlineStr"><is><t xml:space="preserve">{text}</t></is></c>'


def build_xlsx_sheet_xml(rows: Sequence[Sequence[object]]) -> str:
    row_xml: List[str] = []
    for row_index, row in enumerate(rows, start=1):
        cells = [xlsx_cell_xml(f"{excel_column_name(col_index)}{row_index}", value) for col_index, value in enumerate(row, start=1)]
        row_xml.append(f'<row r="{row_index}">{"".join(cells)}</row>')
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        f'<sheetData>{"".join(row_xml)}</sheetData>'
        '</worksheet>'
    )


def write_simple_xlsx(path: Path, sheets: Sequence[Tuple[str, Sequence[Sequence[object]]]]) -> None:
    content_types = [
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
        '<Default Extension="xml" ContentType="application/xml"/>',
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
    ]
    for index in range(1, len(sheets) + 1):
        content_types.append(
            f'<Override PartName="/xl/worksheets/sheet{index}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        )
    content_types.append('</Types>')

    workbook_xml = [
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">',
        '<sheets>',
    ]
    workbook_rels_xml = [
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">',
    ]
    for index, (sheet_name, _rows) in enumerate(sheets, start=1):
        workbook_xml.append(f'<sheet name="{sanitize_xml_text(sheet_name)}" sheetId="{index}" r:id="rId{index}"/>')
        workbook_rels_xml.append(
            f'<Relationship Id="rId{index}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{index}.xml"/>'
        )
    workbook_xml.extend(['</sheets>', '</workbook>'])
    workbook_rels_xml.append('</Relationships>')

    root_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        '</Relationships>'
    )

    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", "".join(content_types))
        archive.writestr("_rels/.rels", root_rels)
        archive.writestr("xl/workbook.xml", "".join(workbook_xml))
        archive.writestr("xl/_rels/workbook.xml.rels", "".join(workbook_rels_xml))
        for index, (_sheet_name, rows) in enumerate(sheets, start=1):
            archive.writestr(f"xl/worksheets/sheet{index}.xml", build_xlsx_sheet_xml(rows))


def build_alert_scene_rows(reports: Sequence[ScenarioReport]) -> Tuple[List[List[object]], List[List[object]]]:
    summary_rows: List[List[object]] = [[
        "命中类型",
        "热点等级",
        "场景组",
        "场景",
        "总样本",
        "Parking样本",
        "Parking占比",
        "主要模块",
        "主要模块占比",
        "告警数",
        "Trace编号",
        "Excel摘要",
        "火焰图文件数",
        "火焰图文件列表",
    ]]
    warning_rows: List[List[object]] = [[
        "热点等级",
        "场景组",
        "场景",
        "告警序号",
        "告警内容",
        "主要模块",
        "主要模块占比",
        "Trace编号",
        "Excel摘要",
    ]]

    def report_sort_key(report: ScenarioReport) -> Tuple[int, int, float, str, str]:
        level = hotspot_level(report.top_modules, report.warnings)
        priority = 0 if level == "高" else 1
        top_ratio = float(report.top_modules[0].get("inclusive_ratio_total", 0.0)) if report.top_modules else 0.0
        return (priority, -len(report.warnings), -top_ratio, report.group, report.scene)

    selected_reports = [
        report
        for report in reports
        if report.warnings or hotspot_level(report.top_modules, report.warnings) == "高"
    ]
    for report in sorted(selected_reports, key=report_sort_key):
        level = hotspot_level(report.top_modules, report.warnings)
        top_module = report.top_modules[0] if report.top_modules else {}
        hit_types: List[str] = []
        if level == "高":
            hit_types.append("高热点")
        if report.warnings:
            hit_types.append("告警")
        summary_rows.append([
            "/".join(hit_types) if hit_types else "-",
            level,
            report.group,
            report.scene,
            report.total_samples,
            report.parking_samples,
            ratio(report.parking_samples, report.total_samples),
            str(top_module.get("module", "-")),
            float(top_module.get("inclusive_ratio_total", 0.0) or 0.0),
            len(report.warnings),
            ", ".join(report.trace_ids),
            summarize_excel(report.excel_matches),
            len(report.files),
            "\n".join(report.files),
        ])
        if report.warnings:
            for index, warning in enumerate(report.warnings, start=1):
                warning_rows.append([
                    level,
                    report.group,
                    report.scene,
                    index,
                    warning,
                    str(top_module.get("module", "-")),
                    float(top_module.get("inclusive_ratio_total", 0.0) or 0.0),
                    ", ".join(report.trace_ids),
                    summarize_excel(report.excel_matches),
                ])

    return summary_rows, warning_rows


def is_noise_symbol(symbol: str) -> bool:
    return symbol in NOISE_SYMBOLS or (symbol.startswith("[") and symbol.endswith("]") and not EXPLICIT_PARKING_RE.search(symbol))


def is_excluded_frame(frame: str) -> bool:
    return any(pattern.search(frame) for pattern in EXCLUDED_MODULE_PATTERNS)


def normalize_key(text: str) -> str:
    cleaned = re.sub(r"\s+", " ", text.strip().lower())
    cleaned = cleaned.replace("（", "(").replace("）", ")")
    cleaned = cleaned.replace("_", "_")
    return cleaned


def scene_aliases(scene_name: str) -> Set[str]:
    base = normalize_key(scene_name)
    aliases = {base}
    if base.startswith("apa_"):
        aliases.add(base[4:])
    for suffix in ("_chengren", "_xiaohai"):
        if base.endswith(suffix):
            aliases.add(base[: -len(suffix)])
    aliases.add(base.replace("apa_", ""))
    aliases.add(base.replace(" ", ""))
    return {alias for alias in aliases if alias}


def discover_perf_samples(perf_root: Path) -> Dict[Tuple[str, str], List[PerfSample]]:
    scenarios: Dict[Tuple[str, str], List[PerfSample]] = defaultdict(list)
    for path in perf_root.rglob("*.fold"):
        relative = path.relative_to(perf_root)
        if len(relative.parts) < 2:
            continue
        group = relative.parts[0]
        scene = relative.parts[1]
        run_parts = [part for part in relative.parts[2:-1] if part.lower().startswith("perf_")]
        run = "/".join(run_parts) if run_parts else path.parent.name
        scenarios[(group, scene)].append(PerfSample(group=group, scene=scene, run=run, path=path))
    return scenarios


def column_to_number(col_ref: str) -> int:
    value = 0
    for char in col_ref:
        if "A" <= char <= "Z":
            value = value * 26 + ord(char) - 64
    return value


def read_shared_strings(archive: zipfile.ZipFile) -> List[str]:
    if "xl/sharedStrings.xml" not in archive.namelist():
        return []
    root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
    strings = []
    for item in root.findall(f"{XLSX_NS}si"):
        strings.append("".join(node.text or "" for node in item.iterfind(f".//{XLSX_NS}t")))
    return strings


def row_to_list(row: ET.Element, shared: Sequence[str]) -> List[str]:
    values: Dict[int, str] = {}
    for cell in row.findall(f"{XLSX_NS}c"):
        ref = cell.attrib.get("r", "")
        match = re.match(r"([A-Z]+)(\d+)", ref)
        if not match:
            continue
        index = column_to_number(match.group(1))
        cell_type = cell.attrib.get("t")
        if cell_type == "s":
            node = cell.find(f"{XLSX_NS}v")
            value = shared[int(node.text)] if node is not None and node.text else ""
        elif cell_type == "inlineStr":
            node = cell.find(f".//{XLSX_NS}t")
            value = node.text if node is not None and node.text else ""
        else:
            node = cell.find(f"{XLSX_NS}v")
            value = node.text if node is not None and node.text else ""
        values[index] = value.strip()
    if not values:
        return []
    max_index = max(values)
    return [values.get(i, "") for i in range(1, max_index + 1)]


def load_workbook_rows(path: Path) -> Dict[str, List[List[str]]]:
    with zipfile.ZipFile(path) as archive:
        shared = read_shared_strings(archive)
        workbook = ET.fromstring(archive.read("xl/workbook.xml"))
        rels = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
        rel_map = {rel.attrib["Id"]: rel.attrib["Target"] for rel in rels}
        sheets: Dict[str, List[List[str]]] = {}
        for sheet in workbook.find(f"{XLSX_NS}sheets").findall(f"{XLSX_NS}sheet"):
            name = sheet.attrib["name"]
            rel_id = sheet.attrib[f"{XLSX_REL_NS}id"]
            target = "xl/" + rel_map[rel_id].lstrip("/")
            root = ET.fromstring(archive.read(target))
            rows = []
            for row in root.find(f"{XLSX_NS}sheetData").findall(f"{XLSX_NS}row"):
                values = row_to_list(row, shared)
                if any(values):
                    rows.append(values)
            sheets[name] = rows
        return sheets


def safe_get(row: Sequence[str], index: int) -> str:
    return row[index] if index < len(row) else ""


def build_excel_index(excel_paths: Sequence[Path]) -> Dict[str, List[ExcelSceneMeta]]:
    index: Dict[str, List[ExcelSceneMeta]] = defaultdict(list)
    seen_entries: Set[Tuple[str, str, str, str]] = set()
    for path in excel_paths:
        sheets = load_workbook_rows(path)
        for sheet_name, rows in sheets.items():
            if sheet_name == "APA_73":
                parse_apa73_sheet(path, sheet_name, rows, index, seen_entries)
            elif sheet_name == "APA_Sotif case":
                parse_sotif_sheet(path, sheet_name, rows, index, seen_entries)
            elif sheet_name == "MAA":
                parse_maa_sheet(path, sheet_name, rows, index, seen_entries)
            elif sheet_name == "MEB":
                parse_meb_sheet(path, sheet_name, rows, index, seen_entries)
    return index


def add_excel_meta(index: Dict[str, List[ExcelSceneMeta]], seen: Set[Tuple[str, str, str, str]], meta: ExcelSceneMeta) -> None:
    fingerprint = (meta.source_file, meta.sheet, meta.scene_id, meta.summary)
    if fingerprint in seen:
        return
    seen.add(fingerprint)
    for alias in scene_aliases(meta.scene_id) | scene_aliases(meta.title):
        index[alias].append(meta)


def parse_apa73_sheet(path: Path, sheet_name: str, rows: Sequence[Sequence[str]], index: Dict[str, List[ExcelSceneMeta]], seen: Set[Tuple[str, str, str, str]]) -> None:
    current_scene_id = ""
    current_title = ""
    tests: Dict[str, Dict[str, object]] = {}
    for row in rows:
        scene_id = safe_get(row, 0) or current_scene_id
        title = safe_get(row, 1) or current_title
        if scene_id:
            current_scene_id = scene_id
        if title:
            current_title = title
        if not current_scene_id:
            continue
        state = tests.setdefault(current_scene_id, {"title": current_title, "total": 0, "success": 0, "directions": set(), "traces": []})
        if safe_get(row, 6).isdigit():
            state["total"] = int(state["total"]) + 1
        if safe_get(row, 10) == "1":
            state["success"] = int(state["success"]) + 1
        if safe_get(row, 7):
            cast_set(state["directions"]).add(safe_get(row, 7))
        trace = safe_get(row, 26)
        if trace:
            cast_list(state["traces"]).append(trace)
        if current_title and not state["title"]:
            state["title"] = current_title
    for scene_id, state in tests.items():
        total = int(state["total"])
        success = int(state["success"])
        summary = f"tests={total}, success={success}, directions={','.join(sorted(cast_set(state['directions']))) or '-'}"
        add_excel_meta(index, seen, ExcelSceneMeta(
            source_file=path.name,
            sheet=sheet_name,
            scene_id=scene_id,
            title=str(state["title"]),
            summary=summary,
            traces=cast_list(state["traces"]),
        ))


def parse_sotif_sheet(path: Path, sheet_name: str, rows: Sequence[Sequence[str]], index: Dict[str, List[ExcelSceneMeta]], seen: Set[Tuple[str, str, str, str]]) -> None:
    current_scene_id = ""
    current_title = ""
    grouped: Dict[str, Dict[str, object]] = {}
    for row in rows:
        scene_id = safe_get(row, 0) or current_scene_id
        title = safe_get(row, 1) or current_title
        if scene_id:
            current_scene_id = scene_id
        if title:
            current_title = title
        if not current_scene_id:
            continue
        state = grouped.setdefault(current_scene_id, {"title": current_title, "variants": 0, "notes": []})
        description = safe_get(row, 2) or safe_get(row, 3)
        if description:
            state["variants"] = int(state["variants"]) + 1
        for column in row[8:]:
            if column:
                cast_list(state["notes"]).append(column)
    for scene_id, state in grouped.items():
        summary = f"variants={state['variants']}, notes={'; '.join(cast_list(state['notes'])[:4])}"
        add_excel_meta(index, seen, ExcelSceneMeta(
            source_file=path.name,
            sheet=sheet_name,
            scene_id=scene_id,
            title=str(state["title"]),
            summary=summary,
            traces=[],
        ))


def parse_maa_sheet(path: Path, sheet_name: str, rows: Sequence[Sequence[str]], index: Dict[str, List[ExcelSceneMeta]], seen: Set[Tuple[str, str, str, str]]) -> None:
    for row in rows:
        scene = safe_get(row, 1)
        if not scene or scene in {"Scene Catalog Collection", "静态障碍物测试用例（前后向）"}:
            continue
        if not safe_get(row, 0).isdigit():
            continue
        notes = [value for value in row[5:] if value]
        summary = f"kpi={safe_get(row, 2)}, repetitions={safe_get(row, 3)}, notes={'; '.join(notes[:6])}"
        add_excel_meta(index, seen, ExcelSceneMeta(
            source_file=path.name,
            sheet=sheet_name,
            scene_id=scene,
            title=scene,
            summary=summary,
            traces=[],
        ))


def parse_meb_sheet(path: Path, sheet_name: str, rows: Sequence[Sequence[str]], index: Dict[str, List[ExcelSceneMeta]], seen: Set[Tuple[str, str, str, str]]) -> None:
    for row in rows:
        scene = safe_get(row, 0)
        if not scene or scene.startswith("*") or scene in {"Low Objects", "Picture", "Backwards", "Total test"}:
            continue
        if scene == "":
            continue
        if not safe_get(row, 3):
            continue
        note_values = [value for value in row[8:] if value]
        summary = f"clutter={safe_get(row, 2)}, speed={safe_get(row, 3)}, success_rate={safe_get(row, 7)}, notes={'; '.join(note_values[:4])}"
        add_excel_meta(index, seen, ExcelSceneMeta(
            source_file=path.name,
            sheet=sheet_name,
            scene_id=scene,
            title=scene,
            summary=summary,
            traces=[],
        ))


def cast_list(value: object) -> List[str]:
    return value if isinstance(value, list) else []


def cast_list_of_dict(value: object) -> List[Dict[str, object]]:
    return value if isinstance(value, list) else []


def cast_set(value: object) -> Set[str]:
    return value if isinstance(value, set) else set()


def mine_repo_symbols(repo_root: Optional[Path], limit: int = 500) -> Set[str]:
    if repo_root is None or not repo_root.exists():
        return set()
    result: Set[str] = set()
    path_keywords = re.compile(r"park|apa|slot|maneuver|trajectory|apahmi|pdc", re.I)
    token_pattern = re.compile(r"\b[A-Za-z_][A-Za-z0-9_:]{4,}\b")
    for path in repo_root.rglob("*"):
        if len(result) >= limit:
            break
        if not path.is_file() or path.suffix.lower() not in {".h", ".hpp", ".c", ".cc", ".cpp"}:
            continue
        if not path_keywords.search(str(path)):
            continue
        try:
            with path.open("r", encoding="utf-8", errors="replace") as handle:
                for line in handle:
                    if not path_keywords.search(line):
                        continue
                    for token in token_pattern.findall(line):
                        lower = token.lower().strip(":")
                        if len(lower) > 48:
                            continue
                        if path_keywords.search(lower):
                            result.add(lower)
                            if len(result) >= limit:
                                break
                    if len(result) >= limit:
                        break
        except OSError:
            continue
    return result


def frame_repo_hit(frame: str, repo_symbols: Set[str]) -> bool:
    if not repo_symbols:
        return False
    for token in re.findall(r"[a-z_][a-z0-9_]{3,}", frame.lower()):
        if token in repo_symbols:
            return True
    return False


def has_direct_context(frames: Sequence[str], repo_symbols: Set[str]) -> bool:
    for frame in frames:
        if is_excluded_frame(frame):
            continue
        lowered = frame.lower()
        if any(token in lowered for token in DIRECT_CONTEXT_SUBSTRINGS):
            return True
        if EXPLICIT_PARKING_RE.search(frame):
            return True
        if frame_repo_hit(frame, repo_symbols):
            return True
    return False


def classify_frame(frame: str, direct_context: bool, repo_symbols: Set[str]) -> Optional[str]:
    if is_excluded_frame(frame):
        return None
    if not direct_context and not EXPLICIT_PARKING_RE.search(frame):
        return None
    for module_name, pattern in MODULE_PATTERNS:
        if pattern.search(frame):
            return module_name
    return None


def detect_owner_module(
    frames: Sequence[str],
    repo_symbols: Set[str],
    frame_cache: Optional[Dict[str, Optional[str]]] = None,
) -> Optional[str]:
    direct_context = has_direct_context(frames, repo_symbols)
    candidates: List[Tuple[int, str]] = []
    process_candidate: Optional[str] = None
    for index, frame in enumerate(frames):
        if is_noise_symbol(frame) or is_excluded_frame(frame):
            continue
        if frame_cache is not None and frame in frame_cache:
            category = frame_cache[frame]
        else:
            category = classify_frame(frame, direct_context, repo_symbols)
            if frame_cache is not None:
                frame_cache[frame] = category
        if not category:
            continue
        if index == 0:
            process_candidate = category
        candidates.append((index, category))
    if not candidates:
        return None
    specific = [(index, category) for index, category in candidates if category not in GENERIC_MODULES]
    if process_candidate and process_candidate not in GENERIC_MODULES:
        return process_candidate
    if specific:
        return max(specific, key=lambda item: item[0])[1]
    if process_candidate:
        return process_candidate
    return max(candidates, key=lambda item: item[0])[1]


def select_leaf_function(
    frames: Sequence[str],
    owner_module: str,
    repo_symbols: Set[str],
    frame_cache: Optional[Dict[str, Optional[str]]] = None,
) -> Optional[str]:
    direct_context = True
    fallback: Optional[str] = None
    for frame in reversed(frames[1:]):
        if is_noise_symbol(frame) or is_excluded_frame(frame):
            continue
        if fallback is None:
            fallback = frame
        if frame_cache is not None and frame in frame_cache:
            category = frame_cache[frame]
        else:
            category = classify_frame(frame, direct_context, repo_symbols)
            if frame_cache is not None:
                frame_cache[frame] = category
        if category == owner_module:
            return frame
    return fallback


def extract_call_chain(frames: Sequence[str], leaf_function: str) -> List[str]:
    filtered_frames: List[str] = []
    for frame in frames[1:]:
        if is_noise_symbol(frame) or is_excluded_frame(frame):
            continue
        filtered_frames.append(frame)
    if not filtered_frames:
        return [leaf_function]

    for index in range(len(filtered_frames) - 1, -1, -1):
        if filtered_frames[index] == leaf_function:
            return filtered_frames[: index + 1]
    return filtered_frames + [leaf_function]


def build_call_tree(path_counter: Counter[Tuple[str, ...]], total_samples: int) -> List[Dict[str, object]]:
    root: Dict[str, object] = {"children": {}}
    for path, count in path_counter.items():
        if count <= 0:
            continue
        cursor = root
        for name in path:
            children = cursor.setdefault("children", {})
            if name not in children:
                children[name] = {"name": name, "samples": 0, "children": {}}
            child = children[name]
            child["samples"] = int(child.get("samples", 0)) + count
            cursor = child

    def freeze(node: Dict[str, object]) -> List[Dict[str, object]]:
        children = list(dict(node.get("children", {})).values())
        children.sort(key=lambda item: (-int(item.get("samples", 0)), str(item.get("name", ""))))
        return [
            {
                "name": str(child.get("name", "")),
                "samples": int(child.get("samples", 0)),
                "ratio_total": ratio(int(child.get("samples", 0)), total_samples),
                "children": freeze(child),
            }
            for child in children
        ]

    return freeze(root)


def find_leaf_category(
    frames: Sequence[str],
    direct_context: bool,
    repo_symbols: Set[str],
    frame_cache: Optional[Dict[str, Optional[str]]] = None,
) -> Optional[Tuple[str, str]]:
    for frame in reversed(frames):
        if is_noise_symbol(frame):
            continue
        if frame_cache is not None and frame in frame_cache:
            category = frame_cache[frame]
        else:
            category = classify_frame(frame, direct_context, repo_symbols)
            if frame_cache is not None:
                frame_cache[frame] = category
        if category:
            return category, frame
    return None


def analyze_scenario(files: Sequence[PerfSample], repo_symbols: Set[str], top_n: int) -> Dict[str, object]:
    total_samples = 0
    parking_samples = 0
    module_inclusive: Counter[str] = Counter()
    module_exclusive: Counter[str] = Counter()
    function_inclusive: Counter[Tuple[str, str]] = Counter()
    function_exclusive: Counter[Tuple[str, str]] = Counter()
    function_call_paths: Dict[Tuple[str, str], Counter[Tuple[str, ...]]] = defaultdict(Counter)
    frame_cache: Dict[str, Optional[str]] = {}
    run_summaries: List[Dict[str, object]] = []

    for sample in sorted(files, key=lambda item: (item.run.lower(), str(item.path).lower())):
        run_total_samples = 0
        run_parking_samples = 0
        run_module_inclusive: Counter[str] = Counter()
        run_function_exclusive: Counter[Tuple[str, str]] = Counter()
        with sample.path.open("r", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                count = parse_sample_count(line)
                if count <= 0:
                    continue
                total_samples += count
                run_total_samples += count
                lowered_line = line.lower()
                if not any(hint in lowered_line for hint in QUICK_LINE_HINTS):
                    continue
                frames, count = parse_folded_line(line)
                if count <= 0 or not frames:
                    continue
                process = normalize_process_name(frames[0])
                stack_frames = [process] + frames[1:]
                owner_module = detect_owner_module(stack_frames, repo_symbols, frame_cache)
                if not owner_module:
                    continue
                parking_samples += count
                run_parking_samples += count
                module_inclusive[owner_module] += count
                module_exclusive[owner_module] += count
                run_module_inclusive[owner_module] += count

                seen_functions: Set[str] = set()
                for frame in stack_frames[1:]:
                    if is_noise_symbol(frame) or is_excluded_frame(frame):
                        continue
                    if frame not in seen_functions:
                        function_inclusive[(owner_module, frame)] += count
                        seen_functions.add(frame)

                leaf_function = select_leaf_function(stack_frames, owner_module, repo_symbols, frame_cache)
                if leaf_function:
                    function_exclusive[(owner_module, leaf_function)] += count
                    run_function_exclusive[(owner_module, leaf_function)] += count
                    call_chain = extract_call_chain(stack_frames, leaf_function)
                    function_call_paths[(owner_module, leaf_function)][tuple(call_chain)] += count

        run_summaries.append({
            "label": sample.run,
            "file_name": sample.path.name,
            "source_path": str(sample.path),
            "total_samples": run_total_samples,
            "parking_samples": run_parking_samples,
            "module_inclusive": run_module_inclusive,
            "function_exclusive": run_function_exclusive,
        })

    run_labels = [str(item["label"]) for item in run_summaries]
    run_totals = [int(item["total_samples"]) for item in run_summaries]

    top_modules = []
    for category, inclusive_count in module_inclusive.most_common(top_n):
        run_values = [int(item["module_inclusive"].get(category, 0)) for item in run_summaries]
        run_stats = summarize_metric_series(run_values, run_totals, run_labels)
        top_modules.append({
            "module": category,
            "inclusive_samples": inclusive_count,
            "inclusive_ratio_total": ratio(inclusive_count, total_samples),
            "inclusive_ratio_parking": ratio(inclusive_count, parking_samples),
            "exclusive_samples": module_exclusive.get(category, 0),
            "exclusive_ratio_total": ratio(module_exclusive.get(category, 0), total_samples),
            "avg_samples": run_stats["avg_samples"],
            "max_samples": run_stats["max_samples"],
            "min_samples": run_stats["min_samples"],
            "avg_ratio_total": run_stats["avg_ratio_total"],
            "max_ratio_total": run_stats["max_ratio_total"],
            "min_ratio_total": run_stats["min_ratio_total"],
            "max_run": run_stats["max_label"],
            "min_run": run_stats["min_label"],
        })

    top_functions = []
    for (category, frame), exclusive_count in function_exclusive.most_common(top_n):
        inclusive_count = function_inclusive.get((category, frame), 0)
        run_values = [int(item["function_exclusive"].get((category, frame), 0)) for item in run_summaries]
        run_stats = summarize_metric_series(run_values, run_totals, run_labels)
        top_functions.append({
            "module": category,
            "function": frame,
            "exclusive_samples": exclusive_count,
            "exclusive_ratio_total": ratio(exclusive_count, total_samples),
            "exclusive_ratio_parking": ratio(exclusive_count, parking_samples),
            "inclusive_samples": inclusive_count,
            "inclusive_ratio_total": ratio(inclusive_count, total_samples),
            "avg_samples": run_stats["avg_samples"],
            "max_samples": run_stats["max_samples"],
            "min_samples": run_stats["min_samples"],
            "avg_ratio_total": run_stats["avg_ratio_total"],
            "max_ratio_total": run_stats["max_ratio_total"],
            "min_ratio_total": run_stats["min_ratio_total"],
            "max_run": run_stats["max_label"],
            "min_run": run_stats["min_label"],
            "call_tree": build_call_tree(function_call_paths.get((category, frame), Counter()), total_samples),
        })

    module_functions = []
    for module_item in top_modules:
        module_name = str(module_item["module"])
        ranked = [
            {
                "function": frame,
                "exclusive_samples": exclusive_count,
                "exclusive_ratio_total": ratio(exclusive_count, total_samples),
                "exclusive_ratio_module": ratio(exclusive_count, int(module_item["inclusive_samples"])),
                "inclusive_samples": function_inclusive.get((module_name, frame), 0),
                "inclusive_ratio_total": ratio(function_inclusive.get((module_name, frame), 0), total_samples),
                "call_tree": build_call_tree(function_call_paths.get((module_name, frame), Counter()), total_samples),
                **summarize_metric_series(
                    [int(item["function_exclusive"].get((module_name, frame), 0)) for item in run_summaries],
                    run_totals,
                    run_labels,
                ),
            }
            for (category, frame), exclusive_count in function_exclusive.most_common()
            if category == module_name
        ]
        module_functions.append({
            "module": module_name,
            "functions": ranked,
        })

    return {
        "total_samples": total_samples,
        "parking_samples": parking_samples,
        "top_modules": top_modules,
        "top_functions": top_functions,
        "module_functions": module_functions,
        "module_inclusive": module_inclusive,
        "function_exclusive": function_exclusive,
        "run_summaries": run_summaries,
    }


def ratio(part: int, total: int) -> float:
    return (part / total) if total else 0.0


def build_peer_stats(reports: Dict[Tuple[str, str], Dict[str, object]]) -> Tuple[Dict[str, Dict[str, List[float]]], Dict[str, Dict[str, List[float]]]]:
    module_stats: Dict[str, Dict[str, List[float]]] = defaultdict(lambda: defaultdict(list))
    function_stats: Dict[str, Dict[str, List[float]]] = defaultdict(lambda: defaultdict(list))
    for (group, _scene), report in reports.items():
        total_samples = int(report["total_samples"])
        for item in report["top_modules"]:
            module_stats[group][str(item["module"])].append(ratio(int(item["inclusive_samples"]), total_samples))
        for item in report["top_functions"]:
            function_stats[group][str(item["function"])].append(ratio(int(item["exclusive_samples"]), total_samples))
    return module_stats, function_stats


def median_or_zero(values: Sequence[float]) -> float:
    filtered = [value for value in values if value > 0]
    return statistics.median(filtered) if filtered else 0.0


def build_warnings(
    group: str,
    report: Dict[str, object],
    module_stats: Dict[str, Dict[str, List[float]]],
    function_stats: Dict[str, Dict[str, List[float]]],
    module_threshold: float,
    function_threshold: float,
    overhead_threshold: float,
    peer_factor: float,
) -> List[str]:
    warnings: List[str] = []
    total_samples = int(report["total_samples"])
    parking_samples = int(report["parking_samples"])
    parking_share = ratio(parking_samples, total_samples)
    if parking_share >= 0.45:
        warnings.append(f"parking相关堆栈占比达到 {parking_share:.1%}，整体算力负载偏高。")
    elif parking_share <= 0.02:
        warnings.append(f"parking相关堆栈占比仅 {parking_share:.1%}，可能存在符号识别不足或该场景未充分触发泊车主流程。")

    for item in report["top_modules"]:
        module = str(item["module"])
        total_ratio = float(item["inclusive_ratio_total"])
        baseline = median_or_zero(module_stats[group].get(module, []))
        if total_ratio >= module_threshold:
            warnings.append(f"模块 {module} 累计占比 {total_ratio:.1%}，超过绝对阈值 {module_threshold:.1%}。")
        if baseline > 0 and total_ratio >= max(0.02, baseline * peer_factor):
            warnings.append(f"模块 {module} 累计占比 {total_ratio:.1%}，约为同组中位数 {baseline:.1%} 的 {total_ratio / baseline:.1f} 倍。")
        if module == "overhead" and total_ratio >= overhead_threshold:
            warnings.append(f"parking链路中的通用开销占比 {total_ratio:.1%}，建议重点检查 IPC/日志/内存分配热点。")

    for item in report["top_functions"]:
        function_name = str(item["function"])
        total_ratio = float(item["exclusive_ratio_total"])
        baseline = median_or_zero(function_stats[group].get(function_name, []))
        if total_ratio >= function_threshold:
            warnings.append(f"函数 {function_name} 独占占比 {total_ratio:.1%}，超过绝对阈值 {function_threshold:.1%}。")
        if baseline > 0 and total_ratio >= max(0.01, baseline * peer_factor):
            warnings.append(f"函数 {function_name} 独占占比 {total_ratio:.1%}，约为同组中位数 {baseline:.1%} 的 {total_ratio / baseline:.1f} 倍。")

    deduped: List[str] = []
    seen = set()
    for warning in warnings:
        if warning not in seen:
            deduped.append(warning)
            seen.add(warning)
    return deduped


def summarize_excel(matches: Sequence[ExcelSceneMeta]) -> str:
    if not matches:
        return "未匹配到Excel场景元数据"
    parts = []
    for meta in matches[:3]:
        parts.append(f"[{meta.sheet}] {meta.scene_id}: {meta.summary}")
    return " | ".join(parts)


def render_markdown(
    reports: Sequence[ScenarioReport],
    perf_root: Path,
    excel_paths: Sequence[Path],
    repo_root: Optional[Path],
    global_stats: Dict[str, List[Dict[str, object]]],
) -> str:
    lines = []
    lines.append("# Parking Runtime 场景分析报告")
    lines.append("")
    lines.append(f"- 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"- perf 根目录: {perf_root}")
    lines.append(f"- Excel: {', '.join(str(path) for path in excel_paths) if excel_paths else '无'}")
    lines.append(f"- oneparking 代码: {repo_root if repo_root else '未提供'}")
    lines.append("")
    lines.append("## 场景总览")
    lines.append("")
    lines.append("| 场景组 | 场景 | 文件数 | 总样本 | Parking样本占比 | 主要模块 | 告警数 | Excel摘要 |")
    lines.append("| --- | --- | ---: | ---: | ---: | --- | ---: | --- |")
    for report in reports:
        major_module = report.top_modules[0]["module"] if report.top_modules else "-"
        lines.append(
            f"| {report.group} | {report.scene} | {len(report.files)} | {report.total_samples:,} | {ratio(report.parking_samples, report.total_samples):.1%} | {major_module} | {len(report.warnings)} | {summarize_excel(report.excel_matches)} |"
        )

    lines.append("")
    lines.append("## 所有场景模块统计")
    lines.append("")
    lines.append("| 模块 | 命中场景数 | 平均占比(全场景) | 平均占比(命中场景) | 最大占比 | 最大场景 |")
    lines.append("| --- | ---: | ---: | ---: | ---: | --- |")
    for item in global_stats.get("modules", []):
        lines.append(
            f"| {item['module']} | {int(item['present_scenario_count'])}/{int(item['scenario_count'])} | {float(item['avg_ratio_total_all']):.1%} | {float(item['avg_ratio_total_present']):.1%} | {float(item['max_ratio_total']):.1%} | {item['max_scene']} |"
        )

    lines.append("")
    lines.append("## 所有场景函数统计 Top 50")
    lines.append("")
    lines.append("| 模块 | 函数 | 命中场景数 | 平均占比(全场景) | 最大占比 | 最大场景 |")
    lines.append("| --- | --- | ---: | ---: | ---: | --- |")
    for item in global_stats.get("functions", [])[:50]:
        lines.append(
            f"| {item['module']} | {item['function']} | {int(item['present_scenario_count'])}/{int(item['scenario_count'])} | {float(item['avg_ratio_total_all']):.1%} | {float(item['max_ratio_total']):.1%} | {item['max_scene']} |"
        )

    for report in reports:
        lines.append("")
        lines.append(f"## {report.group} / {report.scene}")
        lines.append("")
        lines.append(f"- fold文件: {len(report.files)}")
        lines.append(f"- 总样本: {report.total_samples:,}")
        lines.append(f"- Parking相关样本: {report.parking_samples:,} ({ratio(report.parking_samples, report.total_samples):.1%})")
        lines.append(f"- Excel信息: {summarize_excel(report.excel_matches)}")
        lines.append("")
        lines.append("### Top Modules")
        lines.append("")
        lines.append("| 模块 | Inclusive样本 | 占总样本 | 场景内平均占比 | 场景内最大占比 | 最大Run | Exclusive样本 |")
        lines.append("| --- | ---: | ---: | ---: | ---: | --- | ---: |")
        for item in report.top_modules:
            lines.append(
                f"| {item['module']} | {int(item['inclusive_samples']):,} | {float(item['inclusive_ratio_total']):.1%} | {float(item['avg_ratio_total']):.1%} | {float(item['max_ratio_total']):.1%} | {item['max_run']} | {int(item['exclusive_samples']):,} |"
            )
        lines.append("")
        lines.append("### 模块内函数热点")
        lines.append("")
        for module_item in report.module_functions:
            lines.append(f"#### {module_item['module']}")
            lines.append("")
            lines.append("| 函数 | 占总样本 | 场景内平均占比 | 场景内最大占比 | 最大Run | 占模块样本 | Exclusive样本 | Inclusive样本 |")
            lines.append("| --- | ---: | ---: | ---: | --- | ---: | ---: | ---: |")
            functions = module_item["functions"]
            if functions:
                for item in functions:
                    lines.append(
                        f"| {item['function']} | {float(item['exclusive_ratio_total']):.1%} | {float(item['avg_ratio_total']):.1%} | {float(item['max_ratio_total']):.1%} | {item['max_label']} | {float(item['exclusive_ratio_module']):.1%} | {int(item['exclusive_samples']):,} | {int(item['inclusive_samples']):,} |"
                    )
            else:
                lines.append("| - | 0.0% | 0.0% | 0.0% | - | 0.0% | 0 | 0 |")
            lines.append("")
        lines.append("### 全局Top Functions")
        lines.append("")
        lines.append("| 模块 | 函数 | Exclusive样本 | 占总样本 | 场景内平均占比 | 场景内最大占比 | 最大Run | Inclusive样本 |")
        lines.append("| --- | --- | ---: | ---: | ---: | ---: | --- | ---: |")
        for item in report.top_functions:
            lines.append(
                f"| {item['module']} | {item['function']} | {int(item['exclusive_samples']):,} | {float(item['exclusive_ratio_total']):.1%} | {float(item['avg_ratio_total']):.1%} | {float(item['max_ratio_total']):.1%} | {item['max_run']} | {int(item['inclusive_samples']):,} |"
            )
        lines.append("")
        lines.append("### Warnings")
        lines.append("")
        if report.warnings:
            for warning in report.warnings:
                lines.append(f"- {warning}")
        else:
            lines.append("- 未触发默认告警规则")
    lines.append("")
    return "\n".join(lines)


def render_html_dashboard(payload: Dict[str, object]) -> str:
        payload_json = json.dumps(payload, ensure_ascii=False)
        generated_at = str(payload.get("generated_at", ""))
        scenario_count = int(payload.get("scenario_count", 0))
        return f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Runtime Dashboard</title>
    <style>
        :root {{
            --bg: #f2efe8;
            --panel: rgba(255,255,255,0.86);
            --panel-strong: #fffaf2;
            --ink: #1d2a2b;
            --muted: #5d6c6d;
            --line: rgba(29, 42, 43, 0.12);
            --accent: #0d6b5f;
            --accent-soft: #dff3ee;
            --hot: #c45b2d;
            --warn: #b93d28;
            --shadow: 0 20px 40px rgba(29, 42, 43, 0.10);
        }}
        * {{ box-sizing: border-box; }}
        body {{
            margin: 0;
            font-family: "Segoe UI", "Microsoft YaHei", sans-serif;
            color: var(--ink);
            background:
                radial-gradient(circle at top left, rgba(13,107,95,0.16), transparent 28%),
                radial-gradient(circle at top right, rgba(196,91,45,0.16), transparent 22%),
                linear-gradient(180deg, #f8f4ec, var(--bg));
        }}
        .page {{ max-width: 1680px; margin: 0 auto; padding: 24px; }}
        .hero {{
            background: linear-gradient(135deg, rgba(13,107,95,0.95), rgba(27,86,90,0.92));
            color: white;
            padding: 28px 32px;
            border-radius: 24px;
            box-shadow: var(--shadow);
            position: relative;
            overflow: hidden;
        }}
        .hero::after {{
            content: "";
            position: absolute;
            inset: auto -5% -30% auto;
            width: 380px;
            height: 380px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(255,255,255,0.18), transparent 68%);
        }}
        .hero h1 {{ margin: 0 0 10px; font-size: 34px; }}
        .hero p {{ margin: 0; color: rgba(255,255,255,0.86); max-width: 880px; }}
        .hero-meta {{ display: flex; flex-wrap: wrap; gap: 12px; margin-top: 18px; }}
        .hero-actions {{ display: flex; flex-wrap: wrap; gap: 10px; margin-top: 16px; }}
        .pill {{
            background: rgba(255,255,255,0.14);
            border: 1px solid rgba(255,255,255,0.18);
            padding: 8px 12px;
            border-radius: 999px;
            font-size: 13px;
        }}
        .hero-link {{
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 10px 14px;
            border-radius: 999px;
            background: rgba(255,255,255,0.16);
            border: 1px solid rgba(255,255,255,0.24);
            color: white;
            text-decoration: none;
            font-size: 13px;
        }}
        .hero-link:hover {{ background: rgba(255,255,255,0.22); }}
        .guide-panel {{ margin-top: 18px; overflow: hidden; }}
        .guide-panel summary {{
            cursor: pointer;
            list-style: none;
            padding: 16px 18px;
            font-weight: 700;
            color: var(--ink);
        }}
        .guide-panel summary::-webkit-details-marker {{ display: none; }}
        .guide-panel-body {{
            padding: 0 18px 18px;
            border-top: 1px solid var(--line);
            color: var(--ink);
        }}
        .guide-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 14px;
            margin-top: 14px;
        }}
        .guide-item {{
            border: 1px solid var(--line);
            border-radius: 16px;
            background: rgba(255,255,255,0.66);
            padding: 14px;
        }}
        .guide-item strong {{ display: block; margin-bottom: 8px; }}
        .summary-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 14px;
            margin-top: 20px;
        }}
        .summary-card {{
            background: var(--panel);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(255,255,255,0.6);
            border-radius: 20px;
            padding: 18px;
            box-shadow: var(--shadow);
        }}
        .summary-label {{ color: var(--muted); font-size: 12px; text-transform: uppercase; letter-spacing: 0.08em; }}
        .summary-value {{ margin-top: 8px; font-size: 30px; font-weight: 700; }}
        .layout {{ display: grid; grid-template-columns: 360px minmax(0, 1fr); gap: 18px; margin-top: 20px; }}
        .panel {{ background: var(--panel); border: 1px solid rgba(255,255,255,0.62); border-radius: 22px; box-shadow: var(--shadow); }}
        .sidebar {{ padding: 18px; position: sticky; top: 20px; height: fit-content; }}
        .section-title {{ margin: 0 0 12px; font-size: 16px; }}
        .field {{ margin-bottom: 14px; }}
        .field label {{ display: block; font-size: 13px; color: var(--muted); margin-bottom: 6px; }}
        .field input, .field select {{
            width: 100%;
            padding: 12px 14px;
            border-radius: 14px;
            border: 1px solid var(--line);
            background: rgba(255,255,255,0.84);
            color: var(--ink);
            font-size: 14px;
        }}
        .checkbox {{ display: flex; align-items: center; gap: 8px; font-size: 14px; color: var(--ink); }}
        .tag-list {{ display: flex; flex-wrap: wrap; gap: 8px; }}
        .tag {{ padding: 6px 10px; border-radius: 999px; background: var(--accent-soft); color: var(--accent); font-size: 12px; cursor: pointer; border: 0; }}
        .content {{ display: grid; gap: 18px; }}
        .toolbar {{ display: flex; justify-content: space-between; align-items: center; padding: 16px 18px; }}
        .toolbar strong {{ font-size: 18px; }}
        .table-wrap {{ overflow: auto; border-top: 1px solid var(--line); }}
        table {{ width: 100%; border-collapse: collapse; min-width: 980px; }}
        th, td {{ padding: 12px 14px; text-align: left; border-bottom: 1px solid var(--line); vertical-align: top; }}
        th {{ font-size: 12px; text-transform: uppercase; letter-spacing: 0.08em; color: var(--muted); position: sticky; top: 0; background: var(--panel-strong); }}
        tbody tr {{ cursor: pointer; transition: background 0.18s ease; }}
        tbody tr:hover {{ background: rgba(13,107,95,0.06); }}
        tbody tr.active {{ background: rgba(13,107,95,0.10); }}
        .heat {{ min-width: 180px; }}
        .bar-track {{ height: 10px; background: rgba(29,42,43,0.08); border-radius: 999px; overflow: hidden; margin-top: 6px; }}
        .bar-fill {{ height: 100%; border-radius: inherit; background: linear-gradient(90deg, var(--accent), #46a58e); }}
        .bar-fill.warn {{ background: linear-gradient(90deg, var(--hot), #d98b47); }}
        .bar-fill.alert {{ background: linear-gradient(90deg, var(--warn), #ef8d71); }}
        .detail-grid {{ display: grid; grid-template-columns: minmax(0, 1.3fr) minmax(320px, 0.9fr); gap: 18px; }}
        .detail-grid-main {{ grid-template-columns: 1fr; }}
        .detail-panel {{ padding: 18px; overflow: hidden; }}
        .detail-panel h2 {{ margin: 0 0 6px; font-size: 24px; }}
        .detail-meta {{ color: var(--muted); font-size: 14px; margin-bottom: 18px; }}
        .scenario-focus {{
            border: 1px solid var(--line);
            border-radius: 20px;
            background: rgba(255,255,255,0.76);
            padding: 18px;
            margin-bottom: 16px;
        }}
        .scenario-focus h2 {{ margin: 0 0 6px; font-size: 28px; }}
        .metric-row {{ display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; margin-bottom: 18px; }}
        .metric {{ background: rgba(255,255,255,0.68); border: 1px solid var(--line); border-radius: 18px; padding: 14px; }}
        .metric .value {{ font-size: 24px; font-weight: 700; }}
        .detail-board-wrap {{ overflow: hidden; margin-top: 14px; }}
        .detail-board {{
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            grid-template-rows: repeat(2, minmax(280px, 1fr));
            gap: 16px;
            align-items: stretch;
        }}
        .detail-card {{
            display: flex;
            flex-direction: column;
            min-height: 280px;
            max-height: 360px;
            border: 1px solid var(--line);
            border-radius: 18px;
            background: rgba(255,255,255,0.72);
            overflow: hidden;
        }}
        .detail-card-header {{
            padding: 14px 16px 10px;
            border-bottom: 1px solid var(--line);
            background: rgba(255,255,255,0.45);
        }}
        .detail-card-header .section-title {{ margin-bottom: 4px; }}
        .detail-card-body {{
            flex: 1;
            min-height: 0;
            overflow: auto;
            padding: 0 16px 16px;
        }}
        .detail-card-body > :first-child {{ margin-top: 14px; }}
        .detail-card-body > :last-child {{ margin-bottom: 0; }}
        .module-card {{ border: 1px solid var(--line); border-radius: 18px; padding: 14px; background: rgba(255,255,255,0.72); margin-bottom: 12px; }}
        .module-card.active {{
            border-color: rgba(13, 107, 95, 0.55);
            background: rgba(223,243,238,0.82);
            box-shadow: inset 0 0 0 1px rgba(13, 107, 95, 0.16);
        }}
        .module-head {{ display: flex; justify-content: space-between; gap: 10px; align-items: baseline; }}
        .module-name {{ font-weight: 700; }}
        .module-pct {{ color: var(--muted); font-size: 13px; }}
        .highlight-row {{ background: rgba(13,107,95,0.10); }}
        .hierarchy-card.active {{
            border-color: rgba(13, 107, 95, 0.55);
            background: rgba(223,243,238,0.82);
        }}
        .tag.active {{
            background: var(--accent);
            color: white;
        }}
        .list {{ margin: 0; padding-left: 18px; }}
        .list li {{ margin-bottom: 8px; }}
        .hotspot-table {{ margin-top: 14px; }}
        .global-grid {{ display: grid; grid-template-columns: 1fr; gap: 18px; }}
        .empty {{ padding: 22px; color: var(--muted); text-align: center; }}
        .small {{ font-size: 12px; color: var(--muted); }}
        code {{ font-family: "Consolas", "Cascadia Code", monospace; font-size: 12px; word-break: break-all; }}
        .func-name {{
            display: block;
            font-family: "Consolas", "Cascadia Code", monospace;
            font-size: 12px;
            white-space: normal;
            word-break: break-all;
            overflow-wrap: anywhere;
            line-height: 1.45;
        }}
        .hierarchy-grid {{ display: grid; gap: 12px; }}
        .hierarchy-card {{ border: 1px solid var(--line); border-radius: 18px; background: rgba(255,255,255,0.72); padding: 14px; }}
        .hierarchy-card summary {{ cursor: pointer; list-style: none; }}
        .hierarchy-card summary::-webkit-details-marker {{ display: none; }}
        .hierarchy-title {{ display: flex; justify-content: space-between; gap: 12px; align-items: baseline; }}
        .hierarchy-tree, .hierarchy-tree ul {{ list-style: none; margin: 10px 0 0; padding-left: 16px; }}
        .hierarchy-tree > li {{ padding-left: 0; }}
        .hierarchy-node {{ border-left: 1px solid rgba(29, 42, 43, 0.14); margin-left: 4px; padding-left: 12px; }}
        .hierarchy-node-head {{ display: flex; justify-content: space-between; gap: 12px; align-items: flex-start; padding: 6px 0; }}
        .hierarchy-metrics {{ white-space: nowrap; color: var(--muted); font-size: 12px; }}
        @media (max-width: 1200px) {{
            .layout {{ grid-template-columns: 1fr; }}
            .sidebar {{ position: static; }}
            .detail-grid {{ grid-template-columns: 1fr; }}
            .detail-board {{
                grid-template-columns: 1fr;
                grid-template-rows: none;
            }}
            .detail-card {{ max-height: none; }}
        }}
        @media (max-width: 760px) {{
            .page {{ padding: 14px; }}
            .hero {{ padding: 22px; border-radius: 18px; }}
            .metric-row {{ grid-template-columns: 1fr; }}
            .toolbar {{ flex-direction: column; align-items: flex-start; gap: 8px; }}
            .detail-card-body {{ padding: 0 12px 12px; }}
            .detail-card-header {{ padding: 12px 12px 8px; }}
        }}
    </style>
</head>
<body>
    <div class="page">
        <section class="hero">
            <h1>Parking Runtime Dashboard</h1>
            <p>按场景浏览 parking 相关模块和函数的算力热点，支持模块/函数关键字搜索、场景筛选、热点状态定位和异常告警查看。</p>
            <div class="hero-meta">
                <span class="pill">生成时间: {generated_at}</span>
                <span class="pill">场景数: {scenario_count}</span>
                <span class="pill">交互方式: 搜索 / 场景筛选 / 模块热点查询</span>
            </div>
            <div class="hero-actions">
                <a class="hero-link" href="parking_runtime_dashboard_3分钟上手.md" target="_blank" rel="noopener noreferrer">3 分钟上手</a>
                <a class="hero-link" href="parking_runtime_dashboard_用户手册.md" target="_blank" rel="noopener noreferrer">完整用户手册</a>
                <a class="hero-link" href="parking_runtime_report.md" target="_blank" rel="noopener noreferrer">查看 Markdown 报告</a>
            </div>
        </section>
        <details class="panel guide-panel">
            <summary>使用说明</summary>
            <div class="guide-panel-body">
                <div class="small">建议按“先看场景，再看模块，再看函数，再看调用层级，再回 trace”的顺序分析。</div>
                <div class="guide-grid">
                    <article class="guide-item">
                        <strong>1. 先选场景</strong>
                        <div class="small">在场景列表中点击目标场景，优先关注 Parking 占比高、告警多、主要模块异常的场景。</div>
                    </article>
                    <article class="guide-item">
                        <strong>2. 看模块热点</strong>
                        <div class="small">在“模块热点与模块内函数热点”里定位算力消耗最高的 parking 模块。</div>
                    </article>
                    <article class="guide-item">
                        <strong>3. 看函数与层级</strong>
                        <div class="small">结合“全局函数热点”和“函数调用层级”判断热点函数来自哪条调用链。</div>
                    </article>
                    <article class="guide-item">
                        <strong>4. 回 trace 排查</strong>
                        <div class="small">在“Trace 对应关系”里查看 run-trace 映射或场景级 trace 集合，回到原始 trace 做深挖。</div>
                    </article>
                    <article class="guide-item">
                        <strong>5. 当前目录运行规则</strong>
                        <div class="small">脚本默认按当前目录读取 `${{CURRENT_DIR}}/perf_data_decoded`、`${{CURRENT_DIR}}/*.xlsx`，并自动发现 `${{CURRENT_DIR}}/**/_generated/.conan/data`。</div>
                    </article>
                    <article class="guide-item">
                        <strong>6. 最常用命令</strong>
                        <div class="small">全量运行：<code>python .\\analyze_parking_runtime.py</code><br>smoke：<code>python .\\analyze_parking_runtime.py --scenario-filter "Astar_03" --output .\\parking_runtime_report.smoke.md --json-output .\\parking_runtime_report.smoke.json --html-output .\\parking_runtime_dashboard.smoke.html --alert-xlsx-output .\\parking_runtime_alert_scenes.smoke.xlsx</code></div>
                    </article>
                </div>
            </div>
        </details>
        <section id="summaryGrid" class="summary-grid"></section>
        <section class="layout">
            <aside class="panel sidebar">
                <h2 class="section-title">检索与筛选</h2>
                <div class="field">
                    <label for="searchInput">模块/函数/场景搜索</label>
                    <input id="searchInput" type="text" placeholder="例如 apfct / planreq / infra / Astar03">
                </div>
                <div class="field">
                    <label for="groupSelect">场景组</label>
                    <select id="groupSelect"></select>
                </div>
                <div class="field">
                    <label for="moduleSelect">模块</label>
                    <select id="moduleSelect"></select>
                </div>
                <div class="field checkbox">
                    <input id="warningOnly" type="checkbox">
                    <label for="warningOnly">仅显示有告警的场景</label>
                </div>
                <div class="field checkbox">
                    <input id="hotspotOnly" type="checkbox">
                    <label for="hotspotOnly">仅显示命中搜索热点的场景</label>
                </div>
                <div class="field">
                    <label>快捷模块</label>
                    <div id="quickModules" class="tag-list"></div>
                </div>
                <div class="small">搜索会同时匹配场景名、模块名、函数名、Excel 摘要和告警文本。</div>
            </aside>
            <main class="content">
                <section class="panel">
                    <div class="toolbar">
                        <strong>场景列表</strong>
                        <span id="resultMeta" class="small"></span>
                    </div>
                    <div class="table-wrap">
                        <table>
                            <thead>
                                <tr>
                                    <th>场景组</th>
                                    <th>场景</th>
                                    <th>Trace编号</th>
                                    <th>总样本</th>
                                    <th>Parking占比</th>
                                    <th>主要模块</th>
                                    <th>热点状态</th>
                                    <th>告警</th>
                                </tr>
                            </thead>
                            <tbody id="scenarioRows"></tbody>
                        </table>
                    </div>
                </section>
                <section class="detail-grid detail-grid-main">
                    <section class="panel detail-panel" id="detailPanel"></section>
                    <section class="panel detail-panel">
                        <h2>热点搜索结果</h2>
                        <div class="detail-meta">输入模块或函数关键字后，这里会聚合所有匹配场景中的热点条目。</div>
                        <div class="table-wrap hotspot-table">
                            <table>
                                <thead>
                                    <tr>
                                        <th>场景</th>
                                        <th>模块</th>
                                        <th>函数/热点</th>
                                        <th>占总样本</th>
                                        <th>样本</th>
                                    </tr>
                                </thead>
                                <tbody id="hotspotRows"></tbody>
                            </table>
                        </div>
                    </section>
                </section>
                <section class="global-grid">
                    <section class="panel detail-panel">
                        <h2>所有场景模块统计</h2>
                        <div class="detail-meta">汇总所有场景后，展示每个模块的平均值、最大值和峰值场景。</div>
                        <div class="table-wrap hotspot-table">
                            <table>
                                <thead>
                                    <tr>
                                        <th>模块</th>
                                        <th>命中场景</th>
                                        <th>平均占比</th>
                                        <th>最大占比</th>
                                        <th>最大场景</th>
                                    </tr>
                                </thead>
                                <tbody id="globalModuleRows"></tbody>
                            </table>
                        </div>
                    </section>
                    <section class="panel detail-panel">
                        <h2>所有场景函数统计</h2>
                        <div class="detail-meta">汇总所有场景后，展示函数热点的平均值、最大值和峰值场景。</div>
                        <div class="table-wrap hotspot-table">
                            <table>
                                <thead>
                                    <tr>
                                        <th>模块</th>
                                        <th>函数</th>
                                        <th>命中场景</th>
                                        <th>平均占比</th>
                                        <th>最大占比</th>
                                        <th>最大场景</th>
                                    </tr>
                                </thead>
                                <tbody id="globalFunctionRows"></tbody>
                            </table>
                        </div>
                    </section>
                </section>
            </main>
        </section>
    </div>
    <script id="reportData" type="application/json">{payload_json}</script>
    <script>
        const report = JSON.parse(document.getElementById('reportData').textContent);
        const scenarios = report.scenarios || [];
        const globalStats = report.global_stats || {{ modules: [], functions: [] }};
        const state = {{ selectedKey: '', search: '', group: 'ALL', module: 'ALL', warningOnly: false, hotspotOnly: false }};

        const summaryGrid = document.getElementById('summaryGrid');
        const groupSelect = document.getElementById('groupSelect');
        const moduleSelect = document.getElementById('moduleSelect');
        const searchInput = document.getElementById('searchInput');
        const warningOnly = document.getElementById('warningOnly');
        const hotspotOnly = document.getElementById('hotspotOnly');
        const resultMeta = document.getElementById('resultMeta');
        const scenarioRows = document.getElementById('scenarioRows');
        const detailPanel = document.getElementById('detailPanel');
        const hotspotRows = document.getElementById('hotspotRows');
        const globalModuleRows = document.getElementById('globalModuleRows');
        const globalFunctionRows = document.getElementById('globalFunctionRows');
        const quickModules = document.getElementById('quickModules');

        const allGroups = ['ALL', ...new Set(scenarios.map((item) => item.group))];
        const allModules = ['ALL', ...Array.from(new Set([
            ...scenarios.flatMap((item) => item.module_inventory || []),
            ...scenarios.flatMap((item) => (item.top_modules || []).map((mod) => mod.module)),
            ...scenarios.flatMap((item) => (item.top_functions || []).map((func) => func.module)),
            ...scenarios.flatMap((item) => (item.module_functions || []).map((entry) => entry.module)),
            ...(globalStats.modules || []).map((item) => item.module),
        ].filter(Boolean))).sort()];
        const moduleAliases = {{
            apafct: ['apa fct', 'apa_fct', 'fct'],
            parkhmi: ['hmi', 'park hmi', 'apahmi'],
            parkctl: ['ctl', 'park ctl', 'apafctctl'],
            aci: ['motion aci', 'aci'],
            pfc: ['pfc', 'apactl', 'motctl', 'pfcontrol'],
            rbp_eb: ['eb', 'emergency brake', 'rbp eb'],
            rbp_ooc: ['ooc', 'rbp ooc'],
            rbp_pp: ['pp', 'rbp pp', 'planning'],
            rbp_mot: ['mot', 'rbp mot'],
            rbp_infra: ['infra', 'rbp infra', 'coolmaster'],
        }};

        function fmtInt(value) {{
            return Number(value || 0).toLocaleString('zh-CN');
        }}

        function fmtPct(value) {{
            return `${{(Number(value || 0) * 100).toFixed(1)}}%`;
        }}

        function escapeHtml(text) {{
            return String(text || '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
        }}

        function traceSummary(item) {{
            const traces = (item.trace_ids || []).filter(Boolean);
            if (!traces.length) return item.trace_mapping_enabled ? '未映射' : '-';
            if (traces.length <= 3) return traces.join(', ');
            return `${{traces.slice(0, 3).join(', ')}} +${{traces.length - 3}}`;
        }}

        function formatRunTrace(runLabel, traceId) {{
            if (!runLabel && !traceId) return '-';
            if (runLabel && traceId) return `${{runLabel}} / Trace ${{traceId}}`;
            return runLabel || `Trace ${{traceId}}`;
        }}

        function isSelectedModule(moduleName) {{
            return state.module !== 'ALL' && moduleName === state.module;
        }}

        function scrollToSelectedModule() {{
            if (state.module === 'ALL') return;
            const moduleCards = Array.from(detailPanel.querySelectorAll('.module-card'));
            const targetCard = moduleCards.find((card) => card.dataset.module === state.module);
            if (!targetCard) return;
            const scrollContainer = targetCard.closest('.detail-card-body');
            if (scrollContainer) {{
                scrollContainer.scrollTo({{ top: Math.max(0, targetCard.offsetTop - 12), behavior: 'smooth' }});
                return;
            }}
            targetCard.scrollIntoView({{ behavior: 'smooth', block: 'start' }});
        }}

        function renderHierarchyNodes(nodes) {{
            if (!nodes || !nodes.length) return '';
            return `<ul>${{nodes.map((node) => `
                <li class="hierarchy-node">
                    <div class="hierarchy-node-head">
                        <span class="func-name">${{escapeHtml(node.name)}}</span>
                        <span class="hierarchy-metrics">${{fmtInt(node.samples)}} / ${{fmtPct(node.ratio_total)}}</span>
                    </div>
                    ${{renderHierarchyNodes(node.children || [])}}
                </li>`).join('')}}</ul>`;
        }}

        function scenarioKey(item) {{
            return `${{item.group}}::${{item.scene}}`;
        }}

        function hotspotState(item) {{
            const top = item.top_modules[0];
            const ratio = top ? Number(top.inclusive_ratio_total || 0) : 0;
            if (ratio >= 0.12 || item.warnings.length >= 3) return '高';
            if (ratio >= 0.06 || item.warnings.length >= 1) return '中';
            return '低';
        }}

        function barClass(value) {{
            if (value >= 0.12) return 'bar-fill alert';
            if (value >= 0.06) return 'bar-fill warn';
            return 'bar-fill';
        }}

        function normalizeSearchText(value) {{
            return String(value || '')
                .toLowerCase()
                .normalize('NFKC')
                .replace(/[_:\-/\\()[\]{{}}<>.,+*#"'`~!?|]/g, ' ')
                .replace(/\s+/g, ' ')
                .trim();
        }}

        function compactSearchText(value) {{
            return normalizeSearchText(value).replace(/\s+/g, '');
        }}

        function subsequenceScore(text, pattern) {{
            if (!pattern) return 1;
            let matched = 0;
            let streak = 0;
            let bestStreak = 0;
            for (let index = 0; index < text.length && matched < pattern.length; index += 1) {{
                if (text[index] === pattern[matched]) {{
                    matched += 1;
                    streak += 1;
                    bestStreak = Math.max(bestStreak, streak);
                }} else {{
                    streak = 0;
                }}
            }}
            if (matched !== pattern.length) return 0;
            return (matched / Math.max(1, text.length)) + (bestStreak / Math.max(1, pattern.length));
        }}

        function fuzzyTermScore(text, term) {{
            const normalizedText = normalizeSearchText(text);
            const compactText = compactSearchText(text);
            const normalizedTerm = normalizeSearchText(term);
            const compactTerm = compactSearchText(term);
            if (!normalizedTerm) return 0;
            if (normalizedText.includes(normalizedTerm) || compactText.includes(compactTerm)) {{
                return 10 + (compactTerm.length / Math.max(1, compactText.length));
            }}
            const normalizedSubseq = subsequenceScore(compactText, compactTerm);
            if (normalizedSubseq > 0) {{
                return normalizedSubseq;
            }}
            return 0;
        }}

        function buildSearchCorpus(item) {{
            return [
                item.group,
                item.scene,
                ...(item.warnings || []),
                ...(item.trace_ids || []),
                ...(item.run_summaries || []).map((run) => `${{run.label}} ${{run.trace_id || ''}} ${{run.file_name || ''}}`),
                ...(item.excel_matches || []).map((meta) => `${{meta.sheet}} ${{meta.scene_id}} ${{meta.title}} ${{meta.summary}}`),
                ...(item.excel_matches || []).flatMap((meta) => meta.traces || []),
                ...(item.top_modules || []).map((mod) => `${{mod.module}} ${{mod.inclusive_samples}}`),
                ...(item.top_functions || []).map((func) => `${{func.module}} ${{func.function}}`),
                ...(item.module_functions || []).flatMap((mod) => [mod.module, ...(mod.functions || []).map((func) => func.function)]),
                ...(item.top_modules || []).flatMap((mod) => moduleAliases[mod.module] || []),
                ...(item.top_functions || []).flatMap((func) => moduleAliases[func.module] || []),
                ...(item.module_functions || []).flatMap((mod) => moduleAliases[mod.module] || []),
            ];
        }}

        function fuzzySearchScore(item, keyword) {{
            const terms = normalizeSearchText(keyword).split(' ').filter(Boolean);
            if (!terms.length) return 1;
            const corpus = buildSearchCorpus(item);
            let total = 0;
            for (const term of terms) {{
                let best = 0;
                for (const entry of corpus) {{
                    best = Math.max(best, fuzzyTermScore(entry, term));
                }}
                if (best <= 0) return 0;
                total += best;
            }}
            return total;
        }}

        function scenarioMatchesFilters(item) {{
            const keyword = state.search.trim().toLowerCase();
            const keywordScore = fuzzySearchScore(item, keyword);
            const keywordHit = keywordScore > 0;
            const groupHit = state.group === 'ALL' || item.group === state.group;
            const moduleHit = state.module === 'ALL'
                || (item.module_inventory || []).includes(state.module)
                || (item.top_modules || []).some((mod) => mod.module === state.module)
                || (item.top_functions || []).some((func) => func.module === state.module)
                || (item.module_functions || []).some((entry) => entry.module === state.module);
            const warningHit = !state.warningOnly || item.warnings.length > 0;
            const hotspotHit = !state.hotspotOnly || !keyword || fuzzySearchScore({{
                group: item.group,
                scene: item.scene,
                warnings: [],
                excel_matches: [],
                top_modules: item.top_modules,
                top_functions: item.top_functions,
                module_functions: item.module_functions,
            }}, keyword) > 0;
            return keywordHit && groupHit && moduleHit && warningHit && hotspotHit;
        }}

        function buildSummary() {{
            const filtered = scenarios.filter(scenarioMatchesFilters);
            const totalSamples = filtered.reduce((sum, item) => sum + Number(item.total_samples || 0), 0);
            const parkingSamples = filtered.reduce((sum, item) => sum + Number(item.parking_samples || 0), 0);
            const warnings = filtered.reduce((sum, item) => sum + (item.warnings || []).length, 0);
            const hotScenarios = filtered.filter((item) => hotspotState(item) === '高').length;
            const cards = [
                ['匹配场景', filtered.length],
                ['总样本', fmtInt(totalSamples)],
                ['Parking占比', fmtPct(totalSamples ? parkingSamples / totalSamples : 0)],
                ['总告警', warnings],
                ['高热点场景', hotScenarios],
            ];
            summaryGrid.innerHTML = cards.map(([label, value]) => `
                <article class="summary-card">
                    <div class="summary-label">${{escapeHtml(label)}}</div>
                    <div class="summary-value">${{escapeHtml(value)}}</div>
                </article>
            `).join('');
        }}

        function renderScenarioTable() {{
            const keyword = state.search.trim().toLowerCase();
            const filtered = scenarios
                .filter(scenarioMatchesFilters)
                .map((item) => ({{ item, searchScore: fuzzySearchScore(item, keyword) }}))
                .sort((left, right) => right.searchScore - left.searchScore || Number((right.item.top_modules[0] || {{}}).inclusive_ratio_total || 0) - Number((left.item.top_modules[0] || {{}}).inclusive_ratio_total || 0) || right.item.parking_ratio - left.item.parking_ratio)
                .map((entry) => entry.item);
            if (!state.selectedKey && filtered.length) state.selectedKey = scenarioKey(filtered[0]);
            if (filtered.length && !filtered.some((item) => scenarioKey(item) === state.selectedKey)) state.selectedKey = scenarioKey(filtered[0]);
            if (!filtered.length) state.selectedKey = '';

            scenarioRows.innerHTML = filtered.map((item) => {{
                const top = item.top_modules[0] || null;
                const ratio = top ? Number(top.inclusive_ratio_total || 0) : 0;
                const active = scenarioKey(item) === state.selectedKey ? 'active' : '';
                const severity = hotspotState(item);
                return `
                    <tr class="${{active}}" data-key="${{escapeHtml(scenarioKey(item))}}">
                        <td>${{escapeHtml(item.group)}}</td>
                        <td>${{escapeHtml(item.scene)}}</td>
                        <td>${{escapeHtml(traceSummary(item))}}</td>
                        <td>${{fmtInt(item.total_samples)}}</td>
                        <td class="heat">
                            <div>${{fmtPct(item.parking_ratio)}}</div>
                            <div class="bar-track"><div class="${{barClass(item.parking_ratio)}}" style="width:${{Math.min(100, (item.parking_ratio || 0) * 100)}}%"></div></div>
                        </td>
                        <td>${{top ? escapeHtml(top.module) : '-'}}</td>
                        <td>
                            <div>${{severity}}</div>
                            <div class="bar-track"><div class="${{barClass(ratio)}}" style="width:${{Math.min(100, ratio * 100)}}%"></div></div>
                        </td>
                        <td>${{item.warnings.length}}</td>
                    </tr>
                `;
            }}).join('');
            resultMeta.textContent = `当前显示 ${{filtered.length}} / ${{scenarios.length}} 个场景`;

            scenarioRows.querySelectorAll('tr').forEach((row) => {{
                row.addEventListener('click', () => {{
                    state.selectedKey = row.dataset.key;
                    renderScenarioTable();
                    renderDetails();
                }});
            }});
        }}

        function renderDetails() {{
            const item = scenarios.find((entry) => scenarioKey(entry) === state.selectedKey);
            if (!item) {{
                detailPanel.innerHTML = '<div class="empty">没有可显示的场景。</div>';
                return;
            }}
            const excelItems = (item.excel_matches || []).map((meta) => `<li><strong>${{escapeHtml(meta.sheet)}}</strong> · ${{escapeHtml(meta.scene_id)}}<br><span class="small">${{escapeHtml(meta.summary)}}</span></li>`).join('') || '<li>未匹配到 Excel 元数据</li>';
            const warnings = item.warnings.length ? `<ul class="list">${{item.warnings.map((warning) => `<li>${{escapeHtml(warning)}}</li>`).join('')}}</ul>` : '<div class="small">未触发告警</div>';
            const sceneRunRows = (item.run_summaries || []).length
                ? (item.run_summaries || []).map((run) => `
                    <tr>
                        <td>${{escapeHtml(run.label || '-')}}</td>
                        <td><span class="func-name">${{escapeHtml(run.file_name || run.source_path || '-')}}</span></td>
                        <td>${{fmtPct((Number(run.parking_samples || 0) && Number(run.total_samples || 0)) ? Number(run.parking_samples || 0) / Number(run.total_samples || 0) : 0)}}</td>
                    </tr>`).join('')
                : (item.files || []).map((filePath, index) => `
                    <tr>
                        <td>${{escapeHtml(`run_${{index + 1}}`)}}</td>
                        <td><span class="func-name">${{escapeHtml(filePath)}}</span></td>
                        <td>-</td>
                    </tr>`).join('');
            const sceneTraceRows = (item.trace_ids || []).length
                ? (item.trace_ids || []).map((traceId, index) => `
                    <tr>
                        <td>${{index + 1}}</td>
                        <td>${{escapeHtml(traceId)}}</td>
                    </tr>`).join('')
                : '<tr><td colspan="2" class="empty">未找到该场景关联的 Trace 编号。</td></tr>';
            const exactTraceTable = item.trace_mapping_enabled && (item.run_summaries || []).length
                ? `
                    <div class="small">已建立 run 与 trace 的一一对应关系。</div>
                    <div class="table-wrap hotspot-table">
                        <table>
                            <thead>
                                <tr><th>Run</th><th>Trace编号</th><th>文件</th><th>Parking占比</th></tr>
                            </thead>
                            <tbody>
                                ${{(item.run_summaries || []).map((run) => `
                                    <tr>
                                        <td>${{escapeHtml(run.label || '-')}}</td>
                                        <td>${{escapeHtml(run.trace_id || '-')}}</td>
                                        <td><span class="func-name">${{escapeHtml(run.file_name || run.source_path || '-')}}</span></td>
                                        <td>${{fmtPct((Number(run.parking_samples || 0) && Number(run.total_samples || 0)) ? Number(run.parking_samples || 0) / Number(run.total_samples || 0) : 0)}}</td>
                                    </tr>`).join('')}}
                            </tbody>
                        </table>
                    </div>`
                : `<div class="small">${{(item.trace_ids || []).length ? '未形成 run 与 trace 的一一对应，以下按场景给出火焰图与 Trace 编号关联，方便查看原始 trace。' : '未检测到该场景关联的 Trace 编号。'}}</div>`;
            const traceItems = `
                ${{exactTraceTable}}
                <div class="small" style="margin-top: 12px;">场景级关联：同一场景下的火焰图文件与 Trace 编号集合。</div>
                <div class="detail-grid" style="grid-template-columns: minmax(0, 1.4fr) minmax(260px, 0.8fr); gap: 12px; margin-top: 10px;">
                    <div class="table-wrap hotspot-table">
                        <table>
                            <thead>
                                <tr><th>Run</th><th>火焰图文件</th><th>Parking占比</th></tr>
                            </thead>
                            <tbody>
                                ${{sceneRunRows || '<tr><td colspan="3" class="empty">未找到该场景火焰图文件。</td></tr>'}}
                            </tbody>
                        </table>
                    </div>
                    <div class="table-wrap hotspot-table">
                        <table>
                            <thead>
                                <tr><th>#</th><th>Trace编号</th></tr>
                            </thead>
                            <tbody>
                                ${{sceneTraceRows}}
                            </tbody>
                        </table>
                    </div>
                </div>`;
            const moduleFunctionMap = new Map((item.module_functions || []).map((entry) => [entry.module, entry.functions || []]));
            const selectedModuleMissingFromCards = state.module !== 'ALL'
                && (item.module_inventory || []).includes(state.module)
                && !(item.top_modules || []).some((mod) => mod.module === state.module);
            const modules = item.top_modules.map((mod) => {{
                const moduleActive = isSelectedModule(mod.module);
                const functions = moduleFunctionMap.get(mod.module) || [];
                const functionTable = functions.length ? `
                    <div class="table-wrap hotspot-table">
                        <table>
                            <thead>
                                <tr><th>函数</th><th>占总样本</th><th>平均占比</th><th>最大占比</th><th>最大Run / Trace</th><th>占模块样本</th><th>样本</th></tr>
                            </thead>
                            <tbody>
                                ${{functions.map((func) => `
                                    <tr class="${{moduleActive ? 'highlight-row' : ''}}">
                                        <td><span class="func-name">${{escapeHtml(func.function)}}</span></td>
                                        <td>${{fmtPct(func.exclusive_ratio_total)}}</td>
                                        <td>${{fmtPct(func.avg_ratio_total)}}</td>
                                        <td>${{fmtPct(func.max_ratio_total)}}</td>
                                        <td>${{escapeHtml(formatRunTrace(func.max_label || '', func.max_trace || ''))}}</td>
                                        <td>${{fmtPct(func.exclusive_ratio_module)}}</td>
                                        <td>${{fmtInt(func.exclusive_samples)}}</td>
                                    </tr>`).join('')}}
                            </tbody>
                        </table>
                    </div>` : '<div class="small">该模块没有可展示的函数热点。</div>';
                return `
                <article class="module-card${{moduleActive ? ' active' : ''}}" data-module="${{escapeHtml(mod.module)}}">
                    <div class="module-head">
                        <span class="module-name">${{escapeHtml(mod.module)}}</span>
                        <span class="module-pct">占总样本 ${{fmtPct(mod.inclusive_ratio_total)}} / 平均 ${{fmtPct(mod.avg_ratio_total)}} / 最大 ${{fmtPct(mod.max_ratio_total)}}</span>
                    </div>
                    <div class="bar-track"><div class="${{barClass(mod.inclusive_ratio_total)}}" style="width:${{Math.min(100, Number(mod.inclusive_ratio_total || 0) * 100)}}%"></div></div>
                    <div class="small">Inclusive: ${{fmtInt(mod.inclusive_samples)}} · Exclusive: ${{fmtInt(mod.exclusive_samples)}} · 最大Run: ${{escapeHtml(formatRunTrace(mod.max_run || '', mod.max_trace || ''))}}</div>
                    ${{functionTable}}
                </article>
            `;}}).join('');
            const funcs = item.top_functions.length ? `
                <div class="table-wrap hotspot-table">
                    <table>
                        <thead>
                            <tr><th>模块</th><th>函数</th><th>占总样本</th><th>平均占比</th><th>最大占比</th><th>最大Run / Trace</th><th>样本</th></tr>
                        </thead>
                        <tbody>
                            ${{item.top_functions.map((func) => `
                                <tr class="${{isSelectedModule(func.module) ? 'highlight-row' : ''}}">
                                    <td>${{escapeHtml(func.module)}}</td>
                                    <td><span class="func-name">${{escapeHtml(func.function)}}</span></td>
                                    <td>${{fmtPct(func.exclusive_ratio_total)}}</td>
                                    <td>${{fmtPct(func.avg_ratio_total)}}</td>
                                    <td>${{fmtPct(func.max_ratio_total)}}</td>
                                    <td>${{escapeHtml(formatRunTrace(func.max_run || '', func.max_trace || ''))}}</td>
                                    <td>${{fmtInt(func.exclusive_samples)}}</td>
                                </tr>`).join('')}}
                        </tbody>
                    </table>
                </div>` : '<div class="empty">没有函数热点。</div>';
            const callHierarchyPanel = item.top_functions.length ? `
                <div class="hierarchy-grid">
                    ${{item.top_functions.map((func) => `
                        <details class="hierarchy-card${{isSelectedModule(func.module) ? ' active' : ''}}">
                            <summary>
                                <div class="hierarchy-title">
                                    <div>
                                        <div class="small">${{escapeHtml(func.module)}}</div>
                                        <span class="func-name">${{escapeHtml(func.function)}}</span>
                                    </div>
                                    <span class="hierarchy-metrics">${{fmtInt(func.exclusive_samples)}} / ${{fmtPct(func.exclusive_ratio_total)}}</span>
                                </div>
                            </summary>
                            <div class="small">调用层级按累计样本聚合，展示每一层函数名与对应场景占比。</div>
                            <div class="hierarchy-tree">${{renderHierarchyNodes(func.call_tree || []) || '<div class="small">未提取到可展示的调用层级。</div>'}}</div>
                        </details>`).join('')}}
                </div>` : '<div class="empty">没有可展示的函数调用层级。</div>';

            detailPanel.innerHTML = `
                <section class="scenario-focus">
                    <h2>${{escapeHtml(item.group)}} / ${{escapeHtml(item.scene)}}</h2>
                    <div class="detail-meta">Excel摘要: ${{escapeHtml((item.excel_matches || []).map((meta) => meta.summary).slice(0, 2).join(' | ') || '未匹配')}}</div>
                    <div class="metric-row">
                        <div class="metric"><div class="small">总样本</div><div class="value">${{fmtInt(item.total_samples)}}</div></div>
                        <div class="metric"><div class="small">Parking样本</div><div class="value">${{fmtInt(item.parking_samples)}}</div></div>
                        <div class="metric"><div class="small">Parking占比</div><div class="value">${{fmtPct(item.parking_ratio)}}</div></div>
                    </div>
                </section>
                <div class="detail-board-wrap">
                    <div class="detail-board">
                        <section class="detail-card">
                            <header class="detail-card-header">
                                <h3 class="section-title">Trace 对应关系</h3>
                                <div class="small">精确映射优先；无法一一对应时回退到场景级关联。</div>
                            </header>
                            <div class="detail-card-body">${{traceItems}}</div>
                        </section>
                        <section class="detail-card">
                            <header class="detail-card-header">
                                <h3 class="section-title">模块热点与模块内函数热点</h3>
                                <div class="small">模块统计与模块下完整函数列表。</div>
                            </header>
                            <div class="detail-card-body">${{selectedModuleMissingFromCards ? `<div class="small">当前选中模块 ${{escapeHtml(state.module)}} 已命中该场景，但未进入轻量页面的热点详情卡片，可结合 JSON/Markdown 查看完整明细。</div>` : ''}}${{modules || '<div class="empty">没有模块热点。</div>'}}</div>
                        </section>
                        <section class="detail-card">
                            <header class="detail-card-header">
                                <h3 class="section-title">全局函数热点</h3>
                                <div class="small">当前场景下的热点函数排行。</div>
                            </header>
                            <div class="detail-card-body">${{funcs}}</div>
                        </section>
                        <section class="detail-card">
                            <header class="detail-card-header">
                                <h3 class="section-title">函数调用层级</h3>
                                <div class="small">命中算力消耗的函数调用路径。</div>
                            </header>
                            <div class="detail-card-body">${{callHierarchyPanel}}</div>
                        </section>
                        <section class="detail-card">
                            <header class="detail-card-header">
                                <h3 class="section-title">告警</h3>
                                <div class="small">当前场景触发的默认规则告警。</div>
                            </header>
                            <div class="detail-card-body">${{warnings}}</div>
                        </section>
                        <section class="detail-card">
                            <header class="detail-card-header">
                                <h3 class="section-title">Excel 元数据</h3>
                                <div class="small">测试场景与 trace 元数据来源。</div>
                            </header>
                            <div class="detail-card-body"><ul class="list">${{excelItems}}</ul></div>
                        </section>
                    </div>
                </div>
            `;
            scrollToSelectedModule();
        }}

        function renderHotspotResults() {{
            const keyword = state.search.trim().toLowerCase();
            const filtered = scenarios.filter(scenarioMatchesFilters);
            const rows = [];
            for (const item of filtered) {{
                for (const mod of item.top_modules || []) {{
                    const moduleScore = !keyword ? 1 : Math.max(fuzzyTermScore(mod.module, keyword), fuzzyTermScore(`${{item.group}} ${{item.scene}} ${{mod.module}}`, keyword));
                    if (moduleScore > 0) {{
                        rows.push({{ group: item.group, scene: item.scene, module: mod.module, function: '[module hotspot]', ratio: Number(mod.inclusive_ratio_total || 0), samples: Number(mod.inclusive_samples || 0), searchScore: moduleScore }});
                    }}
                }}
                for (const moduleEntry of item.module_functions || []) {{
                    for (const func of moduleEntry.functions || []) {{
                        const functionScore = !keyword ? 1 : Math.max(
                            fuzzyTermScore(moduleEntry.module, keyword),
                            fuzzyTermScore(func.function, keyword),
                            fuzzyTermScore(`${{item.group}} ${{item.scene}} ${{moduleEntry.module}} ${{func.function}}`, keyword),
                        );
                        if (functionScore > 0) {{
                            rows.push({{ group: item.group, scene: item.scene, module: moduleEntry.module, function: func.function, ratio: Number(func.exclusive_ratio_total || 0), samples: Number(func.exclusive_samples || 0), searchScore: functionScore }});
                        }}
                    }}
                }}
                for (const func of item.top_functions || []) {{
                    const globalFunctionScore = !keyword ? 1 : Math.max(
                        fuzzyTermScore(func.module, keyword),
                        fuzzyTermScore(func.function, keyword),
                        fuzzyTermScore(`${{item.group}} ${{item.scene}} ${{func.module}} ${{func.function}}`, keyword),
                    );
                    if (globalFunctionScore > 0) {{
                        rows.push({{ group: item.group, scene: item.scene, module: func.module, function: func.function, ratio: Number(func.exclusive_ratio_total || 0), samples: Number(func.exclusive_samples || 0), searchScore: globalFunctionScore }});
                    }}
                }}
            }}
            rows.sort((a, b) => b.searchScore - a.searchScore || b.ratio - a.ratio || b.samples - a.samples);
            const topRows = rows.slice(0, 120);
            hotspotRows.innerHTML = topRows.length ? topRows.map((row) => `
                <tr>
                    <td>${{escapeHtml(row.group)}} / ${{escapeHtml(row.scene)}}</td>
                    <td>${{escapeHtml(row.module)}}</td>
                    <td><span class="func-name">${{escapeHtml(row.function)}}</span></td>
                    <td>${{fmtPct(row.ratio)}}</td>
                    <td>${{fmtInt(row.samples)}}</td>
                </tr>
            `).join('') : '<tr><td colspan="5" class="empty">没有匹配到热点结果。</td></tr>';
        }}

        function renderGlobalStats() {{
            const keyword = state.search.trim().toLowerCase();
            const moduleRows = (globalStats.modules || [])
                .filter((item) => !keyword || fuzzyTermScore(item.module, keyword) > 0 || fuzzyTermScore(item.max_scene, keyword) > 0)
                .slice(0, 200);
            globalModuleRows.innerHTML = moduleRows.length ? moduleRows.map((item) => `
                <tr>
                    <td>${{escapeHtml(item.module)}}</td>
                    <td>${{fmtInt(item.present_scenario_count)}} / ${{fmtInt(item.scenario_count)}}</td>
                    <td>${{fmtPct(item.avg_ratio_total_all)}}</td>
                    <td>${{fmtPct(item.max_ratio_total)}}</td>
                    <td>${{escapeHtml(item.max_scene || '-')}}</td>
                </tr>
            `).join('') : '<tr><td colspan="5" class="empty">没有匹配到模块统计。</td></tr>';

            const functionRows = (globalStats.functions || [])
                .filter((item) => !keyword || fuzzyTermScore(item.module, keyword) > 0 || fuzzyTermScore(item.function, keyword) > 0 || fuzzyTermScore(item.max_scene, keyword) > 0)
                .slice(0, 300);
            globalFunctionRows.innerHTML = functionRows.length ? functionRows.map((item) => `
                <tr>
                    <td>${{escapeHtml(item.module)}}</td>
                    <td><code>${{escapeHtml(item.function)}}</code></td>
                    <td>${{fmtInt(item.present_scenario_count)}} / ${{fmtInt(item.scenario_count)}}</td>
                    <td>${{fmtPct(item.avg_ratio_total_all)}}</td>
                    <td>${{fmtPct(item.max_ratio_total)}}</td>
                    <td>${{escapeHtml(item.max_scene || '-')}}</td>
                </tr>
            `).join('') : '<tr><td colspan="6" class="empty">没有匹配到函数统计。</td></tr>';
        }}

        function fillSelect(select, values) {{
            select.innerHTML = values.map((value) => `<option value="${{escapeHtml(value)}}">${{escapeHtml(value === 'ALL' ? '全部' : value)}}</option>`).join('');
        }}

        function renderQuickModules() {{
            quickModules.innerHTML = allModules.filter((item) => item !== 'ALL').map((module) => `<button class="tag${{state.module === module ? ' active' : ''}}" data-module="${{escapeHtml(module)}}">${{escapeHtml(module)}}</button>`).join('');
            quickModules.querySelectorAll('button').forEach((button) => {{
                button.addEventListener('click', () => {{
                    state.module = button.dataset.module;
                    moduleSelect.value = state.module;
                    refresh();
                }});
            }});
        }}

        function refresh() {{
            renderQuickModules();
            buildSummary();
            renderScenarioTable();
            renderDetails();
            renderHotspotResults();
            renderGlobalStats();
        }}

        fillSelect(groupSelect, allGroups);
        fillSelect(moduleSelect, allModules);

        searchInput.addEventListener('input', (event) => {{ state.search = event.target.value; refresh(); }});
        groupSelect.addEventListener('change', (event) => {{ state.group = event.target.value; refresh(); }});
        moduleSelect.addEventListener('change', (event) => {{ state.module = event.target.value; refresh(); }});
        warningOnly.addEventListener('change', (event) => {{ state.warningOnly = event.target.checked; refresh(); }});
        hotspotOnly.addEventListener('change', (event) => {{ state.hotspotOnly = event.target.checked; refresh(); }});

        refresh();
    </script>
</body>
</html>'''


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="按场景统计 perf_data_decoded 中与 parking 相关的 runtime 热点并预警异常算力开销。")
    parser.add_argument("--perf-root", default=f"{CURRENT_DIR_PLACEHOLDER}/perf_data_decoded", help="perf_data_decoded 根目录，支持当前目录占位符")
    parser.add_argument("--excel", nargs="*", default=[f"{CURRENT_DIR_PLACEHOLDER}/*.xlsx"], help="场景定义/结果 Excel，支持通配符")
    parser.add_argument("--repo-root", default=f"{CURRENT_DIR_PLACEHOLDER}/**/_generated/.conan/data", help="oneparking 代码根目录，支持通配符自动发现")
    parser.add_argument("--output", default="parking_runtime_report.md", help="Markdown 输出文件")
    parser.add_argument("--json-output", default="parking_runtime_report.json", help="JSON 输出文件")
    parser.add_argument("--html-output", default="parking_runtime_dashboard.html", help="HTML 可视化输出文件")
    parser.add_argument("--alert-xlsx-output", default="parking_runtime_alert_scenes.xlsx", help="告警及高热点场景 Excel 输出文件")
    parser.add_argument("--top", type=int, default=10, help="每个场景输出 Top N 模块/函数")
    parser.add_argument("--scenario-filter", default="", help="仅分析匹配该正则的场景")
    parser.add_argument("--module-threshold", type=float, default=0.12, help="模块累计占总样本的绝对告警阈值")
    parser.add_argument("--function-threshold", type=float, default=0.03, help="函数独占占总样本的绝对告警阈值")
    parser.add_argument("--overhead-threshold", type=float, default=0.08, help="overhead 模块累计占总样本阈值")
    parser.add_argument("--peer-factor", type=float, default=2.5, help="相对同组场景中位数的倍数告警阈值")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    current_dir = Path.cwd()
    script_dir = Path(__file__).resolve().parent
    perf_root = expand_cli_path(args.perf_root, current_dir, script_dir)
    excel_paths = [
        path
        for path in expand_cli_paths(args.excel, current_dir, script_dir, files_only=True)
        if path.suffix.lower() == ".xlsx" and not is_generated_runtime_output(path)
    ]
    repo_root = discover_repo_root(current_dir, script_dir, args.repo_root) if args.repo_root else None

    scenarios = discover_perf_samples(perf_root)
    if args.scenario_filter:
        scenario_re = re.compile(args.scenario_filter, re.I)
        scenarios = {
            key: value
            for key, value in scenarios.items()
            if scenario_re.search(key[0]) or scenario_re.search(key[1])
        }

    excel_index = build_excel_index(excel_paths)
    repo_symbols = mine_repo_symbols(repo_root)

    raw_reports: Dict[Tuple[str, str], Dict[str, object]] = {}
    for key, files in sorted(scenarios.items()):
        raw_reports[key] = analyze_scenario(files, repo_symbols, args.top)

    module_stats, function_stats = build_peer_stats(raw_reports)

    scenario_reports: List[ScenarioReport] = []
    for (group, scene), raw in sorted(raw_reports.items()):
        matches = []
        for alias in scene_aliases(scene) | scene_aliases(group) | scene_aliases(f"{group}_{scene}"):
            matches.extend(excel_index.get(alias, []))
        unique_matches: List[ExcelSceneMeta] = []
        seen_meta = set()
        for match in matches:
            key = (match.source_file, match.sheet, match.scene_id, match.summary)
            if key not in seen_meta:
                unique_matches.append(match)
                seen_meta.add(key)

        mapped_run_summaries, trace_ids, trace_mapping_enabled = attach_trace_mapping(
            cast_list_of_dict(raw["run_summaries"]),
            unique_matches,
        )
        raw["run_summaries"] = mapped_run_summaries
        add_trace_fields(raw, mapped_run_summaries)
        public_run_summaries = simplify_run_summaries(mapped_run_summaries)

        warnings = build_warnings(
            group=group,
            report=raw,
            module_stats=module_stats,
            function_stats=function_stats,
            module_threshold=args.module_threshold,
            function_threshold=args.function_threshold,
            overhead_threshold=args.overhead_threshold,
            peer_factor=args.peer_factor,
        )
        scenario_reports.append(ScenarioReport(
            group=group,
            scene=scene,
            files=[str(file.path) for file in sorted(scenarios[(group, scene)], key=lambda item: (item.run.lower(), str(item.path).lower()))],
            total_samples=int(raw["total_samples"]),
            parking_samples=int(raw["parking_samples"]),
            module_inventory=sorted(str(name) for name in raw["module_inclusive"].keys()),
            top_modules=list(raw["top_modules"]),
            top_functions=list(raw["top_functions"]),
            module_functions=list(raw["module_functions"]),
            warnings=warnings,
            excel_matches=unique_matches,
            run_summaries=public_run_summaries,
            trace_ids=trace_ids,
            trace_mapping_enabled=trace_mapping_enabled,
        ))

    scenario_reports.sort(key=lambda item: (item.group, -item.parking_samples, item.scene))
    global_stats = build_global_summary(raw_reports)

    markdown = render_markdown(scenario_reports, perf_root, excel_paths, repo_root, global_stats)
    output_path = Path(args.output)
    if not output_path.is_absolute():
        output_path = current_dir / output_path
    output_path.write_text(markdown, encoding="utf-8")

    alert_xlsx_path = Path(args.alert_xlsx_output)
    if not alert_xlsx_path.is_absolute():
        alert_xlsx_path = current_dir / alert_xlsx_path
    alert_summary_rows, alert_warning_rows = build_alert_scene_rows(scenario_reports)
    write_simple_xlsx(
        alert_xlsx_path,
        [
            ("异常场景汇总", alert_summary_rows),
            ("告警明细", alert_warning_rows),
        ],
    )

    json_output_path = Path(args.json_output)
    if not json_output_path.is_absolute():
        json_output_path = current_dir / json_output_path
    json_payload = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "perf_root": str(perf_root),
        "excel": [str(path) for path in excel_paths],
        "repo_root": str(repo_root) if repo_root else "",
        "scenario_count": len(scenario_reports),
        "global_stats": global_stats,
        "scenarios": [
            {
                "group": report.group,
                "scene": report.scene,
                "files": report.files,
                "total_samples": report.total_samples,
                "parking_samples": report.parking_samples,
                "parking_ratio": ratio(report.parking_samples, report.total_samples),
                "module_inventory": report.module_inventory,
                "top_modules": report.top_modules,
                "top_functions": report.top_functions,
                "module_functions": report.module_functions,
                "warnings": report.warnings,
                "excel_matches": [meta.__dict__ for meta in report.excel_matches],
                "run_summaries": report.run_summaries,
                "trace_ids": report.trace_ids,
                "trace_mapping_enabled": report.trace_mapping_enabled,
            }
            for report in scenario_reports
        ],
    }
    json_output_path.write_text(json.dumps(json_payload, ensure_ascii=False, indent=2), encoding="utf-8")

    html_payload = build_compact_html_payload(json_payload)

    html_output_path = Path(args.html_output)
    if not html_output_path.is_absolute():
        html_output_path = current_dir / html_output_path
    html_output_path.write_text(render_html_dashboard(html_payload), encoding="utf-8")

    print(f"Markdown report written to: {output_path}")
    print(f"Alert scene Excel written to: {alert_xlsx_path}")
    print(f"JSON report written to: {json_output_path}")
    print(f"HTML dashboard written to: {html_output_path}")
    print(f"Scenarios analyzed: {len(scenario_reports)}")


if __name__ == "__main__":
    main()