#!/usr/bin/env python3
from __future__ import annotations

import argparse
import glob
import json
import re
import statistics
import zipfile
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Set, Tuple
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape as xml_escape


NOISE_SYMBOLS: Set[str] = {
    "[[kernel.kallsyms]]",
    "[unknown]",
    "thread_start",
    "start_thread",
    "__libc_start_main@@GLIBC_2.34",
    "__libc_start_main",
    "__libc_start_call_main",
    "_start",
    "_dl_start",
    "_dl_sysdep_start",
    "dl_main",
}

DIRECT_CONTEXT_SUBSTRINGS: Tuple[str, ...] = (
    "static fusion",
    "static_fusion",
    "nfm",
    "psd",
    "pmp",
    "rbp_eb",
    "rbp_ooc",
    "rbp_pp",
    "rbp",
    "mot",
    "rbp_mot",
    "apafct",
    "apahmi",
    "parkhmi",
    "hmi",
    "parkctl",
    "ctlfault",
    "ctlrunnable",
    "pfc",
    "aci",
    "vme",
    "vhm",
    "coolmaster",
    "ussper",
    "pdc",
    "mee",
    "maa",
    "mca",
    "infra",
    "ooc",
    "pp",
    "eb",
    "emergency",
    "brake",
    "apaplanning",
    "planning",
    "request",
)

QUICK_LINE_HINTS: Tuple[str, ...] = (
    "static fusion",
    "static_fusion",
    "staticfusion",
    "nfm",
    "psd",
    "pmp",
    "rbp_eb",
    "rbp_ooc",
    "rbp_pp",
    "rbp",
    "mot",
    "rbp_mot",
    "apafct",
    "rbpapahmi",
    "apahmi",
    "parkhmi",
    "pmphmi",
    "hmiconvert",
    "hmirange",
    "parkctl",
    "apafctctl",
    "ctlfault",
    "ctlfaultevent",
    "ctlrunnable",
    "ctlonupdate",
    "pfc",
    "aci",
    "vme",
    "vhm",
    "coolmaster",
    "ussper",
    "pdc",
    "mee",
    "maa",
    "mca",
    "infra",
    "ooc",
    "pp",
    "eb",
    "emergency",
    "brake",
    "apaplanning",
    "planningrequest",
    "planning_request",
    "planning request",
)

OVERHEAD_PATTERNS: Tuple[Tuple[str, re.Pattern[str]], ...] = (
    ("ipc_io", re.compile(r"iox::|senderport|receiverport|sharedchunk|allocatechunk|reservechunk|getchunk|samplereader|lightweightinbox", re.I)),
    ("logging", re.compile(r"mplog|logging_|log_message|staticlogmessageregistration|setthreadcontext", re.I)),
    ("memory", re.compile(r"operator new|malloc|_int_malloc|free|decrement\b|sharedpointer", re.I)),
    ("serialization", re.compile(r"serialize|mergefrom|getmetadata|internalserialize|protobuf", re.I)),
    ("synchronization", re.compile(r"pthread_|mutex|futex|lock_wait|cond_wait|cond_timedwait", re.I)),
)

MODULE_PATTERNS: Tuple[Tuple[str, re.Pattern[str]], ...] = (
    ("static_fusion", re.compile(r"static[ _:-]*fusion|staticfusion", re.I)),
    ("nfm", re.compile(r"(^|[^a-z])nfm([^a-z]|$)", re.I)),
    ("psd", re.compile(r"(^|[^a-z])psd([^a-z]|$)", re.I)),
    ("pmp", re.compile(r"(^|[^a-z])pmp([^a-z]|$)", re.I)),
    ("rbp_eb", re.compile(r"rbp::eb|rbp_eb|(^|[^a-z])eb([^a-z]|$)|emergency.*brake|brake.*emergency", re.I)),
    ("rbp_ooc", re.compile(r"rbp::ooc|rbp_ooc|(^|[^a-z])ooc([^a-z]|$)", re.I)),
    ("rbp_pp", re.compile(r"rbp::pp|rbp_pp|(^|[^a-z])pp([^a-z]|$)", re.I)),
    ("rbp_mot", re.compile(r"rbp::mot|rbp_mot|(^|[^a-z])mot([^a-z]|$)", re.I)),
    ("parkhmi", re.compile(r"rbpapahmi|apahmi|parkhmi|pmphmi|hmiConvert|HMIRange|RbpApahmi|Apahmi_onUpdate|Apahmi_onUpdateFunctor|RunContext.*Apahmi|Apahmi_RunContext|::hmi::|(^|[^a-z])hmi([^a-z]|$)", re.I)),
    ("parkctl", re.compile(r"parkctl|apafctctl|ApaFctCtl|CtlFaultEvent|CtlFaultEventListStruct|CtlRunnable|Ctl_onUpdate|Rbp.*Ctl.*RunContext|Rbp.*Ctl.*Functor|(^|[^a-z])ctlfault([^a-z]|$)", re.I)),
    ("pfc", re.compile(r"rbp::pfc|rb::cn::pfc|rbp::mca::pfc|rbp::ccp::pfc|(^|[^a-z])pfc([^a-z]|$)|CPfc|PfControl|Apactl|Motctl", re.I)),
    ("apafct", re.compile(r"rbpapafct|apafct", re.I)),
    ("aci", re.compile(r"rbcnaci|(^|[^a-z])aci([^a-z]|$)", re.I)),
    ("vme", re.compile(r"rbp::vme|(^|[^a-z])vme([^a-z]|$)|(^|[^a-z])vhm([^a-z]|$)|CVhm|VhmState|RbpVhm|vhm_", re.I)),
    ("ussper", re.compile(r"rbpussper|rbp::ussper|(^|[^a-z])ussper([^a-z]|$)", re.I)),
    ("pdc", re.compile(r"rbppdc|rbp::pdc|(^|[^a-z])pdc([^a-z]|$)", re.I)),
    ("mee", re.compile(r"(^|[^a-z])mee([^a-z]|$)", re.I)),
    ("maa", re.compile(r"(^|[^a-z])maa([^a-z]|$)", re.I)),
    ("mca", re.compile(r"rbpmca|rbp::mca|(^|[^a-z])mca([^a-z]|$)", re.I)),
    ("rbp_infra", re.compile(r"rbpinfra|rbp::infra|(^|[^a-z])infra([^a-z]|$)|coolmaster|RbpCoolMaster", re.I)),
    ("apaplanning", re.compile(r"apa[ _:-]*planning|apaplanning", re.I)),
    ("planning_request", re.compile(r"planning[ _:-]*request|request[ _:-]*planning", re.I)),
    ("rbp_others", re.compile(r"\brbp(?![-_:/a-z0-9]*vis)[-_:/a-z0-9:]*", re.I)),
)

EXCLUDED_MODULE_PATTERNS: Tuple[re.Pattern[str], ...] = (
    re.compile(r"rbp[-_:/a-z0-9]*vis", re.I),
    re.compile(r"/asw/bin/rbp-vis", re.I),
    re.compile(r"(^|[^a-z])vis([^a-z]|$)", re.I),
    re.compile(r"::vis(::|$)", re.I),
    re.compile(r"vis::", re.I),
)

EXPLICIT_PARKING_RE = re.compile(
    r"static[ _:-]*fusion|nfm|psd|pmp|rbp|mot|rbp_mot|rbp_eb|rbp_ooc|rbp_pp|apafct|apahmi|parkhmi|hmi|parkctl|ctlfault|ctlrunnable|pfc|aci|vme|vhm|ussper|pdc|mee|maa|mca|infra|coolmaster|emergency.*brake|apaplanning|planning[ _:-]*request|ooc|pp|eb",
    re.I,
)

CONTEXTUAL_RE = re.compile(
    r"trajectory|planner|motion_planner|prediction|trajpred|iox::|senderport|receiverport|sharedchunk|allocatechunk|reservechunk|getchunk|samplereader|serialize|mergefrom|getmetadata|internalserialize|mplog|logging_|log_message|malloc|operator new|pthread_|mutex|futex",
    re.I,
)

GENERIC_MODULES: Set[str] = {"rbp_others"}

XLSX_NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
XLSX_REL_NS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
SCRIPT_DIR_PLACEHOLDER = "${SCRIPT_DIR}"
CURRENT_DIR_PLACEHOLDER = "${CURRENT_DIR}"
CWD_PLACEHOLDER = "${CWD}"


@dataclass
class PerfSample:
    group: str
    scene: str
    run: str
    path: Path


@dataclass
class ExcelSceneMeta:
    source_file: str
    sheet: str
    scene_id: str
    title: str
    summary: str
    traces: List[str] = field(default_factory=list)


@dataclass
class ScenarioReport:
    group: str
    scene: str
    files: List[str]
    total_samples: int
    parking_samples: int
    module_inventory: List[str]
    top_modules: List[Dict[str, object]]
    top_functions: List[Dict[str, object]]
    module_functions: List[Dict[str, object]]
    warnings: List[str]
    excel_matches: List[ExcelSceneMeta]
    run_summaries: List[Dict[str, object]] = field(default_factory=list)
    trace_ids: List[str] = field(default_factory=list)
    trace_mapping_enabled: bool = False


def replace_path_placeholders(value: str, current_dir: Path, script_dir: Path) -> str:
    replaced = str(value)
    replaced = replaced.replace(CURRENT_DIR_PLACEHOLDER, str(current_dir))
    replaced = replaced.replace(CWD_PLACEHOLDER, str(current_dir))
    replaced = replaced.replace(SCRIPT_DIR_PLACEHOLDER, str(script_dir))
    return replaced


def has_glob_pattern(value: str) -> bool:
    return any(token in value for token in ("*", "?", "["))


def expand_cli_path(value: str, current_dir: Path, script_dir: Path) -> Path:
    replaced = replace_path_placeholders(value, current_dir, script_dir)
    path = Path(replaced)
    if not path.is_absolute():
        path = current_dir / path
    return path


def expand_cli_paths(
    values: Sequence[str],
    current_dir: Path,
    script_dir: Path,
    *,
    files_only: bool = False,
    dirs_only: bool = False,
) -> List[Path]:
    resolved: List[Path] = []
    seen: Set[Path] = set()
    for value in values:
        replaced = replace_path_placeholders(value, current_dir, script_dir)
        candidate = Path(replaced)
        pattern = str(candidate if candidate.is_absolute() else current_dir / candidate)
        matches = [Path(item) for item in glob.glob(pattern, recursive=True)] if has_glob_pattern(pattern) else [Path(pattern)]
        for match in sorted(matches):
            path = match.resolve()
            if not path.exists():
                continue
            if files_only and not path.is_file():
                continue
            if dirs_only and not path.is_dir():
                continue
            if path in seen:
                continue
            seen.add(path)
            resolved.append(path)
    return resolved


def is_generated_runtime_output(path: Path) -> bool:
    return path.name.lower().startswith("parking_runtime_")


def discover_repo_root(current_dir: Path, script_dir: Path, explicit_value: str) -> Optional[Path]:
    candidates = expand_cli_paths([explicit_value], current_dir, script_dir, dirs_only=True)
    if candidates:
        return candidates[0]
    return None


def hotspot_level(top_modules: Sequence[Dict[str, object]], warnings: Sequence[str]) -> str:
    top = top_modules[0] if top_modules else None
    ratio_value = float(top.get("inclusive_ratio_total", 0.0)) if isinstance(top, dict) else 0.0
    if ratio_value >= 0.12 or len(warnings) >= 3:
        return "高"
    if ratio_value >= 0.06 or len(warnings) >= 1:
        return "中"
    return "低"


def summarize_metric_series(values: Sequence[int], totals: Sequence[int], labels: Sequence[str]) -> Dict[str, object]:
    if not values or not totals or not labels:
        return {
            "run_count": 0,
            "avg_samples": 0.0,
            "max_samples": 0,
            "min_samples": 0,
            "avg_ratio_total": 0.0,
            "max_ratio_total": 0.0,
            "min_ratio_total": 0.0,
            "max_label": "",
            "min_label": "",
        }
    ratios = [ratio(value, total) for value, total in zip(values, totals)]
    max_index = max(range(len(values)), key=lambda index: (values[index], ratios[index]))
    min_index = min(range(len(values)), key=lambda index: (values[index], ratios[index]))
    return {
        "run_count": len(values),
        "avg_samples": statistics.fmean(values),
        "max_samples": max(values),
        "min_samples": min(values),
        "avg_ratio_total": statistics.fmean(ratios),
        "max_ratio_total": max(ratios),
        "min_ratio_total": min(ratios),
        "max_label": labels[max_index],
        "min_label": labels[min_index],
    }


def collect_trace_ids(excel_matches: Sequence[ExcelSceneMeta]) -> List[str]:
    trace_ids: List[str] = []
    seen: Set[str] = set()
    for meta in excel_matches:
        for trace in meta.traces:
            normalized = str(trace).strip()
            if not normalized or normalized in seen:
                continue
            trace_ids.append(normalized)
            seen.add(normalized)
    return trace_ids


def attach_trace_mapping(run_summaries: Sequence[Dict[str, object]], excel_matches: Sequence[ExcelSceneMeta]) -> Tuple[List[Dict[str, object]], List[str], bool]:
    trace_ids = collect_trace_ids(excel_matches)
    mapping_enabled = bool(run_summaries) and len(trace_ids) == len(run_summaries)
    enriched: List[Dict[str, object]] = []
    for index, item in enumerate(run_summaries):
        enriched_item = dict(item)
        enriched_item["trace_id"] = trace_ids[index] if mapping_enabled else ""
        enriched_item["trace_mapped"] = mapping_enabled
        enriched.append(enriched_item)
    return enriched, trace_ids, mapping_enabled


def add_trace_fields(raw: Dict[str, object], run_summaries: Sequence[Dict[str, object]]) -> None:
    trace_by_label: Dict[str, str] = {}
    for item in run_summaries:
        label = str(item.get("label", ""))
        trace_id = str(item.get("trace_id", ""))
        if label and trace_id and label not in trace_by_label:
            trace_by_label[label] = trace_id

    for module_item in cast_list(raw["top_modules"]):
        max_run = str(module_item.get("max_run", ""))
        min_run = str(module_item.get("min_run", ""))
        module_item["max_trace"] = trace_by_label.get(max_run, "")
        module_item["min_trace"] = trace_by_label.get(min_run, "")

    for function_item in cast_list(raw["top_functions"]):
        max_run = str(function_item.get("max_run", ""))
        min_run = str(function_item.get("min_run", ""))
        function_item["max_trace"] = trace_by_label.get(max_run, "")
        function_item["min_trace"] = trace_by_label.get(min_run, "")

    for module_entry in cast_list(raw["module_functions"]):
        for function_item in cast_list(module_entry.get("functions", [])):
            max_label = str(function_item.get("max_label", ""))
            min_label = str(function_item.get("min_label", ""))
            function_item["max_trace"] = trace_by_label.get(max_label, "")
            function_item["min_trace"] = trace_by_label.get(min_label, "")


def simplify_run_summaries(run_summaries: Sequence[Dict[str, object]]) -> List[Dict[str, object]]:
    simplified: List[Dict[str, object]] = []
    for item in run_summaries:
        total_samples = int(item.get("total_samples", 0) or 0)
        parking_samples = int(item.get("parking_samples", 0) or 0)
        simplified.append({
            "label": str(item.get("label", "")),
            "file_name": str(item.get("file_name", "")),
            "source_path": str(item.get("source_path", "")),
            "total_samples": total_samples,
            "parking_samples": parking_samples,
            "parking_ratio": ratio(parking_samples, total_samples),
            "trace_id": str(item.get("trace_id", "")),
            "trace_mapped": bool(item.get("trace_mapped", False)),
        })
    return simplified


def build_global_summary(raw_reports: Dict[Tuple[str, str], Dict[str, object]]) -> Dict[str, List[Dict[str, object]]]:
    scenario_keys = list(sorted(raw_reports.keys()))
    scenario_labels = [f"{group} / {scene}" for group, scene in scenario_keys]
    scenario_totals = [int(raw_reports[key]["total_samples"]) for key in scenario_keys]

    modules_seen: Set[str] = set()
    functions_seen: Set[Tuple[str, str]] = set()
    for key in scenario_keys:
        modules_seen.update(raw_reports[key]["module_inclusive"].keys())
        functions_seen.update(raw_reports[key]["function_exclusive"].keys())

    global_modules: List[Dict[str, object]] = []
    for module_name in sorted(modules_seen):
        values = [int(raw_reports[key]["module_inclusive"].get(module_name, 0)) for key in scenario_keys]
        stats = summarize_metric_series(values, scenario_totals, scenario_labels)
        present_values = [value for value in values if value > 0]
        present_ratios = [ratio(value, total) for value, total in zip(values, scenario_totals) if value > 0]
        global_modules.append({
            "module": module_name,
            "scenario_count": len(scenario_keys),
            "present_scenario_count": sum(1 for value in values if value > 0),
            "avg_samples_all": stats["avg_samples"],
            "avg_samples_present": statistics.fmean(present_values) if present_values else 0.0,
            "max_samples": stats["max_samples"],
            "min_samples": stats["min_samples"],
            "avg_ratio_total_all": stats["avg_ratio_total"],
            "avg_ratio_total_present": statistics.fmean(present_ratios) if present_ratios else 0.0,
            "max_ratio_total": stats["max_ratio_total"],
            "min_ratio_total": stats["min_ratio_total"],
            "max_scene": stats["max_label"],
            "min_scene": stats["min_label"],
        })

    global_functions: List[Dict[str, object]] = []
    for module_name, function_name in sorted(functions_seen):
        values = [int(raw_reports[key]["function_exclusive"].get((module_name, function_name), 0)) for key in scenario_keys]
        stats = summarize_metric_series(values, scenario_totals, scenario_labels)
        present_values = [value for value in values if value > 0]
        present_ratios = [ratio(value, total) for value, total in zip(values, scenario_totals) if value > 0]
        global_functions.append({
            "module": module_name,
            "function": function_name,
            "scenario_count": len(scenario_keys),
            "present_scenario_count": sum(1 for value in values if value > 0),
            "avg_samples_all": stats["avg_samples"],
            "avg_samples_present": statistics.fmean(present_values) if present_values else 0.0,
            "max_samples": stats["max_samples"],
            "min_samples": stats["min_samples"],
            "avg_ratio_total_all": stats["avg_ratio_total"],
            "avg_ratio_total_present": statistics.fmean(present_ratios) if present_ratios else 0.0,
            "max_ratio_total": stats["max_ratio_total"],
            "min_ratio_total": stats["min_ratio_total"],
            "max_scene": stats["max_label"],
            "min_scene": stats["min_label"],
        })

    global_modules.sort(key=lambda item: (-float(item["max_ratio_total"]), -float(item["avg_ratio_total_all"]), str(item["module"])))
    global_functions.sort(key=lambda item: (-float(item["max_ratio_total"]), -float(item["avg_ratio_total_all"]), str(item["module"]), str(item["function"])))
    return {
        "modules": global_modules,
        "functions": global_functions,
    }


def normalize_process_name(name: str) -> str:
    if name.startswith(":-1____"):
        return "[idle]"
    match = re.match(r"^(\d+)-(.+)$", name)
    if match:
        name = match.group(2)
    name = re.sub(r"/(\d+)$", "", name)
    name = re.sub(r"-(\d+)$", "", name)
    return name


def parse_folded_line(line: str) -> Tuple[List[str], int]:
    line = line.strip()
    if not line or line.startswith("#"):
        return [], 0
    try:
        stack_part, count_part = line.rsplit(" ", 1)
        return stack_part.split(";"), int(count_part)
    except ValueError:
        return line.split(";"), 1


def parse_sample_count(line: str) -> int:
    stripped = line.strip()
    if not stripped or stripped.startswith("#"):
        return 0
    try:
        return int(stripped.rsplit(" ", 1)[1])
    except (IndexError, ValueError):
        return 0

def is_noise_symbol(symbol: str) -> bool:
    return symbol in NOISE_SYMBOLS or (symbol.startswith("[") and symbol.endswith("]") and not EXPLICIT_PARKING_RE.search(symbol))


def is_excluded_frame(frame: str) -> bool:
    return any(pattern.search(frame) for pattern in EXCLUDED_MODULE_PATTERNS)


def normalize_key(text: str) -> str:
    cleaned = re.sub(r"\s+", " ", text.strip().lower())
    cleaned = cleaned.replace("（", "(").replace("）", ")")
    cleaned = cleaned.replace("_", "_")
    return cleaned


def scene_aliases(scene_name: str) -> Set[str]:
    base = normalize_key(scene_name)
    aliases = {base}
    if base.startswith("apa_"):
        aliases.add(base[4:])
    for suffix in ("_chengren", "_xiaohai"):
        if base.endswith(suffix):
            aliases.add(base[: -len(suffix)])
    aliases.add(base.replace("apa_", ""))
    aliases.add(base.replace(" ", ""))
    return {alias for alias in aliases if alias}


def discover_perf_samples(perf_root: Path) -> Dict[Tuple[str, str], List[PerfSample]]:
    scenarios: Dict[Tuple[str, str], List[PerfSample]] = defaultdict(list)
    for path in perf_root.rglob("*.fold"):
        relative = path.relative_to(perf_root)
        if len(relative.parts) < 2:
            continue
        group = relative.parts[0]
        scene = relative.parts[1]
        run_parts = [part for part in relative.parts[2:-1] if part.lower().startswith("perf_")]
        run = "/".join(run_parts) if run_parts else path.parent.name
        scenarios[(group, scene)].append(PerfSample(group=group, scene=scene, run=run, path=path))
    return scenarios


def column_to_number(col_ref: str) -> int:
    value = 0
    for char in col_ref:
        if "A" <= char <= "Z":
            value = value * 26 + ord(char) - 64
    return value


def read_shared_strings(archive: zipfile.ZipFile) -> List[str]:
    if "xl/sharedStrings.xml" not in archive.namelist():
        return []
    root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
    strings = []
    for item in root.findall(f"{XLSX_NS}si"):
        strings.append("".join(node.text or "" for node in item.iterfind(f".//{XLSX_NS}t")))
    return strings


def row_to_list(row: ET.Element, shared: Sequence[str]) -> List[str]:
    values: Dict[int, str] = {}
    for cell in row.findall(f"{XLSX_NS}c"):
        ref = cell.attrib.get("r", "")
        match = re.match(r"([A-Z]+)(\d+)", ref)
        if not match:
            continue
        index = column_to_number(match.group(1))
        cell_type = cell.attrib.get("t")
        if cell_type == "s":
            node = cell.find(f"{XLSX_NS}v")
            value = shared[int(node.text)] if node is not None and node.text else ""
        elif cell_type == "inlineStr":
            node = cell.find(f".//{XLSX_NS}t")
            value = node.text if node is not None and node.text else ""
        else:
            node = cell.find(f"{XLSX_NS}v")
            value = node.text if node is not None and node.text else ""
        values[index] = value.strip()
    if not values:
        return []
    max_index = max(values)
    return [values.get(i, "") for i in range(1, max_index + 1)]


def load_workbook_rows(path: Path) -> Dict[str, List[List[str]]]:
    with zipfile.ZipFile(path) as archive:
        shared = read_shared_strings(archive)
        workbook = ET.fromstring(archive.read("xl/workbook.xml"))
        rels = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
        rel_map = {rel.attrib["Id"]: rel.attrib["Target"] for rel in rels}
        sheets: Dict[str, List[List[str]]] = {}
        for sheet in workbook.find(f"{XLSX_NS}sheets").findall(f"{XLSX_NS}sheet"):
            name = sheet.attrib["name"]
            rel_id = sheet.attrib[f"{XLSX_REL_NS}id"]
            target = "xl/" + rel_map[rel_id].lstrip("/")
            root = ET.fromstring(archive.read(target))
            rows = []
            for row in root.find(f"{XLSX_NS}sheetData").findall(f"{XLSX_NS}row"):
                values = row_to_list(row, shared)
                if any(values):
                    rows.append(values)
            sheets[name] = rows
        return sheets


def safe_get(row: Sequence[str], index: int) -> str:
    return row[index] if index < len(row) else ""


def build_excel_index(excel_paths: Sequence[Path]) -> Dict[str, List[ExcelSceneMeta]]:
    index: Dict[str, List[ExcelSceneMeta]] = defaultdict(list)
    seen_entries: Set[Tuple[str, str, str, str]] = set()
    for path in excel_paths:
        sheets = load_workbook_rows(path)
        for sheet_name, rows in sheets.items():
            if sheet_name == "APA_73":
                parse_apa73_sheet(path, sheet_name, rows, index, seen_entries)
            elif sheet_name == "APA_Sotif case":
                parse_sotif_sheet(path, sheet_name, rows, index, seen_entries)
            elif sheet_name == "MAA":
                parse_maa_sheet(path, sheet_name, rows, index, seen_entries)
            elif sheet_name == "MEB":
                parse_meb_sheet(path, sheet_name, rows, index, seen_entries)
    return index


def add_excel_meta(index: Dict[str, List[ExcelSceneMeta]], seen: Set[Tuple[str, str, str, str]], meta: ExcelSceneMeta) -> None:
    fingerprint = (meta.source_file, meta.sheet, meta.scene_id, meta.summary)
    if fingerprint in seen:
        return
    seen.add(fingerprint)
    for alias in scene_aliases(meta.scene_id) | scene_aliases(meta.title):
        index[alias].append(meta)


def parse_apa73_sheet(path: Path, sheet_name: str, rows: Sequence[Sequence[str]], index: Dict[str, List[ExcelSceneMeta]], seen: Set[Tuple[str, str, str, str]]) -> None:
    current_scene_id = ""
    current_title = ""
    tests: Dict[str, Dict[str, object]] = {}
    for row in rows:
        scene_id = safe_get(row, 0) or current_scene_id
        title = safe_get(row, 1) or current_title
        if scene_id:
            current_scene_id = scene_id
        if title:
            current_title = title
        if not current_scene_id:
            continue
        state = tests.setdefault(current_scene_id, {"title": current_title, "total": 0, "success": 0, "directions": set(), "traces": []})
        if safe_get(row, 6).isdigit():
            state["total"] = int(state["total"]) + 1
        if safe_get(row, 10) == "1":
            state["success"] = int(state["success"]) + 1
        if safe_get(row, 7):
            cast_set(state["directions"]).add(safe_get(row, 7))
        trace = safe_get(row, 26)
        if trace:
            cast_list(state["traces"]).append(trace)
        if current_title and not state["title"]:
            state["title"] = current_title
    for scene_id, state in tests.items():
        total = int(state["total"])
        success = int(state["success"])
        summary = f"tests={total}, success={success}, directions={','.join(sorted(cast_set(state['directions']))) or '-'}"
        add_excel_meta(index, seen, ExcelSceneMeta(
            source_file=path.name,
            sheet=sheet_name,
            scene_id=scene_id,
            title=str(state["title"]),
            summary=summary,
            traces=cast_list(state["traces"]),
        ))


def parse_sotif_sheet(path: Path, sheet_name: str, rows: Sequence[Sequence[str]], index: Dict[str, List[ExcelSceneMeta]], seen: Set[Tuple[str, str, str, str]]) -> None:
    current_scene_id = ""
    current_title = ""
    grouped: Dict[str, Dict[str, object]] = {}
    for row in rows:
        scene_id = safe_get(row, 0) or current_scene_id
        title = safe_get(row, 1) or current_title
        if scene_id:
            current_scene_id = scene_id
        if title:
            current_title = title
        if not current_scene_id:
            continue
        state = grouped.setdefault(current_scene_id, {"title": current_title, "variants": 0, "notes": []})
        description = safe_get(row, 2) or safe_get(row, 3)
        if description:
            state["variants"] = int(state["variants"]) + 1
        for column in row[8:]:
            if column:
                cast_list(state["notes"]).append(column)
    for scene_id, state in grouped.items():
        summary = f"variants={state['variants']}, notes={'; '.join(cast_list(state['notes'])[:4])}"
        add_excel_meta(index, seen, ExcelSceneMeta(
            source_file=path.name,
            sheet=sheet_name,
            scene_id=scene_id,
            title=str(state["title"]),
            summary=summary,
            traces=[],
        ))


def parse_maa_sheet(path: Path, sheet_name: str, rows: Sequence[Sequence[str]], index: Dict[str, List[ExcelSceneMeta]], seen: Set[Tuple[str, str, str, str]]) -> None:
    for row in rows:
        scene = safe_get(row, 1)
        if not scene or scene in {"Scene Catalog Collection", "静态障碍物测试用例（前后向）"}:
            continue
        if not safe_get(row, 0).isdigit():
            continue
        notes = [value for value in row[5:] if value]
        summary = f"kpi={safe_get(row, 2)}, repetitions={safe_get(row, 3)}, notes={'; '.join(notes[:6])}"
        add_excel_meta(index, seen, ExcelSceneMeta(
            source_file=path.name,
            sheet=sheet_name,
            scene_id=scene,
            title=scene,
            summary=summary,
            traces=[],
        ))


def parse_meb_sheet(path: Path, sheet_name: str, rows: Sequence[Sequence[str]], index: Dict[str, List[ExcelSceneMeta]], seen: Set[Tuple[str, str, str, str]]) -> None:
    for row in rows:
        scene = safe_get(row, 0)
        if not scene or scene.startswith("*") or scene in {"Low Objects", "Picture", "Backwards", "Total test"}:
            continue
        if scene == "":
            continue
        if not safe_get(row, 3):
            continue
        note_values = [value for value in row[8:] if value]
        summary = f"clutter={safe_get(row, 2)}, speed={safe_get(row, 3)}, success_rate={safe_get(row, 7)}, notes={'; '.join(note_values[:4])}"
        add_excel_meta(index, seen, ExcelSceneMeta(
            source_file=path.name,
            sheet=sheet_name,
            scene_id=scene,
            title=scene,
            summary=summary,
            traces=[],
        ))


def cast_list(value: object) -> List[str]:
    return value if isinstance(value, list) else []


def cast_list_of_dict(value: object) -> List[Dict[str, object]]:
    return value if isinstance(value, list) else []


def cast_set(value: object) -> Set[str]:
    return value if isinstance(value, set) else set()


def mine_repo_symbols(repo_root: Optional[Path], limit: int = 500) -> Set[str]:
    if repo_root is None or not repo_root.exists():
        return set()
    result: Set[str] = set()
    path_keywords = re.compile(r"park|apa|slot|maneuver|trajectory|apahmi|pdc", re.I)
    token_pattern = re.compile(r"\b[A-Za-z_][A-Za-z0-9_:]{4,}\b")
    for path in repo_root.rglob("*"):
        if len(result) >= limit:
            break
        if not path.is_file() or path.suffix.lower() not in {".h", ".hpp", ".c", ".cc", ".cpp"}:
            continue
        if not path_keywords.search(str(path)):
            continue
        try:
            with path.open("r", encoding="utf-8", errors="replace") as handle:
                for line in handle:
                    if not path_keywords.search(line):
                        continue
                    for token in token_pattern.findall(line):
                        lower = token.lower().strip(":")
                        if len(lower) > 48:
                            continue
                        if path_keywords.search(lower):
                            result.add(lower)
                            if len(result) >= limit:
                                break
                    if len(result) >= limit:
                        break
        except OSError:
            continue
    return result


def frame_repo_hit(frame: str, repo_symbols: Set[str]) -> bool:
    if not repo_symbols:
        return False
    for token in re.findall(r"[a-z_][a-z0-9_]{3,}", frame.lower()):
        if token in repo_symbols:
            return True
    return False


def has_direct_context(frames: Sequence[str], repo_symbols: Set[str]) -> bool:
    for frame in frames:
        if is_excluded_frame(frame):
            continue
        lowered = frame.lower()
        if any(token in lowered for token in DIRECT_CONTEXT_SUBSTRINGS):
            return True
        if EXPLICIT_PARKING_RE.search(frame):
            return True
        if frame_repo_hit(frame, repo_symbols):
            return True
    return False


def classify_frame(frame: str, direct_context: bool, repo_symbols: Set[str]) -> Optional[str]:
    if is_excluded_frame(frame):
        return None
    if not direct_context and not EXPLICIT_PARKING_RE.search(frame):
        return None
    for module_name, pattern in MODULE_PATTERNS:
        if pattern.search(frame):
            return module_name
    return None


def detect_owner_module(
    frames: Sequence[str],
    repo_symbols: Set[str],
    frame_cache: Optional[Dict[str, Optional[str]]] = None,
) -> Optional[str]:
    direct_context = has_direct_context(frames, repo_symbols)
    candidates: List[Tuple[int, str]] = []
    process_candidate: Optional[str] = None
    for index, frame in enumerate(frames):
        if is_noise_symbol(frame) or is_excluded_frame(frame):
            continue
        if frame_cache is not None and frame in frame_cache:
            category = frame_cache[frame]
        else:
            category = classify_frame(frame, direct_context, repo_symbols)
            if frame_cache is not None:
                frame_cache[frame] = category
        if not category:
            continue
        if index == 0:
            process_candidate = category
        candidates.append((index, category))
    if not candidates:
        return None
    specific = [(index, category) for index, category in candidates if category not in GENERIC_MODULES]
    if process_candidate and process_candidate not in GENERIC_MODULES:
        return process_candidate
    if specific:
        return max(specific, key=lambda item: item[0])[1]
    if process_candidate:
        return process_candidate
    return max(candidates, key=lambda item: item[0])[1]


def select_leaf_function(
    frames: Sequence[str],
    owner_module: str,
    repo_symbols: Set[str],
    frame_cache: Optional[Dict[str, Optional[str]]] = None,
) -> Optional[str]:
    direct_context = True
    fallback: Optional[str] = None
    for frame in reversed(frames[1:]):
        if is_noise_symbol(frame) or is_excluded_frame(frame):
            continue
        if fallback is None:
            fallback = frame
        if frame_cache is not None and frame in frame_cache:
            category = frame_cache[frame]
        else:
            category = classify_frame(frame, direct_context, repo_symbols)
            if frame_cache is not None:
                frame_cache[frame] = category
        if category == owner_module:
            return frame
    return fallback


def extract_call_chain(frames: Sequence[str], leaf_function: str) -> List[str]:
    filtered_frames: List[str] = []
    for frame in frames[1:]:
        if is_noise_symbol(frame) or is_excluded_frame(frame):
            continue
        filtered_frames.append(frame)
    if not filtered_frames:
        return [leaf_function]

    for index in range(len(filtered_frames) - 1, -1, -1):
        if filtered_frames[index] == leaf_function:
            return filtered_frames[: index + 1]
    return filtered_frames + [leaf_function]


def build_call_tree(path_counter: Counter[Tuple[str, ...]], total_samples: int) -> List[Dict[str, object]]:
    root: Dict[str, object] = {"children": {}}
    for path, count in path_counter.items():
        if count <= 0:
            continue
        cursor = root
        for name in path:
            children = cursor.setdefault("children", {})
            if name not in children:
                children[name] = {"name": name, "samples": 0, "children": {}}
            child = children[name]
            child["samples"] = int(child.get("samples", 0)) + count
            cursor = child

    def freeze(node: Dict[str, object]) -> List[Dict[str, object]]:
        children = list(dict(node.get("children", {})).values())
        children.sort(key=lambda item: (-int(item.get("samples", 0)), str(item.get("name", ""))))
        return [
            {
                "name": str(child.get("name", "")),
                "samples": int(child.get("samples", 0)),
                "ratio_total": ratio(int(child.get("samples", 0)), total_samples),
                "children": freeze(child),
            }
            for child in children
        ]

    return freeze(root)


def find_leaf_category(
    frames: Sequence[str],
    direct_context: bool,
    repo_symbols: Set[str],
    frame_cache: Optional[Dict[str, Optional[str]]] = None,
) -> Optional[Tuple[str, str]]:
    for frame in reversed(frames):
        if is_noise_symbol(frame):
            continue
        if frame_cache is not None and frame in frame_cache:
            category = frame_cache[frame]
        else:
            category = classify_frame(frame, direct_context, repo_symbols)
            if frame_cache is not None:
                frame_cache[frame] = category
        if category:
            return category, frame
    return None


def analyze_scenario(files: Sequence[PerfSample], repo_symbols: Set[str], top_n: int) -> Dict[str, object]:
    total_samples = 0
    parking_samples = 0
    module_inclusive: Counter[str] = Counter()
    module_exclusive: Counter[str] = Counter()
    function_inclusive: Counter[Tuple[str, str]] = Counter()
    function_exclusive: Counter[Tuple[str, str]] = Counter()
    function_call_paths: Dict[Tuple[str, str], Counter[Tuple[str, ...]]] = defaultdict(Counter)
    frame_cache: Dict[str, Optional[str]] = {}
    run_summaries: List[Dict[str, object]] = []

    for sample in sorted(files, key=lambda item: (item.run.lower(), str(item.path).lower())):
        run_total_samples = 0
        run_parking_samples = 0
        run_module_inclusive: Counter[str] = Counter()
        run_function_exclusive: Counter[Tuple[str, str]] = Counter()
        with sample.path.open("r", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                count = parse_sample_count(line)
                if count <= 0:
                    continue
                total_samples += count
                run_total_samples += count
                lowered_line = line.lower()
                if not any(hint in lowered_line for hint in QUICK_LINE_HINTS):
                    continue
                frames, count = parse_folded_line(line)
                if count <= 0 or not frames:
                    continue
                process = normalize_process_name(frames[0])
                stack_frames = [process] + frames[1:]
                owner_module = detect_owner_module(stack_frames, repo_symbols, frame_cache)
                if not owner_module:
                    continue
                parking_samples += count
                run_parking_samples += count
                module_inclusive[owner_module] += count
                module_exclusive[owner_module] += count
                run_module_inclusive[owner_module] += count

                seen_functions: Set[str] = set()
                for frame in stack_frames[1:]:
                    if is_noise_symbol(frame) or is_excluded_frame(frame):
                        continue
                    if frame not in seen_functions:
                        function_inclusive[(owner_module, frame)] += count
                        seen_functions.add(frame)

                leaf_function = select_leaf_function(stack_frames, owner_module, repo_symbols, frame_cache)
                if leaf_function:
                    function_exclusive[(owner_module, leaf_function)] += count
                    run_function_exclusive[(owner_module, leaf_function)] += count
                    call_chain = extract_call_chain(stack_frames, leaf_function)
                    function_call_paths[(owner_module, leaf_function)][tuple(call_chain)] += count

        run_summaries.append({
            "label": sample.run,
            "file_name": sample.path.name,
            "source_path": str(sample.path),
            "total_samples": run_total_samples,
            "parking_samples": run_parking_samples,
            "module_inclusive": run_module_inclusive,
            "function_exclusive": run_function_exclusive,
        })

    run_labels = [str(item["label"]) for item in run_summaries]
    run_totals = [int(item["total_samples"]) for item in run_summaries]

    top_modules = []
    for category, inclusive_count in module_inclusive.most_common(top_n):
        run_values = [int(item["module_inclusive"].get(category, 0)) for item in run_summaries]
        run_stats = summarize_metric_series(run_values, run_totals, run_labels)
        top_modules.append({
            "module": category,
            "inclusive_samples": inclusive_count,
            "inclusive_ratio_total": ratio(inclusive_count, total_samples),
            "inclusive_ratio_parking": ratio(inclusive_count, parking_samples),
            "exclusive_samples": module_exclusive.get(category, 0),
            "exclusive_ratio_total": ratio(module_exclusive.get(category, 0), total_samples),
            "avg_samples": run_stats["avg_samples"],
            "max_samples": run_stats["max_samples"],
            "min_samples": run_stats["min_samples"],
            "avg_ratio_total": run_stats["avg_ratio_total"],
            "max_ratio_total": run_stats["max_ratio_total"],
            "min_ratio_total": run_stats["min_ratio_total"],
            "max_run": run_stats["max_label"],
            "min_run": run_stats["min_label"],
        })

    top_functions = []
    for (category, frame), exclusive_count in function_exclusive.most_common(top_n):
        inclusive_count = function_inclusive.get((category, frame), 0)
        run_values = [int(item["function_exclusive"].get((category, frame), 0)) for item in run_summaries]
        run_stats = summarize_metric_series(run_values, run_totals, run_labels)
        top_functions.append({
            "module": category,
            "function": frame,
            "exclusive_samples": exclusive_count,
            "exclusive_ratio_total": ratio(exclusive_count, total_samples),
            "exclusive_ratio_parking": ratio(exclusive_count, parking_samples),
            "inclusive_samples": inclusive_count,
            "inclusive_ratio_total": ratio(inclusive_count, total_samples),
            "avg_samples": run_stats["avg_samples"],
            "max_samples": run_stats["max_samples"],
            "min_samples": run_stats["min_samples"],
            "avg_ratio_total": run_stats["avg_ratio_total"],
            "max_ratio_total": run_stats["max_ratio_total"],
            "min_ratio_total": run_stats["min_ratio_total"],
            "max_run": run_stats["max_label"],
            "min_run": run_stats["min_label"],
            "call_tree": build_call_tree(function_call_paths.get((category, frame), Counter()), total_samples),
        })

    module_functions = []
    for module_item in top_modules:
        module_name = str(module_item["module"])
        ranked = [
            {
                "function": frame,
                "exclusive_samples": exclusive_count,
                "exclusive_ratio_total": ratio(exclusive_count, total_samples),
                "exclusive_ratio_module": ratio(exclusive_count, int(module_item["inclusive_samples"])),
                "inclusive_samples": function_inclusive.get((module_name, frame), 0),
                "inclusive_ratio_total": ratio(function_inclusive.get((module_name, frame), 0), total_samples),
                "call_tree": build_call_tree(function_call_paths.get((module_name, frame), Counter()), total_samples),
                **summarize_metric_series(
                    [int(item["function_exclusive"].get((module_name, frame), 0)) for item in run_summaries],
                    run_totals,
                    run_labels,
                ),
            }
            for (category, frame), exclusive_count in function_exclusive.most_common()
            if category == module_name
        ]
        module_functions.append({
            "module": module_name,
            "functions": ranked,
        })

    converted_function_exclusive = {}
    for (module, func), count in function_exclusive.items():
        # 将元组转为字符串键，例如 "module::function"
        converted_function_exclusive[f"{module}::{func}"] = count

    # 同样处理 function_inclusive
    converted_function_inclusive = {}
    for (module, func), count in function_inclusive.items():
        converted_function_inclusive[f"{module}::{func}"] = count

    # 处理 run_summaries 中的 function_exclusive
    for run in run_summaries:
        if "function_exclusive" in run:
            old = run["function_exclusive"]
            new = {}
            for (module, func), count in old.items():
                new[f"{module}::{func}"] = count
            run["function_exclusive"] = new

        # 转换 module_inclusive (Counter → dict)
    converted_module_inclusive = dict(module_inclusive)

    return {
        "total_samples": total_samples,
        "parking_samples": parking_samples,
        "top_modules": top_modules,
        "top_functions": top_functions,
        "module_functions": module_functions,
        "module_inclusive": converted_module_inclusive,
        "function_exclusive": converted_function_exclusive,
        "run_summaries": run_summaries,
    }


def ratio(part: int, total: int) -> float:
    return (part / total) if total else 0.0


def build_peer_stats(reports: Dict[Tuple[str, str], Dict[str, object]]) -> Tuple[Dict[str, Dict[str, List[float]]], Dict[str, Dict[str, List[float]]]]:
    module_stats: Dict[str, Dict[str, List[float]]] = defaultdict(lambda: defaultdict(list))
    function_stats: Dict[str, Dict[str, List[float]]] = defaultdict(lambda: defaultdict(list))
    for (group, _scene), report in reports.items():
        total_samples = int(report["total_samples"])
        for item in report["top_modules"]:
            module_stats[group][str(item["module"])].append(ratio(int(item["inclusive_samples"]), total_samples))
        for item in report["top_functions"]:
            function_stats[group][str(item["function"])].append(ratio(int(item["exclusive_samples"]), total_samples))
    return module_stats, function_stats


def median_or_zero(values: Sequence[float]) -> float:
    filtered = [value for value in values if value > 0]
    return statistics.median(filtered) if filtered else 0.0


def build_warnings(
    group: str,
    report: Dict[str, object],
    module_stats: Dict[str, Dict[str, List[float]]],
    function_stats: Dict[str, Dict[str, List[float]]],
    module_threshold: float,
    function_threshold: float,
    overhead_threshold: float,
    peer_factor: float,
) -> List[str]:
    warnings: List[str] = []
    total_samples = int(report["total_samples"])
    parking_samples = int(report["parking_samples"])
    parking_share = ratio(parking_samples, total_samples)
    if parking_share >= 0.45:
        warnings.append(f"parking相关堆栈占比达到 {parking_share:.1%}，整体算力负载偏高。")
    elif parking_share <= 0.02:
        warnings.append(f"parking相关堆栈占比仅 {parking_share:.1%}，可能存在符号识别不足或该场景未充分触发泊车主流程。")

    for item in report["top_modules"]:
        module = str(item["module"])
        total_ratio = float(item["inclusive_ratio_total"])
        baseline = median_or_zero(module_stats[group].get(module, []))
        if total_ratio >= module_threshold:
            warnings.append(f"模块 {module} 累计占比 {total_ratio:.1%}，超过绝对阈值 {module_threshold:.1%}。")
        if baseline > 0 and total_ratio >= max(0.02, baseline * peer_factor):
            warnings.append(f"模块 {module} 累计占比 {total_ratio:.1%}，约为同组中位数 {baseline:.1%} 的 {total_ratio / baseline:.1f} 倍。")
        if module == "overhead" and total_ratio >= overhead_threshold:
            warnings.append(f"parking链路中的通用开销占比 {total_ratio:.1%}，建议重点检查 IPC/日志/内存分配热点。")

    for item in report["top_functions"]:
        function_name = str(item["function"])
        total_ratio = float(item["exclusive_ratio_total"])
        baseline = median_or_zero(function_stats[group].get(function_name, []))
        if total_ratio >= function_threshold:
            warnings.append(f"函数 {function_name} 独占占比 {total_ratio:.1%}，超过绝对阈值 {function_threshold:.1%}。")
        if baseline > 0 and total_ratio >= max(0.01, baseline * peer_factor):
            warnings.append(f"函数 {function_name} 独占占比 {total_ratio:.1%}，约为同组中位数 {baseline:.1%} 的 {total_ratio / baseline:.1f} 倍。")

    deduped: List[str] = []
    seen = set()
    for warning in warnings:
        if warning not in seen:
            deduped.append(warning)
            seen.add(warning)
    return deduped
def run_analysis(
    file_paths: List[str],
    scene_group: str,
    scene_name: str,
    trace_id: str = "",
    top_n: int = 10,
    excel_paths: List[str] = None
) -> Dict[str, Any]:
    """
    分析单个场景（一组火焰图文件）的性能数据。
    file_paths: 同场景下的所有 .fold 文件路径
    scene_group: 场景组（如 APA）
    scene_name: 场景名（如 垂直泊车）
    trace_id: 可选，手动指定的 trace 编号（若提供，将覆盖 Excel 匹配结果）
    top_n: 显示前 N 个热点
    excel_paths: Excel 文件路径列表，用于解析元数据
    """
    # 1. 构建 PerfSample 列表（使用提供的 scene_group/scene_name）
    samples = []
    for path in file_paths:
        # 文件名作为 run 标识（取文件名不带扩展名）
        run = Path(path).stem
        samples.append(PerfSample(
            group=scene_group,
            scene=scene_name,
            run=run,
            path=Path(path)
        ))
    
    # 2. 调用原有分析函数（假设 analyze_scenario 返回单个场景的数据）
    # 注意：analyze_scenario 内部会统计所有 samples 的模块/函数热点
    result = analyze_scenario(samples, set(), top_n)
    
    # 3. 如果有 Excel 文件，解析并匹配元数据
    excel_matches = []
    if excel_paths:
        excel_index = build_excel_index([Path(p) for p in excel_paths])
        # 为当前场景寻找匹配的元数据
        # 使用 scene_aliases 函数（与前端一致）生成别名
        for alias in scene_aliases(scene_name) | scene_aliases(scene_group):
            matches = excel_index.get(alias, [])
            for meta in matches:
                # 去重（根据 source_file, sheet, scene_id）
                if not any(m.source_file == meta.source_file and m.sheet == meta.sheet and m.scene_id == meta.scene_id for m in excel_matches):
                    excel_matches.append(meta)
        # 如果手动指定了 trace_id，可以将其添加到 traces 列表中
        if trace_id and not any(trace_id in meta.traces for meta in excel_matches):
            # 可以选择将 trace_id 追加到第一个匹配的元数据中，或新建一个
            if excel_matches:
                excel_matches[0].traces.append(trace_id)
            else:
                # 创建一个虚拟的 Excel 元数据
                from analyze_parking_runtime import ExcelSceneMeta
                excel_matches.append(ExcelSceneMeta(
                    source_file="manual",
                    sheet="manual",
                    scene_id=scene_name,
                    title=scene_name,
                    summary=f"手动指定 trace: {trace_id}",
                    traces=[trace_id]
                ))
    
    # 4. 构建最终结果（单个场景）
    # 注意：analyze_scenario 返回的 result 结构可能不包含 scenarios 数组，
    # 而是直接包含模块/函数统计。需要根据实际情况调整。
    # 这里假设 result 已经包含了 total_samples, parking_samples, top_modules 等字段。
    # 我们将其包装成与 Dashboard 期望的格式一致：
    scenario_data = {
        "group": scene_group,
        "scene": scene_name,
        "files": file_paths,
        "total_samples": result.get("total_samples", 0),
        "parking_samples": result.get("parking_samples", 0),
        "parking_ratio": ratio(result.get("parking_samples", 0), result.get("total_samples", 1)),
        "module_inventory": list(result.get("module_inclusive", {}).keys()),
        "top_modules": result.get("top_modules", []),
        "top_functions": result.get("top_functions", []),
        "module_functions": result.get("module_functions", []),
        "warnings": [],  # 可以后续根据规则生成
        "excel_matches": [meta.__dict__ for meta in excel_matches],
        "run_summaries": result.get("run_summaries", []),
        "trace_ids": list(set(t for meta in excel_matches for t in meta.traces)),
        "trace_mapping_enabled": bool(excel_matches and len(result.get("run_summaries", [])) == len(set(t for meta in excel_matches for t in meta.traces))),
    }
    
    # 构建全局 stats（单场景时可为空，也可基于当前场景生成）
    global_stats = {
        "modules": [],
        "functions": []
    }
    
    return {
        "generated_at": datetime.now().isoformat(),
        "scenario_count": 1,
        "global_stats": global_stats,
        "scenarios": [scenario_data]
    }