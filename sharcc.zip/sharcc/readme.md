# V10 项目架构文档

## 1. 项目概述

V10 是一个 Python 命令行工具集，用于将汽车 ECU 参数标定数据（PDL/DCM/pmavardef）转换为 ParGen XML 格式。功能上对标 SHARCC（基于 Eclipse EMF 的 Java 桌面应用），将其核心逻辑用 Python 重新实现。

核心能力：
- **export** — 原始文件解析，生成中间 JSON 格式
- **generate** — 单车型 ParGen XML 生成
- **combine** — 多车型合并/拆分 XML 生成
- **add** — 车型变体的复制新增

## 2. 项目结构

```
v10/
├── __init__.py
├── __main__.py                  # python -m v10 入口
├── main.py                      # CLI 定义与子命令分发
│
├── export/                      # 阶段一：原始文件 → JSON
│   ├── configmaster_export.py       # PDL/DCM/pmavardef → JSON 转换
│   └── verify_configmaster.py       # 导出结果验证
│
├── generator/                   # 核心引擎
│   ├── models.py                    # 全局数据模型（dataclass）
│   ├── pdl_parser.py                # PDL 文件解析器
│   ├── dcm_parser.py                # DCM 文件解析器
│   ├── configmaster_loader.py       # JSON → 数据模型 加载器
│   ├── component.py                 # PDL Component/Cluster 索引构建
│   ├── quantization.py              # 物理值 ↔ 存储值 量化转换
│   ├── variant.py                   # 变体文件系统解析
│   ├── pmatarget.py                 # PMA Target / PID 配置
│   └── generator.py                 # ParGen XML 生成器（核心）
│
├── combine/                     # 多车型合并
│   └── combine_builder.py           # Combined / Non-combined 构建器
│
└── add/                         # 车型新增
    └── add_variant.py               # 复制车型 + 重命名引用
```

## 3. 软件架构

### 3.1 分层架构

```
┌─────────────────────────────────────────────────┐
│                   CLI 层                         │
│                  main.py                         │
│         argparse 子命令分发                       │
├─────────────────────────────────────────────────┤
│               业务逻辑层                          │
│  ┌───────────┐ ┌──────────────┐ ┌─────────────┐ │
│  │ generator  │ │combine_builder│ │ add_variant │ │
│  │  .py       │ │  .py          │ │  .py        │ │
│  └─────┬─────┘ └──────┬───────┘ └─────────────┘ │
│        │               │                          │
│        │    ┌──────────┘                          │
│        ▼    ▼                                     │
│  ┌─────────────────────────────────────┐          │
│  │         ParGenXmlGenerator          │          │
│  │  XML 结构构建 + 值转换 + 去重合并    │          │
│  └─────────────┬───────────────────────┘          │
├────────────────┼────────────────────────────────┤
│            基础设施层                              │
│  ┌─────────┐ ┌┴────────────┐ ┌───────────────┐  │
│  │component │ │quantization │ │variant        │  │
│  │索引构建   │ │量化计算      │ │变体解析       │  │
│  └─────────┘ └─────────────┘ └───────────────┘  │
│  ┌─────────────────────────────────────────────┐ │
│  │              models.py                       │ │
│  │         全局 dataclass 数据模型               │ │
│  └─────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────┤
│              数据加载层                            │
│  ┌───────────┐ ┌───────────┐ ┌────────────────┐ │
│  │pdl_parser  │ │dcm_parser │ │configmaster    │ │
│  │PDL 解析    │ │DCM 解析    │ │_loader JSON加载│ │
│  └───────────┘ └───────────┘ └────────────────┘ │
└─────────────────────────────────────────────────┘
```

### 3.2 数据流

```
原始文件                    中间格式 (JSON)                    输出
─────────                  ──────────────                    ─────

                         ┌─ variant.json ──┐
*.pmavardef ──export──▶  │                 │
                         │                 │
*.pdl ────── export──▶   ├─ model.json ────┼── generate ──▶ 单车型.xml
                         │                 │
*.dcm ────── export──▶   ├─ value/*.json ──┼── combine ───▶ 合并.xml / 拆分.xml
                         │                 │
                         └─────────────────┼── add ───────▶ 更新后的 variant.json
                                                            + 复制的 value.json
```

## 4. 数据模型

### 4.1 变体层级（pmavardef / variant.json）

```
VariantDefinition
├── all_major_variant_dcms: List[str]     # 所有车型共享的 DCM
└── major_variants: List[MajorVariant]
    └── MajorVariant                       # 车型（如 ASIC_MCHG）
        ├── common_dcm_files: List[str]    # 该车型的公共 DCM
        └── modules: List[VariantModule]
            └── VariantModule              # 模块
                └── minor_variants: List[MinorVariant]
                    └── MinorVariant       # 小变体
                        └── sub_variants: List[SubVariant]
                            └── SubVariant # 子变体
                                └── dcm_files: List[str]
```

### 4.2 参数定义（PDL）

```
PdlPackage                              # 一个 .pdl 包
├── classes: List[PdlClass]             # 参数类（= Cluster）
│   └── PdlClass
│       └── parameters: List[PdlParameter]
│           └── PdlParameter
│               ├── type_name / type_kind
│               ├── init_expression      # 默认值表达式
│               ├── quantization_ref     # 量化引用
│               └── is_virtual / is_constant / is_protected
├── enumerations: List[PdlEnumeration]
├── quantizations: List[PdlQuantization]
│   └── factor_text / factor_value       # 量化因子
├── units: List[PdlUnit]
├── custom_types: List[PdlCustomType]    # 自定义类型（范围、基类型）
├── memory_defs: List[PdlMemoryDef]      # ROM / NVM 分配
├── exported_parameters / exported_constants
└── source_dir
```

### 4.3 参数值（DCM / value.json）

```
DcmParameter
├── name: str         # 全限定名（如 rbp.vmc.apg.APG_Abort.VeloAbort）
├── kind: str         # FESTWERT | FESTWERTEBLOCK | KENNLINIE | KENNFELD
├── values: List[str] # 标定值
├── x_axis / y_axis   # 曲线/特性图的轴
└── size_x / size_y   # 维度
```

### 4.4 数据在内存中的索引结构

`PdlComponentBuilder` 从 `PdlPackage` 列表构建以下索引：

| 索引 | 键 | 值 | 用途 |
|------|----|----|------|
| `cluster_to_component` | Cluster 名 | Component 名 | Cluster → 所属组件 |
| `cluster_to_pdlclass` | Cluster 名 | PdlClass | Cluster → 参数定义 |
| `cluster_to_package` | Cluster 名 | Package 名 | Cluster → 包名（用于 FQN 匹配） |
| `cluster_to_memory` | Cluster 名 | ROM/NVM | 内存类型 |
| `all_quantizations` | 名称 | PdlQuantization | 全局量化表 |
| `all_enumerations` | 名称 | PdlEnumeration | 全局枚举表 |
| `all_custom_types` | 名称 | PdlCustomType | 全局自定义类型表 |
| `param_name_to_alias` | 参数名 | 别名 | 参数别名映射 |

## 5. 核心模块技术细节

### 5.1 ParGenXmlGenerator（generator.py）

XML 生成的核心类，负责构建完整的 ParGen ParameterSet XML。

**生成的 XML 结构：**

```xml
<ParameterSet>
  <Info>                          <!-- 版本号 + 时间戳 -->
  <Constants>                     <!-- PDL 导出常量 -->
  <DataTypes>                     <!-- 枚举、量化、自定义类型定义 -->
  <MajorVariantList>              <!-- 车型列表 -->
  <ComponentList>                 <!-- 组件 → Cluster → 参数 -->
    <Component>
      <ParameterCluster>
        <Define>                  <!-- 参数元数据 -->
        <VariantImplementationList>
          <VariantImplementation> <!-- 每个车型的参数值 -->
            <MajorVariant>
            <MinorVariant>
              <SubVariant>
                <Parameter value="..."/>
```

**关键算法：**

**值转换管线** (`_convert_values`):
```
DCM 原始字符串
    │
    ├── 文本类型 → 直接输出
    ├── 逻辑类型 → true/false → 1/0
    ├── 枚举类型 → 枚举名 → 整数值
    ├── 有量化公式 → storage = round_half_up(physical × factor)
    ├── 全局量化公式 → 同上
    └── 无量化 → float32 格式化 或 取整
```

**表达式求值** (`_eval_expression`):
- 支持 PDL 三元表达式 `(a > b) ? x : y`
- 运算符优先级解析
- 跨 Cluster 上下文引用（同一 minor/sub 下其他 Cluster 的值）

**VariantImplementation 去重** (`_compare_vi_trees`):
- 对同一 Cluster，比较多个车型的 minor/sub/value 树
- 结构和值完全一致的 VariantImplementation 合并为一个，MajorVariantList 包含多个车型名
- 对应 SHARCC 的 writeOptimizedVariantImplementation 逻辑

**DCM 索引与包匹配**:
- `dcm_by_cluster`: DCM 参数按 Cluster 分组
- `dcm_by_short_name`: 按短名索引（用于表达式引用）
- FQN 包前缀必须匹配 PDL `cluster_to_package`，避免跨包同名冲突

### 5.2 QuantizationConverter（quantization.py）

物理值到存储值的转换：

```
storage = round_half_up(Decimal(physical_str) × factor_value)
```

- 使用 Python `Decimal` 类型，避免浮点精度问题
- `ROUND_HALF_UP` 舍入策略（四舍五入），与 SHARCC Java 行为一致
- `get_resolution()` 返回 `1 / factor`，用于 XML DataTypes 定义

### 5.3 PdlComponentBuilder（component.py）

从 `List[PdlPackage]` 构建全局索引：

- 包名到组件名的映射遵循 Java 命名规则（`rbp.vmc.apg` → `APG`）
- 合并所有包中的量化、枚举、自定义类型、单位到全局表
- 构建 Cluster → Component 映射（一个 Component 包含多个 Cluster）
- 提取导出参数和常量

### 5.4 ConfigMasterLoader（configmaster_loader.py）

从 JSON 文件重建内存数据模型：

| JSON 文件 | 重建对象 | 说明 |
|-----------|---------|------|
| `variant.json` | `VariantDefinition` | 解析 `modules.vehicle.options` 中的层级结构 |
| `value/*.value.json` | `Dict[str, List[DcmParameter]]` | JSON 值 → DcmParameter，自动推断 kind |
| `model.json` | `List[PdlPackage]` + 全局类型表 | 重建 PDL 元数据，供 PdlComponentBuilder 使用 |

**value.json 值推断规则：**
- 标量数字 → `FESTWERT`
- 数字列表 → `FESTWERTEBLOCK`
- 含 `values` + `x_axis` 的对象 → `KENNLINIE` 或 `KENNFELD`

### 5.5 CombineBuilder（combine_builder.py）

多车型 XML 构建器，两种模式：

| 模式 | 输入 | 输出 | MajorVariantList |
|------|------|------|----------------|
| Combined | N 个车型 | 1 个 XML | 包含所有 N 个车型名 |
| Non-combined | N 个车型 | N 个 XML | 每个文件只含 1 个车型名 |

**Combined 模式实现：**
1. 第一个车型作为 primary，其余作为 `related_variants`
2. 每个车型独立解析 DCM 数据
3. 传入 `ParGenXmlGenerator`，由其内部的 `_compare_vi_trees` 处理去重合并

**ConfigMasterVariantResolver：**
- `variant.json` 的内存解析器
- `resolve_dcm_data(name)` — 收集该车型引用的所有 value.json 数据
- `collect_dcm_names_for_variant(mv)` — 收集该车型所有 DCM stem 名

### 5.6 Export（configmaster_export.py）

四阶段导出流程：

| 阶段 | 输入 | 输出 | 核心类/函数 |
|------|------|------|-----------|
| 1. parameter.json | PDL 文件 | `parameter/*.parameter.json` | `PdlComponentBuilder` + `generate_parameter_json` |
| 2. value.json | DCM 文件 | `value/*.value.json` | `DcmParser` + `generate_value_json` |
| 3. variant.json | pmavardef | `variant.json` | `PmaVardefParser` + `generate_variant_json` |
| 4. model.json | PDL 元数据 | `model.json` | `generate_model_json` |

### 5.7 AddVariant（add_variant.py）

车型复制流程：

1. 解析 `variant.json` 中 `modules.vehicle.options[SOURCE]`
2. 深拷贝整个 JSON 子树
3. 用正则 `(?<=_)OLD_SHORT(?=_|\b)` 重命名所有 value.json 文件引用
4. 将新条目写入 `modules.vehicle.options[NEW_NAME]`
5. （可选）复制对应的 value.json 物理文件并重命名

## 6. 模块依赖关系

```
main.py
 ├──▶ generator/configmaster_loader.py ──▶ generator/models.py
 │                                     ──▶ generator/component.py
 ├──▶ generator/component.py ──▶ generator/models.py
 ├──▶ generator/quantization.py ──▶ generator/models.py
 ├──▶ generator/generator.py ──▶ generator/models.py
 │                            ──▶ generator/component.py
 │                            ──▶ generator/quantization.py
 │                            ──▶ generator/variant.py
 ├──▶ combine/combine_builder.py ──▶ generator/generator.py
 │                                ──▶ generator/configmaster_loader.py
 │                                ──▶ generator/component.py
 │                                ──▶ generator/quantization.py
 │                                ──▶ generator/models.py
 ├──▶ export/configmaster_export.py ──▶ v7/（外部依赖）
 └──▶ add/add_variant.py（无内部依赖，仅 stdlib）
```

## 7. 与 SHARCC 的对应关系

| SHARCC (Java) | V10 (Python) | 说明 |
|---------------|-------------|------|
| `IVariantsFactory` / EMF | `models.py` dataclass | 数据模型 |
| `VariantsSwitch` (Visitor) | `VariantResolver` / `ConfigMasterVariantResolver` | 变体遍历 |
| `PdlComponentBuilder` | `component.py` `PdlComponentBuilder` | 同名，逻辑一致 |
| `QuantizationConverter` | `quantization.py` `QuantizationConverter` | Decimal HALF_UP |
| `ParGenXmlGenerator` | `generator.py` `ParGenXmlGenerator` | 同名，核心生成 |
| `BuildParGenXMLOperation` | `combine_builder.py` `CombineBuilder` | 合并/拆分逻辑 |
| `VariantImplementationCreator` | `generator.py` `_add_variant_impl_pdl` | VI 构建 + 去重 |
| `writeOptimizedVariantImplementation` | `generator.py` `_compare_vi_trees` | 相同 VI 合并 |
| pmavardef XML 解析 | `export/configmaster_export.py` → `variant.json` | 转为 JSON 中间格式 |

## 8. 技术栈

| 技术 | 用途 |
|------|------|
| Python 3.9+ | 运行时 |
| `dataclasses` | 数据模型定义 |
| `xml.etree.ElementTree` | XML 构建 |
| `xml.dom.minidom` | XML 格式化输出 |
| `decimal.Decimal` | 高精度量化计算 |
| `argparse` | CLI 参数解析 |
| `json` | JSON 读写 |
| `re` | 正则匹配（文件引用重命名、表达式解析） |
| `pathlib` | 文件路径处理 |

无第三方依赖，仅使用 Python 标准库。
