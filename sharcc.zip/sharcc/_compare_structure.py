"""Compare XML structure between single, combined, and split outputs."""
import xml.etree.ElementTree as ET
import sys


def describe_xml(path):
    tree = ET.parse(path)
    root = tree.getroot()

    info = {
        "root_tag": root.tag,
        "top_children": [c.tag for c in root],
        "major_variants": [],
        "num_components": 0,
        "num_clusters": 0,
        "num_vi_blocks": 0,
        "num_constants": 0,
        "num_datatypes": 0,
    }

    mvl = root.find("MajorVariantList")
    if mvl is not None:
        info["major_variants"] = [m.text for m in mvl.findall("MajorVariant")]

    constants = root.find("Constants")
    if constants is not None:
        info["num_constants"] = len(constants.findall("Constant"))

    dt = root.find("DataTypes")
    if dt is not None:
        info["num_datatypes"] = len(list(dt))

    cl = root.find("ComponentList")
    if cl is not None:
        comps = cl.findall("Component")
        info["num_components"] = len(comps)
        total_clusters = 0
        total_vi = 0
        for comp in comps:
            pcl = comp.find("ParameterClusterList")
            if pcl is not None:
                clusters = pcl.findall("ParameterCluster")
                total_clusters += len(clusters)
                for pc in clusters:
                    vil = pc.find("VariantImlementationList")
                    if vil is not None:
                        total_vi += len(vil.findall("VariantImlementation"))
        info["num_clusters"] = total_clusters
        info["num_vi_blocks"] = total_vi

    return info


def print_info(label, path):
    info = describe_xml(path)
    print(f"\n{'='*60}")
    print(f"  {label}: {path}")
    print(f"{'='*60}")
    print(f"  Root tag:        {info['root_tag']}")
    print(f"  Top children:    {info['top_children']}")
    print(f"  MajorVariants:   {info['major_variants']}")
    print(f"  Constants:       {info['num_constants']}")
    print(f"  DataTypes:       {info['num_datatypes']}")
    print(f"  Components:      {info['num_components']}")
    print(f"  Clusters:        {info['num_clusters']}")
    print(f"  VI blocks:       {info['num_vi_blocks']}")


files = [
    ("Single (MCHG only)", "test_single.xml"),
    ("Combined (MCHG+HXHW)", "test_combined.xml"),
    ("Split - MCHG", "test_split__ASIC_MCHG.xml"),
    ("Split - HXHW", "test_split__ASIC_HXHW.xml"),
]

for label, path in files:
    try:
        print_info(label, path)
    except Exception as e:
        print(f"\n  ERROR loading {path}: {e}")
