"""Deep compare between SHARCC reference XML and v10 combined XML."""
import xml.etree.ElementTree as ET
import sys
from collections import OrderedDict


def parse_structure(path):
    """Parse XML and extract full structural info."""
    tree = ET.parse(path)
    root = tree.getroot()
    info = {}

    # Top-level
    info["root_tag"] = root.tag
    info["top_children"] = [c.tag for c in root]

    # MajorVariantList
    mvl = root.find("MajorVariantList")
    info["major_variants"] = sorted([m.text for m in mvl.findall("MajorVariant")]) if mvl is not None else []

    # Constants
    constants = root.find("Constants")
    info["constants"] = []
    if constants is not None:
        for c in constants.findall("Constant"):
            info["constants"].append({
                "name": c.findtext("Name", ""),
                "value": c.findtext("Value", ""),
            })

    # DataTypes
    dt = root.find("DataTypes")
    info["datatypes_count"] = len(list(dt)) if dt is not None else 0
    info["datatype_names"] = sorted([child.findtext("Name", "") for child in dt]) if dt is not None else []

    # Components
    cl = root.find("ComponentList")
    info["components"] = OrderedDict()
    if cl is not None:
        for comp in cl.findall("Component"):
            comp_name = comp.findtext("Name", "")
            comp_info = {"clusters": OrderedDict(), "defines": []}

            dl = comp.find("DefineList")
            if dl is not None:
                for d in dl.findall("Define"):
                    comp_info["defines"].append(d.findtext("Name", ""))

            pcl = comp.find("ParameterClusterList")
            if pcl is not None:
                for pc in pcl.findall("ParameterCluster"):
                    cl_name = pc.findtext("Name", "")
                    cl_info = {
                        "memory": pc.findtext("MemoryArea", ""),
                        "variant_app": pc.findtext("VariantApplication", ""),
                        "pid": pc.findtext("PID", ""),
                        "param_count": 0,
                        "vi_count": 0,
                        "vi_majors": [],
                    }

                    pdl = pc.find("ParameterDefinitionList")
                    if pdl is not None:
                        cl_info["param_count"] = len(pdl.findall("ParameterDefinition"))

                    vil = pc.find("VariantImlementationList")
                    if vil is not None:
                        vis = vil.findall("VariantImlementation")
                        cl_info["vi_count"] = len(vis)
                        for vi in vis:
                            mvl2 = vi.find("MajorVariantList")
                            if mvl2 is not None:
                                names = sorted([m.text for m in mvl2.findall("MajorVariant")])
                                cl_info["vi_majors"].append(names)

                    comp_info["clusters"][cl_name] = cl_info
            info["components"][comp_name] = comp_info

    return info


def compare(ref_path, v10_path):
    print(f"\nReference: {ref_path}")
    print(f"V10:       {v10_path}\n")

    ref = parse_structure(ref_path)
    v10 = parse_structure(v10_path)

    # Basic structure
    print("=" * 70)
    print("  BASIC STRUCTURE")
    print("=" * 70)
    for key in ["root_tag", "top_children", "major_variants"]:
        r, v = ref[key], v10[key]
        status = "OK" if r == v else "DIFF"
        print(f"  [{status}] {key}: ref={r}  v10={v}")

    # Constants
    print(f"\n  Constants: ref={len(ref['constants'])}  v10={len(v10['constants'])}")
    for rc in ref["constants"]:
        vc = next((c for c in v10["constants"] if c["name"] == rc["name"]), None)
        if vc:
            if rc["value"] != vc["value"]:
                print(f"    DIFF value: {rc['name']}: ref={rc['value']} v10={vc['value']}")
        else:
            print(f"    MISSING in v10: {rc['name']}")

    # DataTypes
    print(f"\n  DataTypes: ref={ref['datatypes_count']}  v10={v10['datatypes_count']}")
    ref_dt = set(ref["datatype_names"])
    v10_dt = set(v10["datatype_names"])
    if ref_dt != v10_dt:
        only_ref = ref_dt - v10_dt
        only_v10 = v10_dt - ref_dt
        if only_ref:
            print(f"    Only in ref ({len(only_ref)}): {sorted(only_ref)[:10]}...")
        if only_v10:
            print(f"    Only in v10 ({len(only_v10)}): {sorted(only_v10)[:10]}...")
    else:
        print(f"    [OK] All {ref['datatypes_count']} types match")

    # Components
    print(f"\n{'='*70}")
    print("  COMPONENTS")
    print(f"{'='*70}")
    ref_comps = set(ref["components"].keys())
    v10_comps = set(v10["components"].keys())
    print(f"  Components: ref={len(ref_comps)}  v10={len(v10_comps)}")

    only_ref_c = ref_comps - v10_comps
    only_v10_c = v10_comps - ref_comps
    if only_ref_c:
        print(f"    Only in ref: {sorted(only_ref_c)}")
    if only_v10_c:
        print(f"    Only in v10: {sorted(only_v10_c)}")

    # Per-component cluster comparison
    diff_clusters = []
    common_comps = sorted(ref_comps & v10_comps)
    total_clusters_ref = 0
    total_clusters_v10 = 0
    total_vi_ref = 0
    total_vi_v10 = 0

    for comp_name in common_comps:
        rc = ref["components"][comp_name]
        vc = v10["components"][comp_name]

        ref_cls = set(rc["clusters"].keys())
        v10_cls = set(vc["clusters"].keys())
        total_clusters_ref += len(ref_cls)
        total_clusters_v10 += len(v10_cls)

        only_ref_cl = ref_cls - v10_cls
        only_v10_cl = v10_cls - ref_cls
        if only_ref_cl or only_v10_cl:
            diff_clusters.append((comp_name, only_ref_cl, only_v10_cl))

        for cl_name in sorted(ref_cls & v10_cls):
            rcl = rc["clusters"][cl_name]
            vcl = vc["clusters"][cl_name]
            total_vi_ref += rcl["vi_count"]
            total_vi_v10 += vcl["vi_count"]

            diffs = []
            if rcl["param_count"] != vcl["param_count"]:
                diffs.append(f"params: {rcl['param_count']} vs {vcl['param_count']}")
            if rcl["vi_count"] != vcl["vi_count"]:
                diffs.append(f"VI blocks: {rcl['vi_count']} vs {vcl['vi_count']}")
            if rcl["memory"] != vcl["memory"]:
                diffs.append(f"memory: {rcl['memory']} vs {vcl['memory']}")
            if rcl["variant_app"] != vcl["variant_app"]:
                diffs.append(f"varApp: {rcl['variant_app']} vs {vcl['variant_app']}")

            # Compare VI major variant assignments
            ref_vi_sorted = sorted([tuple(x) for x in rcl["vi_majors"]])
            v10_vi_sorted = sorted([tuple(x) for x in vcl["vi_majors"]])
            if ref_vi_sorted != v10_vi_sorted:
                diffs.append(f"VI majors: ref={ref_vi_sorted} v10={v10_vi_sorted}")

            if diffs:
                print(f"\n  [{comp_name}/{cl_name}]")
                for d in diffs:
                    print(f"    {d}")

    print(f"\n{'='*70}")
    print("  SUMMARY")
    print(f"{'='*70}")
    print(f"  Components:  ref={len(ref_comps)}  v10={len(v10_comps)}")
    print(f"  Clusters:    ref={total_clusters_ref}  v10={total_clusters_v10}")
    print(f"  VI blocks:   ref={total_vi_ref}  v10={total_vi_v10}")

    if diff_clusters:
        print(f"\n  Cluster mismatches:")
        for comp, only_r, only_v in diff_clusters:
            if only_r:
                print(f"    {comp}: only in ref: {sorted(only_r)}")
            if only_v:
                print(f"    {comp}: only in v10: {sorted(only_v)}")

    if (ref_comps == v10_comps and total_clusters_ref == total_clusters_v10
        and not diff_clusters):
        print(f"\n  Structure match: PASS")
    else:
        print(f"\n  Structure match: DIFFERENCES FOUND")


if __name__ == "__main__":
    ref = sys.argv[1] if len(sys.argv) > 1 else "SYS/RB_SIP/APPL/test__BYD_2WS_AIHC__multiVariants.xml"
    v10 = sys.argv[2] if len(sys.argv) > 2 else "test_combined.xml"
    compare(ref, v10)
