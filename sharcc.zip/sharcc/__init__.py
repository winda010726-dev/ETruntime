"""v10 - Unified ParGen XML module with combine support."""
