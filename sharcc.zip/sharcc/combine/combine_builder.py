"""Combined / non-combined multi-variant XML builder.

Mirrors SHARCC's BuildParGenXMLOperation:
  - Combined mode:   N variants -> 1 XML (MajorVariantList contains all names)
  - Non-combined:    N variants -> N XMLs (each file contains 1 variant)
  - Optimize option: merge VariantImplementations with identical minor/sub trees
"""

import os
import xml.etree.ElementTree as ET
from typing import Dict, List, Optional, Set, Tuple

from ..generator.models import DcmParameter, MajorVariant, VariantDefinition
from ..generator.component import PdlComponentBuilder
from ..generator.quantization import QuantizationConverter
from ..generator.generator import ParGenXmlGenerator
from ..generator.configmaster_loader import (
    load_variant_json, load_all_value_json, load_model_json,
)


class ConfigMasterVariantResolver:
    """Resolves variant data from pre-loaded ConfigMaster JSON."""

    def __init__(self, vardef: VariantDefinition, all_dcm_data: Dict[str, List[DcmParameter]]):
        self.vardef = vardef
        self.all_dcm_data = all_dcm_data

    def get_major_variant_names(self) -> List[str]:
        return [mv.name for mv in self.vardef.major_variants]

    def resolve_variant_tree(self, name: str) -> Optional[MajorVariant]:
        for mv in self.vardef.major_variants:
            if mv.name == name:
                return mv
        return None

    def resolve_dcm_data(self, major_variant_name: str) -> Dict[str, List[DcmParameter]]:
        dcm_names = list(self.vardef.all_major_variant_dcms)
        mv = self.resolve_variant_tree(major_variant_name)
        if mv:
            dcm_names.extend(mv.common_dcm_files)
            for mod in mv.modules:
                for minor in mod.minor_variants:
                    for sub in minor.sub_variants:
                        dcm_names.extend(sub.dcm_files)
        result = {}
        for dcm_name in dcm_names:
            stem = os.path.splitext(dcm_name)[0]
            if stem in self.all_dcm_data:
                result[stem] = self.all_dcm_data[stem]
        return result

    def collect_dcm_names_for_variant(self, mv: MajorVariant) -> Set[str]:
        stems: Set[str] = set()
        for dcm in self.vardef.all_major_variant_dcms:
            stems.add(os.path.splitext(dcm)[0])
        for dcm in mv.common_dcm_files:
            stems.add(os.path.splitext(dcm)[0])
        for mod in mv.modules:
            for minor in mod.minor_variants:
                for sub in minor.sub_variants:
                    for dcm in sub.dcm_files:
                        stems.add(os.path.splitext(dcm)[0])
        return stems


class CombineBuilder:
    """Build ParGen XML for multiple variants (combined or split mode).

    Combined mode (SHARCC isCombinedXMLToBeGenerated=true):
      All selected variants in one XML file.
      MajorVariantList lists all variant names.
      Each ParameterCluster contains VariantImplementation blocks for all variants.

    Non-combined mode (SHARCC isCombinedXMLToBeGenerated=false):
      Each variant gets its own XML file.
      MajorVariantList contains only that variant's name.

    Optimize mode (SHARCC writeOptimizedVariantImplementation):
      When two variants produce identical minor/sub/value trees for a cluster,
      they share one VariantImplementation with multiple MajorVariant names.
      This is already implemented in ParGenXmlGenerator._compare_vi_trees.
    """

    def __init__(
        self,
        configmaster_dir: str,
        variant_names: List[str],
        combined: bool = True,
        optimize: bool = False,
        scan_all_dcm: bool = False,
        component_map: Optional[Dict[str, str]] = None,
        float32_enabled: bool = True,
    ):
        self.cm_dir = configmaster_dir
        self.variant_names = variant_names
        self.combined = combined
        self.optimize = optimize
        self.scan_all_dcm = scan_all_dcm
        self.component_map = component_map or {}
        self.float32_enabled = float32_enabled

        self.vardef: Optional[VariantDefinition] = None
        self.all_dcm_data: Dict[str, List[DcmParameter]] = {}
        self.pdl_builder: Optional[PdlComponentBuilder] = None
        self.qconv: Optional[QuantizationConverter] = None
        self.global_types_map: Dict = {}
        self.global_enums_map: Dict = {}
        self.global_quant_formulas: Dict = {}

    def load(self) -> None:
        """Load all input data (variant.json, value/, model.json)."""
        variant_path = os.path.join(self.cm_dir, "variant.json")
        value_dir = os.path.join(self.cm_dir, "value")
        model_path = os.path.join(self.cm_dir, "model.json")

        print(f"\n[1/4] Loading variant.json: {variant_path}")
        self.vardef = load_variant_json(variant_path)
        available = [mv.name for mv in self.vardef.major_variants]
        print(f"  Found {len(available)} vehicle model(s)")

        for vn in self.variant_names:
            if vn not in available:
                raise ValueError(f"Variant '{vn}' not found. Available: {available[:5]}...")

        print(f"\n[2/4] Loading model.json: {model_path}")
        if os.path.isfile(model_path):
            pdl_packages, self.global_types_map, self.global_enums_map, self.global_quant_formulas = (
                load_model_json(model_path)
            )
            if pdl_packages:
                self.pdl_builder = PdlComponentBuilder(pdl_packages, component_map=self.component_map)
                self.qconv = QuantizationConverter(self.pdl_builder.all_quantizations)
                print(f"  Components: {len(self.pdl_builder.get_component_names())}")
        else:
            print("  [WARN] model.json not found, proceeding without PDL data.")

        print(f"\n[3/4] Loading value.json files from: {value_dir}")
        self.all_dcm_data = load_all_value_json(value_dir)
        print(f"  Total value.json files loaded: {len(self.all_dcm_data)}")

    def build_combined(self, output_path: str) -> str:
        """Build one combined XML for all selected variants.

        The primary variant is the first in the list; the rest are treated
        as "related variants" and fed into ParGenXmlGenerator, which already
        supports multi-variant MajorVariantList and duplicate merging.
        """
        resolver = ConfigMasterVariantResolver(self.vardef, self.all_dcm_data)

        primary = self.variant_names[0]
        rest = self.variant_names[1:]

        mv = resolver.resolve_variant_tree(primary)
        dcm_data = resolver.resolve_dcm_data(primary)
        mapped_stems = resolver.collect_dcm_names_for_variant(mv) if mv else set()

        if self.scan_all_dcm:
            dcm_data = self._apply_scan_all(dcm_data, resolver, mv)

        related_variants: List[Tuple[str, MajorVariant, Dict]] = []
        for rv_name in rest:
            rv_mv = resolver.resolve_variant_tree(rv_name)
            rv_dcm_data = resolver.resolve_dcm_data(rv_name)
            if self.scan_all_dcm:
                rv_dcm_data = self._apply_scan_all(rv_dcm_data, resolver, rv_mv)
            rv_mapped = resolver.collect_dcm_names_for_variant(rv_mv) if rv_mv else set()
            mapped_stems.update(rv_mapped)
            related_variants.append((rv_name, rv_mv, rv_dcm_data))

        generator = ParGenXmlGenerator(
            major_variant_name=primary,
            major_variant=mv,
            vardef=self.vardef,
            dcm_data=dcm_data,
            pdl_builder=self.pdl_builder,
            quant_converter=self.qconv,
            global_types_map=self.global_types_map,
            global_enums_map=self.global_enums_map,
            global_quant_formulas=self.global_quant_formulas,
            related_variants=related_variants,
            mapped_dcm_stems=mapped_stems,
            float32_enabled=self.float32_enabled,
        )

        xml_str = generator.generate()
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(xml_str)

        return output_path

    def build_split(self, output_path: str) -> List[str]:
        """Build one XML per variant (non-combined mode).

        Each file is named: <base>__<VariantName>.xml
        (matching SHARCC's naming convention).
        """
        resolver = ConfigMasterVariantResolver(self.vardef, self.all_dcm_data)

        base, ext = os.path.splitext(output_path)
        if not ext:
            ext = ".xml"

        output_files = []
        for vn in self.variant_names:
            mv = resolver.resolve_variant_tree(vn)
            dcm_data = resolver.resolve_dcm_data(vn)
            mapped_stems = resolver.collect_dcm_names_for_variant(mv) if mv else set()

            if self.scan_all_dcm:
                dcm_data = self._apply_scan_all(dcm_data, resolver, mv)

            generator = ParGenXmlGenerator(
                major_variant_name=vn,
                major_variant=mv,
                vardef=self.vardef,
                dcm_data=dcm_data,
                pdl_builder=self.pdl_builder,
                quant_converter=self.qconv,
                global_types_map=self.global_types_map,
                global_enums_map=self.global_enums_map,
                global_quant_formulas=self.global_quant_formulas,
                related_variants=[],
                mapped_dcm_stems=mapped_stems,
                float32_enabled=self.float32_enabled,
            )

            xml_str = generator.generate()
            file_path = f"{base}__{vn}{ext}"
            os.makedirs(os.path.dirname(os.path.abspath(file_path)), exist_ok=True)
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(xml_str)

            output_files.append(file_path)

        return output_files

    def build(self, output_path: str) -> List[str]:
        """Build XMLs based on mode (combined/non-combined).

        Returns list of generated file paths.
        """
        print(f"\n[4/4] Generating XML ({'combined' if self.combined else 'non-combined'} mode)")
        print(f"  Variants: {', '.join(self.variant_names)}")

        if self.combined or len(self.variant_names) == 1:
            result = self.build_combined(output_path)
            print(f"\n  Generated: {result}")
            return [result]
        else:
            results = self.build_split(output_path)
            for r in results:
                print(f"  Generated: {r}")
            return results

    def _apply_scan_all(
        self,
        dcm_data: Dict[str, List[DcmParameter]],
        resolver: ConfigMasterVariantResolver,
        mv: Optional[MajorVariant],
    ) -> Dict[str, List[DcmParameter]]:
        """Add all value.json data and re-prioritize variant-specific ones."""
        already = set(dcm_data.keys())
        for stem, params in self.all_dcm_data.items():
            if stem not in already:
                dcm_data[stem] = params

        vardef_stems = set()
        for dcm in self.vardef.all_major_variant_dcms:
            vardef_stems.add(os.path.splitext(dcm)[0])
        if mv:
            for dcm in mv.common_dcm_files:
                vardef_stems.add(os.path.splitext(dcm)[0])
            for mod in mv.modules:
                for minor in mod.minor_variants:
                    for sub in minor.sub_variants:
                        for dcm in sub.dcm_files:
                            vardef_stems.add(os.path.splitext(dcm)[0])

        priority = {s: dcm_data[s] for s in vardef_stems if s in dcm_data}
        for s in priority:
            del dcm_data[s]
        dcm_data.update(priority)

        return dcm_data
