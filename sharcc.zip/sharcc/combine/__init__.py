"""Combined / non-combined multi-variant XML generation."""
