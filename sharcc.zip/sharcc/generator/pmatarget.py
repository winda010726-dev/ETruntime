"""Parser for .pmatarget files and Fee_Cfg.c PID configuration."""

import os
import re
from typing import Dict, List, Optional, Tuple


class PmaTarget:
    """Parsed representation of a .pmatarget file."""

    def __init__(self, name: str, dcm_list: List[str], build_target: str = ""):
        self.name = name
        self.dcm_list = dcm_list
        self.build_target = build_target


def parse_fee_cfg(path: str) -> Dict[str, int]:
    """Parse Fee_Cfg.c to extract ParameterCluster PID mappings.

    Scans for the header line containing 'FeeRbBlockPersistentId', then
    parses each subsequent row:  { 0xPID , ... } /* ClusterName */
    Returns {cluster_name: pid_decimal}.
    """
    pid_map: Dict[str, int] = {}
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except OSError:
        return pid_map

    in_block = False
    for line in lines:
        if not in_block:
            if "FeeRbBlockPersistentId" in line:
                in_block = True
            continue
        if "};" in line and "{" not in line:
            break
        m = re.search(
            r"\{\s*(0x[0-9A-Fa-f]+)\s*,.*?\}\s*/\*\s*(\S+)\s*\*/",
            line,
        )
        if m:
            pid_hex = m.group(1)
            cluster_name = m.group(2)
            pid_map[cluster_name] = int(pid_hex, 16)
    return pid_map


def parse_fee_cfg_with_blocklength(path: str) -> Dict[str, Tuple[int, int]]:
    """Parse Fee_Cfg.c to extract PID and block length for each cluster.

    Returns {cluster_name: (pid_decimal, block_length_bytes)}.
    Java validates that the cluster byte size matches block_length;
    on mismatch it sets PID to null.
    """
    result: Dict[str, Tuple[int, int]] = {}
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except OSError:
        return result

    in_block = False
    for line in lines:
        if not in_block:
            if "FeeRbBlockPersistentId" in line:
                in_block = True
            continue
        if "};" in line and "{" not in line:
            break
        comments = re.findall(r"/\*\s*(.*?)\s*\*/", line)
        if len(comments) < 2:
            continue
        cluster_name = comments[-1].strip()
        stripped = re.sub(r"/\*(?:.|[\n\r])*?\*/", "", line)
        brace_m = re.search(r"\{(.+?)\}", stripped)
        if not brace_m:
            continue
        fields = [f.strip() for f in brace_m.group(1).split(",")]
        if len(fields) >= 3:
            try:
                pid = int(fields[0], 16) if fields[0].startswith("0x") else 0
                blk = int(fields[2], 16) if fields[2].startswith("0x") else 0
                result[cluster_name] = (pid, blk)
            except ValueError:
                pass
    return result


def find_fee_cfg(project_root: str, build_target: str) -> Optional[str]:
    """Locate Fee_Cfg.c matching the build target folder name."""
    import glob
    for path in glob.glob(os.path.join(project_root, "**", "Fee_Cfg.c"), recursive=True):
        parts = path.replace("\\", "/").split("/")
        if build_target in parts:
            return path
    return None


def parse_pmatarget(path: str) -> PmaTarget:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()

    name_m = re.search(r"target\s+(\S+)\s*;", text)
    name = name_m.group(1) if name_m else ""

    dcm_list: List[str] = []
    dcm_m = re.search(r"DCMList\s+is\s*\{([^}]*)\}", text, re.DOTALL)
    if dcm_m:
        body = dcm_m.group(1)
        for item in body.split(","):
            item = item.strip()
            if item:
                dcm_list.append(item)

    bt_m = re.search(r"BuildTarget\s+is\s+(\S+)", text)
    build_target = bt_m.group(1) if bt_m else ""

    return PmaTarget(name=name, dcm_list=dcm_list, build_target=build_target)


def find_pmatarget_file(dcm_root: str, target_name: str) -> Optional[str]:
    """Find .pmatarget file by target name (searches inside the target for matching name)."""
    import glob
    for path in glob.glob(os.path.join(dcm_root, "**", "*.pmatarget"), recursive=True):
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                text = f.read(500)
            m = re.search(r"target\s+(\S+)\s*;", text)
            if m and m.group(1) == target_name:
                return path
        except OSError:
            continue
    return None


def resolve_switch_dcm_paths(
    pmatarget: PmaTarget, dcm_root: str
) -> List[str]:
    """Resolve DCM file names from pmatarget to actual file paths."""
    import glob
    all_dcm_files: Dict[str, str] = {}
    for path in glob.glob(os.path.join(dcm_root, "**", "*.dcm"), recursive=True):
        fname = os.path.basename(path)
        all_dcm_files[fname] = path

    resolved: List[str] = []
    for dcm_name in pmatarget.dcm_list:
        if dcm_name in all_dcm_files:
            resolved.append(all_dcm_files[dcm_name])
    return resolved
