"""Data models for ParGen XML Generator."""

from dataclasses import dataclass, field
from decimal import Decimal
from typing import List, Optional


# --- DCM ---

@dataclass
class DcmParameter:
    name: str
    kind: str  # FESTWERT, FESTWERTEBLOCK, KENNLINIE, KENNFELD
    long_name: str = ""
    display_name: str = ""
    unit_w: str = ""
    unit_x: str = ""
    unit_y: str = ""
    values: List[str] = field(default_factory=list)
    x_axis: List[str] = field(default_factory=list)
    y_axis: List[str] = field(default_factory=list)
    size_x: int = 0
    size_y: int = 0
    is_text: bool = False


# --- pmavardef ---

@dataclass
class SubVariant:
    name: str
    dcm_files: List[str] = field(default_factory=list)


@dataclass
class MinorVariant:
    name: str
    sub_variants: List[SubVariant] = field(default_factory=list)


@dataclass
class VariantModule:
    name: str
    minor_variants: List[MinorVariant] = field(default_factory=list)


@dataclass
class MajorVariant:
    name: str
    common_dcm_files: List[str] = field(default_factory=list)
    modules: List[VariantModule] = field(default_factory=list)


@dataclass
class VariantDefinition:
    all_major_variant_dcms: List[str] = field(default_factory=list)
    major_variants: List[MajorVariant] = field(default_factory=list)


# --- PDL ---

@dataclass
class PdlEnumEntry:
    name: str
    value: Optional[int] = None


@dataclass
class PdlEnumeration:
    name: str
    entries: List[PdlEnumEntry] = field(default_factory=list)
    visibility: str = ""
    description: str = ""


@dataclass
class PdlQuantization:
    name: str
    factor_text: str = ""
    factor_value: Optional[Decimal] = None


@dataclass
class PdlUnit:
    name: str
    expression: str = ""


@dataclass
class PdlParameter:
    name: str = ""
    type_name: str = ""
    type_kind: str = ""  # continuous, discrete, logical, enum, array, map, curve, cube, bitfield, custom
    is_virtual: bool = False
    is_constant: bool = False
    is_protected: bool = False
    init_expression: str = ""
    array_size: int = 0
    description: str = ""
    quantization_ref: str = ""
    unit_ref: str = ""
    aliases: List[str] = field(default_factory=list)


@dataclass
class PdlClass:
    name: str
    parameters: List[PdlParameter] = field(default_factory=list)
    visibility: str = ""
    description: str = ""


@dataclass
class PdlMemoryDef:
    memory_type: str = ""  # ROM, NVM, NVM_INIT, RAM, RAM_INIT
    cluster_names: List[str] = field(default_factory=list)


@dataclass
class PdlCustomType:
    name: str
    base_type: str = ""  # continuous, discrete
    range_min: str = ""
    range_max: str = ""
    quantization_ref: str = ""
    unit_ref: str = ""
    visibility: str = ""
    description: str = ""


@dataclass
class PdlPackage:
    name: str = ""
    imports: List[str] = field(default_factory=list)
    classes: List[PdlClass] = field(default_factory=list)
    enumerations: List[PdlEnumeration] = field(default_factory=list)
    quantizations: List[PdlQuantization] = field(default_factory=list)
    units: List[PdlUnit] = field(default_factory=list)
    memory_defs: List[PdlMemoryDef] = field(default_factory=list)
    custom_types: List[PdlCustomType] = field(default_factory=list)
    exported_parameters: List[PdlParameter] = field(default_factory=list)
    exported_constants: List[PdlParameter] = field(default_factory=list)
    source_dir: str = ""
