"""Load ConfigMaster JSON files and reconstruct v7-compatible data structures.

Reads:
  - variant.json      → VariantDefinition
  - value/*.value.json → Dict[str, List[DcmParameter]]
  - model.json         → PdlComponentBuilder (+ global types)
"""

import json
import os
from collections import OrderedDict
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from .models import (
    DcmParameter, MajorVariant, MinorVariant, SubVariant,
    PdlClass, PdlCustomType, PdlEnumEntry, PdlEnumeration,
    PdlPackage, PdlParameter, PdlQuantization, PdlUnit, PdlMemoryDef,
    VariantDefinition, VariantModule,
)
from .component import PdlComponentBuilder


# ---------------------------------------------------------------------------
# variant.json → VariantDefinition
# ---------------------------------------------------------------------------

def _ref_to_dcm_name(ref: str) -> str:
    """Convert 'Foo.value.json' back to 'Foo.dcm'."""
    if ref.endswith(".value.json"):
        return ref[:-len(".value.json")] + ".dcm"
    return ref


def load_variant_json(path: str) -> VariantDefinition:
    """Reconstruct VariantDefinition from variant.json."""
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    modules_data = data.get("modules", {})
    vardef = VariantDefinition()

    common = modules_data.get("common", {}).get("options", {}).get("default", {})
    vardef.all_major_variant_dcms = [_ref_to_dcm_name(r) for r in common.get("base", [])]

    vehicle_options = modules_data.get("vehicle", {}).get("options", {})
    for mv_name, mv_data in vehicle_options.items():
        mv = MajorVariant(name=mv_name)
        mv.common_dcm_files = [_ref_to_dcm_name(r) for r in mv_data.get("base", [])]

        mv_modules = mv_data.get("modules", {})
        for mod_name, mod_data in mv_modules.items():
            module = VariantModule(name=mod_name)
            mod_options = mod_data.get("options", {})
            for opt_key, opt_data in mod_options.items():
                if "__" in opt_key:
                    minor_name, sub_name = opt_key.split("__", 1)
                else:
                    minor_name = opt_key
                    sub_name = ""

                existing_minor = None
                for m in module.minor_variants:
                    if m.name == minor_name:
                        existing_minor = m
                        break

                sv = SubVariant(
                    name=sub_name,
                    dcm_files=[_ref_to_dcm_name(r) for r in opt_data.get("base", [])]
                )

                if existing_minor:
                    existing_minor.sub_variants.append(sv)
                else:
                    minor = MinorVariant(name=minor_name, sub_variants=[sv])
                    module.minor_variants.append(minor)

            mv.modules.append(module)

        vardef.major_variants.append(mv)

    return vardef


# ---------------------------------------------------------------------------
# value.json → dcm_data
# ---------------------------------------------------------------------------

def _json_value_to_dcm_strings(val: Any) -> List[str]:
    """Convert a JSON value back to DCM string representation."""
    if isinstance(val, bool):
        return ["true" if val else "false"]
    if isinstance(val, (int, float)):
        return [str(val)]
    if isinstance(val, str):
        return [val]
    if isinstance(val, list):
        return [str(v) for v in val]
    return [str(val)]


def _infer_dcm_kind(val: Any) -> Tuple[str, bool]:
    """Infer DCM kind from JSON value type. Returns (kind, is_text)."""
    if isinstance(val, dict):
        if "y_axis" in val:
            return "KENNFELD", False
        if "x_axis" in val:
            return "KENNLINIE", False
        return "KENNLINIE", False
    if isinstance(val, list):
        return "FESTWERTEBLOCK", False
    if isinstance(val, str):
        return "FESTWERT", True
    return "FESTWERT", False


def load_value_json_file(path: str) -> List[DcmParameter]:
    """Load a single value.json file and return DcmParameter list.

    Keys can be either full FQN (e.g. rbp.hai.aci.ACI_EPS.Timer20ms)
    or short cluster.param form (e.g. ACI_EPS.Timer20ms).
    """
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    params: List[DcmParameter] = []
    for key, val in data.items():
        if key.startswith("_"):
            continue

        kind, is_text = _infer_dcm_kind(val)

        p = DcmParameter(name=key, kind=kind, is_text=is_text)

        if kind in ("KENNLINIE", "KENNFELD"):
            p.values = _json_value_to_dcm_strings(val.get("values", []))
            x = val.get("x_axis", [])
            y = val.get("y_axis", [])
            p.x_axis = _json_value_to_dcm_strings(x) if x else []
            p.y_axis = _json_value_to_dcm_strings(y) if y else []
            p.size_x = len(p.x_axis)
            p.size_y = len(p.y_axis)
        elif kind == "FESTWERTEBLOCK":
            p.values = _json_value_to_dcm_strings(val)
        else:
            p.values = _json_value_to_dcm_strings(val)

        params.append(p)

    return params


def load_all_value_json(value_dir: str) -> Dict[str, List[DcmParameter]]:
    """Load all value.json files from a directory. Returns {dcm_stem: [DcmParameter]}."""
    dcm_data: Dict[str, List[DcmParameter]] = {}

    for fname in sorted(os.listdir(value_dir)):
        if not fname.endswith(".value.json"):
            continue
        stem = fname[:-len(".value.json")]
        path = os.path.join(value_dir, fname)
        try:
            params = load_value_json_file(path)
            if params:
                dcm_data[stem] = params
        except Exception as e:
            print(f"  [ERROR] Loading {fname}: {e}")

    return dcm_data


# ---------------------------------------------------------------------------
# model.json → PdlComponentBuilder + global types
# ---------------------------------------------------------------------------

def load_model_json(path: str) -> Tuple[
    List[PdlPackage],
    Dict[str, Dict],
    Dict[str, Dict],
    Dict[str, str],
]:
    """Load model.json and reconstruct PdlPackage list + global fallback maps.

    Returns: (pdl_packages, global_types_map, global_enums_map, global_quant_formulas)
    """
    with open(path, "r", encoding="utf-8") as f:
        model = json.load(f)

    all_custom_types = {}
    for name, ct_data in model.get("custom_types", {}).items():
        all_custom_types[name] = PdlCustomType(
            name=name,
            base_type=ct_data.get("base_type", ""),
            range_min=ct_data.get("range_min", ""),
            range_max=ct_data.get("range_max", ""),
            quantization_ref=ct_data.get("quantization_ref", ""),
            unit_ref=ct_data.get("unit_ref", ""),
            visibility=ct_data.get("visibility", ""),
            description=ct_data.get("description", ""),
        )

    all_enumerations = {}
    for name, en_data in model.get("enumerations", {}).items():
        entries = [
            PdlEnumEntry(name=e["name"], value=e.get("value"))
            for e in en_data.get("entries", [])
        ]
        all_enumerations[name] = PdlEnumeration(
            name=name,
            entries=entries,
            visibility=en_data.get("visibility", ""),
            description=en_data.get("description", ""),
        )

    all_quantizations = {}
    for name, q_data in model.get("quantizations", {}).items():
        fv = q_data.get("factor_value")
        all_quantizations[name] = PdlQuantization(
            name=name,
            factor_text=q_data.get("factor_text", ""),
            factor_value=Decimal(fv) if fv is not None else None,
        )

    all_units = {}
    for name, u_data in model.get("units", {}).items():
        all_units[name] = PdlUnit(name=name, expression=u_data.get("expression", ""))

    cluster_to_memory = model.get("cluster_to_memory", {})
    cluster_to_package = model.get("cluster_to_package", {})
    param_aliases = model.get("param_aliases", {})

    components = model.get("components", {})
    packages: List[PdlPackage] = []
    comp_pkg_names: Dict[str, str] = {}

    for comp_name, comp_classes in components.items():
        pkg = PdlPackage()
        pkg_name = cluster_to_package.get(
            next(iter(comp_classes), ""), comp_name
        )
        pkg.name = pkg_name
        comp_pkg_names[comp_name] = pkg_name

        for cls_name, cls_data in comp_classes.items():
            cls = PdlClass(
                name=cls_name,
                visibility=cls_data.get("visibility", ""),
                description=cls_data.get("description", ""),
            )
            for p_data in cls_data.get("parameters", []):
                param = PdlParameter(
                    name=p_data.get("name", ""),
                    type_name=p_data.get("type_name", ""),
                    type_kind=p_data.get("type_kind", ""),
                    is_virtual=p_data.get("is_virtual", False),
                    is_constant=p_data.get("is_constant", False),
                    is_protected=p_data.get("is_protected", False),
                    init_expression=p_data.get("init_expression", ""),
                    array_size=p_data.get("array_size", 0),
                    description=p_data.get("description", ""),
                    quantization_ref=p_data.get("quantization_ref", ""),
                    unit_ref=p_data.get("unit_ref", ""),
                    aliases=p_data.get("aliases", []),
                )
                cls.parameters.append(param)
            pkg.classes.append(cls)

        # Attach types/enums/quantizations/units referenced by this component's classes
        refs_ct: Set[str] = set()
        refs_en: Set[str] = set()
        refs_q: Set[str] = set()
        refs_u: Set[str] = set()
        for cls in pkg.classes:
            for p in cls.parameters:
                short_tn = p.type_name.split(".")[-1] if "." in p.type_name else p.type_name
                if short_tn in all_custom_types:
                    refs_ct.add(short_tn)
                    ct = all_custom_types[short_tn]
                    if ct.quantization_ref and ct.quantization_ref in all_quantizations:
                        refs_q.add(ct.quantization_ref)
                    if ct.unit_ref and ct.unit_ref in all_units:
                        refs_u.add(ct.unit_ref)
                if short_tn in all_enumerations:
                    refs_en.add(short_tn)
                if p.quantization_ref and p.quantization_ref in all_quantizations:
                    refs_q.add(p.quantization_ref)
                if p.unit_ref and p.unit_ref in all_units:
                    refs_u.add(p.unit_ref)

        pkg.custom_types = [all_custom_types[n] for n in refs_ct]
        pkg.enumerations = [all_enumerations[n] for n in refs_en]
        pkg.quantizations = [all_quantizations[n] for n in refs_q]
        pkg.units = [all_units[n] for n in refs_u]

        # Memory allocation
        for cls in pkg.classes:
            if cls.name in cluster_to_memory:
                mem_type = cluster_to_memory[cls.name]
                pkg.memory_defs.append(PdlMemoryDef(
                    memory_type=mem_type,
                    cluster_names=[cls.name],
                ))

        packages.append(pkg)

    # Collect all types/enums/quants/units already attached to some package
    attached_ct: Set[str] = set()
    attached_en: Set[str] = set()
    attached_q: Set[str] = set()
    attached_u: Set[str] = set()
    for pkg in packages:
        for ct in pkg.custom_types:
            attached_ct.add(ct.name)
        for en in pkg.enumerations:
            attached_en.add(en.name)
        for q in pkg.quantizations:
            attached_q.add(q.name)
        for u in pkg.units:
            attached_u.add(u.name)

    # Create a catch-all package for standalone types not referenced by any component
    remaining_ct = [all_custom_types[n] for n in all_custom_types if n not in attached_ct]
    remaining_en = [all_enumerations[n] for n in all_enumerations if n not in attached_en]
    remaining_q = [all_quantizations[n] for n in all_quantizations if n not in attached_q]
    remaining_u = [all_units[n] for n in all_units if n not in attached_u]
    if remaining_ct or remaining_en or remaining_q or remaining_u:
        global_pkg = PdlPackage(name="datatypes")
        global_pkg.custom_types = remaining_ct
        global_pkg.enumerations = remaining_en
        global_pkg.quantizations = remaining_q
        global_pkg.units = remaining_u
        packages.append(global_pkg)

    # Exported constants and params → attach to the matching package
    pkg_by_comp: Dict[str, PdlPackage] = {}
    for i, comp_name in enumerate(components.keys()):
        pkg_by_comp[comp_name] = packages[i]

    for ec_data in model.get("exported_constants", []):
        comp = ec_data["component"]
        p = PdlParameter(
            name=ec_data.get("name", ""),
            type_name=ec_data.get("type_name", ""),
            type_kind=ec_data.get("type_kind", ""),
            is_virtual=ec_data.get("is_virtual", False),
            is_constant=True,
            init_expression=ec_data.get("init_expression", ""),
            description=ec_data.get("description", ""),
            quantization_ref=ec_data.get("quantization_ref", ""),
            unit_ref=ec_data.get("unit_ref", ""),
        )
        if comp in pkg_by_comp:
            pkg_by_comp[comp].exported_constants.append(p)

    for ep_data in model.get("exported_params", []):
        comp = ep_data["component"]
        p = PdlParameter(
            name=ep_data.get("name", ""),
            type_name=ep_data.get("type_name", ""),
            type_kind=ep_data.get("type_kind", ""),
            is_virtual=ep_data.get("is_virtual", False),
            init_expression=ep_data.get("init_expression", ""),
            description=ep_data.get("description", ""),
            quantization_ref=ep_data.get("quantization_ref", ""),
            unit_ref=ep_data.get("unit_ref", ""),
            array_size=ep_data.get("array_size", 0),
        )
        if comp in pkg_by_comp:
            pkg_by_comp[comp].exported_parameters.append(p)

    global_types_map = model.get("global_types", {})
    global_enums_map = model.get("global_enums", {})
    global_quant_formulas = model.get("global_quant_formulas", {})

    return packages, global_types_map, global_enums_map, global_quant_formulas
