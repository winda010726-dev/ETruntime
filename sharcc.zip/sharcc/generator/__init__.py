"""ParGen XML generator core."""
