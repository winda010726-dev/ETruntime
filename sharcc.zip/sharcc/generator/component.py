"""PDL-aware Component Builder — maps PDL package/class to Component/Cluster."""

from collections import OrderedDict
from typing import Dict, List, Optional, Tuple

from .models import (
    PdlClass, PdlCustomType, PdlEnumeration, PdlPackage, PdlParameter,
    PdlQuantization, PdlUnit,
)

_EXCLUDED_PLUGIN_DIRS = {'MES_ACS_PL'}


class PdlComponentBuilder:
    """
    Maps PDL package/class structure to ParGen Component/ParameterCluster.

    Component name = PdlPackage.name with '.' -> '_' and '^' removed
    (exactly matching Java ComponentCreator logic).
    Supports --component-map overrides for alias tables.
    """

    def __init__(self, pdl_packages: List[PdlPackage], component_map: Optional[Dict[str, str]] = None):
        self.pdl_packages = pdl_packages
        self.component_map = component_map or {}
        self._build_indexes()

    def _build_indexes(self):
        self.package_by_component: Dict[str, List[PdlPackage]] = OrderedDict()
        self.cluster_to_component: Dict[str, str] = {}
        self.cluster_to_pdlclass: Dict[str, PdlClass] = {}
        self.cluster_to_package: Dict[str, str] = {}
        self.cluster_to_memory: Dict[str, str] = {}
        self.all_quantizations: Dict[str, PdlQuantization] = {}
        self.all_enumerations: Dict[str, PdlEnumeration] = {}
        self.all_custom_types: Dict[str, PdlCustomType] = {}
        self.all_units: Dict[str, PdlUnit] = {}
        self.all_exported_constants: List[Tuple[str, PdlParameter]] = []
        self.all_exported_params: List[Tuple[str, PdlParameter]] = []
        self.param_name_to_alias: Dict[str, str] = {}

        for pkg in self.pdl_packages:
            raw_name = self._to_component_name(pkg.name)
            comp_name = self.component_map.get(raw_name, raw_name)

            if comp_name not in self.package_by_component:
                self.package_by_component[comp_name] = []
            self.package_by_component[comp_name].append(pkg)

            for q in pkg.quantizations:
                self.all_quantizations[q.name] = q

            for e in pkg.enumerations:
                self.all_enumerations[e.name] = e

            for ct in pkg.custom_types:
                self.all_custom_types[ct.name] = ct

            for u in pkg.units:
                self.all_units[u.name] = u

            for md in pkg.memory_defs:
                for cn in md.cluster_names:
                    short = cn.split(".")[-1]
                    self.cluster_to_memory[short] = md.memory_type
                    self.cluster_to_memory[cn] = md.memory_type

            for cls in pkg.classes:
                self.cluster_to_component[cls.name] = comp_name
                self.cluster_to_pdlclass[cls.name] = cls
                self.cluster_to_package[cls.name] = pkg.name
                for p in cls.parameters:
                    if p.aliases:
                        for alias in p.aliases:
                            self.param_name_to_alias[p.name] = alias

            is_excluded = pkg.source_dir in _EXCLUDED_PLUGIN_DIRS

            for p in pkg.exported_constants:
                if not is_excluded:
                    self.all_exported_constants.append((comp_name, p))

            for p in pkg.exported_parameters:
                if not is_excluded:
                    self.all_exported_params.append((comp_name, p))

    @staticmethod
    def _to_component_name(pkg_name: str) -> str:
        name = pkg_name.replace(".", "_")
        name = name.replace("^", "")
        return name

    def get_component_names(self) -> List[str]:
        return sorted(self.package_by_component.keys(), key=str.lower)

    def get_classes_for_component(self, comp_name: str) -> List[PdlClass]:
        pkgs = self.package_by_component.get(comp_name, [])
        seen: Dict[str, PdlClass] = {}
        for pkg in pkgs:
            for cls in pkg.classes:
                seen[cls.name] = cls
        classes = list(seen.values())
        classes.sort(key=lambda c: c.name.lower())
        return classes

    def get_memory_type(self, cluster_name: str) -> str:
        mem = self.cluster_to_memory.get(cluster_name)
        if mem:
            return mem
        return "ROM"

    def get_param_quantization(self, param: PdlParameter) -> str:
        if param.type_name in self.all_custom_types:
            ct = self.all_custom_types[param.type_name]
            return ct.quantization_ref
        return ""

    def get_type_in_model(self, param: PdlParameter) -> str:
        short_type = param.type_name.split(".")[-1] if "." in param.type_name else param.type_name
        if param.type_kind == "array":
            inner = short_type
            if inner in self.all_custom_types:
                return inner
            if inner in self.all_enumerations:
                return inner
            return inner
        if short_type in self.all_custom_types:
            return short_type
        if short_type in self.all_enumerations:
            return short_type
        if param.type_kind in ("continuous", "discrete", "logical"):
            kind = param.type_kind
            if kind == "continuous":
                kind = "cont"
            elif kind == "discrete":
                kind = "disc"
            return kind
        if param.type_kind == "bitfield":
            return param.type_name
        if param.type_kind == "custom":
            return param.type_name
        fallback = param.type_kind or param.type_name or "cont"
        if fallback == "continuous":
            fallback = "cont"
        elif fallback == "discrete":
            fallback = "disc"
        return fallback
