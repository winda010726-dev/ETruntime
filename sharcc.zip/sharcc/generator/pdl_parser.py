"""PDL tokenizer, parser, and global type loader."""

import math
import os
import re
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from .models import (
    PdlClass, PdlCustomType, PdlEnumEntry, PdlEnumeration, PdlMemoryDef,
    PdlPackage, PdlParameter, PdlQuantization, PdlUnit,
)


class PdlTokenizer:
    """Tokenizes PDL source into (type, value, line_no) triples.

    Javadoc-style comments (/** ... */) are emitted as JAVADOC tokens
    so the parser can attach them as documentation to the next element.
    """

    KEYWORDS = {
        "package", "import", "class", "parameter", "constant", "virtual",
        "continuous", "cont", "discrete", "logical", "enum", "datatype",
        "is", "quantization", "Q", "phys", "unit", "MemoryLocation", "for",
        "group", "platform", "mappings", "type", "default", "range",
        "symbols", "size", "Infinity", "NaN", "bitfield", "of", "reserved:",
        "public", "protected", "project", "disclosure",
        "ROM", "NVM", "NVM_INIT", "RAM", "RAM_INIT",
        "map", "curve", "axis", "cube", "values",
        "true", "false",
        "bitfield8", "bitfield16", "bitfield32",
        "pow", "max", "min", "abs", "sqrt", "exp",
    }

    TOKEN_SPEC = [
        ("COMMENT_ML", r"/\*[\s\S]*?\*/"),
        ("COMMENT_SL", r"//[^\n]*"),
        ("STRING", r'"[^"]*"'),
        ("STRING2", r"'[^']*'"),
        ("FLOAT", r"\d+\.\d+([eE][+-]?\d+)?"),
        ("SCINUM", r"\d+[eE][+-]?\d+"),
        ("INT", r"\d+"),
        ("ASSIGN", r":="),
        ("ARROW", r"->"),
        ("DOTDOT", r"\.\."),
        ("DOTSTAR", r"\.\*"),
        ("OR", r"\|\|"),
        ("AND", r"&&"),
        ("EQ", r"=="),
        ("NEQ", r"!="),
        ("GE", r">="),
        ("LE", r"<="),
        ("ID", r"`?[a-zA-Z_][a-zA-Z0-9_]*"),
        ("PUNCT", r"[{}()\[\];,.=@?|&!<>:+\-*/%^]"),
        ("WS", r"\s+"),
    ]
    _rx = re.compile("|".join(f"(?P<{n}>{p})" for n, p in TOKEN_SPEC))

    def tokenize(self, text: str) -> List[Tuple[str, str, int]]:
        tokens = []
        for m in self._rx.finditer(text):
            kind = m.lastgroup
            val = m.group()
            line = text.count("\n", 0, m.start()) + 1
            if kind == "WS":
                continue
            if kind == "COMMENT_SL":
                continue
            if kind == "COMMENT_ML":
                if val.startswith("/**"):
                    tokens.append(("JAVADOC", val, line))
                continue
            if kind == "STRING2":
                kind = "STRING"
            if kind == "ID" and val.lstrip("`") in self.KEYWORDS:
                kind = "KW"
            tokens.append((kind, val.lstrip("`"), line))
        return tokens


class PdlParser:
    """
    Recursive-descent parser for PDL files.

    Extracts: package name, classes (with parameters), quantizations,
    enumerations, custom datatypes, units, memory definitions,
    exported parameters/constants.
    """

    def __init__(self, filepath: str, encoding: str = "cp1252"):
        self.filepath = filepath
        self.encoding = encoding

    @staticmethod
    def _clean_javadoc(raw: str) -> str:
        """Clean a /** ... */ Javadoc comment to match Java PdlDescriptionProvider.clean().

        Mirrors Xtext's MultiLineCommentDocumentationProvider: removes all
        occurrences of /**, */, /* (in that order), then strips leading
        asterisks per line, collapses whitespace, removes $ and " characters.
        """
        text = raw.replace("/**", "").replace("*/", "").replace("/*", "")
        lines = text.split("\n")
        cleaned_lines = []
        for line in lines:
            stripped = line.strip()
            stripped = stripped.lstrip("*")
            if stripped.startswith(" "):
                stripped = stripped[1:]
            cleaned_lines.append(stripped)
        text = " ".join(cleaned_lines)
        text = re.sub(r'\s+', ' ', text)
        text = text.replace('$', '').replace('"', '')
        return text.strip()

    def parse(self) -> PdlPackage:
        try:
            with open(self.filepath, "r", encoding=self.encoding) as f:
                text = f.read()
        except UnicodeDecodeError:
            with open(self.filepath, "r", encoding="cp1252") as f:
                text = f.read()

        tokenizer = PdlTokenizer()
        tokens = tokenizer.tokenize(text)
        return self._parse_package(tokens)

    def _parse_package(self, tokens: List[Tuple[str, str, int]]) -> PdlPackage:
        pkg = PdlPackage()
        pos = 0
        n = len(tokens)

        while pos < n and tokens[pos][1] == "@":
            pos = self._skip_annotation(tokens, pos)

        if pos < n and tokens[pos][1] == "package":
            pos += 1
            pkg.name, pos = self._read_qualified_name(tokens, pos)
            pos = self._skip_to(tokens, pos, ";")

        pending_aliases: List[str] = []
        pending_doc: str = ""
        while pos < n:
            tok_type, tok_val, tok_line = tokens[pos]

            if tok_type == "JAVADOC":
                pending_doc = self._clean_javadoc(tok_val)
                pos += 1
                continue

            if tok_val == "@":
                alias_vals, pos = self._parse_annotation_capture(tokens, pos)
                if alias_vals:
                    pending_aliases.extend(alias_vals)
                continue

            if tok_val == "import":
                pending_doc = ""
                imp_name, pos = self._parse_import(tokens, pos)
                if imp_name:
                    pkg.imports.append(imp_name)
                continue

            if tok_val == "quantization":
                pending_doc = ""
                q, pos = self._parse_quantization(tokens, pos)
                if q:
                    pkg.quantizations.append(q)
                continue

            if tok_val == "unit":
                pending_doc = ""
                u, pos = self._parse_unit(tokens, pos)
                if u:
                    pkg.units.append(u)
                continue

            if tok_val == "MemoryLocation":
                pending_doc = ""
                md, pos = self._parse_memory_def(tokens, pos)
                if md:
                    pkg.memory_defs.append(md)
                continue

            visibility = ""
            if tok_val in ("public", "protected"):
                visibility = tok_val
                pos += 1
                if pos >= n:
                    break
                tok_type, tok_val, tok_line = tokens[pos]

            if tok_val == "datatype":
                dt_result, pos = self._parse_datatype(tokens, pos, visibility, pending_doc)
                pending_doc = ""
                if dt_result:
                    if isinstance(dt_result, PdlEnumeration):
                        pkg.enumerations.append(dt_result)
                    elif isinstance(dt_result, PdlCustomType):
                        pkg.custom_types.append(dt_result)
                continue

            if tok_val == "class":
                cls, pos = self._parse_class(tokens, pos, visibility, pending_doc)
                pending_doc = ""
                if cls:
                    pkg.classes.append(cls)
                continue

            if tok_val == "parameter":
                param, pos = self._parse_parameter(tokens, pos, is_exported=True)
                if param:
                    param.aliases = pending_aliases
                    if pending_doc:
                        param.description = pending_doc
                    pkg.exported_parameters.append(param)
                pending_aliases = []
                pending_doc = ""
                continue

            if tok_val == "constant":
                param, pos = self._parse_constant(tokens, pos, is_exported=True)
                if param:
                    param.aliases = pending_aliases
                    if pending_doc:
                        param.description = pending_doc
                    pkg.exported_constants.append(param)
                pending_aliases = []
                pending_doc = ""
                continue

            if tok_val == "platform":
                pending_doc = ""
                pos = self._skip_block_or_semicolon(tokens, pos)
                continue

            if tok_val == "group":
                pending_doc = ""
                pos = self._skip_block_or_semicolon(tokens, pos)
                continue

            if tok_val in ("project", "disclosure"):
                pending_doc = ""
                pos = self._skip_block_or_semicolon(tokens, pos)
                continue

            pos += 1

        return pkg

    def _parse_import(self, tokens, pos) -> Tuple[str, int]:
        pos += 1
        name, pos = self._read_qualified_name(tokens, pos)
        if pos < len(tokens) and tokens[pos][1] == ".*":
            name += ".*"
            pos += 1
        elif pos < len(tokens) and tokens[pos][1] == ".":
            pos += 1
            if pos < len(tokens) and tokens[pos][1] == "*":
                name += ".*"
                pos += 1
        pos = self._skip_to(tokens, pos, ";")
        return name, pos

    def _parse_quantization(self, tokens, pos) -> Tuple[Optional[PdlQuantization], int]:
        pos += 1
        if pos >= len(tokens):
            return None, pos
        name = tokens[pos][1]
        pos += 1

        q = PdlQuantization(name=name)
        eq_pos = self._find_token(tokens, pos, "=")
        if eq_pos is not None:
            pos = eq_pos + 1
            factor_tokens = []
            while pos < len(tokens):
                if tokens[pos][1] == ";":
                    pos += 1
                    break
                if (tokens[pos][1] == "*" and pos + 1 < len(tokens)
                        and tokens[pos + 1][1] == "phys"):
                    pos += 2
                    if pos < len(tokens) and tokens[pos][1] == ";":
                        pos += 1
                    break
                factor_tokens.append(tokens[pos][1])
                pos += 1

            no_space_chars = {"/", "(", ")", ","}
            parts = []
            for tok in factor_tokens:
                if tok in no_space_chars:
                    if parts and parts[-1] == " ":
                        parts.pop()
                    parts.append(tok)
                elif parts and parts[-1] in no_space_chars:
                    parts.append(tok)
                else:
                    if parts:
                        parts.append(" ")
                    parts.append(tok)
            ft = "".join(parts)
            if ft.startswith("(") and ft.endswith(")"):
                inner = ft[1:-1]
                depth = 0
                balanced = True
                for ch in inner:
                    if ch == "(":
                        depth += 1
                    elif ch == ")":
                        depth -= 1
                    if depth < 0:
                        balanced = False
                        break
                if balanced and depth == 0:
                    ft = inner
            q.factor_text = ft
            q.factor_value = self._eval_expr(q.factor_text)
        else:
            pos = self._skip_to(tokens, pos, ";")

        return q, pos

    def _parse_unit(self, tokens, pos) -> Tuple[Optional[PdlUnit], int]:
        pos += 1
        if pos >= len(tokens):
            return None, pos
        name = tokens[pos][1]
        pos += 1
        expr_parts = []
        if pos < len(tokens) and tokens[pos][1] == ":=":
            pos += 1
            while pos < len(tokens) and tokens[pos][1] != ";":
                expr_parts.append(tokens[pos][1])
                pos += 1
        pos = self._skip_to(tokens, pos, ";")
        return PdlUnit(name=name, expression=" ".join(expr_parts)), pos

    def _parse_memory_def(self, tokens, pos) -> Tuple[Optional[PdlMemoryDef], int]:
        pos += 1
        md = PdlMemoryDef()

        if pos < len(tokens) and tokens[pos][1] == "is":
            pos += 1
        if pos < len(tokens):
            md.memory_type = tokens[pos][1]
            pos += 1
        if pos < len(tokens) and tokens[pos][1] == "for":
            pos += 1
        if pos < len(tokens) and tokens[pos][1] == "{":
            pos += 1
            while pos < len(tokens) and tokens[pos][1] != "}":
                if tokens[pos][1] == ",":
                    pos += 1
                    continue
                name, pos = self._read_qualified_name(tokens, pos)
                if name:
                    md.cluster_names.append(name)
            if pos < len(tokens):
                pos += 1
        return md, pos

    def _parse_datatype(self, tokens, pos, visibility="", doc="") -> Tuple[Any, int]:
        pos += 1
        if pos >= len(tokens):
            return None, pos
        name = tokens[pos][1]
        pos += 1

        if pos < len(tokens) and tokens[pos][1] == "is":
            pos += 1

        if pos >= len(tokens):
            return None, pos

        if tokens[pos][1] == "enum":
            pos += 1
            enum = PdlEnumeration(name=name, visibility=visibility, description=doc)
            if pos < len(tokens) and tokens[pos][1] == "{":
                pos += 1
                idx = 0
                while pos < len(tokens) and tokens[pos][1] != "}":
                    if tokens[pos][0] == "ID" or tokens[pos][0] == "KW":
                        entry_name = tokens[pos][1]
                        pos += 1
                        entry_val = None
                        if pos < len(tokens) and tokens[pos][1] == "=":
                            pos += 1
                            if pos < len(tokens):
                                try:
                                    entry_val = int(tokens[pos][1])
                                except ValueError:
                                    entry_val = idx
                                pos += 1
                        if entry_val is None:
                            entry_val = idx
                        enum.entries.append(PdlEnumEntry(name=entry_name, value=entry_val))
                        idx = entry_val + 1
                        if pos < len(tokens) and tokens[pos][1] == ",":
                            pos += 1
                    else:
                        pos += 1
                if pos < len(tokens):
                    pos += 1
            pos = self._skip_to(tokens, pos, ";")
            return enum, pos

        base = ""
        if tokens[pos][1] in ("continuous", "cont", "discrete"):
            base = "continuous" if tokens[pos][1] in ("continuous", "cont") else "discrete"
            pos += 1

        ct = PdlCustomType(name=name, base_type=base, visibility=visibility, description=doc)
        if pos < len(tokens) and tokens[pos][1] == "{":
            pos += 1
            while pos < len(tokens) and tokens[pos][1] != "}":
                if tokens[pos][1] == "range" and pos + 1 < len(tokens) and tokens[pos + 1][1] in (":=", "="):
                    pos += 2
                    ct.range_min, ct.range_max, pos = self._parse_range(tokens, pos)
                elif tokens[pos][1] == "quantization" and pos + 1 < len(tokens) and tokens[pos + 1][1] in (":=", "="):
                    pos += 2
                    if pos < len(tokens):
                        ct.quantization_ref = tokens[pos][1]
                        pos += 1
                elif tokens[pos][1] == "unit" and pos + 1 < len(tokens) and tokens[pos + 1][1] in (":=", "="):
                    pos += 2
                    if pos < len(tokens):
                        ct.unit_ref = tokens[pos][1]
                        pos += 1
                else:
                    pos += 1
                if pos < len(tokens) and tokens[pos][1] == ";":
                    pos += 1
            if pos < len(tokens):
                pos += 1
        pos = self._skip_to(tokens, pos, ";")
        return ct, pos

    def _parse_range(self, tokens, pos) -> Tuple[str, str, int]:
        rmin, rmax = "", ""
        if pos < len(tokens) and tokens[pos][1] == "[":
            pos += 1
        min_parts = []
        while pos < len(tokens) and tokens[pos][1] not in ("..", "]", "}"):
            min_parts.append(tokens[pos][1])
            pos += 1
        rmin = "".join(min_parts)
        if pos < len(tokens) and tokens[pos][1] == "..":
            pos += 1
        max_parts = []
        while pos < len(tokens) and tokens[pos][1] not in ("]", "}", ";"):
            max_parts.append(tokens[pos][1])
            pos += 1
        rmax = "".join(max_parts)
        if pos < len(tokens) and tokens[pos][1] == "]":
            pos += 1
        return rmin, rmax, pos

    def _parse_class(self, tokens, pos, visibility="", doc="") -> Tuple[Optional[PdlClass], int]:
        pos += 1
        if pos >= len(tokens):
            return None, pos
        name = tokens[pos][1]
        pos += 1
        cls = PdlClass(name=name, visibility=visibility, description=doc)

        if pos < len(tokens) and tokens[pos][1] == "{":
            pos += 1
            brace_depth = 1
            pending_aliases: List[str] = []
            member_doc: str = ""
            while pos < len(tokens) and brace_depth > 0:
                tt = tokens[pos][0]
                tv = tokens[pos][1]

                if tt == "JAVADOC":
                    member_doc = self._clean_javadoc(tv)
                    pos += 1
                    continue

                if tv == "{":
                    brace_depth += 1
                    pos += 1
                    continue
                if tv == "}":
                    brace_depth -= 1
                    if brace_depth == 0:
                        pos += 1
                        break
                    pos += 1
                    continue

                if tv == "@":
                    alias_vals, pos = self._parse_annotation_capture(tokens, pos)
                    if alias_vals:
                        pending_aliases.extend(alias_vals)
                    continue

                if tv == "parameter" and brace_depth == 1:
                    param, pos = self._parse_parameter(tokens, pos, is_exported=False)
                    if param:
                        param.aliases = pending_aliases
                        if member_doc:
                            param.description = member_doc
                        cls.parameters.append(param)
                    pending_aliases = []
                    member_doc = ""
                    continue

                if tv == "constant" and brace_depth == 1:
                    param, pos = self._parse_constant(tokens, pos, is_exported=False)
                    if param:
                        param.is_constant = True
                        param.aliases = pending_aliases
                        if member_doc:
                            param.description = member_doc
                        cls.parameters.append(param)
                    pending_aliases = []
                    member_doc = ""
                    continue

                if tv == "bitfield" and brace_depth == 1:
                    pending_aliases = []
                    member_doc = ""
                    pos = self._skip_block_or_semicolon(tokens, pos)
                    continue

                if tv == "reserved:" and brace_depth == 1:
                    pending_aliases = []
                    member_doc = ""
                    pos = self._skip_to(tokens, pos, ";")
                    continue

                pos += 1

        return cls, pos

    def _parse_annotation_capture(self, tokens, pos) -> Tuple[List[str], int]:
        """Parse @ALIAS(name1, name2, ...) and return all alias names."""
        pos += 1
        alias_vals: List[str] = []
        if pos < len(tokens) and tokens[pos][0] in ("ID", "KW"):
            ann_name = tokens[pos][1]
            pos += 1
            if pos < len(tokens) and tokens[pos][1] == "(":
                pos += 1
                if ann_name == "ALIAS":
                    while pos < len(tokens) and tokens[pos][1] != ")":
                        if tokens[pos][0] in ("ID", "KW"):
                            alias_vals.append(tokens[pos][1])
                        pos += 1
                        if pos < len(tokens) and tokens[pos][1] == ",":
                            pos += 1
                else:
                    depth = 1
                    while pos < len(tokens) and depth > 0:
                        if tokens[pos][1] == "(":
                            depth += 1
                        elif tokens[pos][1] == ")":
                            depth -= 1
                        pos += 1
                    return alias_vals, pos
                if pos < len(tokens) and tokens[pos][1] == ")":
                    pos += 1
        return alias_vals, pos

    def _parse_parameter(self, tokens, pos, is_exported=False) -> Tuple[Optional[PdlParameter], int]:
        pos += 1
        param = PdlParameter()

        if pos < len(tokens) and tokens[pos][1] == "protected":
            param.is_protected = True
            pos += 1

        if pos < len(tokens) and tokens[pos][1] == "virtual":
            param.is_virtual = True
            pos += 1

        param.type_kind, param.type_name, param.array_size, pos = self._parse_type(tokens, pos)

        if pos < len(tokens) and tokens[pos][0] == "ID":
            param.name = tokens[pos][1]
            pos += 1

        if param.array_size == 0 and pos < len(tokens) and tokens[pos][1] == "[":
            pos += 1
            if pos < len(tokens):
                try:
                    param.array_size = int(tokens[pos][1])
                    param.type_kind = "array"
                except ValueError:
                    pass
                pos += 1
            if pos < len(tokens) and tokens[pos][1] == "]":
                pos += 1

        if pos < len(tokens) and tokens[pos][1] == ":=":
            pos += 1
            expr_parts = []
            depth = 0
            while pos < len(tokens):
                tv = tokens[pos][1]
                if tv in ("{", "(", "["):
                    depth += 1
                elif tv in ("}", ")", "]"):
                    depth -= 1
                if tv == ";" and depth <= 0:
                    break
                expr_parts.append(tv)
                pos += 1
            param.init_expression = " ".join(expr_parts)

        pos = self._skip_to(tokens, pos, ";")
        return param, pos

    def _parse_constant(self, tokens, pos, is_exported=False) -> Tuple[Optional[PdlParameter], int]:
        pos += 1
        param = PdlParameter(is_constant=True)

        if pos < len(tokens) and tokens[pos][1] == "virtual":
            param.is_virtual = True
            pos += 1

        param.type_kind, param.type_name, param.array_size, pos = self._parse_type(tokens, pos)

        if pos < len(tokens) and tokens[pos][0] == "ID":
            param.name = tokens[pos][1]
            pos += 1

        if param.array_size == 0 and pos < len(tokens) and tokens[pos][1] == "[":
            pos += 1
            if pos < len(tokens):
                try:
                    param.array_size = int(tokens[pos][1])
                    param.type_kind = "array"
                except ValueError:
                    pass
                pos += 1
            if pos < len(tokens) and tokens[pos][1] == "]":
                pos += 1

        if pos < len(tokens) and tokens[pos][1] == ":=":
            pos += 1
            expr_parts = []
            depth = 0
            while pos < len(tokens):
                tv = tokens[pos][1]
                if tv in ("{", "(", "["):
                    depth += 1
                elif tv in ("}", ")", "]"):
                    depth -= 1
                if tv == ";" and depth <= 0:
                    break
                expr_parts.append(tv)
                pos += 1
            param.init_expression = " ".join(expr_parts)

        pos = self._skip_to(tokens, pos, ";")
        return param, pos

    def _parse_type(self, tokens, pos) -> Tuple[str, str, int, int]:
        if pos >= len(tokens):
            return "", "", 0, pos

        tv = tokens[pos][1]
        kind = ""
        name = ""
        arr = 0

        if tv in ("continuous", "cont"):
            kind = "continuous"
            name = "continuous"
            pos += 1
        elif tv == "discrete":
            kind = "discrete"
            name = "discrete"
            pos += 1
        elif tv == "logical":
            kind = "logical"
            name = "logical"
            pos += 1
        elif tv in ("map", "curve", "cube"):
            kind = tv
            name = tv
            pos = self._skip_balanced(tokens, pos + 1, "(", ")")
        elif tv in ("bitfield8", "bitfield16", "bitfield32"):
            kind = "bitfield"
            name = tv
            pos += 1
        elif tokens[pos][0] == "ID":
            ref_name, pos = self._read_qualified_name(tokens, pos)
            kind = "custom"
            name = ref_name
        else:
            pos += 1
            return "", "", 0, pos

        if pos < len(tokens) and tokens[pos][1] == "[":
            pos += 1
            if pos < len(tokens):
                try:
                    arr = int(tokens[pos][1])
                except ValueError:
                    arr = 0
                pos += 1
            if pos < len(tokens) and tokens[pos][1] == "]":
                pos += 1
            kind = "array"

        return kind, name, arr, pos

    def _read_qualified_name(self, tokens, pos) -> Tuple[str, int]:
        parts = []
        if pos < len(tokens) and (tokens[pos][0] in ("ID", "KW")):
            parts.append(tokens[pos][1])
            pos += 1
            while pos < len(tokens) and tokens[pos][1] == ".":
                if pos + 1 < len(tokens) and tokens[pos + 1][1] == "^":
                    if pos + 2 < len(tokens) and tokens[pos + 2][0] in ("ID", "KW"):
                        parts.append("^" + tokens[pos + 2][1])
                        pos += 3
                        continue
                if pos + 1 < len(tokens) and tokens[pos + 1][0] in ("ID", "KW"):
                    parts.append(tokens[pos + 1][1])
                    pos += 2
                else:
                    break
        return ".".join(parts), pos

    def _skip_annotation(self, tokens, pos) -> int:
        pos += 1
        if pos < len(tokens) and tokens[pos][0] in ("ID", "KW"):
            pos += 1
        if pos < len(tokens) and tokens[pos][1] == "(":
            pos = self._skip_balanced(tokens, pos, "(", ")")
        return pos

    def _skip_balanced(self, tokens, pos, open_ch, close_ch) -> int:
        if pos >= len(tokens) or tokens[pos][1] != open_ch:
            return pos
        depth = 1
        pos += 1
        while pos < len(tokens) and depth > 0:
            if tokens[pos][1] == open_ch:
                depth += 1
            elif tokens[pos][1] == close_ch:
                depth -= 1
            pos += 1
        return pos

    def _skip_to(self, tokens, pos, target) -> int:
        while pos < len(tokens):
            if tokens[pos][1] == target:
                return pos + 1
            pos += 1
        return pos

    def _find_token(self, tokens, pos, target) -> Optional[int]:
        i = pos
        while i < len(tokens):
            if tokens[i][1] == target:
                return i
            if tokens[i][1] == ";":
                return None
            i += 1
        return None

    def _skip_block_or_semicolon(self, tokens, pos) -> int:
        depth = 0
        while pos < len(tokens):
            tv = tokens[pos][1]
            if tv == "{":
                depth += 1
            elif tv == "}":
                depth -= 1
                if depth <= 0:
                    pos += 1
                    if pos < len(tokens) and tokens[pos][1] == ";":
                        pos += 1
                    return pos
            elif tv == ";" and depth <= 0:
                return pos + 1
            pos += 1
        return pos

    @staticmethod
    def _eval_expr(text: str) -> Optional[Decimal]:
        import decimal
        text = text.strip()
        if not text:
            return None
        safe = text.replace(" ", "")
        if not re.match(r'^[\d.eE+\-*/(),powPi]+$', safe):
            return None
        PI_HP = Decimal("3.14159265")

        with decimal.localcontext() as ctx:
            ctx.prec = 34
            try:
                tokens = re.findall(r'\d+\.?\d*(?:[eE][+-]?\d+)?|Pi|pow|[+\-*/(),]', safe)
                d_parts = []
                for tok in tokens:
                    if tok == "Pi":
                        d_parts.append(f"D('{PI_HP}')")
                    elif tok == "pow":
                        d_parts.append("_pow")
                    elif re.match(r'^\d', tok):
                        d_parts.append(f"D('{tok}')")
                    else:
                        d_parts.append(tok)
                d_expr = "".join(d_parts)
                result = eval(d_expr, {"__builtins__": {}, "D": Decimal,
                                       "_pow": lambda a, b: Decimal(a) ** int(b)}, {})
                return Decimal(result) if not isinstance(result, Decimal) else result
            except Exception:
                safe_f = safe.replace("Pi", repr(math.pi))
                try:
                    result = eval(safe_f, {"__builtins__": {}, "pow": pow}, {})
                    return Decimal(str(result))
                except Exception:
                    return None


# ── Global PDL Type / Quantization Loader (regex-based fallback) ──

def _parse_datatype_pdl(filepath: str):
    types_list: List[Dict] = []
    enums_list: List[Dict] = []
    try:
        with open(filepath, encoding="cp1252") as f:
            content = f.read()
    except (FileNotFoundError, OSError):
        return types_list, enums_list
    for tm in re.finditer(
        r'(?:/\*\*([^*]*(?:\*(?!/)[^*]*)*)\*/\s*)?public\s+datatype\s+(\w+)\s+is\s+(cont|continuous|discrete|enum)\s*\{([^}]+)\}',
        content, re.DOTALL,
    ):
        doc_raw = tm.group(1) or ""
        doc = _clean_javadoc_text(doc_raw)
        if tm.group(3) == "enum":
            tname, tbody = tm.group(2), tm.group(4)
            literals = []
            for lit in re.finditer(r'(\w+)\s*=\s*(\d+)', tbody):
                literals.append({"name": lit.group(1), "value": lit.group(2)})
            enums_list.append({"name": tname, "literals": literals})
            continue
        tname, tkind, tbody = tm.group(2), tm.group(3), tm.group(4)
        rm = re.search(r'range\s*:=\s*\[([^\]]+)\]', tbody)
        rmin, rmax = 0, 0
        if rm:
            p = rm.group(1).split('..')
            rr, rs = p[0].strip(), p[1].strip()
            try:
                rf, sf = float(rr), float(rs)
                rmin = int(rf) if rf == int(rf) and '.' not in rr else rr
                rmax = int(sf) if sf == int(sf) and '.' not in rs else rs
            except ValueError:
                pass
        qm = re.search(r'quantization\s*:=\s*(\w+)', tbody)
        quant = qm.group(1) if qm else ""
        um = re.search(r'unit\s*:=\s*"([^"]*)"', tbody)
        unit = um.group(1) if um else ""
        types_list.append({"name": tname, "kind": tkind, "min": rmin, "max": rmax,
                           "quant": quant, "unit": unit, "description": doc})
    return types_list, enums_list


def _clean_javadoc_text(raw: str) -> str:
    lines = raw.split('\n')
    cleaned = []
    for line in lines:
        line = re.sub(r'^\s*\*\s?', '', line)
        line = line.strip()
        if line:
            cleaned.append(line)
    text = ' '.join(cleaned)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def _parse_quant_pdl(filepath: str) -> Dict[str, str]:
    quants: Dict[str, str] = {}
    try:
        with open(filepath, encoding="cp1252") as f:
            content = f.read()
    except (FileNotFoundError, OSError):
        return quants
    for m in re.finditer(r'quantization\s+(\w+)\s+is\s+Q\s*\(phys\)\s*=\s*([^;]+);', content):
        quants[m.group(1)] = m.group(2).strip()
    return quants


def load_global_types(pdl_dir: str):
    types_map: Dict[str, Dict] = {}
    enums_map: Dict[str, Dict] = {}
    quant_formulas: Dict[str, str] = {}
    scanned: Set[str] = set()
    for root, _, files in os.walk(pdl_dir):
        for f in sorted(files):
            if not f.endswith(".pdl"):
                continue
            fp = os.path.join(root, f)
            if fp in scanned:
                continue
            scanned.add(fp)
            if "uantiz" in f.lower() or "uantis" in f.lower():
                quant_formulas.update(_parse_quant_pdl(fp))
            else:
                types, enums = _parse_datatype_pdl(fp)
                for t in types:
                    types_map.setdefault(t["name"], t)
                for e in enums:
                    enums_map.setdefault(e["name"], e)
    return types_map, enums_map, quant_formulas


def load_pdl_files(pdl_dir: str) -> List[PdlPackage]:
    packages = []
    pdl_files = sorted(Path(pdl_dir).rglob("*.pdl"))
    if not pdl_files:
        print("  [WARN] No .pdl files found.")
        return packages

    for pf in pdl_files:
        try:
            parser = PdlParser(str(pf))
            pkg = parser.parse()
            if not pkg.name:
                pkg.name = pf.stem
            try:
                pkg.source_dir = pf.relative_to(pdl_dir).parts[0]
            except (ValueError, IndexError):
                pkg.source_dir = ""
            has_content = (
                pkg.classes or pkg.enumerations or pkg.quantizations
                or pkg.custom_types or pkg.exported_constants
                or pkg.exported_parameters or pkg.units
            )
            if has_content or pkg.name:
                packages.append(pkg)
                cls_count = len(pkg.classes)
                q_count = len(pkg.quantizations)
                e_count = len(pkg.enumerations)
                ct_count = len(pkg.custom_types)
                p_count = sum(len(c.parameters) for c in pkg.classes)
                print(
                    f"  Loaded {pf.name}: package={pkg.name}, "
                    f"{cls_count} classes, {p_count} params, {q_count} quantizations, "
                    f"{e_count} enums, {ct_count} custom types"
                )
        except Exception as e:
            print(f"  [ERROR] Failed to parse {pf}: {e}")
    return packages


def load_memory_allocation_pdl(dcm_dir: str) -> List[PdlPackage]:
    """Load memory_allocation_*.pdl files from DCM directory."""
    packages = []
    dcm_path = Path(dcm_dir)
    pdl_files = sorted(dcm_path.glob("memory_allocation_*.pdl"))
    if not pdl_files:
        return packages
    for pf in pdl_files:
        try:
            parser = PdlParser(str(pf))
            pkg = parser.parse()
            if pkg.memory_defs:
                packages.append(pkg)
                total_clusters = sum(len(md.cluster_names) for md in pkg.memory_defs)
                print(f"  Loaded memory alloc: {pf.name} ({total_clusters} clusters)")
        except Exception as e:
            print(f"  [ERROR] Failed to parse memory alloc {pf}: {e}")
    return packages
