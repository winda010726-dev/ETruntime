"""DCM text file parser (KONSERVIERUNG_FORMAT 2.0)."""

import os
import re
from typing import Dict, List, Optional, Tuple

from .models import DcmParameter


class DcmParser:
    BLOCK_KEYWORDS = {"FESTWERT", "FESTWERTEBLOCK", "KENNLINIE", "KENNFELD"}

    def __init__(self, filepath: str, encoding: str = "latin-1"):
        self.filepath = filepath
        self.encoding = encoding

    def parse(self) -> List[DcmParameter]:
        with open(self.filepath, "r", encoding=self.encoding) as f:
            lines = f.readlines()
        return self._parse_lines(lines)

    def _parse_lines(self, lines: List[str]) -> List[DcmParameter]:
        parameters: List[DcmParameter] = []
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if not line or line.startswith("*") or line.startswith("!"):
                i += 1
                continue
            tokens = line.split()
            if not tokens:
                i += 1
                continue

            keyword = tokens[0]
            if keyword == "KONSERVIERUNG_FORMAT":
                i += 1
                continue
            if keyword in self.BLOCK_KEYWORDS:
                param, i = self._parse_block(keyword, tokens, lines, i)
                if param:
                    parameters.append(param)
            else:
                i += 1
        return parameters

    def _parse_block(
        self, keyword: str, header_tokens: List[str], lines: List[str], start: int
    ) -> Tuple[Optional[DcmParameter], int]:
        name = header_tokens[1] if len(header_tokens) > 1 else ""
        size_x, size_y = 0, 0
        if keyword in ("FESTWERTEBLOCK", "KENNLINIE") and len(header_tokens) > 2:
            size_x = self._safe_int(header_tokens[2])
        elif keyword == "KENNFELD" and len(header_tokens) > 2:
            size_x = self._safe_int(header_tokens[2])
            if len(header_tokens) > 3:
                size_y = self._safe_int(header_tokens[3])

        param = DcmParameter(name=name, kind=keyword, size_x=size_x, size_y=size_y)
        i = start + 1
        while i < len(lines):
            line = lines[i].strip()
            if line == "END":
                i += 1
                break
            tokens = line.split(None, 1)
            if not tokens:
                i += 1
                continue
            fk = tokens[0]
            fv = tokens[1].strip() if len(tokens) > 1 else ""

            if fk == "LANGNAME":
                param.long_name = self._unquote(fv)
            elif fk == "DISPLAYNAME":
                param.display_name = self._unquote(fv)
            elif fk == "EINHEIT_W":
                param.unit_w = self._unquote(fv)
            elif fk == "EINHEIT_X":
                param.unit_x = self._unquote(fv)
            elif fk == "EINHEIT_Y":
                param.unit_y = self._unquote(fv)
            elif fk == "WERT":
                param.values.extend(fv.split())
            elif fk == "TEXT":
                param.is_text = True
                param.values.extend(self._parse_text_values(fv))
            elif fk == "ST/X":
                param.x_axis.extend(fv.split())
            elif fk == "ST/Y":
                param.y_axis.extend(fv.split())
            i += 1
        else:
            i = len(lines)
        return param, i

    @staticmethod
    def _safe_int(s: str) -> int:
        try:
            return int(s)
        except ValueError:
            return 0

    @staticmethod
    def _unquote(s: str) -> str:
        s = s.strip()
        if len(s) >= 2 and s[0] == '"' and s[-1] == '"':
            return s[1:-1]
        return s

    @staticmethod
    def _parse_text_values(s: str) -> List[str]:
        return re.findall(r'"([^"]*)"', s) or [s.strip()]


def load_dcm_files(dcm_paths: List[str], quiet: bool = False) -> Dict[str, List[DcmParameter]]:
    dcm_data: Dict[str, List[DcmParameter]] = {}
    for path in dcm_paths:
        stem = os.path.splitext(os.path.basename(path))[0]
        try:
            parser = DcmParser(path)
            params = parser.parse()
            dcm_data[stem] = params
            if not quiet:
                print(f"  Loaded {path} ({len(params)} parameters)")
        except Exception as e:
            if not quiet:
                print(f"  [ERROR] Failed to parse {path}: {e}")
    return dcm_data


def scan_all_dcm_files(dcm_dir: str) -> List[str]:
    """Recursively find all .dcm files in the directory tree."""
    results = []
    for root, dirs, files in os.walk(dcm_dir):
        for f in sorted(files):
            if f.lower().endswith(".dcm"):
                results.append(os.path.join(root, f))
    return results
