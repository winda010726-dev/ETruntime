"""Quantization converter — physical value to storage value conversion."""

import decimal
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from typing import Dict, Optional

from .models import PdlQuantization


class QuantizationConverter:
    """
    Converts physical values (from DCM) to storage values using
    quantization formulas from PDL.

    Algorithm (matching Java tool):
        resolution = 1 / quantFactor
        storage = round_half_up(physical / resolution) = round_half_up(physical * quantFactor)
    """

    def __init__(self, quantizations: Dict[str, PdlQuantization]):
        self.quantizations = quantizations

    def convert(self, physical_str: str, quant_name: str, is_float: bool = False) -> str:
        if not quant_name or quant_name not in self.quantizations:
            return physical_str

        q = self.quantizations[quant_name]
        if q.factor_value is None or q.factor_value == 0:
            return physical_str

        if is_float:
            return self._format_float(physical_str)

        try:
            physical = Decimal(physical_str)
        except (InvalidOperation, ValueError):
            return physical_str

        storage = physical * q.factor_value
        storage = storage.quantize(Decimal("1"), rounding=ROUND_HALF_UP)
        return str(storage)

    def get_resolution(self, quant_name: str) -> Optional[Decimal]:
        if quant_name not in self.quantizations:
            return None
        q = self.quantizations[quant_name]
        if q.factor_value is None or q.factor_value == 0:
            return None
        with decimal.localcontext() as ctx:
            ctx.prec = 34
            return Decimal(1) / q.factor_value

    def get_formula_string(self, quant_name: str) -> str:
        if quant_name not in self.quantizations:
            return ""
        q = self.quantizations[quant_name]
        return f"f(phys) = {q.factor_text} * phys"

    @staticmethod
    def _format_float(val_str: str) -> str:
        try:
            d = Decimal(val_str)
            f = float(d)
            if abs(f) >= 1e6 or (0 < abs(f) < 0.001):
                return f"{f:.6E}"
            return val_str
        except (InvalidOperation, ValueError):
            return val_str
