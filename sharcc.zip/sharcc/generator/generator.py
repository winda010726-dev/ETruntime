"""ParGen XML Generator — core XML generation logic."""

import math
import os
import re
import xml.etree.ElementTree as ET
from datetime import datetime
import decimal
from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, List, Optional, Set, Tuple
from xml.dom import minidom

from .models import (
    DcmParameter, MajorVariant, PdlClass, PdlCustomType, PdlEnumEntry,
    PdlEnumeration, PdlParameter, PdlQuantization, VariantDefinition,
)
from .component import PdlComponentBuilder
from .quantization import QuantizationConverter
from .variant import VariantResolver


class ParGenXmlGenerator:
    VERSION = "7.0"

    def __init__(
        self,
        major_variant_name: str,
        major_variant: Optional[MajorVariant],
        vardef: VariantDefinition,
        dcm_data: Dict[str, List[DcmParameter]],
        pdl_builder: Optional[PdlComponentBuilder],
        quant_converter: Optional[QuantizationConverter],
        global_types_map: Optional[Dict[str, Dict]] = None,
        global_enums_map: Optional[Dict[str, Dict]] = None,
        global_quant_formulas: Optional[Dict[str, str]] = None,
        related_variants: Optional[List[Tuple[str, "MajorVariant", Dict]]] = None,
        mapped_dcm_stems: Optional[Set[str]] = None,
        switch_dcm_data: Optional[Dict[str, List[DcmParameter]]] = None,
        pid_config: Optional[Dict[str, int]] = None,
        pid_block_lengths: Optional[Dict[str, int]] = None,
        float32_enabled: bool = True,
    ):
        self.major_variant_name = major_variant_name
        self.major_variant = major_variant
        self.vardef = vardef
        self.dcm_data = dcm_data
        self.pdl = pdl_builder
        self.qconv = quant_converter
        self.global_types_map = global_types_map or {}
        self.global_enums_map = global_enums_map or {}
        self.global_quant_formulas = global_quant_formulas or {}
        self.related_variants = related_variants or []
        self.mapped_dcm_stems = mapped_dcm_stems or set()
        self.pid_config: Dict[str, int] = pid_config or {}
        self.pid_block_lengths: Dict[str, int] = pid_block_lengths or {}
        self.float32_enabled = float32_enabled
        self.pid_errors: List[str] = []

        self._switch_by_short: Dict[str, DcmParameter] = {}
        for _stem, params in (switch_dcm_data or {}).items():
            for p in params:
                short = p.name.split(".")[-1]
                self._switch_by_short[short] = p

        self.dcm_param_index: Dict[str, Dict[str, DcmParameter]] = {}
        for dcm_stem, params in dcm_data.items():
            self.dcm_param_index[dcm_stem] = {p.name: p for p in params}

        # BUG-1 FIX: Build dcm_by_cluster and dcm_by_short_name ONLY from
        # pmavardef-mapped DCM stems. This prevents scan-all-dcm data from
        # overriding PDL defaults for parameters not explicitly configured.
        # v4.1 FIX: Also verify DCM package path matches PDL package path
        # to prevent cross-package collisions (e.g. rbp.hai.aci vs rbp.apc.aci).
        self._pdl_cluster_pkg = {
            k: v.replace("^", "") for k, v in self.pdl.cluster_to_package.items()
        } if self.pdl else {}
        self.dcm_by_cluster: Dict[str, Dict[str, DcmParameter]] = {}
        self.dcm_by_short_name: Dict[str, DcmParameter] = {}
        self._dcm_all_clusters: Set[str] = set()
        for dcm_stem, params in dcm_data.items():
            if self.mapped_dcm_stems and dcm_stem not in self.mapped_dcm_stems:
                continue
            for p in params:
                parts = p.name.split(".")
                if len(parts) >= 2:
                    cluster = parts[-2]
                    short = parts[-1]
                    self._dcm_all_clusters.add(cluster)
                    if cluster in self._pdl_cluster_pkg and len(parts) > 2:
                        dcm_pkg = ".".join(parts[:-2])
                        pdl_pkg = self._pdl_cluster_pkg[cluster]
                        if dcm_pkg != pdl_pkg:
                            continue
                    if cluster not in self.dcm_by_cluster:
                        self.dcm_by_cluster[cluster] = {}
                    self.dcm_by_cluster[cluster][short] = p
                    self.dcm_by_short_name[short] = p

        self._expr_env: Optional[Dict[str, float]] = None
        # ---- BEGIN CHANGE [v3.1-fix-3B-cache-cross-ctx] ----
        self._sv_cross_ctx_cache: Optional[Dict[Tuple[str, str], Dict[str, float]]] = None
        self._rv_expr_env_cache: Dict[str, Dict[str, float]] = {}
        self._rv_cross_ctx_cache: Dict[str, Dict[Tuple[str, str], Dict[str, float]]] = {}
        self._rv_sv_cluster_cache: Dict[str, Dict[str, List[Dict]]] = {}
        # ---- END CHANGE [v3.1-fix-3B-cache-cross-ctx] ----

    # ------------------------------------------------------------------
    # Expression evaluation environment
    # ------------------------------------------------------------------

    def _get_expression_env(self) -> Dict[str, float]:
        if self._expr_env is not None:
            return self._expr_env
        self._expr_env = self._build_expression_env()
        return self._expr_env

    # ---- BEGIN CHANGE [v3.1-fix-3A-env] ----
    def _build_expression_env(
        self, by_short: Optional[Dict[str, "DcmParameter"]] = None
    ) -> Dict[str, float]:
        """
        Build comprehensive name->value map for expression evaluation.

        When by_short is None (default), uses self.dcm_by_short_name
        (main variant). Pass a different by_short to build an env for
        a related variant.
        """
        if by_short is None:
            by_short = self.dcm_by_short_name
        # ---- END CHANGE [v3.1-fix-3A-env] ----
        env: Dict[str, float] = {"Pi": math.pi, "pi": math.pi}
        if not self.pdl:
            return env

        unresolved: Dict[str, str] = {}
        for _, p in self.pdl.all_exported_constants:
            if p.name and p.init_expression:
                unresolved[p.name] = p.init_expression
        for _, p in self.pdl.all_exported_params:
            if p.name and p.init_expression:
                unresolved[p.name] = p.init_expression
        for cls in self.pdl.cluster_to_pdlclass.values():
            for p in cls.parameters:
                if p.name and p.init_expression:
                    unresolved[p.name] = p.init_expression

        for name in list(unresolved.keys()):
            if name in by_short:
                dcm_p = by_short[name]
                if dcm_p.values and len(dcm_p.values) == 1:
                    try:
                        env[name] = float(dcm_p.values[0])
                    except (ValueError, TypeError):
                        pass

        for _ in range(10):
            progress = False
            for name, expr in list(unresolved.items()):
                if name in env:
                    continue
                stripped = expr.strip()
                if stripped.startswith("{"):
                    continue
                val = self._try_resolve_numeric(stripped, depth=0, env=env)
                if val is not None:
                    env[name] = val
                    progress = True
            if not progress:
                break

        return env

    def generate(self) -> str:
        self.pid_errors.clear()
        root = ET.Element("ParameterSet")
        self._add_info(root)
        self._add_constants(root)
        self._add_data_types(root)
        self._add_major_variant_list(root)
        self._add_component_list(root)

        raw = ET.tostring(root, encoding="unicode", xml_declaration=False)
        xml_body = self._pretty_print(raw)

        if self.pid_errors:
            comment_text = (
                "Following issues were detected during PID validation:\n"
                + "\n".join(self.pid_errors)
            )
            comment_block = f"<!--{comment_text}-->"
            decl_end = xml_body.find("?>")
            if decl_end >= 0:
                insert_pos = decl_end + 2
                xml_body = xml_body[:insert_pos] + "\n" + comment_block + xml_body[insert_pos:]
            else:
                xml_body = comment_block + "\n" + xml_body

        return xml_body

    # -- Info --
    def _add_info(self, root: ET.Element):
        info = ET.SubElement(root, "Info")
        now = datetime.now()
        ET.SubElement(info, "Version").text = self.VERSION
        ET.SubElement(info, "Year").text = str(now.year)
        ET.SubElement(info, "Month").text = str(now.month)
        ET.SubElement(info, "Day").text = str(now.day)
        ET.SubElement(info, "Hours").text = str(now.hour)
        ET.SubElement(info, "Minutes").text = str(now.minute)

    # -- Constants --
    def _add_constants(self, root: ET.Element):
        constants_elem = ET.SubElement(root, "Constants")
        if not self.pdl:
            return

        for comp_name, param in self.pdl.all_exported_constants:
            if param.is_virtual:
                continue
            c = ET.SubElement(constants_elem, "Constant")
            ET.SubElement(c, "Name").text = param.name
            type_in_model = self.pdl.get_type_in_model(param)
            ET.SubElement(c, "TypeInModel").text = type_in_model
            switch_val = self._get_switch_value(param.name)
            if switch_val is not None:
                val = switch_val
            else:
                val = self._eval_const_value(param)
            if not self.float32_enabled and type_in_model == "cont":
                try:
                    val = str(self._round_half_up(float(val)))
                except (ValueError, TypeError):
                    pass
            ET.SubElement(c, "Value").text = val
            ET.SubElement(c, "Description").text = param.description

    def _eval_const_value(self, param: PdlParameter) -> str:
        expr = param.init_expression.strip()
        if not expr:
            return "0"
        return self._eval_expression(expr)

    # ---- BEGIN CHANGE [v3.1-fix-3A-eval-expr] ----
    def _eval_expression(self, expr: str,
                         env: Optional[Dict[str, float]] = None) -> str:
        """Evaluate expression resolving named references from PDL constants/params."""
        if not expr:
            return "0"

        if env is None:
            env = self._get_expression_env()
        resolved = self._try_resolve_numeric(expr, depth=0, env=env)
        if resolved is not None:
            if resolved == int(resolved):
                return str(int(resolved))
            return str(resolved)
        return expr
    # ---- END CHANGE [v3.1-fix-3A-eval-expr] ----

    def _try_resolve_numeric(
        self, expr: str, depth: int = 0, env: Optional[Dict[str, float]] = None
    ) -> Optional[float]:
        # ---- BEGIN CHANGE [v3.1-fix-3B-depth] ----
        if depth > 20:
            return None
        # ---- END CHANGE [v3.1-fix-3B-depth] ----
        if env is None:
            env = {"Pi": math.pi, "pi": math.pi}

        text = expr.strip()
        if not text:
            return None

        lower = text.lower()
        if lower in ("true", "false"):
            return 1.0 if lower == "true" else 0.0

        text = re.sub(r'\{([^}]*)\}', r'\1', text)

        safe = text.replace(" ", "")
        if re.match(r'^-?[\d.eE+\-*/()]+$', safe):
            try:
                return float(eval(safe, {"__builtins__": {}}, {}))
            except Exception:
                return None

        # ---- BEGIN CHANGE [v3.1-fix-3B-perf-longexpr] ----
        # For long expressions (e.g. 60K+ MpAdaptThreshLimCurve elements),
        # skip the O(n*m) identifier replacement and go straight to the
        # recursive ternary evaluator which follows only one path.
        if len(text) > 5000:
            result = self._eval_pdl_ternary(text, env)
            return result

        resolved_text = text
        identifiers = re.findall(r'[a-zA-Z_]\w*', text)
        all_found = True
        for ident in identifiers:
            if ident in env:
                resolved_text = re.sub(r'\b' + re.escape(ident) + r'\b',
                                       str(env[ident]), resolved_text)
            elif ident not in ("Pi", "pi"):
                all_found = False

        if all_found:
            safe_resolved = resolved_text.replace(" ", "")
            if re.match(r'^-?[\d.eE+\-*/().]+$', safe_resolved):
                try:
                    return float(eval(safe_resolved, {"__builtins__": {}}, {}))
                except Exception:
                    pass

        safe_env = {k: v for k, v in env.items()}
        try:
            result = eval(text, {"__builtins__": {}}, safe_env)
            return float(result)
        except Exception:
            pass
        # ---- END CHANGE [v3.1-fix-3B-perf-longexpr] ----

        result = self._eval_pdl_ternary(text, env)
        if result is not None:
            return result

        return None

    # -- DataTypes --
    def _collect_referenced_types(self) -> Set[str]:
        """Collect type/quantization/enum names referenced in the PDL model.

        Mirrors Java's isReferencedObject (Xtext IReferenceFinder):
          - Enumerations/CustomTypes: referenced if any parameter uses them
          - Quantizations: referenced if any custom type OR parameter uses them
        Only considers classes that will actually appear in the XML output
        (i.e., classes with DCM data).
        """
        type_refs: Set[str] = set()
        quant_refs: Set[str] = set()
        if not self.pdl:
            return set()

        def _collect_from_param(p: PdlParameter):
            if p.type_name and p.type_name not in ("continuous", "cont", "discrete", "logical"):
                type_refs.add(p.type_name)
                if "." in p.type_name:
                    type_refs.add(p.type_name.rsplit(".", 1)[-1])
            if p.quantization_ref:
                quant_refs.add(p.quantization_ref)

        for comp_name in self.pdl.get_component_names():
            has_exports = comp_name in [cn for cn, p in self.pdl.all_exported_params
                                        if not p.is_virtual]
            if not self._component_has_dcm_data(comp_name) and not has_exports:
                continue
            for cls in self.pdl.get_classes_for_component(comp_name):
                for p in cls.parameters:
                    _collect_from_param(p)

        for _comp, p in self.pdl.all_exported_params:
            _collect_from_param(p)
        for _comp, p in self.pdl.all_exported_constants:
            _collect_from_param(p)

        for ct in self.pdl.all_custom_types.values():
            if ct.quantization_ref:
                quant_refs.add(ct.quantization_ref)

        for tinfo in self.global_types_map.values():
            q = tinfo.get("quant", "")
            if q and q != "ident":
                quant_refs.add(q)

        return type_refs | quant_refs

    def _add_data_types(self, root: ET.Element):
        dt = ET.SubElement(root, "DataTypes")
        if not self.pdl:
            return

        referenced = self._collect_referenced_types()

        for name, enum in self.pdl.all_enumerations.items():
            if name in referenced:
                self._add_enumeration(dt, enum)

        for name, q in self.pdl.all_quantizations.items():
            if name in referenced:
                self._add_quantization(dt, q)

        for name, ct in self.pdl.all_custom_types.items():
            if name in referenced:
                self._add_custom_type(dt, ct)

        emitted = {name for name in self.pdl.all_custom_types}
        emitted.update(self.pdl.all_enumerations.keys())
        emitted.update(self.pdl.all_quantizations.keys())
        for tname, tinfo in self.global_types_map.items():
            if tname not in emitted and tname in referenced:
                ct = PdlCustomType(
                    name=tname,
                    base_type="continuous" if tinfo.get("kind") in ("cont", "continuous") else tinfo.get("kind", ""),
                    range_min=str(tinfo.get("min", "0")),
                    range_max=str(tinfo.get("max", "0")),
                    quantization_ref=tinfo.get("quant", ""),
                    unit_ref=tinfo.get("unit", ""),
                    description=tinfo.get("description", ""),
                )
                self._add_custom_type(dt, ct)
                emitted.add(tname)
        for ename, einfo in self.global_enums_map.items():
            if ename not in emitted and ename in referenced:
                enum = PdlEnumeration(name=ename)
                for lit in einfo.get("literals", []):
                    try:
                        val = int(lit["value"])
                    except (ValueError, KeyError):
                        val = 0
                    enum.entries.append(PdlEnumEntry(name=lit["name"], value=val))
                self._add_enumeration(dt, enum)
                emitted.add(ename)

    def _add_enumeration(self, parent: ET.Element, enum: PdlEnumeration):
        e = ET.SubElement(parent, "Enumeration")
        ET.SubElement(e, "Name").text = enum.name
        ET.SubElement(e, "Basetype").text = ""
        ET.SubElement(e, "Description").text = enum.description or ""
        lits = ET.SubElement(e, "Literals")
        for entry in enum.entries:
            lit = ET.SubElement(lits, "Literal")
            ET.SubElement(lit, "Name").text = entry.name
            ET.SubElement(lit, "Value").text = str(entry.value if entry.value is not None else 0)

    def _add_quantization(self, parent: ET.Element, q: PdlQuantization):
        qe = ET.SubElement(parent, "Quantization")
        ET.SubElement(qe, "Name").text = q.name
        formula = f"f(phys) = {q.factor_text} * phys" if q.factor_text else ""
        ET.SubElement(qe, "Formula").text = formula

    def _add_custom_type(self, parent: ET.Element, ct: PdlCustomType):
        cte = ET.SubElement(parent, "CustomType")
        ET.SubElement(cte, "Name").text = ct.name
        ET.SubElement(cte, "TypeInPlatform").text = self._compute_platform_type(ct)
        ET.SubElement(cte, "Description").text = ct.description or ""

        rng = ET.SubElement(cte, "Range")
        ET.SubElement(rng, "Min").text = self._format_range_value(ct.range_min) or "0"
        ET.SubElement(rng, "Max").text = self._format_range_value(ct.range_max) or "0"

        ET.SubElement(cte, "Offset").text = "0"

        if ct.quantization_ref:
            ET.SubElement(cte, "Quantization").text = ct.quantization_ref

        resolution = ""
        qref = ct.quantization_ref
        if qref and qref not in ("ident", "NoQuant"):
            if self.qconv:
                res = self.qconv.get_resolution(qref)
                if res is not None:
                    resolution = self._format_resolution(res)
            if not resolution and qref in self.global_quant_formulas:
                factor = self._eval_global_quant_factor(self.global_quant_formulas[qref])
                if factor and factor != 0:
                    with decimal.localcontext() as ctx:
                        ctx.prec = 34
                        resolution = self._format_resolution(Decimal(1) / Decimal(str(factor)))
        if not resolution:
            resolution = "1"
        ET.SubElement(cte, "Resolution").text = resolution

        unit = ct.unit_ref
        if unit.startswith('"') and unit.endswith('"'):
            unit = unit[1:-1]
        ET.SubElement(cte, "Unit").text = unit

    @staticmethod
    def _format_range_value(val: str) -> str:
        if not val:
            return val
        if 'E' in val.upper() or 'e' in val:
            try:
                d = Decimal(val)
                return format(d, 'f')
            except Exception:
                pass
        return val

    def _compute_platform_type(self, ct: PdlCustomType) -> str:
        try:
            rmin = float(ct.range_min) if ct.range_min else 0.0
            rmax = float(ct.range_max) if ct.range_max else 0.0
        except ValueError:
            return ""
        factor = 1.0
        qref = ct.quantization_ref
        if qref and qref != "ident":
            if self.qconv and qref in self.qconv.quantizations:
                q = self.qconv.quantizations[qref]
                if q.factor_value and float(q.factor_value) != 0:
                    factor = float(q.factor_value)
            elif qref in self.global_quant_formulas:
                factor = self._eval_global_quant_factor(self.global_quant_formulas[qref])
        machine_min = rmin * factor
        machine_max = rmax * factor
        _TYPES = [
            ("UInt8", 0, 255),
            ("SInt8", -128, 127),
            ("UInt16", 0, 65535),
            ("SInt16", -32768, 32767),
            ("UInt32", 0, 4294967295),
            ("SInt32", -2147483648, 2147483647),
        ]
        for tname, tmin, tmax in _TYPES:
            if machine_min < 0 and tmin >= 0:
                continue
            if tmin <= machine_min and machine_max <= tmax:
                return tname
        return "SInt32"

    def _all_variant_names(self) -> List[str]:
        names = [self.major_variant_name]
        for rv_name, _, _ in self.related_variants:
            if rv_name not in names:
                names.append(rv_name)
        return names

    # -- MajorVariantList --
    def _add_major_variant_list(self, root: ET.Element):
        mvl = ET.SubElement(root, "MajorVariantList")
        for vn in self._all_variant_names():
            ET.SubElement(mvl, "MajorVariant").text = vn

    # -- ComponentList --
    def _add_component_list(self, root: ET.Element):
        comp_list = ET.SubElement(root, "ComponentList")

        if self.pdl and self.pdl.get_component_names():
            self._add_components_from_pdl(comp_list)
        elif self.major_variant:
            self._add_components_from_vardef(comp_list)

    def _build_sv_cluster_data(
        self, dcm_variant_map: Dict[str, List[Dict]]
    ) -> Tuple[Dict[str, List[Dict]], Dict[str, List[Dict]]]:
        sv_cluster_data: Dict[str, List[Dict]] = {}
        allsub_cluster_data: Dict[str, List[Dict]] = {}

        for dcm_stem, entries in dcm_variant_map.items():
            for entry in entries:
                minor = entry.get("minor", "")
                sub = entry.get("sub", "")
                if not minor:
                    continue

                fqn_params = self.dcm_param_index.get(dcm_stem, {})
                params_by_cluster: Dict[str, Dict[str, DcmParameter]] = {}
                for fqn, dcm_p in fqn_params.items():
                    parts = fqn.split(".")
                    if len(parts) >= 2:
                        cluster = parts[-2]
                        short = parts[-1]
                        params_by_cluster.setdefault(cluster, {})[short] = dcm_p

                target = allsub_cluster_data if not sub else sv_cluster_data

                for cluster_name, cl_params in params_by_cluster.items():
                    if cluster_name not in target:
                        target[cluster_name] = []
                    existing_minor = None
                    for m in target[cluster_name]:
                        if m["minor_name"] == minor:
                            existing_minor = m
                            break
                    if existing_minor is None:
                        existing_minor = {"minor_name": minor, "subvariants": []}
                        target[cluster_name].append(existing_minor)
                    existing_sub = None
                    for s in existing_minor["subvariants"]:
                        if s["name"] == sub:
                            existing_sub = s
                            break
                    if existing_sub is None:
                        existing_minor["subvariants"].append({
                            "name": sub,
                            "params": cl_params,
                        })
                    else:
                        for pname, pval in cl_params.items():
                            if pname not in existing_sub["params"]:
                                existing_sub["params"][pname] = pval

        for store in (sv_cluster_data, allsub_cluster_data):
            for cl_name in store:
                store[cl_name].sort(key=lambda m: m["minor_name"])
                for m in store[cl_name]:
                    m["subvariants"].sort(key=lambda s: s["name"])

        return sv_cluster_data, allsub_cluster_data

    def _cluster_has_dcm_data(self, cluster_name: str) -> bool:
        if cluster_name in self._dcm_all_clusters:
            return True
        for rv_name, rv_obj, rv_dcm_data in self.related_variants:
            for dcm_stem, rparams in rv_dcm_data.items():
                for p in rparams:
                    parts = p.name.split(".")
                    if len(parts) >= 2 and parts[-2] == cluster_name:
                        return True
        return False

    def _component_has_dcm_data(self, comp_name: str) -> bool:
        classes = self.pdl.get_classes_for_component(comp_name) if self.pdl else []
        for cls in classes:
            if self._cluster_has_dcm_data(cls.name):
                return True
        return comp_name in [cn for cn, p in self.pdl.all_exported_params
                              if not p.is_virtual]

    def _add_components_from_pdl(self, comp_list: ET.Element):
        dcm_variant_map: Dict[str, List[Dict]] = {}
        if self.major_variant:
            resolver = VariantResolver(self.vardef, "")
            dcm_variant_map = resolver.collect_dcm_names_for_variant(
                self.major_variant, self.vardef
            )

        sv_cluster_data, allsub_cluster_data = self._build_sv_cluster_data(dcm_variant_map)

        for comp_name in self.pdl.get_component_names():
            classes = self.pdl.get_classes_for_component(comp_name)
            has_exports = comp_name in [cn for cn, p in self.pdl.all_exported_params
                                       if not p.is_virtual]
            if not classes and not has_exports:
                continue
            if not self._component_has_dcm_data(comp_name) and not has_exports:
                continue

            comp_elem = ET.SubElement(comp_list, "Component")
            ET.SubElement(comp_elem, "Name").text = comp_name

            dl = ET.SubElement(comp_elem, "DefineList")
            for cn, param in self.pdl.all_exported_params:
                if cn == comp_name and not param.is_virtual:
                    self._add_define(dl, param)

            pcl = ET.SubElement(comp_elem, "ParameterClusterList")
            class_param_names = {}
            for cls in classes:
                pnames = {p.name for p in cls.parameters
                          if not p.is_virtual and not p.is_constant}
                if pnames:
                    class_param_names[cls.name] = pnames

            for cls in classes:
                non_virtual = [p for p in cls.parameters if not p.is_virtual and not p.is_constant]
                if not non_virtual:
                    continue
                is_enum_subclass = False
                for pn, pparam_names in class_param_names.items():
                    if cls.name != pn and cls.name.startswith(pn + "_"):
                        suffix = cls.name[len(pn) + 1:]
                        my_params = class_param_names.get(cls.name, set())
                        expected = {suffix + "_" + p for p in my_params}
                        if expected.issubset(pparam_names):
                            is_enum_subclass = True
                            break
                if is_enum_subclass:
                    continue
                self._add_cluster_from_pdl(pcl, cls, sv_cluster_data, allsub_cluster_data)

    def _get_switch_value(self, param_name: str) -> Optional[str]:
        """Look up a Switch DCM value by short name (TEXT or numeric FESTWERT)."""
        dp = self._switch_by_short.get(param_name)
        if dp and dp.values:
            if dp.is_text:
                return dp.values[0]
            raw = dp.values[0]
            try:
                fv = float(raw)
                return str(int(fv)) if fv == int(fv) else str(fv)
            except (ValueError, OverflowError):
                return raw
        return None

    def _resolve_enum_literal(self, param: PdlParameter) -> Optional[str]:
        """If init_expression is 'TypeName.Literal', return the literal name."""
        expr = (param.init_expression or "").strip()
        if "." in expr and not any(op in expr for op in ("+", "-", "*", "/", "(", "?", ":")):
            parts = expr.split(".", 1)
            if len(parts) == 2 and parts[0] and parts[1]:
                type_name = parts[0].strip()
                literal = parts[1].strip()
                if self.pdl and type_name in self.pdl.all_enumerations:
                    return literal
                if type_name in self.global_enums_map:
                    return literal
        return None

    def _add_define(self, parent: ET.Element, param: PdlParameter):
        d = ET.SubElement(parent, "Define")
        ET.SubElement(d, "Name").text = param.name
        type_in_model = self.pdl.get_type_in_model(param)
        ET.SubElement(d, "TypeInModel").text = type_in_model
        if type_in_model == "disc":
            ET.SubElement(d, "TypeInPlatform").text = "SInt32"
        switch_val = self._get_switch_value(param.name)
        if switch_val is not None:
            val = switch_val
        else:
            enum_lit = self._resolve_enum_literal(param)
            if enum_lit is not None:
                val = enum_lit
            else:
                val = self._eval_const_value(param)
        ET.SubElement(d, "Value").text = val
        ET.SubElement(d, "Scope").text = "global"
        ET.SubElement(d, "ExternalOverwrite").text = "yes"
        ET.SubElement(d, "Description").text = param.description

    def _get_cluster_description(self, cls: PdlClass) -> str:
        """Cluster description from PDL Javadoc (matching Java's PdlDescriptionProvider)."""
        if cls.description:
            return cls.description
        return ""

    def _get_param_description(self, param: PdlParameter, cluster_name: str) -> str:
        """Parameter DESCRIPTION from PDL Javadoc only (no DCM fallback).

        Java uses IEObjectDocumentationProvider which only returns PDL
        doc-comments; it has no DCM LANGNAME fallback.
        """
        if param.description:
            return param.description
        return ""

    _TYPE_BYTE_SIZES = {
        "UInt8": 1, "SInt8": 1, "Boolean": 1,
        "UInt16": 2, "SInt16": 2,
        "UInt32": 4, "SInt32": 4, "Float32": 4,
        "Float64": 8,
    }

    def _estimate_cluster_byte_size(self, cls: PdlClass) -> int:
        """Estimate byte size of a cluster's parameters (for PID validation).

        Java calculates ``PlatformType.getSizeInBit() / 8`` per element,
        then multiplies by the array size.  We replicate this by resolving
        each parameter's platform type through the custom-type mapping.
        """
        total = 0
        for p in cls.parameters:
            if p.is_virtual or p.is_constant:
                continue
            platform_type = self._resolve_platform_type_for_param(p)
            sz = self._TYPE_BYTE_SIZES.get(platform_type, 1)
            count = p.array_size if p.array_size > 0 else 1
            total += sz * count
        return total

    _PLATFORM_TYPE_RE = re.compile(
        r"(UInt8|SInt8|Boolean|UInt16|SInt16|UInt32|SInt32|Float32|Float64)"
    )

    def _resolve_platform_type_for_param(self, p: PdlParameter) -> str:
        """Resolve the platform type name for a single parameter.

        For standard types (``Type_UInt32`` etc.) strips the ``Type_`` prefix.
        For custom types resolves the underlying platform type through the
        global type map, ``_compute_platform_type``, or by extracting a
        known platform type name embedded in the type name.
        """
        if not self.pdl:
            return ""
        tim = self.pdl.get_type_in_model(p)
        if not tim:
            return ""
        base = tim.rsplit(".", 1)[-1] if "." in tim else tim
        if base.startswith("Type_"):
            stripped = base[5:]
            if stripped in self._TYPE_BYTE_SIZES:
                return stripped
        if base in self._TYPE_BYTE_SIZES:
            return base
        for lookup_name in (base, base[5:] if base.startswith("Type_") else base):
            ct = self.global_types_map.get(lookup_name)
            if ct:
                qref = ct.get("quant", "")
                rmin = str(ct.get("min", "0"))
                rmax = str(ct.get("max", "0"))
                tmp = PdlCustomType(name=lookup_name, range_min=rmin, range_max=rmax,
                                    quantization_ref=qref)
                pt = self._compute_platform_type(tmp)
                if pt:
                    return pt
        m = self._PLATFORM_TYPE_RE.search(base)
        if m:
            return m.group(1)
        type_name = p.type_name.rsplit(".", 1)[-1] if "." in p.type_name else p.type_name
        m2 = self._PLATFORM_TYPE_RE.search(type_name)
        if m2:
            return m2.group(1)
        return ""

    def _get_cluster_pid(self, cluster_name: str, cls: Optional[PdlClass] = None) -> Optional[str]:
        """Return PID string, empty string, or *None*.

        - Returns the PID number as a string when configured and valid.
        - Returns ``""`` when no PID is configured (caller keeps the
          ``<PID></PID>`` element).
        - Returns ``None`` when byte-size validation fails (caller must
          omit the ``<PID>`` element entirely, matching Java's
          ``setPID(null)`` behaviour).
        """
        if cluster_name not in self.pid_config:
            return ""
        if cls is not None and cluster_name in self.pid_block_lengths:
            computed = self._estimate_cluster_byte_size(cls)
            block_len = self.pid_block_lengths[cluster_name]
            if computed != block_len:
                self.pid_errors.append(
                    f"Size of parameter cluster '{cluster_name}' "
                    f"(size {computed}) doesn't match the Fee block "
                    f"length of {block_len}"
                )
                return None
        return str(self.pid_config[cluster_name])

    def _add_cluster_from_pdl(
        self,
        parent: ET.Element,
        cls: PdlClass,
        sv_cluster_data: Dict[str, List[Dict]],
        allsub_cluster_data: Optional[Dict[str, List[Dict]]] = None,
    ):
        pc = ET.SubElement(parent, "ParameterCluster")
        ET.SubElement(pc, "Name").text = cls.name

        mem = self.pdl.get_memory_type(cls.name) if self.pdl else "ROM"
        ET.SubElement(pc, "MemoryArea").text = mem

        params = [p for p in cls.parameters if not p.is_virtual and not p.is_constant]

        has_sv = cls.name in sv_cluster_data
        ET.SubElement(pc, "VariantApplication").text = (
            "MINOR_ALL" if has_sv else "SINGLE"
        )
        pid_val = self._get_cluster_pid(cls.name, cls)
        if pid_val is not None:
            ET.SubElement(pc, "PID").text = pid_val
        ET.SubElement(pc, "Description").text = self._get_cluster_description(cls)

        pd_list = ET.SubElement(pc, "ParameterDefinitionList")
        for param in params:
            pd = ET.SubElement(pd_list, "ParameterDefinition")
            ET.SubElement(pd, "Name").text = param.name
            ET.SubElement(pd, "TypeInModel").text = self.pdl.get_type_in_model(param)
            num = param.array_size if param.array_size > 0 else 1
            ET.SubElement(pd, "Number").text = str(num)
            ET.SubElement(pd, "DESCRIPTION").text = self._get_param_description(param, cls.name)
            cal = ET.SubElement(pd, "CANAPE_ALIAS_LIST")
            for alias in param.aliases:
                ET.SubElement(cal, "CANAPE_ALIAS").text = alias
            if param.type_kind == "logical":
                ET.SubElement(pd, "TypeInPlatform").text = "Boolean"
            ET.SubElement(pd, "Disclosure").text = "internal"

        allsub_data = (allsub_cluster_data or {}).get(cls.name)

        vi_list = ET.SubElement(pc, "VariantImlementationList")
        self._add_variant_impl_pdl(
            vi_list, params, cls.name, sv_cluster_data.get(cls.name),
            allsub_data=allsub_data
        )

    @staticmethod
    def _build_sv_ctx(sv_params: Dict[str, "DcmParameter"]) -> Dict[str, float]:
        """Build a name->float context from SubVariant DCM params for expression evaluation."""
        ctx: Dict[str, float] = {}
        for pname, dp in sv_params.items():
            if dp.values and len(dp.values) == 1:
                try:
                    ctx[pname] = float(dp.values[0])
                except (ValueError, TypeError):
                    pass
        return ctx

    # ------------------------------------------------------------------
    # v3: Generate-then-compare (mirrors Java VariantImplementationCreator)
    # ------------------------------------------------------------------

    @staticmethod
    def _compare_vi_trees(vi1: ET.Element, vi2: ET.Element) -> int:
        """Compare two VariantImlementation subtrees by their MinorVariantList.

        Mirrors Java's MinorVariantComparator -> SubVariantComparator
        -> ParameterValueComparator chain.
        Returns 0 if identical, 1 if different.
        """
        mvl1 = vi1.find("MinorVariantList")
        mvl2 = vi2.find("MinorVariantList")
        if mvl1 is None or mvl2 is None:
            return 0 if (mvl1 is None and mvl2 is None) else 1

        minors1 = mvl1.findall("MinorVariant")
        minors2 = mvl2.findall("MinorVariant")
        if len(minors1) != len(minors2):
            return 1

        for m1, m2 in zip(minors1, minors2):
            n1 = m1.findtext("Name", "")
            n2 = m2.findtext("Name", "")
            if n1 != n2:
                return 1

            svl1 = m1.find("SubVariantList")
            svl2 = m2.find("SubVariantList")
            subs1 = svl1.findall("SubVariant") if svl1 is not None else []
            subs2 = svl2.findall("SubVariant") if svl2 is not None else []
            if len(subs1) != len(subs2):
                return 1

            for s1, s2 in zip(subs1, subs2):
                sn1 = s1.findtext("Name", "")
                sn2 = s2.findtext("Name", "")
                if sn1 != sn2:
                    return 1

                pvl1 = s1.find("ParameterValueList")
                pvl2 = s2.find("ParameterValueList")
                pvs1 = pvl1.findall("ParameterValue") if pvl1 is not None else []
                pvs2 = pvl2.findall("ParameterValue") if pvl2 is not None else []
                if len(pvs1) != len(pvs2):
                    return 1

                for p1, p2 in zip(pvs1, pvs2):
                    vl1_elem = p1.find("ValueList")
                    vl2_elem = p2.find("ValueList")
                    if vl1_elem is None or vl2_elem is None:
                        if vl1_elem is not vl2_elem:
                            return 1
                        continue
                    vals1 = [v.text or "" for v in vl1_elem.findall("Value")]
                    vals2 = [v.text or "" for v in vl2_elem.findall("Value")]
                    if vals1 != vals2:
                        return 1
        return 0

    def _add_variant_impl_pdl(
        self,
        parent: ET.Element,
        params: List[PdlParameter],
        cluster_name: str = "",
        sv_data: Optional[List[Dict]] = None,
        allsub_data: Optional[List[Dict]] = None,
    ):
        # ---- BEGIN CHANGE [v3.1-fix-3B-build-cross-ctx] (cached) ----
        if self._sv_cross_ctx_cache is None:
            if self.major_variant:
                main_resolver = VariantResolver(self.vardef, "")
                main_dcm_map = main_resolver.collect_dcm_names_for_variant(
                    self.major_variant, self.vardef
                )
                self._sv_cross_ctx_cache = self._build_sv_cross_cluster_ctx(
                    main_dcm_map, self.dcm_data
                )
            else:
                self._sv_cross_ctx_cache = {}

        variant_configs = [
            (self.major_variant_name, self.dcm_by_cluster,
             self.dcm_by_short_name, sv_data, self._sv_cross_ctx_cache)
        ]
        # ---- END CHANGE [v3.1-fix-3B-build-cross-ctx] (cached) ----
        for rv_name, rv_obj, rv_dcm_data in self.related_variants:
            rv_by_cluster: Dict[str, Dict[str, DcmParameter]] = {}
            rv_by_short: Dict[str, DcmParameter] = {}
            for dcm_stem, rparams in rv_dcm_data.items():
                if self.mapped_dcm_stems and dcm_stem not in self.mapped_dcm_stems:
                    continue
                for p in rparams:
                    parts = p.name.split(".")
                    if len(parts) >= 2:
                        cl = parts[-2]
                        sh = parts[-1]
                        if cl in self._pdl_cluster_pkg and len(parts) > 2:
                            dcm_pkg = ".".join(parts[:-2])
                            if dcm_pkg != self._pdl_cluster_pkg[cl]:
                                continue
                        rv_by_cluster.setdefault(cl, {})[sh] = p
                        rv_by_short[sh] = p
            rv_sv_data = None
            # ---- BEGIN CHANGE [v3.1-fix-3B-rv-cross-ctx] (cached) ----
            rv_sv_cross_ctx = self._rv_cross_ctx_cache.get(rv_name)
            if rv_sv_cross_ctx is None:
                rv_sv_cross_ctx = {}
            # ---- END CHANGE [v3.1-fix-3B-rv-cross-ctx] ----
            if rv_obj:
                # ---- BEGIN CHANGE [v3.1-fix-perf-rv-cache] ----
                if rv_name not in self._rv_sv_cluster_cache:
                    rv_resolver = VariantResolver(self.vardef, "")
                    rv_dcm_variant_map = rv_resolver.collect_dcm_names_for_variant(rv_obj, self.vardef)
                    self._rv_sv_cluster_cache[rv_name] = self._build_sv_cluster_data_with_dcm(
                        rv_dcm_variant_map, rv_dcm_data
                    )
                    self._rv_cross_ctx_cache[rv_name] = self._build_sv_cross_cluster_ctx(
                        rv_dcm_variant_map, rv_dcm_data
                    )
                rv_sv_cluster = self._rv_sv_cluster_cache[rv_name]
                rv_sv_data = rv_sv_cluster.get(cluster_name)
                rv_sv_cross_ctx = self._rv_cross_ctx_cache[rv_name]
                # ---- END CHANGE [v3.1-fix-perf-rv-cache] ----
            variant_configs.append((rv_name, rv_by_cluster, rv_by_short,
                                    rv_sv_data, rv_sv_cross_ctx))

        # Step 1: Generate full XML subtree for each MajorVariant independently
        # ---- BEGIN CHANGE [v3.1-fix-3A-per-variant-env] ----
        generated: List[Tuple[str, ET.Element]] = []
        for vn, v_by_cl, v_by_sh, v_sv_data, v_sv_cross in variant_configs:
            # Main variant uses cached env; related variants get their own
            if v_by_sh is self.dcm_by_short_name:
                v_expr_env = None  # will use cached self._get_expression_env()
            else:
                v_expr_env = self._build_expression_env(by_short=v_by_sh)
            temp_vi = ET.Element("VariantImlementation")
            self._write_single_variant_values(
                temp_vi, params, cluster_name, v_by_cl, v_by_sh, v_sv_data,
                variant_expr_env=v_expr_env,
                sv_cross_ctx=v_sv_cross,
                allsub_data=allsub_data,
            )
            generated.append((vn, temp_vi))
        # ---- END CHANGE [v3.1-fix-3A-per-variant-env] ----

        # Step 2: Compare rendered output and merge duplicates
        # (mirrors Java's findDuplicate using MinorVariantComparator chain)
        merged_groups: List[Tuple[List[str], ET.Element]] = []
        for vn, vi_elem in generated:
            duplicate = None
            for group in merged_groups:
                if self._compare_vi_trees(group[1], vi_elem) == 0:
                    duplicate = group
                    break
            if duplicate is not None:
                duplicate[0].append(vn)
            else:
                merged_groups.append(([vn], vi_elem))

        # Step 3: Write merged results to parent
        for names, vi_elem in merged_groups:
            vi = ET.SubElement(parent, "VariantImlementation")
            mvl = ET.SubElement(vi, "MajorVariantList")
            for n in sorted(names):
                ET.SubElement(mvl, "MajorVariant").text = n
            for child in list(vi_elem):
                vi.append(child)

    # ---- BEGIN CHANGE [v3.1-fix-3B-cross-cluster-ctx] ----
    def _build_sv_cross_cluster_ctx(
        self,
        dcm_variant_map: Dict[str, List[Dict]],
        dcm_data: Dict[str, List[DcmParameter]],
    ) -> Dict[Tuple[str, str], Dict[str, float]]:
        """Build (minor, sub) → {short_name: float_value} across ALL clusters.

        Used to provide full SubVariant context for expression evaluation,
        so expressions in one cluster can reference params from other clusters
        mapped to the same SubVariant (e.g. SensPosZloaded from Global_SensPos
        used in MpAdaptThreshLimCurve.Codegroup1).
        """
        # Pre-build enum reverse lookup: member_name → numeric_value
        enum_val_map: Dict[str, float] = {}
        if self.pdl:
            for _, enum in self.pdl.all_enumerations.items():
                for entry in enum.entries:
                    if entry.value is not None:
                        enum_val_map[entry.name] = float(entry.value)

        dcm_param_idx = {stem: {p.name: p for p in params} for stem, params in dcm_data.items()}
        ctx: Dict[Tuple[str, str], Dict[str, float]] = {}
        for dcm_stem, entries in dcm_variant_map.items():
            for entry in entries:
                minor = entry.get("minor", "")
                sub = entry.get("sub", "")
                if not minor:
                    continue
                key = (minor, sub)
                if key not in ctx:
                    ctx[key] = {}
                fqn_params = dcm_param_idx.get(dcm_stem, {})
                for fqn, dcm_p in fqn_params.items():
                    parts = fqn.split(".")
                    if len(parts) >= 2:
                        short = parts[-1]
                        if dcm_p.values and len(dcm_p.values) == 1:
                            val_str = dcm_p.values[0]
                            try:
                                ctx[key][short] = float(val_str)
                            except (ValueError, TypeError):
                                # Resolve enum member names to numeric values
                                if val_str in enum_val_map:
                                    ctx[key][short] = enum_val_map[val_str]
        return ctx
    # ---- END CHANGE [v3.1-fix-3B-cross-cluster-ctx] ----

    def _build_sv_cluster_data_with_dcm(
        self, dcm_variant_map: Dict[str, List[Dict]], dcm_data: Dict[str, List[DcmParameter]]
    ) -> Dict[str, List[Dict]]:
        dcm_param_idx = {stem: {p.name: p for p in params} for stem, params in dcm_data.items()}
        sv_cluster_data: Dict[str, List[Dict]] = {}
        for dcm_stem, entries in dcm_variant_map.items():
            for entry in entries:
                minor = entry.get("minor", "")
                sub = entry.get("sub", "")
                if not minor:
                    continue
                fqn_params = dcm_param_idx.get(dcm_stem, {})
                params_by_cluster: Dict[str, Dict[str, DcmParameter]] = {}
                for fqn, dcm_p in fqn_params.items():
                    parts = fqn.split(".")
                    if len(parts) >= 2:
                        params_by_cluster.setdefault(parts[-2], {})[parts[-1]] = dcm_p
                for cl_name, cl_params in params_by_cluster.items():
                    if cl_name not in sv_cluster_data:
                        sv_cluster_data[cl_name] = []
                    existing_minor = None
                    for m in sv_cluster_data[cl_name]:
                        if m["minor_name"] == minor:
                            existing_minor = m
                            break
                    if existing_minor is None:
                        existing_minor = {"minor_name": minor, "subvariants": []}
                        sv_cluster_data[cl_name].append(existing_minor)
                    existing_sub = None
                    for s in existing_minor["subvariants"]:
                        if s["name"] == sub:
                            existing_sub = s
                            break
                    if existing_sub is None:
                        existing_minor["subvariants"].append({"name": sub, "params": cl_params})
                    else:
                        for pname, pval in cl_params.items():
                            if pname not in existing_sub["params"]:
                                existing_sub["params"][pname] = pval

        for cl_name in sv_cluster_data:
            sv_cluster_data[cl_name].sort(key=lambda m: m["minor_name"])
            for m in sv_cluster_data[cl_name]:
                m["subvariants"].sort(key=lambda s: s["name"])

        return sv_cluster_data

    # ---- BEGIN CHANGE [v3.1-fix-3A-write-sv] ----
    def _write_single_variant_values(
        self, vi: ET.Element, params: List[PdlParameter], cluster_name: str,
        by_cluster: Dict, by_short: Dict, sv_data: Optional[List[Dict]],
        variant_expr_env: Optional[Dict[str, float]] = None,
        sv_cross_ctx: Optional[Dict[Tuple[str, str], Dict[str, float]]] = None,
        allsub_data: Optional[List[Dict]] = None,
    ):
        # ---- END CHANGE [v3.1-fix-3A-write-sv] ----
        minor_list = ET.SubElement(vi, "MinorVariantList")
        if sv_data:
            for minor_info in sv_data:
                minor_elem = ET.SubElement(minor_list, "MinorVariant")
                ET.SubElement(minor_elem, "Name").text = minor_info["minor_name"]
                sv_list = ET.SubElement(minor_elem, "SubVariantList")
                for sv_info in minor_info["subvariants"]:
                    sub_elem = ET.SubElement(sv_list, "SubVariant")
                    ET.SubElement(sub_elem, "Name").text = sv_info["name"]
                    pv_list = ET.SubElement(sub_elem, "ParameterValueList")
                    sv_ctx = self._build_sv_ctx(sv_info["params"])
                    # ---- BEGIN CHANGE [v3.1-fix-3B-merge-cross-ctx] ----
                    if sv_cross_ctx:
                        cross_key = (minor_info["minor_name"], sv_info["name"])
                        cross_params = sv_cross_ctx.get(cross_key, {})
                        for k, v in cross_params.items():
                            if k not in sv_ctx:
                                sv_ctx[k] = v
                    # ---- END CHANGE [v3.1-fix-3B-merge-cross-ctx] ----
                    for param in params:
                        pv = ET.SubElement(pv_list, "ParameterValue")
                        vl = ET.SubElement(pv, "ValueList")
                        raw_values = []
                        dcm_p = sv_info["params"].get(param.name)
                        if dcm_p and dcm_p.values:
                            raw_values = dcm_p.values
                        else:
                            raw_values = self._get_dcm_values_from(param.name, cluster_name, by_cluster, by_short)
                        for cv in self._convert_values(param, raw_values, cluster_name,
                                                       context_env=sv_ctx, base_env=variant_expr_env):
                            ET.SubElement(vl, "Value").text = cv
        elif allsub_data:
            for minor_info in allsub_data:
                minor_elem = ET.SubElement(minor_list, "MinorVariant")
                ET.SubElement(minor_elem, "Name").text = minor_info["minor_name"]
                sv_list = ET.SubElement(minor_elem, "SubVariantList")
                sub_elem = ET.SubElement(sv_list, "SubVariant")
                ET.SubElement(sub_elem, "Name").text = ""
                pv_list = ET.SubElement(sub_elem, "ParameterValueList")
                sv_ctx = {}
                if minor_info["subvariants"]:
                    sv_ctx = self._build_sv_ctx(minor_info["subvariants"][0].get("params", {}))
                for param in params:
                    pv = ET.SubElement(pv_list, "ParameterValue")
                    vl = ET.SubElement(pv, "ValueList")
                    raw_values = []
                    if minor_info["subvariants"]:
                        dcm_p = minor_info["subvariants"][0].get("params", {}).get(param.name)
                        if dcm_p and dcm_p.values:
                            raw_values = dcm_p.values
                    if not raw_values:
                        raw_values = self._get_dcm_values_from(param.name, cluster_name, by_cluster, by_short)
                    for cv in self._convert_values(param, raw_values, cluster_name,
                                                   context_env=sv_ctx, base_env=variant_expr_env):
                        ET.SubElement(vl, "Value").text = cv
        else:
            minor_elem = ET.SubElement(minor_list, "MinorVariant")
            ET.SubElement(minor_elem, "Name").text = ""
            sv_list = ET.SubElement(minor_elem, "SubVariantList")
            sub_elem = ET.SubElement(sv_list, "SubVariant")
            ET.SubElement(sub_elem, "Name").text = ""
            pv_list = ET.SubElement(sub_elem, "ParameterValueList")
            flat_ctx: Dict[str, float] = {}
            if cluster_name and cluster_name in by_cluster:
                for pname, dp in by_cluster[cluster_name].items():
                    if dp.values and len(dp.values) == 1:
                        try:
                            flat_ctx[pname] = float(dp.values[0])
                        except (ValueError, TypeError):
                            pass
            for pname_s, dp_s in by_short.items():
                if pname_s not in flat_ctx and dp_s.values and len(dp_s.values) == 1:
                    try:
                        flat_ctx[pname_s] = float(dp_s.values[0])
                    except (ValueError, TypeError):
                        pass
            for param in params:
                pv = ET.SubElement(pv_list, "ParameterValue")
                vl = ET.SubElement(pv, "ValueList")
                raw_values = self._get_dcm_values_from(param.name, cluster_name, by_cluster, by_short)
                for cv in self._convert_values(param, raw_values, cluster_name,
                                               context_env=flat_ctx, base_env=variant_expr_env):
                    ET.SubElement(vl, "Value").text = cv

    # ---- BEGIN CHANGE [v4-fix-name-collision] ----
    def _get_dcm_values_from(self, param_name: str, cluster_name: str,
                             by_cluster: Dict, by_short: Dict) -> List[str]:
        if cluster_name and cluster_name in by_cluster:
            dcm_p = by_cluster[cluster_name].get(param_name)
            if dcm_p and dcm_p.values:
                return dcm_p.values
        # Removed by_short fallback: it caused cross-cluster name collisions
        # (e.g. VHM_Odo.MaxDistDiscarded matching VHM2_FailureHandling.MaxDistDiscarded)
        return []
    # ---- END CHANGE [v4-fix-name-collision] ----

    # ---- BEGIN CHANGE [v4-fix-name-collision-flat] ----
    def _get_dcm_values(self, param_name: str, dcm_stem: str, cluster_name: str = "") -> List[str]:
        if cluster_name and cluster_name in self.dcm_by_cluster:
            dcm_p = self.dcm_by_cluster[cluster_name].get(param_name)
            if dcm_p and dcm_p.values:
                return dcm_p.values
        # Removed dcm_by_short_name fallback to prevent cross-cluster collisions
        return []
    # ---- END CHANGE [v4-fix-name-collision-flat] ----

    # ---- BEGIN CHANGE [v3.1-fix-3A-convert] ----
    def _convert_values(self, param: PdlParameter, raw_values: List[str],
                        cluster_name: str = "",
                        context_env: Optional[Dict[str, float]] = None,
                        base_env: Optional[Dict[str, float]] = None) -> List[str]:
        # ---- END CHANGE [v3.1-fix-3A-convert] ----
        if not raw_values:
            pdl_defaults = self._get_pdl_default_values(
                param, context_env=context_env, base_env=base_env
            )
            if pdl_defaults:
                raw_values = pdl_defaults
            else:
                num = param.array_size if param.array_size > 0 else 1
                return [self._get_default_value(param)] * num

        is_text = any(not self._is_numeric(v) for v in raw_values)
        if is_text:
            results = []
            for v in raw_values:
                vl = v.lower()
                if vl in ("true", "false"):
                    results.append("1" if vl == "true" else "0")
                else:
                    results.append(v)
            return results

        if param.type_kind == "logical":
            return [("1" if float(v) != 0 else "0") for v in raw_values]

        ptype = param.type_name

        enum_map = self._get_enum_map(ptype)
        if enum_map is not None:
            results = []
            for v in raw_values:
                iv = int(float(v))
                results.append(enum_map.get(iv, str(iv)))
            return results

        if ptype in self.global_enums_map:
            val_to_name = {int(lit["value"]): lit["name"] for lit in self.global_enums_map[ptype]["literals"]}
            return [val_to_name.get(int(float(v)), str(int(float(v)))) for v in raw_values]

        quant_name = self.pdl.get_param_quantization(param) if self.pdl else ""
        if quant_name and self.qconv and quant_name in self.qconv.quantizations:
            return [self.qconv.convert(v, quant_name) for v in raw_values]

        if ptype in self.global_types_map:
            gt = self.global_types_map[ptype]
            qname = gt.get("quant", "ident")
            if qname != "ident" and qname in self.global_quant_formulas:
                factor = self._eval_global_quant_factor(self.global_quant_formulas[qname])
                if factor != 0 and factor != 1.0:
                    r = Decimal(1) / Decimal(str(factor))
                    return [str((Decimal(str(float(v))) / r).quantize(Decimal("1"), rounding=ROUND_HALF_UP)) for v in raw_values]
            # Java isModelTypeFloat: true only if ContinuousType AND no quantization.
            # Types with quantization (even factor=1.0 like P1) are NOT float in Java.
            has_quant = (gt.get("quant", "ident") != "ident")
            is_float = self.float32_enabled and not has_quant and (isinstance(gt.get("min"), str) or isinstance(gt.get("max"), str))
            if is_float:
                return [self._format_java_float(v) for v in raw_values]
            return [str(self._round_half_up(float(v))) for v in raw_values]

        is_float_type = self._is_float_type(param)
        if is_float_type:
            return [self._format_java_float(v) for v in raw_values]

        return [str(self._round_half_up(float(v))) for v in raw_values]

    @staticmethod
    def _eval_global_quant_factor(formula: str) -> float:
        expr = re.sub(r'\*?\s*phys\b', '', formula).strip().rstrip('*').strip()
        if not expr:
            return 1.0
        expr = expr.replace('Pi', '3.14159265')
        try:
            return float(eval(expr, {"__builtins__": {}}, {"pow": pow}))
        except Exception:
            return 1.0

    def _get_enum_map(self, type_name: str) -> Optional[Dict[int, str]]:
        if not self.pdl or type_name not in self.pdl.all_enumerations:
            return None
        enum = self.pdl.all_enumerations[type_name]
        return {e.value: e.name for e in enum.entries if e.value is not None}

    def _is_float_type(self, param: PdlParameter) -> bool:
        if not self.float32_enabled:
            return False
        if param.type_kind in ("continuous", "cont") and param.type_name in ("continuous", "cont"):
            quant = self.pdl.get_param_quantization(param) if self.pdl else ""
            return not quant
        if not self.pdl or param.type_name not in self.pdl.all_custom_types:
            return False
        ct = self.pdl.all_custom_types[param.type_name]
        return ct.base_type in ("continuous", "cont") and not ct.quantization_ref

    @staticmethod
    def _is_numeric(s: str) -> bool:
        try:
            float(s)
            return True
        except (ValueError, TypeError):
            return False

    # ---- BEGIN CHANGE [v4-float-format] ----
    @staticmethod
    def _format_java_float(v: str) -> str:
        """Mimic Java DecimalFormat("0.0###############") for float-enabled types:
        integer values always get .0 suffix (e.g. 0 → "0.0", -1 → "-1.0")."""
        fv = float(v)
        if fv == int(fv) and not (fv != fv):
            return f"{int(fv)}.0"
        return f"{fv:.10g}"
    # ---- END CHANGE [v4-float-format] ----

    @staticmethod
    def _round_half_up(v: float) -> int:
        return int(Decimal(str(v)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))

    # ---- BEGIN CHANGE [v3.1-fix-3A-pdl-defaults] ----
    def _get_pdl_default_values(self, param: PdlParameter,
                               context_env: Optional[Dict[str, float]] = None,
                               base_env: Optional[Dict[str, float]] = None) -> List[str]:
        # ---- END CHANGE [v3.1-fix-3A-pdl-defaults] ----
        if not param.init_expression:
            return []

        expr = param.init_expression.strip()

        lower = expr.lower()
        if lower in ("true", "false"):
            return ["1" if lower == "true" else "0"]

        # ---- BEGIN CHANGE [v3.1-fix-3B-array-eval] ----
        # Build the combined env once, reuse for both {}-array and scalar paths
        effective_base = base_env if base_env is not None else self._get_expression_env()
        combined_env = dict(effective_base)
        if context_env:
            combined_env.update(context_env)

        if "{" in expr and "}" in expr:
            first_brace = expr.index("{")
            last_brace = expr.rindex("}")
            inner = expr[first_brace + 1 : last_brace].strip()
            if inner:
                # Depth-aware split: only split on commas at paren depth 0
                elements: List[str] = []
                depth = 0
                current: List[str] = []
                for ch in inner:
                    if ch == '(':
                        depth += 1
                    elif ch == ')':
                        depth -= 1
                    if ch == ',' and depth == 0:
                        elements.append(''.join(current).strip())
                        current = []
                    else:
                        current.append(ch)
                if current:
                    elements.append(''.join(current).strip())

                result: List[str] = []
                for elem in elements:
                    if not elem:
                        continue
                    result.append(self._eval_expression(elem, env=combined_env))
                if result:
                    return result
        # ---- END CHANGE [v3.1-fix-3B-array-eval] ----

        resolved = self._try_resolve_numeric(expr, depth=0, env=combined_env)
        if resolved is not None:
            if resolved == int(resolved):
                return [str(int(resolved))]
            return [str(resolved)]

        if self.pdl and param.type_name:
            enum = self.pdl.all_enumerations.get(param.type_name)
            if enum:
                for entry in enum.entries:
                    if entry.name == expr:
                        return [entry.name]
        if param.type_name in self.global_enums_map:
            for lit in self.global_enums_map[param.type_name]["literals"]:
                if lit["name"] == expr:
                    return [lit["name"]]
        if re.match(r'^[a-zA-Z_]\w*$', expr):
            return [expr]

        return []

    def _get_default_value(self, param: PdlParameter) -> str:
        if param.init_expression:
            val = self._eval_const_value(param)
            if val != param.init_expression:
                if self._is_float_type(param) and self._is_numeric(val):
                    return self._format_java_float(val)
                return val
            expr = param.init_expression.strip()
            lower = expr.lower()
            if lower in ("true", "false"):
                return "1" if lower == "true" else "0"
            if self.pdl and param.type_name:
                enum = self.pdl.all_enumerations.get(param.type_name)
                if enum:
                    for entry in enum.entries:
                        if entry.name == expr:
                            return entry.name
            if param.type_name in self.global_enums_map:
                for lit in self.global_enums_map[param.type_name]["literals"]:
                    if lit["name"] == expr:
                        return lit["name"]
            if re.match(r'^[a-zA-Z_]\w*$', expr):
                return expr
        if param.type_kind == "logical":
            return "0"
        if self.pdl and param.type_name in self.pdl.all_enumerations:
            enum = self.pdl.all_enumerations[param.type_name]
            if enum.entries:
                return enum.entries[0].name
        if self._is_float_type(param):
            return "0.0"
        return "0"

    # -- Fallback: component from vardef (no PDL) --
    def _add_components_from_vardef(self, comp_list: ET.Element):
        if self.major_variant is None:
            return
        for module in self.major_variant.modules:
            comp_name = module.name or "Default"
            comp_elem = ET.SubElement(comp_list, "Component")
            ET.SubElement(comp_elem, "Name").text = comp_name
            ET.SubElement(comp_elem, "DefineList")
            pcl = ET.SubElement(comp_elem, "ParameterClusterList")

            for minor in module.minor_variants:
                for sub in minor.sub_variants:
                    for dcm_file in sub.dcm_files:
                        stem = os.path.splitext(os.path.basename(dcm_file))[0]
                        if stem in self.dcm_data:
                            pc = ET.SubElement(pcl, "ParameterCluster")
                            ET.SubElement(pc, "Name").text = stem
                            ET.SubElement(pc, "MemoryArea").text = "ROM"
                            ET.SubElement(pc, "VariantApplication").text = "SINGLE"
                            ET.SubElement(pc, "Description").text = ""
                            pd_list = ET.SubElement(pc, "ParameterDefinitionList")
                            for p in self.dcm_data[stem]:
                                pd = ET.SubElement(pd_list, "ParameterDefinition")
                                ET.SubElement(pd, "Name").text = p.name
                                ET.SubElement(pd, "TypeInModel").text = self._infer_dcm_type(p)
                                ET.SubElement(pd, "Number").text = str(max(1, len(p.values)))
                                ET.SubElement(pd, "DESCRIPTION").text = p.long_name
                            vi_list = ET.SubElement(pc, "VariantImlementationList")
                            vi = ET.SubElement(vi_list, "VariantImlementation")
                            mvl = ET.SubElement(vi, "MajorVariantList")
                            ET.SubElement(mvl, "MajorVariant").text = self.major_variant_name
                            ml = ET.SubElement(vi, "MinorVariantList")
                            me = ET.SubElement(ml, "MinorVariant")
                            ET.SubElement(me, "Name").text = minor.name
                            svl = ET.SubElement(me, "SubVariantList")
                            sve = ET.SubElement(svl, "SubVariant")
                            ET.SubElement(sve, "Name").text = sub.name
                            pvl = ET.SubElement(sve, "ParameterValueList")
                            for p in self.dcm_data[stem]:
                                pv = ET.SubElement(pvl, "ParameterValue")
                                vle = ET.SubElement(pv, "ValueList")
                                for v in (p.values or ["0"]):
                                    ET.SubElement(vle, "Value").text = v

    @staticmethod
    def _infer_dcm_type(param: DcmParameter) -> str:
        if param.is_text:
            return "string"
        if param.kind == "KENNFELD":
            return "map"
        if param.kind == "KENNLINIE":
            return "curve"
        if param.kind == "FESTWERTEBLOCK":
            return "array"
        return "continuous"

    # ------------------------------------------------------------------
    # Complex PDL expression evaluator (ternary, comparison, enum)
    # ------------------------------------------------------------------

    # ---- BEGIN CHANGE [v3.1-fix-3B-ternary-limit] ----
    def _eval_pdl_ternary(self, expr: str, env: Dict[str, float],
                          _depth: int = 0) -> Optional[float]:
        if _depth > 200 or len(expr) > 100000:
            return None
    # ---- END CHANGE [v3.1-fix-3B-ternary-limit] ----
        text = expr.strip()
        if not text:
            return None

        while text.startswith('(') and text.endswith(')'):
            depth = 0
            matched = True
            for i, ch in enumerate(text):
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    depth -= 1
                if depth == 0 and i < len(text) - 1:
                    matched = False
                    break
            if matched:
                text = text[1:-1].strip()
            else:
                break

        lower = text.lower()
        if lower in ("true", "false"):
            return 1.0 if lower == "true" else 0.0

        try:
            return float(text)
        except ValueError:
            pass

        if text in env:
            return env[text]

        m = re.match(r'^(\w+)\s*\.\s*(\w+)$', text)
        if m:
            val = self._resolve_enum_value(m.group(1), m.group(2))
            if val is not None:
                return val

        nd = _depth + 1
        q_pos = self._find_op_depth0(text, '?')
        if q_pos > 0:
            cond_str = text[:q_pos].strip()
            rest = text[q_pos + 1:]
            c_pos = self._find_op_depth0(rest, ':')
            if c_pos >= 0:
                true_str = rest[:c_pos].strip()
                false_str = rest[c_pos + 1:].strip()
                cond_val = self._eval_pdl_ternary(cond_str, env, nd)
                if cond_val is not None:
                    branch = true_str if cond_val != 0 else false_str
                    return self._eval_pdl_ternary(branch, env, nd)
                return None

        for op_str in ('<=', '>=', '!=', '=='):
            idx = self._find_op_depth0(text, op_str)
            if idx >= 0:
                lv = self._eval_pdl_ternary(text[:idx].strip(), env, nd)
                rv = self._eval_pdl_ternary(text[idx + len(op_str):].strip(), env, nd)
                if lv is not None and rv is not None:
                    if op_str == '<=':
                        return 1.0 if lv <= rv else 0.0
                    elif op_str == '>=':
                        return 1.0 if lv >= rv else 0.0
                    elif op_str == '!=':
                        return 1.0 if lv != rv else 0.0
                    else:
                        return 1.0 if lv == rv else 0.0
                return None

        for op_str in ('<', '>'):
            idx = self._find_op_depth0(text, op_str)
            if idx >= 0:
                if (op_str == '<' and idx + 1 < len(text) and text[idx + 1] == '='):
                    continue
                if (op_str == '>' and idx + 1 < len(text) and text[idx + 1] == '='):
                    continue
                lv = self._eval_pdl_ternary(text[:idx].strip(), env, nd)
                rv = self._eval_pdl_ternary(text[idx + 1:].strip(), env, nd)
                if lv is not None and rv is not None:
                    if op_str == '<':
                        return 1.0 if lv < rv else 0.0
                    else:
                        return 1.0 if lv > rv else 0.0
                return None

        idx = self._find_last_addop_depth0(text)
        if idx > 0:
            lv = self._eval_pdl_ternary(text[:idx].strip(), env, nd)
            rv = self._eval_pdl_ternary(text[idx + 1:].strip(), env, nd)
            if lv is not None and rv is not None:
                return (lv + rv) if text[idx] == '+' else (lv - rv)
            return None

        for op_ch in ('*', '/'):
            idx = self._find_last_op_depth0_char(text, op_ch)
            if idx >= 0:
                lv = self._eval_pdl_ternary(text[:idx].strip(), env, nd)
                rv = self._eval_pdl_ternary(text[idx + 1:].strip(), env, nd)
                if lv is not None and rv is not None:
                    if op_ch == '*':
                        return lv * rv
                    elif rv != 0:
                        return lv / rv
                return None

        if text.startswith('-'):
            inner = self._eval_pdl_ternary(text[1:].strip(), env, nd)
            if inner is not None:
                return -inner

        return None

    def _find_op_depth0(self, text: str, op: str) -> int:
        depth = 0
        for i in range(len(text) - len(op) + 1):
            if text[i] == '(':
                depth += 1
            elif text[i] == ')':
                depth -= 1
            elif depth == 0 and text[i:i + len(op)] == op:
                if op in ('<', '>') and i + 1 < len(text) and text[i + 1] == '=':
                    continue
                if op == '!' and (i + 1 >= len(text) or text[i + 1] != '='):
                    continue
                return i
        return -1

    def _find_last_addop_depth0(self, text: str) -> int:
        depth = 0
        last = -1
        for i in range(len(text)):
            if text[i] == '(':
                depth += 1
            elif text[i] == ')':
                depth -= 1
            elif depth == 0 and text[i] in ('+', '-'):
                if i == 0:
                    continue
                prev = ''
                for j in range(i - 1, -1, -1):
                    if text[j] != ' ':
                        prev = text[j]
                        break
                if prev and prev not in ('(', '?', ':', '<', '>', '=', '!', '+', '-', '*', '/'):
                    last = i
        return last

    def _find_last_op_depth0_char(self, text: str, op: str) -> int:
        depth = 0
        last = -1
        for i in range(len(text)):
            if text[i] == '(':
                depth += 1
            elif text[i] == ')':
                depth -= 1
            elif depth == 0 and text[i] == op:
                last = i
        return last

    def _resolve_enum_value(self, enum_type: str, member: str) -> Optional[float]:
        if self.pdl and enum_type in self.pdl.all_enumerations:
            for entry in self.pdl.all_enumerations[enum_type].entries:
                if entry.name == member:
                    return float(entry.value) if entry.value is not None else None
        if enum_type in self.global_enums_map:
            for lit in self.global_enums_map[enum_type]["literals"]:
                if lit["name"] == member:
                    try:
                        return float(lit["value"])
                    except (ValueError, TypeError):
                        return None
        return None

    @staticmethod
    def _format_resolution(res: Decimal) -> str:
        f = float(res)
        if abs(f) >= 1e6 or (0 < abs(f) < 0.001):
            _, res_digits, res_exp = res.as_tuple()
            res_sig = ''.join(str(d) for d in res_digits).rstrip('0') or '0'
            is_exact = len(res_sig) <= 17
            if is_exact:
                src = res
            else:
                src = Decimal(repr(f))
            sign_char, digits, exp_int = src.as_tuple()
            coeff_str = ''.join(str(d) for d in digits)
            coeff_str = coeff_str.rstrip('0') or '0'
            if len(coeff_str) == 1:
                mantissa = coeff_str + ".0"
            else:
                mantissa = coeff_str[0] + "." + coeff_str[1:]
            e = exp_int + len(digits) - 1
            sign = '-' if e < 0 else '+'
            s = f"{mantissa}E{sign}{abs(e)}"
            if sign_char:
                s = '-' + s
            return s
        return str(res)

    @staticmethod
    def _pretty_print(xml_str: str) -> str:
        dom = minidom.parseString(xml_str)
        pretty = dom.toprettyxml(indent="  ", encoding="UTF-8")
        text = pretty.decode("UTF-8")
        lines = text.split("\n")
        result = []
        for line in lines:
            if not line.strip():
                continue
            line = re.sub(
                r'<(\w+)\s*/>',
                lambda m: (
                    f'<{m.group(1)}/>'
                    if m.group(1) in ('DefineList',)
                    else f'<{m.group(1)}></{m.group(1)}>'
                ),
                line,
            )
            result.append(line)
        return "\n".join(result)
