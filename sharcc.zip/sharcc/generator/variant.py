"""Variant resolver — maps vehicle model to DCM paths."""

import os
from collections import OrderedDict
from typing import Dict, List, Optional

from .models import DcmParameter, MajorVariant, VariantDefinition


class VariantResolver:
    def __init__(self, vardef: VariantDefinition, dcm_dir: str):
        self.vardef = vardef
        self.dcm_dir = dcm_dir

    def get_major_variant_names(self) -> List[str]:
        return [mv.name for mv in self.vardef.major_variants]

    def resolve_dcm_files(self, major_variant_name: str) -> List[str]:
        dcm_names: List[str] = []
        dcm_names.extend(self.vardef.all_major_variant_dcms)
        mv = self._find_major_variant(major_variant_name)
        if mv is None:
            return []
        dcm_names.extend(mv.common_dcm_files)
        for module in mv.modules:
            for minor in module.minor_variants:
                for sub in minor.sub_variants:
                    dcm_names.extend(sub.dcm_files)
        unique = list(OrderedDict.fromkeys(dcm_names))
        return self._resolve_paths(unique)

    def resolve_variant_tree(self, name: str) -> Optional[MajorVariant]:
        return self._find_major_variant(name)

    def _find_major_variant(self, name: str) -> Optional[MajorVariant]:
        for mv in self.vardef.major_variants:
            if mv.name == name:
                return mv
        return None

    def _resolve_paths(self, dcm_names: List[str]) -> List[str]:
        resolved = []
        for dcm_name in dcm_names:
            if not dcm_name:
                continue
            if not dcm_name.lower().endswith(".dcm"):
                dcm_name += ".dcm"
            hit = self._find_file(dcm_name)
            if hit:
                resolved.append(hit)
            else:
                print(f"  [WARN] DCM file not found: {dcm_name}")
        return resolved

    def _find_file(self, name: str) -> Optional[str]:
        if not hasattr(self, "_file_index"):
            self._file_index: Dict[str, str] = {}
            for dirpath, _, filenames in os.walk(self.dcm_dir):
                for fname in filenames:
                    if fname.lower().endswith(".dcm"):
                        self._file_index[fname.lower()] = os.path.join(dirpath, fname)
        return self._file_index.get(name.lower())

    def collect_dcm_names_for_variant(
        self, mv: MajorVariant, vardef: VariantDefinition
    ) -> Dict[str, List[Dict]]:
        """
        Returns: { dcm_stem: [ {minor, sub} , ... ] }
        to track which variant combination uses which DCM.
        """
        result: Dict[str, List[Dict]] = OrderedDict()

        for dcm in vardef.all_major_variant_dcms:
            s = self._stem(dcm)
            result.setdefault(s, []).append({"minor": "", "sub": ""})

        for dcm in mv.common_dcm_files:
            s = self._stem(dcm)
            result.setdefault(s, []).append({"minor": "", "sub": ""})

        for module in mv.modules:
            for minor in module.minor_variants:
                for sub in minor.sub_variants:
                    for dcm in sub.dcm_files:
                        s = self._stem(dcm)
                        result.setdefault(s, []).append(
                            {"minor": minor.name, "sub": sub.name}
                        )
        return result

    @staticmethod
    def _stem(name: str) -> str:
        return os.path.splitext(os.path.basename(name))[0]
