"""Allow running v10 as a package: python -m v10 <command>."""
from .main import main

main()
