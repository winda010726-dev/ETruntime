"""Unified CLI for v10: generate, combine, export, add.

Usage:
  python -m v10.main generate  --configmaster-dir DIR --variant NAME [--output FILE]
  python -m v10.main combine   --configmaster-dir DIR --variants A B C [--combine|--no-combine] [--output FILE]
  python -m v10.main export    --pdl-dir DIR --dcm-dir DIR [--output-dir DIR]
  python -m v10.main add       copy VARIANT_JSON SOURCE NEW_NAME [--value-dir DIR] [--dry-run]
  python -m v10.main add       list VARIANT_JSON [--major NAME]
"""

import argparse
import os
import sys
from pathlib import Path
from typing import Dict, List


def cmd_generate(args):
    """Single-variant XML generation (v9-compatible)."""
    from .generator.configmaster_loader import (
        load_variant_json, load_all_value_json, load_model_json,
    )
    from .generator.component import PdlComponentBuilder
    from .generator.quantization import QuantizationConverter
    from .generator.generator import ParGenXmlGenerator

    cm_dir = args.configmaster_dir
    variant_path = os.path.join(cm_dir, "variant.json")
    value_dir = os.path.join(cm_dir, "value")
    model_path = os.path.join(cm_dir, "model.json")

    print(f"\n[1/5] Loading variant.json: {variant_path}")
    vardef = load_variant_json(variant_path)
    mv_names = [mv.name for mv in vardef.major_variants]
    print(f"  Found {len(mv_names)} vehicle model(s)")

    print(f"\n[2/5] Loading model.json: {model_path}")
    pdl_builder = None
    qconv = None
    global_types_map: Dict = {}
    global_enums_map: Dict = {}
    global_quant_formulas: Dict = {}

    if os.path.isfile(model_path):
        pdl_packages, global_types_map, global_enums_map, global_quant_formulas = load_model_json(model_path)
        if pdl_packages:
            pdl_builder = PdlComponentBuilder(pdl_packages)
            qconv = QuantizationConverter(pdl_builder.all_quantizations)
            print(f"  Components: {len(pdl_builder.get_component_names())}")
    else:
        print("  [WARN] model.json not found.")

    selected = args.variant
    if selected not in mv_names:
        print(f"  [ERROR] Variant '{selected}' not found. Available: {mv_names[:5]}...")
        sys.exit(1)
    print(f"\n[3/5] Selected: {selected}")

    print(f"\n[4/5] Loading value.json: {value_dir}")
    all_dcm_data = load_all_value_json(value_dir)
    print(f"  Loaded: {len(all_dcm_data)} files")

    from .combine.combine_builder import ConfigMasterVariantResolver
    resolver = ConfigMasterVariantResolver(vardef, all_dcm_data)
    dcm_data = resolver.resolve_dcm_data(selected)
    mv = resolver.resolve_variant_tree(selected)
    mapped_stems = resolver.collect_dcm_names_for_variant(mv) if mv else set()

    generator = ParGenXmlGenerator(
        major_variant_name=selected,
        major_variant=mv,
        vardef=vardef,
        dcm_data=dcm_data,
        pdl_builder=pdl_builder,
        quant_converter=qconv,
        global_types_map=global_types_map,
        global_enums_map=global_enums_map,
        global_quant_formulas=global_quant_formulas,
        mapped_dcm_stems=mapped_stems,
        float32_enabled=not args.no_float32,
    )

    xml_str = generator.generate()
    output_path = args.output or f"{selected}.xml"
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(xml_str)

    print(f"\n[5/5] Generated: {output_path}")


def cmd_combine(args):
    """Multi-variant XML generation (combined / non-combined)."""
    from .combine.combine_builder import CombineBuilder

    builder = CombineBuilder(
        configmaster_dir=args.configmaster_dir,
        variant_names=args.variants,
        combined=args.combine,
        optimize=getattr(args, "optimize", False),
        scan_all_dcm=getattr(args, "scan_all_dcm", False),
        float32_enabled=not getattr(args, "no_float32", False),
    )

    builder.load()

    output = args.output or "output.xml"
    results = builder.build(output)

    print(f"\nDone. Generated {len(results)} file(s):")
    for r in results:
        print(f"  {r}")


def cmd_export(args):
    """Convert PDL/DCM/pmavardef into ConfigMaster JSON."""
    from .export import configmaster_export as ce

    export_args = []
    if args.pdl_dir:
        export_args += ["--pdl-dir", args.pdl_dir]
    if args.dcm_dir:
        export_args += ["--dcm-dir", args.dcm_dir]
    if args.pmavardef:
        export_args += ["--pmavardef", args.pmavardef]
    if args.output:
        export_args += ["--output", args.output]

    sys.argv = ["configmaster_export"] + export_args
    ce.main()


def cmd_add(args):
    """Delegate to add_variant.py CLI."""
    from .add import add_variant
    sys.argv = ["add_variant"] + args.add_args
    add_variant.main()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="v10",
        description="v10 - Unified ParGen XML module with combine support",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # --- generate ---
    p_gen = sub.add_parser("generate", help="Generate XML for a single variant")
    p_gen.add_argument("--configmaster-dir", required=True, help="ConfigMaster output directory")
    p_gen.add_argument("--variant", required=True, help="Vehicle model name")
    p_gen.add_argument("--output", default=None, help="Output XML path")
    p_gen.add_argument("--no-float32", action="store_true", help="Legacy integer rounding mode")

    # --- combine ---
    p_comb = sub.add_parser("combine", help="Generate XML for multiple variants")
    p_comb.add_argument("--configmaster-dir", required=True, help="ConfigMaster output directory")
    p_comb.add_argument("--variants", nargs="+", required=True, help="List of variant names")
    p_comb.add_argument("--output", default=None, help="Output XML path (base name for split mode)")
    p_comb.add_argument("--combine", action="store_true", default=True,
                        dest="combine", help="Combined mode: all variants in one XML (default)")
    p_comb.add_argument("--no-combine", action="store_false", dest="combine",
                        help="Non-combined mode: one XML per variant")
    p_comb.add_argument("--optimize", action="store_true",
                        help="Merge identical VariantImplementations")
    p_comb.add_argument("--scan-all-dcm", action="store_true",
                        help="Include all value.json files")
    p_comb.add_argument("--no-float32", action="store_true",
                        help="Legacy integer rounding mode")

    # --- export ---
    p_exp = sub.add_parser("export", help="Convert PDL/DCM/pmavardef to ConfigMaster JSON")
    p_exp.add_argument("--pdl-dir", default=None, help="Directory containing PDL files")
    p_exp.add_argument("--dcm-dir", default=None, help="Directory containing DCM files")
    p_exp.add_argument("--pmavardef", default=None, help="Path to pmavardef XML file")
    p_exp.add_argument("--output", default=None, help="Output directory (default: ./configmaster_output)")

    # --- add ---
    p_add = sub.add_parser("add", help="Add/copy MajorVariant in variant.json")
    p_add.add_argument("add_args", nargs=argparse.REMAINDER,
                       help="Arguments passed to add_variant.py (e.g., copy variant.json SRC NEW)")

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "generate":
        cmd_generate(args)
    elif args.command == "combine":
        cmd_combine(args)
    elif args.command == "export":
        cmd_export(args)
    elif args.command == "add":
        cmd_add(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
