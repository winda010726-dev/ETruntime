"""Add/copy MajorVariant in variant.json."""
