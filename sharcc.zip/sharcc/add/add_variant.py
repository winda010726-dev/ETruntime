"""Add a new MajorVariant to variant.json by copying an existing one.

Mirrors the SHARCC copy-variant workflow:
  1. Deep-copy the source MajorVariant structure (base + all modules/options)
  2. Rename value.json references using the same regex as SHARCC's
     DCMFileNamingHelperUtil: (?<=_)OLD_NAME(?=_|\b)  (case-insensitive)
  3. Copy the actual value.json files with new names

Usage:
  python add_variant.py copy <variant.json> <source> <new_name> [--value-dir DIR] [--dry-run]
  python add_variant.py list <variant.json> [--major NAME]

Examples:
  python add_variant.py copy variant.json ASIC_MCHG ASIC_MCHG_NEW --value-dir ./value
  python add_variant.py copy variant.json ASIC_MCHG ASIC_MCHG_NEW --dry-run
  python add_variant.py list variant.json
  python add_variant.py list variant.json --major ASIC_MCHG
"""

import argparse
import copy
import json
import re
import shutil
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# SHARCC-compatible file name replacement
# ---------------------------------------------------------------------------

def extract_short_name(major_name: str) -> str:
    """Extract the short suffix used in file names.

    ASIC_MCHG  -> MCHG
    ASIC_HXHW  -> HXHW
    ASIC_HS_2WS -> HS_2WS

    The pmavardef file names use the part after "ASIC_" as the suffix
    embedded in DCM/value file names.
    """
    if major_name.startswith("ASIC_"):
        return major_name[len("ASIC_"):]
    return major_name


def replace_variant_name(old_name: str, new_name: str, filename: str) -> str:
    """Replace old variant name with new in a filename.

    Uses the same regex as SHARCC DCMFileNamingHelperUtil.replaceOldVariantName:
      Pattern: (?<=_)OLD_NAME(?=_|\b)  with CASE_INSENSITIVE flag

    This matches OLD_NAME when preceded by '_' and followed by '_' or word boundary.
    Shared files (like CEP_ApplClassProject.value.json) won't match -> unchanged.
    """
    if not old_name or not new_name:
        return filename
    pattern = r"(?<=_)" + re.escape(old_name) + r"(?=_|\b)"
    result = re.sub(pattern, new_name, filename, flags=re.IGNORECASE)
    return result


def rename_file_reference(old_major: str, new_major: str, filename: str) -> str:
    """Rename a value.json reference from old variant to new.

    Applies replacement using the short name (e.g. MCHG -> MCHG_NEW).
    """
    old_short = extract_short_name(old_major)
    new_short = extract_short_name(new_major)
    return replace_variant_name(old_short, new_short, filename)


# ---------------------------------------------------------------------------
# Deep-copy variant structure
# ---------------------------------------------------------------------------

def copy_major_variant(
    data: Dict[str, Any],
    source_name: str,
    new_name: str,
) -> Tuple[Dict[str, Any], List[Tuple[str, str]]]:
    """Copy a MajorVariant, renaming all file references.

    Returns (new_variant_data, [(old_filename, new_filename), ...])
    """
    options = data["modules"]["vehicle"]["options"]

    if source_name not in options:
        print(f"Error: source MajorVariant '{source_name}' not found", file=sys.stderr)
        sys.exit(1)
    if new_name in options:
        print(f"Error: MajorVariant '{new_name}' already exists", file=sys.stderr)
        sys.exit(1)

    source = options[source_name]
    new_variant = copy.deepcopy(source)
    file_renames: List[Tuple[str, str]] = []

    # Rename base files
    new_base = []
    for f in new_variant["base"]:
        new_f = rename_file_reference(source_name, new_name, f)
        new_base.append(new_f)
        if new_f != f:
            file_renames.append((f, new_f))
    new_variant["base"] = new_base

    # Rename files in all modules -> options -> base
    for mod_name, mod in new_variant.get("modules", {}).items():
        new_options = {}
        for opt_key, opt_val in mod.get("options", {}).items():
            new_opt_base = []
            for f in opt_val.get("base", []):
                new_f = rename_file_reference(source_name, new_name, f)
                new_opt_base.append(new_f)
                if new_f != f:
                    file_renames.append((f, new_f))
            new_options[opt_key] = {"base": new_opt_base}
        mod["options"] = new_options

    return new_variant, file_renames


# ---------------------------------------------------------------------------
# Copy value.json files
# ---------------------------------------------------------------------------

def copy_value_files(
    file_renames: List[Tuple[str, str]],
    value_dir: Path,
    dry_run: bool = False,
) -> Tuple[int, int, List[str]]:
    """Copy value.json files with new names.

    Returns (copied_count, skipped_count, warnings)
    """
    copied = 0
    skipped = 0
    warnings = []

    for old_f, new_f in file_renames:
        old_path = value_dir / old_f
        new_path = value_dir / new_f

        if not old_path.exists():
            warnings.append(f"Source not found: {old_f}")
            skipped += 1
            continue

        if new_path.exists():
            warnings.append(f"Already exists, skipped: {new_f}")
            skipped += 1
            continue

        if dry_run:
            copied += 1
        else:
            shutil.copy2(old_path, new_path)
            copied += 1

    return copied, skipped, warnings


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------

def list_variants(data: Dict[str, Any], major_name: Optional[str] = None) -> None:
    options = data["modules"]["vehicle"]["options"]

    if major_name:
        if major_name not in options:
            print(f"Error: MajorVariant '{major_name}' not found", file=sys.stderr)
            sys.exit(1)
        major = options[major_name]
        print(f"\nMajorVariant: {major_name}")
        print(f"  base files: {len(major.get('base', []))}")
        for mod_name, mod in major.get("modules", {}).items():
            opts = mod.get("options", {})
            print(f"  Module: {mod_name}  ({len(opts)} option(s))")
            for opt_key, opt_val in opts.items():
                n = len(opt_val.get("base", []))
                print(f"    {opt_key}  ({n} file(s))")
    else:
        print(f"\nTotal MajorVariants: {len(options)}")
        for name in sorted(options.keys()):
            major = options[name]
            n_base = len(major.get("base", []))
            n_modules = len(major.get("modules", {}))
            print(f"  {name}  (base: {n_base}, modules: {n_modules})")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Add MajorVariant to variant.json (SHARCC-compatible copy mode)",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_copy = sub.add_parser("copy", help="Copy an existing MajorVariant with new name")
    p_copy.add_argument("variant_json", type=Path, help="Path to variant.json")
    p_copy.add_argument("source", help="Source MajorVariant name (e.g. ASIC_MCHG)")
    p_copy.add_argument("new_name", help="New MajorVariant name (e.g. ASIC_MCHG_NEW)")
    p_copy.add_argument(
        "--value-dir", type=Path, default=None,
        help="Directory containing value.json files to copy (default: same dir as variant.json / value)",
    )
    p_copy.add_argument(
        "--dry-run", action="store_true",
        help="Show what would be done without making changes",
    )

    p_list = sub.add_parser("list", help="List existing variants")
    p_list.add_argument("variant_json", type=Path, help="Path to variant.json")
    p_list.add_argument("--major", default=None, help="Show details for a specific MajorVariant")

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    with open(args.variant_json, "r", encoding="utf-8") as f:
        data = json.load(f)

    if args.command == "copy":
        value_dir = args.value_dir
        if value_dir is None:
            value_dir = args.variant_json.parent / "value"

        # 1. Copy variant structure + rename references
        new_variant, file_renames = copy_major_variant(data, args.source, args.new_name)

        # Deduplicate renames (same file can appear in multiple places)
        seen = set()
        unique_renames = []
        for old_f, new_f in file_renames:
            if (old_f, new_f) not in seen:
                seen.add((old_f, new_f))
                unique_renames.append((old_f, new_f))

        shared_count = 0
        for f in new_variant["base"]:
            if not any(r[1] == f for r in unique_renames):
                shared_count += 1

        # 2. Insert into variant.json
        data["modules"]["vehicle"]["options"][args.new_name] = new_variant

        # 3. Copy value.json files
        copied = 0
        skipped = 0
        warnings = []
        if value_dir.exists():
            copied, skipped, warnings = copy_value_files(unique_renames, value_dir, args.dry_run)
        else:
            warnings.append(f"Value directory not found: {value_dir}")

        # 4. Save variant.json
        if not args.dry_run:
            with open(args.variant_json, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
                f.write("\n")

        # Report
        prefix = "[DRY RUN] " if args.dry_run else ""
        print(f"\n{prefix}Copy MajorVariant: {args.source} -> {args.new_name}")
        print(f"  variant.json: {'would update' if args.dry_run else 'updated'}")
        print(f"  Structure: base={len(new_variant['base'])}, modules={len(new_variant.get('modules', {}))}")
        print(f"  Shared files (unchanged): {shared_count}")
        print(f"  Renamed references: {len(unique_renames)}")
        print(f"  Value files copied: {copied}")
        if skipped:
            print(f"  Value files skipped: {skipped}")
        if warnings:
            print(f"\n  Warnings:")
            for w in warnings:
                print(f"    - {w}")

    elif args.command == "list":
        list_variants(data, args.major)


if __name__ == "__main__":
    main()
