import json
from openai import OpenAI
import time
import os

DASHSCOPE_API_KEY = "sk-0c9412d65b504561974758e0736f3e28"

client = OpenAI(
    api_key= DASHSCOPE_API_KEY,
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
)

#工具
def get_jetson_status(metric):
    if metric == "temperature":
        return "75°C"
    elif metric == "gpu_load":
        return "85%"
    return "Unknown"

def get_vision_metrics():
    return json.dumps({
        "fps":12,
        "inference_latency_ms": 180,
        "frame_drop_count": 23
    })

TOOL_REGISTRY = {
    "get_jetson_status" : get_jetson_status,
    "get_vision_metrics" : get_vision_metrics,
}

TOOLS_DEFINITION = [
    {
        "type": "function",
        "function": {
            "name": "get_jetson_status",
            "description": "获取 Jetson 设备的硬件状态（温度、GPU负载）",
            "parameters": {
                "type": "object",
                "properties": {
                    "metric": {"type": "string", "enum": ["temperature", "gpu_load"]}
                },
                "required": ["metric"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_vision_metrics",
            "description": "获取视觉系统的实时指标（FPS、推理延迟、丢帧数）",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        }
    }
]

def react_loop(user_input, max_steps=5):
    request_id = f"req_{int(time.time())}"
    snapshot = {
        "request_id": request_id,
        "user_input": user_input,
        "steps": [],
        "total_tokens": 0,
    }
    messages = [
        {"role": "system", "content": """你是一个边缘计算诊断专家。

诊断规则：
1. 必须调用所有相关工具收集足够数据后，才能下结论
2. 如果数据不足以确定根因，继续调用其他工具
3. 不要建议用户自己去查，你自己查

输出格式：
- 根因（root cause）: 一句话总结
- 置信度: 高/中/低
- 证据: 列出支持判断的数据
- 建议: 具体操作步骤"""},
        {"role": "user", "content": user_input}
    ]

    final_answer = "达到最大步数限制，强制停止"

    for step in range(max_steps):
        print(f"\n--- Step {step + 1} ---")
        response = client.chat.completions.create(
            model="qwen-turbo",
            messages=messages,
            tools=TOOLS_DEFINITION,
        )
        msg = response.choices[0].message

        step_record = {
            "step": step,
            "prompt_tokens": response.usage.prompt_tokens,
            "completion_tokens": response.usage.completion_tokens,
        }
        snapshot["total_tokens"] += response.usage.total_tokens

        if not msg.tool_calls:
            print(f"最终答案: {msg.content}")
            step_record["action"] = "final_answer"
            step_record["content"] = msg.content
            snapshot["steps"].append(step_record)
            final_answer = msg.content
            break

        messages.append(msg)

        seen = set()
        unique_tool_calls = []
        for tc in msg.tool_calls:
            key = f"{tc.function.name}_{tc.function.arguments}"
            if key not in seen:
                seen.add(key)
                unique_tool_calls.append(tc)

        step_record["action"] = "tool_calls"
        step_record["tools"] = []

        for tool_call in unique_tool_calls:
            name = tool_call.function.name
            args = json.loads(tool_call.function.arguments)
            print(f"调用工具: {name}({args})")
            func = TOOL_REGISTRY.get(name)
            if func is None:
                result = f"错误: 工具 {name} 不存在"
            else:
                try:
                    result = func(**args)
                except Exception as e:
                    result = f"执行失败: {e}"
            print(f"工具返回: {result}")
            messages.append({
                "tool_call_id": tool_call.id,
                "role": "tool",
                "name": name,
                "content": str(result),
            })
            step_record["tools"].append({
                "name": name,
                "args": args,
                "result": result,
            })

        snapshot["steps"].append(step_record)

    # 保存快照
    os.makedirs("snapshots", exist_ok=True)
    with open(f"snapshots/{request_id}.json", "w", encoding="utf-8") as f:
        json.dump(snapshot, f, ensure_ascii=False, indent=2)
    print(f"\n快照已保存: snapshots/{request_id}.json")

    return final_answer
# ========== 运行 ==========
react_loop("视觉系统好像变慢了，帮我查一下是什么原因")