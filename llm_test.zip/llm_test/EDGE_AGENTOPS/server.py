"""
Edge AgentOps — FastAPI 服务 (F9 + F11)。

启动:
    uvicorn server:app --reload --host 0.0.0.0 --port 8000

端点:
    GET  /                       -> 服务信息
    GET  /health                 -> 健康检查
    GET  /api/scenarios          -> 列出所有场景
    POST /api/scenario           -> 切换场景
    POST /api/diagnose           -> 提交诊断（走 Orchestrator 多 Agent 编排）
    POST /api/diagnose/simple    -> 提交诊断（走单 Agent，跳过路由）
    GET  /api/agents             -> 查看已注册的 Agent 列表
    POST /api/monitor/start      -> 启动告警监控
    POST /api/monitor/stop       -> 停止告警监控
    GET  /api/monitor/status     -> 监控状态 + 告警历史
    GET  /api/monitor/diagnoses  -> 告警触发的诊断历史
"""

from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from agent_core import ReActAgent, AgentConfig
from simulator import JetsonSimulator
from tools import build_tool_registry, TOOLS_DEFINITION
from agents import AgentRegistry, Orchestrator, ALL_SPECS
from monitor import AlertMonitor

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s %(message)s",
)
logger = logging.getLogger("server")


# ─── 全局状态 ────────────────────────────────────────────

class AppState:
    """FastAPI 生命周期内的共享状态。"""

    def __init__(self):
        self.sim = JetsonSimulator("normal")
        self.config = AgentConfig()
        self.tool_registry = build_tool_registry(self.sim)

        # 单 Agent（向后兼容 + 告警监控用）
        self.simple_agent = ReActAgent(
            self.config, self.tool_registry, TOOLS_DEFINITION,
        )

        # 多 Agent 编排
        self.agent_registry = AgentRegistry(self.config, self.tool_registry)
        for spec in ALL_SPECS:
            self.agent_registry.register(spec)
        self.orchestrator = Orchestrator(self.config, self.agent_registry)

        # 告警监控（用单 Agent，快速响应）
        self.monitor = AlertMonitor(self.sim, self.simple_agent)


state: Optional[AppState] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global state
    state = AppState()
    logger.info("Edge AgentOps 服务已启动 (已注册 %d 个 Agent)",
                len(state.agent_registry.list_agents()))
    yield
    if state and state.monitor.is_running:
        state.monitor.stop()
    logger.info("Edge AgentOps 服务已关闭")


app = FastAPI(
    title="Edge AgentOps",
    description="边缘计算 AI 诊断服务 — 多 Agent 编排 + 告警驱动",
    version="0.5.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── 请求/响应模型 ───────────────────────────────────────

class DiagnoseRequest(BaseModel):
    question: str = Field(..., min_length=1, description="用户问题 / 诊断请求")
    scenario: Optional[str] = Field(None, description="可选：先切换到指定场景再诊断")
    timeout_seconds: Optional[float] = Field(None, ge=5, le=600, description="超时秒数")


class ScenarioSwitch(BaseModel):
    scenario: str = Field(..., description="目标场景名称")


class MonitorConfig(BaseModel):
    poll_interval: float = Field(10.0, ge=1, le=300, description="轮询间隔（秒）")
    cooldown_seconds: float = Field(60.0, ge=10, le=3600, description="同规则冷却时间（秒）")


# ─── 基础端点 ────────────────────────────────────────────

@app.get("/")
async def root():
    return {
        "service": "Edge AgentOps",
        "version": "0.5.0",
        "mode": "multi-agent orchestration",
        "docs": "/docs",
        "agents": state.agent_registry.list_agents() if state else [],
    }


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "current_scenario": state.sim.scenario_name,
        "monitor_running": state.monitor.is_running,
        "registered_agents": state.agent_registry.list_agents(),
    }


@app.get("/api/scenarios")
async def list_scenarios():
    return {
        "current": state.sim.scenario_name,
        "available": state.sim.list_scenarios(),
    }


@app.post("/api/scenario")
async def switch_scenario(req: ScenarioSwitch):
    try:
        state.sim.set_scenario(req.scenario)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {
        "message": f"Switched to scenario: {req.scenario}",
        "scenario": req.scenario,
        "description": state.sim.description,
    }


@app.get("/api/agents")
async def list_agents():
    """查看已注册的 Agent 列表及其能力描述。"""
    agents = []
    for name in state.agent_registry.list_agents():
        spec = state.agent_registry.get_spec(name)
        agents.append({
            "name": spec.name,
            "description": spec.description,
            "keywords": spec.keywords,
            "tools_count": len(spec.tools_definition),
            "max_steps": spec.max_steps,
        })
    return {"agents": agents, "total": len(agents)}


# ─── 诊断端点 ────────────────────────────────────────────

@app.post("/api/diagnose")
async def diagnose(req: DiagnoseRequest):
    """
    核心诊断端点（多 Agent 编排模式）。

    流程：Orchestrator 路由 -> 专项 Agent 诊断 -> 汇总报告。
    """
    if req.scenario:
        try:
            state.sim.set_scenario(req.scenario)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))

    loop = asyncio.get_event_loop()
    try:
        result = await loop.run_in_executor(
            None,
            lambda: state.orchestrator.run(
                req.question,
                timeout_seconds=req.timeout_seconds,
            ),
        )
    except Exception as e:
        logger.exception("Orchestrator 诊断失败")
        raise HTTPException(status_code=500, detail=f"诊断执行失败: {e}")

    return {
        "request_id": result["request_id"],
        "mode": "orchestrator",
        "scenario": state.sim.scenario_name,
        "question": req.question,
        "answer": result["answer"],
        "agents_called": result["agents_called"],
        "route_latency_ms": result["route_latency_ms"],
        "sub_results": result["sub_results"],
        "total_tokens": result["total_tokens"],
        "stop_reason": result["stop_reason"],
    }


@app.post("/api/diagnose/simple")
async def diagnose_simple(req: DiagnoseRequest):
    """
    简单诊断端点（单 Agent 模式，跳过 Orchestrator）。

    适用于告警驱动等需要快速响应的场景。
    """
    if req.scenario:
        try:
            state.sim.set_scenario(req.scenario)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))

    loop = asyncio.get_event_loop()
    try:
        result = await loop.run_in_executor(
            None,
            lambda: state.simple_agent.run(
                req.question,
                timeout_seconds=req.timeout_seconds,
            ),
        )
    except Exception as e:
        logger.exception("Agent 诊断失败")
        raise HTTPException(status_code=500, detail=f"诊断执行失败: {e}")

    return {
        "request_id": result["request_id"],
        "mode": "simple",
        "scenario": state.sim.scenario_name,
        "question": req.question,
        "answer": result["answer"],
        "stop_reason": result["stop_reason"],
        "total_tokens": result["total_tokens"],
        "steps_count": len(result["steps"]),
        "compression_count": result["compression_count"],
    }


# ─── 告警监控端点 ────────────────────────────────────────

@app.post("/api/monitor/start")
async def start_monitor(cfg: MonitorConfig = MonitorConfig()):
    if state.monitor.is_running:
        raise HTTPException(status_code=409, detail="Monitor already running")

    state.monitor = AlertMonitor(
        sim=state.sim,
        agent=state.simple_agent,
        poll_interval=cfg.poll_interval,
        cooldown_seconds=cfg.cooldown_seconds,
    )
    state.monitor.start_background()

    return {
        "message": "Alert monitor started",
        "poll_interval": cfg.poll_interval,
        "cooldown_seconds": cfg.cooldown_seconds,
        "rules_count": len(state.monitor.rules),
    }


@app.post("/api/monitor/stop")
async def stop_monitor():
    if not state.monitor.is_running:
        raise HTTPException(status_code=409, detail="Monitor not running")
    state.monitor.stop()
    return {"message": "Alert monitor stopped"}


@app.get("/api/monitor/status")
async def monitor_status():
    history = state.monitor.alert_history
    return {
        "running": state.monitor.is_running,
        "current_scenario": state.sim.scenario_name,
        "total_alerts": len(history),
        "total_diagnoses": len(state.monitor.diagnosis_history),
        "rules": [
            {
                "name": r.name,
                "description": r.description,
                "threshold": r.threshold,
                "compare": r.compare,
                "severity": r.severity,
            }
            for r in state.monitor.rules
        ],
        "recent_alerts": [
            {
                "rule": a.rule_name,
                "severity": a.severity,
                "value": a.value,
                "threshold": a.threshold,
                "timestamp": a.timestamp,
            }
            for a in history[-20:]
        ],
    }


@app.get("/api/monitor/diagnoses")
async def monitor_diagnoses():
    """返回告警触发的自动诊断历史。"""
    diagnoses = state.monitor.diagnosis_history
    return {
        "total": len(diagnoses),
        "diagnoses": [
            {
                "trigger": d["trigger"],
                "alerts": d["alerts"],
                "max_severity": d["max_severity"],
                "answer": d["diagnosis"].get("answer", ""),
                "stop_reason": d["diagnosis"].get("stop_reason", ""),
                "total_tokens": d["diagnosis"].get("total_tokens", 0),
                "timestamp": d["timestamp"],
            }
            for d in diagnoses[-20:]
        ],
    }
