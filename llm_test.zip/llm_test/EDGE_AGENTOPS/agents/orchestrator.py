"""
Orchestrator — 多 Agent 调度大脑。

工作流程：
  1. 接收用户问题
  2. 用 LLM 判断应该派发给哪个（或哪几个）专项 Agent
  3. 并行/串行调用选中的 Agent
  4. 汇总各 Agent 的诊断结果，生成最终报告

Orchestrator 本身不调任何工具，它"调 Agent"。
"""

from __future__ import annotations

import json
import time
import logging
from typing import List, Optional, Callable

from openai import OpenAI

from agent_core import AgentConfig
from agent_core.snapshot import SnapshotManager
from .registry import AgentRegistry

logger = logging.getLogger("orchestrator")


class Orchestrator:
    """
    多 Agent 编排器。

    用法：
        orch = Orchestrator(config, registry)
        result = orch.run("视觉系统变慢了")
        # result["answer"] = 最终汇总报告
        # result["agents_called"] = ["vision_diag", "hardware_diag"]
        # result["sub_results"] = [...]
    """

    def __init__(self, config: AgentConfig, registry: AgentRegistry):
        self.config = config
        self.registry = registry
        self.client = OpenAI(
            api_key=config.api_key,
            base_url=config.base_url,
        )
        self.snapshot_mgr = SnapshotManager()

    def run(
        self,
        user_input: str,
        *,
        on_step: Optional[Callable] = None,
        timeout_seconds: Optional[float] = None,
    ) -> dict:
        """
        完整的编排流程：路由 → 派发 → 汇总。

        Returns:
            dict with keys: answer, request_id, agents_called, sub_results,
                            route_latency_ms, total_tokens, stop_reason
        """
        timeout = timeout_seconds or self.config.timeout_seconds
        t_start = time.time()
        snapshot = self.snapshot_mgr.create(user_input)

        # Step 1: 路由决策
        print("\n=== Orchestrator: 路由决策 ===")
        t0 = time.time()
        selected_agents = self._route(user_input)
        route_latency_ms = round((time.time() - t0) * 1000)
        print(f"路由结果: {selected_agents} ({route_latency_ms}ms)")

        route_step = {
            "step": 0,
            "action": "route",
            "selected_agents": selected_agents,
            "route_latency_ms": route_latency_ms,
        }
        self.snapshot_mgr.add_step(snapshot, route_step)
        if on_step:
            on_step(route_step)

        if not selected_agents:
            selected_agents = self.registry.list_agents()
            print(f"路由未命中，使用全部 Agent: {selected_agents}")

        # Step 2: 派发给各专项 Agent
        sub_results: List[dict] = []
        total_tokens = 0

        for agent_name in selected_agents:
            elapsed = time.time() - t_start
            remaining = timeout - elapsed if timeout else None
            if remaining is not None and remaining < 5:
                logger.warning("剩余时间不足，跳过 %s", agent_name)
                break

            print(f"\n=== 派发给: {agent_name} ===")
            agent = self.registry.get_agent(agent_name)
            if agent is None:
                logger.error("Agent %s 未注册", agent_name)
                continue

            agent_result = agent.run(
                user_input,
                timeout_seconds=remaining,
            )

            sub_result = {
                "agent": agent_name,
                "answer": agent_result["answer"],
                "stop_reason": agent_result["stop_reason"],
                "total_tokens": agent_result["total_tokens"],
                "steps_count": len(agent_result["steps"]),
                "compression_count": agent_result["compression_count"],
            }
            sub_results.append(sub_result)
            total_tokens += agent_result["total_tokens"]

            agent_step = {
                "step": len(sub_results),
                "action": "sub_agent",
                "agent": agent_name,
                "total_tokens": agent_result["total_tokens"],
                "stop_reason": agent_result["stop_reason"],
            }
            self.snapshot_mgr.add_step(snapshot, agent_step)
            if on_step:
                on_step(agent_step)

        # Step 3: 汇总各 Agent 结论
        print("\n=== Orchestrator: 汇总结论 ===")
        t0 = time.time()
        final_answer = self._summarize(user_input, sub_results)
        summarize_latency_ms = round((time.time() - t0) * 1000)
        total_tokens_estimate = total_tokens

        summary_step = {
            "step": len(sub_results) + 1,
            "action": "summarize",
            "summarize_latency_ms": summarize_latency_ms,
        }
        self.snapshot_mgr.add_step(snapshot, summary_step)
        if on_step:
            on_step(summary_step)

        self.snapshot_mgr.finalize(snapshot, final_answer)

        return {
            "answer": final_answer,
            "request_id": snapshot["request_id"],
            "agents_called": selected_agents,
            "sub_results": sub_results,
            "route_latency_ms": route_latency_ms,
            "total_tokens": total_tokens_estimate,
            "stop_reason": "complete",
        }

    def _route(self, user_input: str) -> List[str]:
        """用 LLM 决定应该派发给哪些 Agent。"""
        roster = self.registry.roster()
        agents_list = self.registry.list_agents()

        route_prompt = f"""你是一个诊断调度器。根据用户的问题，决定应该派给哪些专项诊断 Agent。

可用的 Agent 列表：
{roster}

规则：
1. 根据问题内容选择 1-3 个最相关的 Agent
2. 如果问题涉及多个领域，选多个 Agent
3. 如果不确定，选 system_diag（它有全局视角）
4. 只返回 JSON，不要解释

用户问题: {user_input}

请返回 JSON 格式: {{"agents": ["agent_name1", "agent_name2"]}}"""

        try:
            response = self.client.chat.completions.create(
                model=self.config.model,
                messages=[{"role": "user", "content": route_prompt}],
                temperature=0,
            )
            content = response.choices[0].message.content.strip()

            # 尝试从 LLM 输出中提取 JSON
            if "```" in content:
                content = content.split("```")[1]
                if content.startswith("json"):
                    content = content[4:]
                content = content.strip()

            data = json.loads(content)
            selected = data.get("agents", [])

            # 过滤掉不存在的 Agent 名
            valid = [a for a in selected if a in agents_list]
            return valid if valid else agents_list

        except Exception as e:
            logger.warning("路由决策失败 (%s)，使用全部 Agent", e)
            return agents_list

    def _summarize(self, user_input: str, sub_results: List[dict]) -> str:
        """汇总各 Agent 的诊断结果，生成最终报告。"""
        if not sub_results:
            return "没有可用的诊断结果。"

        if len(sub_results) == 1:
            return sub_results[0]["answer"]

        agent_reports = []
        for r in sub_results:
            agent_reports.append(f"【{r['agent']}】的诊断：\n{r['answer']}")
        reports_text = "\n\n".join(agent_reports)

        summarize_prompt = f"""你是诊断汇总专家。多个专项 Agent 分别对同一个问题给出了诊断，请你汇总为一份统一的诊断报告。

用户原始问题: {user_input}

各 Agent 的诊断结果:
{reports_text}

要求：
1. 综合各 Agent 的证据，给出统一的根因判断
2. 如果各 Agent 结论一致，提高置信度
3. 如果各 Agent 结论冲突，分析分歧并给出你的判断
4. 输出格式：根因 / 置信度 / 证据 / 建议"""

        try:
            response = self.client.chat.completions.create(
                model=self.config.model,
                messages=[{"role": "user", "content": summarize_prompt}],
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error("汇总失败: %s", e)
            return "\n\n---\n\n".join(r["answer"] for r in sub_results)
