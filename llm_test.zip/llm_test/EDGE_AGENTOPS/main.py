"""
Edge AgentOps Demo 入口。

用法:
    python main.py                          # 默认 gpu_thermal_throttle 场景
    python main.py camera_disconnect        # 指定场景
    python main.py --list                   # 列出所有可用场景

运行前:
    1. pip install -r requirements.txt
    2. 设置环境变量 DASHSCOPE_API_KEY=你的key
       或者创建 .env 文件写入: DASHSCOPE_API_KEY=你的key
"""

import sys

from agent_core import ReActAgent, AgentConfig
from simulator import JetsonSimulator
from tools import build_tool_registry, TOOLS_DEFINITION


DEMO_QUESTIONS = {
    "normal": "帮我检查一下系统状态是否正常",
    "gpu_thermal_throttle": "视觉系统好像变慢了，帮我查一下是什么原因",
    "camera_disconnect": "为什么检测任务没有结果？",
    "memory_pressure": "系统响应越来越慢，而且经常卡住，帮我诊断一下",
    "pipeline_buffer_full": "丢帧很严重，但相机看起来是正常的，怎么回事？",
}


def main():
    if "--list" in sys.argv:
        sim = JetsonSimulator()
        print("可用场景:")
        for s in sim.list_scenarios():
            print(f"  {s}")
        return

    scenario = sys.argv[1] if len(sys.argv) > 1 else "gpu_thermal_throttle"

    sim = JetsonSimulator(scenario)
    print(f"场景: {sim.scenario_name} — {sim.description}\n")

    registry = build_tool_registry(sim)

    config = AgentConfig()
    agent = ReActAgent(config, registry, TOOLS_DEFINITION)

    question = DEMO_QUESTIONS.get(scenario, "帮我诊断一下当前系统状态")
    print(f"用户提问: {question}")
    print("=" * 60)

    answer = agent.run(question)

    print("\n" + "=" * 60)
    print("诊断完成。")

    # 演示切换场景（不重建 Agent）
    if scenario != "camera_disconnect":
        print("\n\n>>> 切换场景演示 <<<")
        sim.set_scenario("camera_disconnect")
        question2 = DEMO_QUESTIONS["camera_disconnect"]
        print(f"\n用户提问: {question2}")
        print("=" * 60)
        agent.run(question2)


if __name__ == "__main__":
    main()
