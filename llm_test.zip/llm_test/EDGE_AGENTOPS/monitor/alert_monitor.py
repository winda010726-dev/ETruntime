"""
告警驱动监控器。

运行一个后台循环，定期轮询 Simulator 指标，对照告警规则评估。
一旦触发告警，自动创建 Agent 诊断任务。

设计要点：
  - 去抖动（debounce）：同一规则在冷却期内不重复触发
  - 告警聚合：同一轮多条告警合并为一次 Agent 调用
  - 异步执行：不阻塞监控循环本身
"""

from __future__ import annotations

import asyncio
import time
import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, List, Optional

from .alert_rules import AlertRule, DEFAULT_RULES

if TYPE_CHECKING:
    from agent_core import ReActAgent
    from simulator.jetson_sim import JetsonSimulator

logger = logging.getLogger("alert_monitor")


@dataclass
class AlertEvent:
    rule_name: str
    severity: str
    value: float
    threshold: float
    prompt: str
    timestamp: float = field(default_factory=time.time)


class AlertMonitor:
    """
    后台告警监控器。

    用法（standalone）：
        monitor = AlertMonitor(sim, agent)
        await monitor.start()   # 阻塞运行
        monitor.stop()          # 从外部停止

    用法（FastAPI lifespan）：
        作为 asyncio.Task 运行在 FastAPI 后台。
    """

    def __init__(
        self,
        sim: JetsonSimulator,
        agent: ReActAgent,
        rules: Optional[List[AlertRule]] = None,
        poll_interval: float = 10.0,
        cooldown_seconds: float = 60.0,
    ):
        self.sim = sim
        self.agent = agent
        self.rules = rules or DEFAULT_RULES
        self.poll_interval = poll_interval
        self.cooldown_seconds = cooldown_seconds

        self._running = False
        self._task: Optional[asyncio.Task] = None
        self._last_triggered: dict[str, float] = {}
        self._alert_history: List[AlertEvent] = []
        self._diagnosis_history: List[dict] = []

    @property
    def alert_history(self) -> List[AlertEvent]:
        return list(self._alert_history)

    @property
    def diagnosis_history(self) -> List[dict]:
        return list(self._diagnosis_history)

    @property
    def is_running(self) -> bool:
        return self._running

    def start_background(self, loop: Optional[asyncio.AbstractEventLoop] = None) -> asyncio.Task:
        """在事件循环中启动后台监控任务。"""
        self._running = True
        self._task = asyncio.ensure_future(self._monitor_loop())
        logger.info("AlertMonitor 后台任务已启动 (间隔 %.1fs, 冷却 %.1fs)",
                     self.poll_interval, self.cooldown_seconds)
        return self._task

    def stop(self):
        """停止监控循环。"""
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
        logger.info("AlertMonitor 已停止")

    async def _monitor_loop(self):
        """核心监控循环。"""
        while self._running:
            try:
                alerts = self._evaluate_rules()
                if alerts:
                    await self._handle_alerts(alerts)
            except Exception:
                logger.exception("监控循环异常")

            await asyncio.sleep(self.poll_interval)

    def _evaluate_rules(self) -> List[AlertEvent]:
        """评估所有规则，返回触发的告警（已去抖动）。"""
        now = time.time()
        triggered: List[AlertEvent] = []

        for rule in self.rules:
            result = rule.evaluate(self.sim)
            if result is None:
                continue

            last_time = self._last_triggered.get(rule.name, 0)
            if now - last_time < self.cooldown_seconds:
                continue

            event = AlertEvent(
                rule_name=result["rule"],
                severity=result["severity"],
                value=result["value"],
                threshold=result["threshold"],
                prompt=result["prompt"],
                timestamp=now,
            )
            triggered.append(event)
            self._last_triggered[rule.name] = now
            self._alert_history.append(event)

            logger.warning("告警触发: %s | %s | value=%.1f threshold=%.1f",
                           rule.name, result["severity"],
                           result["value"], result["threshold"])

        return triggered

    async def _handle_alerts(self, alerts: List[AlertEvent]):
        """聚合告警并触发 Agent 诊断。"""
        if len(alerts) == 1:
            prompt = alerts[0].prompt
        else:
            lines = [a.prompt for a in alerts]
            prompt = "同时触发了多个告警，请综合诊断：\n" + "\n".join(lines)

        severity_order = {"critical": 0, "warning": 1, "info": 2}
        max_severity = min(alerts, key=lambda a: severity_order.get(a.severity, 9)).severity

        logger.info("触发 Agent 诊断 (severity=%s, alerts=%d)", max_severity, len(alerts))

        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, self.agent.run, prompt)

        diagnosis = {
            "trigger": "alert",
            "alerts": [
                {
                    "rule": a.rule_name,
                    "severity": a.severity,
                    "value": a.value,
                    "threshold": a.threshold,
                }
                for a in alerts
            ],
            "max_severity": max_severity,
            "prompt": prompt,
            "diagnosis": result,
            "timestamp": time.time(),
        }
        self._diagnosis_history.append(diagnosis)

        logger.info("Agent 诊断完成: request_id=%s stop_reason=%s",
                     result.get("request_id"), result.get("stop_reason"))
