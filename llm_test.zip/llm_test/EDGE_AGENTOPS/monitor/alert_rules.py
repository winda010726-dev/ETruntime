"""
告警规则定义。

每条规则 = 一个指标提取函数 + 阈值 + 比较方向 + 触发后给 Agent 的提示语。
规则之间独立评估，任意一条触发都会启动 Agent 诊断。
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Callable, List, Optional

from simulator.jetson_sim import JetsonSimulator


@dataclass
class AlertRule:
    name: str
    description: str
    metric_fn: Callable[[JetsonSimulator], Optional[float]]
    threshold: float
    compare: str  # "gt" | "lt" | "gte" | "lte"
    severity: str  # "critical" | "warning" | "info"
    prompt_template: str  # {value} 和 {threshold} 会被替换

    def evaluate(self, sim: JetsonSimulator) -> Optional[dict]:
        """评估规则，返回告警 dict 或 None（未触发）。"""
        value = self.metric_fn(sim)
        if value is None:
            return None

        triggered = False
        if self.compare == "gt":
            triggered = value > self.threshold
        elif self.compare == "lt":
            triggered = value < self.threshold
        elif self.compare == "gte":
            triggered = value >= self.threshold
        elif self.compare == "lte":
            triggered = value <= self.threshold

        if not triggered:
            return None

        return {
            "rule": self.name,
            "severity": self.severity,
            "description": self.description,
            "value": value,
            "threshold": self.threshold,
            "prompt": self.prompt_template.format(value=value, threshold=self.threshold),
        }


def _parse_temperature(sim: JetsonSimulator) -> Optional[float]:
    raw = sim.get_jetson_status("temperature")
    try:
        return float(raw.replace("°C", "").strip())
    except (ValueError, AttributeError):
        return None


def _parse_gpu_load(sim: JetsonSimulator) -> Optional[float]:
    raw = sim.get_jetson_status("gpu_load")
    try:
        return float(raw.replace("%", "").strip())
    except (ValueError, AttributeError):
        return None


def _parse_memory_pct(sim: JetsonSimulator) -> Optional[float]:
    raw = sim.get_jetson_status("memory_usage")
    try:
        parts = raw.split("/")
        used = float(parts[0].replace("GB", "").strip())
        total = float(parts[1].replace("GB", "").strip())
        return round(used / total * 100, 1)
    except (ValueError, IndexError, AttributeError):
        return None


def _parse_vision_fps(sim: JetsonSimulator) -> Optional[float]:
    raw = sim.get_vision_metrics()
    try:
        data = json.loads(raw)
        return float(data.get("fps", 0))
    except (json.JSONDecodeError, TypeError):
        return None


def _parse_frame_drop(sim: JetsonSimulator) -> Optional[float]:
    raw = sim.get_vision_metrics()
    try:
        data = json.loads(raw)
        return float(data.get("frame_drop_count", 0))
    except (json.JSONDecodeError, TypeError):
        return None


def _parse_camera_connected(sim: JetsonSimulator) -> Optional[float]:
    """返回 1.0 = connected, 0.0 = disconnected。"""
    raw = sim.get_camera_status()
    try:
        data = json.loads(raw)
        return 1.0 if data.get("status") == "connected" else 0.0
    except (json.JSONDecodeError, TypeError):
        return None


DEFAULT_RULES: List[AlertRule] = [
    AlertRule(
        name="gpu_temperature_high",
        description="GPU 温度过高",
        metric_fn=_parse_temperature,
        threshold=80.0,
        compare="gt",
        severity="critical",
        prompt_template="[告警触发] GPU 温度 {value}°C 超过阈值 {threshold}°C，请立即诊断是否发生热降频及其对视觉系统的影响。",
    ),
    AlertRule(
        name="gpu_load_high",
        description="GPU 负载过高",
        metric_fn=_parse_gpu_load,
        threshold=90.0,
        compare="gt",
        severity="warning",
        prompt_template="[告警触发] GPU 负载 {value}% 超过 {threshold}%，请诊断负载过高的原因。",
    ),
    AlertRule(
        name="memory_pressure",
        description="内存使用率过高",
        metric_fn=_parse_memory_pct,
        threshold=90.0,
        compare="gt",
        severity="critical",
        prompt_template="[告警触发] 内存使用率 {value}% 超过 {threshold}%，存在 OOM 风险，请诊断内存占用来源。",
    ),
    AlertRule(
        name="vision_fps_low",
        description="视觉系统帧率过低",
        metric_fn=_parse_vision_fps,
        threshold=15.0,
        compare="lt",
        severity="warning",
        prompt_template="[告警触发] 视觉 FPS 仅 {value}，低于阈值 {threshold}，请诊断帧率下降原因。",
    ),
    AlertRule(
        name="frame_drop_high",
        description="丢帧数过多",
        metric_fn=_parse_frame_drop,
        threshold=50.0,
        compare="gt",
        severity="warning",
        prompt_template="[告警触发] 丢帧数 {value} 超过 {threshold}，请诊断丢帧原因。",
    ),
    AlertRule(
        name="camera_disconnected",
        description="相机离线",
        metric_fn=_parse_camera_connected,
        threshold=0.5,
        compare="lt",
        severity="critical",
        prompt_template="[告警触发] 相机处于离线状态，请诊断相机断连原因并给出恢复建议。",
    ),
]
