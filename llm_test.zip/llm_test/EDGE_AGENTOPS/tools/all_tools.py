"""
工具层。

每个工具 = 一个 JSON Schema 描述 + 一个 Python 函数。
- JSON Schema 给 LLM 看，让它知道工具的名字、作用、参数
- Python 函数做真正的执行，数据来自 JetsonSimulator

工具按领域分组，供 Orchestrator 分配给专项 Agent：
  - vision: 视觉管线相关
  - hardware: 硬件状态相关
  - system: 系统概览 + 日志
"""

from __future__ import annotations

from simulator.jetson_sim import JetsonSimulator


# ===== 工具定义（按领域标记） =====

TOOL_GET_JETSON_STATUS = {
    "type": "function",
    "function": {
        "name": "get_jetson_status",
        "description": "获取 Jetson 设备的硬件状态指标",
        "parameters": {
            "type": "object",
            "properties": {
                "metric": {
                    "type": "string",
                    "enum": [
                        "temperature",
                        "gpu_load",
                        "cpu_usage",
                        "memory_usage",
                        "power",
                    ],
                    "description": "要查询的指标名称",
                }
            },
            "required": ["metric"],
        },
    },
}

TOOL_GET_VISION_METRICS = {
    "type": "function",
    "function": {
        "name": "get_vision_metrics",
        "description": "获取视觉系统的实时指标（FPS、推理延迟、丢帧数、模型名等）",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}

TOOL_GET_CAMERA_STATUS = {
    "type": "function",
    "function": {
        "name": "get_camera_status",
        "description": "获取相机的连接状态、帧率、分辨率",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}

TOOL_GET_PIPELINE_STATUS = {
    "type": "function",
    "function": {
        "name": "get_pipeline_status",
        "description": "获取视觉管线状态（Ring Buffer 使用率、共享内存状态、生产者/消费者帧率、丢帧数）",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}

TOOL_GET_RECENT_LOGS = {
    "type": "function",
    "function": {
        "name": "get_recent_logs",
        "description": "获取系统最近的日志（包含错误和警告）",
        "parameters": {
            "type": "object",
            "properties": {
                "n": {
                    "type": "integer",
                    "description": "返回最近 n 条日志，默认 10",
                }
            },
            "required": [],
        },
    },
}

TOOL_GET_SYSTEM_OVERVIEW = {
    "type": "function",
    "function": {
        "name": "get_system_overview",
        "description": "获取系统整体概览（Jetson 硬件 + 视觉 FPS + 相机状态 + Buffer 使用率）",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}


# ===== 按领域分组 =====

VISION_TOOLS = [TOOL_GET_VISION_METRICS, TOOL_GET_PIPELINE_STATUS]
HARDWARE_TOOLS = [TOOL_GET_JETSON_STATUS, TOOL_GET_CAMERA_STATUS]
SYSTEM_TOOLS = [TOOL_GET_RECENT_LOGS, TOOL_GET_SYSTEM_OVERVIEW]

TOOLS_DEFINITION = VISION_TOOLS + HARDWARE_TOOLS + SYSTEM_TOOLS


def build_tool_registry(sim: JetsonSimulator) -> dict:
    """
    构建工具注册表：工具名 -> 可调用函数。

    关键设计：工具函数绑定到具体的 simulator 实例。
    切换场景只需 sim.set_scenario("xxx")，工具自动读新数据。
    """
    return {
        "get_jetson_status": sim.get_jetson_status,
        "get_vision_metrics": sim.get_vision_metrics,
        "get_camera_status": sim.get_camera_status,
        "get_pipeline_status": sim.get_pipeline_status,
        "get_recent_logs": sim.get_recent_logs,
        "get_system_overview": sim.get_system_overview,
    }
