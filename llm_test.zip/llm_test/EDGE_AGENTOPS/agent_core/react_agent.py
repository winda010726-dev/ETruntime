import json
import time
from openai import OpenAI

from .config import AgentConfig
from .snapshot import SnapshotManager


class ReActAgent:
    """
    ReAct (Reason-Act-Observe) Agent。

    核心循环：
    1. 将用户问题 + 历史发给 LLM
    2. LLM 决定调用哪些工具 → 执行 → 把结果放回上下文
    3. 重复直到 LLM 给出最终答案或达到步数上限

    相比原始 react_loop 函数，类的好处：
    - config / tools / snapshot 分离，职责清晰
    - 可以切换 simulator 场景而不改 Agent 代码
    - 后续可以扩展 token 滑动窗口、multi-agent 路由
    """

    def __init__(self, config: AgentConfig, tool_registry: dict, tools_definition: list):
        self.config = config
        self.client = OpenAI(
            api_key=config.api_key,
            base_url=config.base_url,
        )
        self.tool_registry = tool_registry
        self.tools_definition = tools_definition
        self.snapshot_mgr = SnapshotManager()

    def run(self, user_input: str) -> str:
        snapshot = self.snapshot_mgr.create(user_input)
        messages = [
            {"role": "system", "content": self.config.system_prompt},
            {"role": "user", "content": user_input},
        ]

        final_answer = "达到最大步数限制，强制停止"

        for step in range(self.config.max_steps):
            print(f"\n--- Step {step + 1} ---")

            t0 = time.time()
            response = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                tools=self.tools_definition,
            )
            llm_latency_ms = round((time.time() - t0) * 1000)
            msg = response.choices[0].message

            step_record = {
                "step": step + 1,
                "llm_latency_ms": llm_latency_ms,
                "prompt_tokens": response.usage.prompt_tokens,
                "completion_tokens": response.usage.completion_tokens,
                "total_tokens": response.usage.total_tokens,
            }

            if not msg.tool_calls:
                print(f"最终答案:\n{msg.content}")
                step_record["action"] = "final_answer"
                step_record["content"] = msg.content
                self.snapshot_mgr.add_step(snapshot, step_record)
                final_answer = msg.content
                break

            messages.append(msg)

            unique_calls = self._deduplicate_tool_calls(msg.tool_calls)
            step_record["action"] = "tool_calls"
            step_record["tools"] = []

            for tc in unique_calls:
                name = tc.function.name
                args = json.loads(tc.function.arguments)
                result = self._execute_tool(name, args)

                print(f"  调用工具: {name}({args})  →  {result}")

                messages.append({
                    "tool_call_id": tc.id,
                    "role": "tool",
                    "name": name,
                    "content": str(result),
                })
                step_record["tools"].append({
                    "name": name,
                    "args": args,
                    "result": result,
                })

            self.snapshot_mgr.add_step(snapshot, step_record)

        self.snapshot_mgr.finalize(snapshot, final_answer)
        return final_answer

    def _execute_tool(self, name: str, args: dict) -> str:
        func = self.tool_registry.get(name)
        if func is None:
            return f"错误: 工具 {name} 不存在"
        try:
            return func(**args)
        except Exception as e:
            return f"执行失败: {e}"

    @staticmethod
    def _deduplicate_tool_calls(tool_calls) -> list:
        seen = set()
        unique = []
        for tc in tool_calls:
            key = f"{tc.function.name}_{tc.function.arguments}"
            if key not in seen:
                seen.add(key)
                unique.append(tc)
        return unique
