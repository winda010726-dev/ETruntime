import json
import os
import time


class SnapshotManager:
    """
    请求快照管理器。

    每次 Agent 执行都会生成一个完整快照，包含：
    - 用户输入
    - 每一步的 LLM 响应、工具调用、token 消耗
    - 最终诊断结果

    用于事后审计、问题复现和性能分析。
    """

    def __init__(self, snapshot_dir: str = "snapshots"):
        self.snapshot_dir = snapshot_dir
        os.makedirs(self.snapshot_dir, exist_ok=True)

    def create(self, user_input: str) -> dict:
        request_id = f"req_{int(time.time() * 1000)}"
        return {
            "request_id": request_id,
            "user_input": user_input,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "steps": [],
            "total_tokens": 0,
            "final_answer": None,
        }

    def add_step(self, snapshot: dict, step_record: dict):
        snapshot["steps"].append(step_record)
        snapshot["total_tokens"] += step_record.get("total_tokens", 0)

    def finalize(self, snapshot: dict, final_answer: str):
        snapshot["final_answer"] = final_answer
        filepath = os.path.join(
            self.snapshot_dir, f"{snapshot['request_id']}.json"
        )
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(snapshot, f, ensure_ascii=False, indent=2)
        print(f"\n快照已保存: {filepath}")
        return filepath
