import os
from dotenv import load_dotenv

load_dotenv()


class AgentConfig:
    """Agent 的全局配置，统一管理 API 参数和运行限制"""

    def __init__(
        self,
        api_key: str = "sk-0c9412d65b504561974758e0736f3e28",
        base_url: str = "https://dashscope.aliyuncs.com/compatible-mode/v1",
        model: str = "qwen-turbo",
        max_steps: int = 10,
        max_tokens_per_request: int = 4000,
        system_prompt: str = "",
    ):
        self.api_key = api_key or os.getenv("DASHSCOPE_API_KEY", "")
        self.base_url = base_url
        self.model = model
        self.max_steps = max_steps
        self.max_tokens_per_request = max_tokens_per_request
        self.system_prompt = system_prompt or self._default_system_prompt()

    @staticmethod
    def _default_system_prompt() -> str:
        return """你是一个边缘计算诊断专家，负责诊断 Jetson 设备和视觉系统的问题。

诊断规则：
1. 必须调用所有相关工具收集足够数据后，才能下结论
2. 如果数据不足以确定根因，继续调用其他工具
3. 不要建议用户自己去查，你自己查
4. 对每个工具只调用一次，不要重复调用同一工具

输出格式：
- 根因（root cause）: 一句话总结
- 置信度: 高/中/低
- 证据: 列出支持判断的数据
- 建议: 具体操作步骤"""
