"""
Token 滑动窗口 + 上下文压缩。

问题：ReAct 多步推理时，messages 不断增长，最终超出模型上下文窗口。
方案：
  1. 用 tiktoken 估算每条 message 的 token 数
  2. 当总 token 数接近预算时，把最早的 tool 调用/结果压缩为一句摘要
  3. system prompt + 最新 N 轮始终保留，只压缩中间部分

压缩策略（三级）：
  Level 1: 删除 tool result 的原始 JSON，只保留摘要
  Level 2: 合并连续的 tool call + result 为一条 "已查询过 X、Y" 的消息
  Level 3: 只保留 system + user + 最后一轮上下文（极端情况）
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field


def estimate_tokens(text: str) -> int:
    """粗略估算 token 数。中文约 1.5 字/token，英文约 4 字符/token。"""
    if not text:
        return 0
    chinese_chars = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
    other_chars = len(text) - chinese_chars
    return int(chinese_chars * 0.7 + other_chars / 4) + 1


def estimate_message_tokens(msg: dict) -> int:
    """估算单条 message 的 token 数（含 role/name 等结构开销）。"""
    overhead = 4  # role, separators
    content = msg.get("content") or ""
    tokens = overhead + estimate_tokens(content)

    if msg.get("tool_calls"):
        for tc in msg["tool_calls"]:
            fn = tc.get("function", {})
            tokens += estimate_tokens(fn.get("name", ""))
            tokens += estimate_tokens(fn.get("arguments", ""))
    return tokens


@dataclass
class ContextWindow:
    """
    管理 messages 列表的 token 预算。

    用法：
        ctx = ContextWindow(token_budget=3000)
        ctx.append(msg)          # 每次添加消息后自动检查
        messages = ctx.messages  # 获取当前（可能已压缩的）消息列表
    """

    token_budget: int = 3000
    preserve_recent: int = 4  # 始终保留最近 N 条消息不压缩

    _messages: list[dict] = field(default_factory=list)
    _token_counts: list[int] = field(default_factory=list)
    _total_tokens: int = 0
    _compression_count: int = 0

    @property
    def messages(self) -> list[dict]:
        return list(self._messages)

    @property
    def total_tokens(self) -> int:
        return self._total_tokens

    @property
    def compression_count(self) -> int:
        return self._compression_count

    def append(self, msg: dict):
        """添加消息，必要时触发压缩。"""
        tokens = estimate_message_tokens(msg)
        self._messages.append(msg)
        self._token_counts.append(tokens)
        self._total_tokens += tokens

        if self._total_tokens > self.token_budget * 0.85:
            self._compress()

    def extend(self, msgs: list[dict]):
        for m in msgs:
            self.append(m)

    def _compress(self):
        """压缩中间消息，保留 system prompt 和最近几轮。"""
        if len(self._messages) <= self.preserve_recent + 1:
            return

        system_msg = None
        start_idx = 0
        if self._messages and self._messages[0]["role"] == "system":
            system_msg = self._messages[0]
            start_idx = 1

        protected_count = self.preserve_recent
        compress_end = len(self._messages) - protected_count

        if compress_end <= start_idx:
            return

        compressible = self._messages[start_idx:compress_end]
        if not compressible:
            return

        summary = self._summarize_messages(compressible)
        summary_msg = {
            "role": "system",
            "content": f"[上下文摘要] 之前的诊断步骤摘要：{summary}",
        }

        new_messages = []
        new_token_counts = []

        if system_msg:
            new_messages.append(system_msg)
            new_token_counts.append(self._token_counts[0])

        summary_tokens = estimate_message_tokens(summary_msg)
        new_messages.append(summary_msg)
        new_token_counts.append(summary_tokens)

        new_messages.extend(self._messages[compress_end:])
        new_token_counts.extend(self._token_counts[compress_end:])

        self._messages = new_messages
        self._token_counts = new_token_counts
        self._total_tokens = sum(new_token_counts)
        self._compression_count += 1

    @staticmethod
    def _summarize_messages(messages: list[dict]) -> str:
        """把一组消息压缩成文字摘要。"""
        tool_calls_made = []
        key_findings = []
        user_questions = []

        for msg in messages:
            role = msg.get("role", "")

            if role == "user":
                content = msg.get("content", "")
                if content:
                    user_questions.append(content[:80])

            elif role == "assistant":
                if msg.get("tool_calls"):
                    for tc in msg["tool_calls"]:
                        fn = tc.get("function", {})
                        tool_calls_made.append(fn.get("name", "unknown"))
                content = msg.get("content")
                if content and not msg.get("tool_calls"):
                    key_findings.append(content[:100])

            elif role == "tool":
                content = msg.get("content", "")
                name = msg.get("name", "tool")
                try:
                    data = json.loads(content)
                    brief = _brief_json(data)
                except (json.JSONDecodeError, TypeError):
                    brief = content[:60] if len(content) > 60 else content
                key_findings.append(f"{name} 返回: {brief}")

        parts = []
        if user_questions:
            parts.append(f"用户问题: {'; '.join(user_questions)}")
        if tool_calls_made:
            parts.append(f"已调用工具: {', '.join(tool_calls_made)}")
        if key_findings:
            parts.append(f"关键发现: {'; '.join(key_findings[:5])}")

        return " | ".join(parts) if parts else "无显著信息"


def _brief_json(data: dict, max_keys: int = 4) -> str:
    """把 JSON dict 压缩成简短字符串。"""
    if not isinstance(data, dict):
        return str(data)[:60]
    items = list(data.items())[:max_keys]
    parts = [f"{k}={v}" for k, v in items]
    suffix = f" (+{len(data) - max_keys} more)" if len(data) > max_keys else ""
    return ", ".join(parts) + suffix
