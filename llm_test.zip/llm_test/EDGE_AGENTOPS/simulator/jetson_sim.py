"""
Jetson 设备仿真器。

作用：在没有真实 Jetson 硬件时，模拟各种设备状态和故障场景。
每个场景是一组固定的指标数据，工具函数从这里读数据而不是真实设备。

场景设计原则：每个场景对应一个明确的根因，Agent 必须通过
多个工具的交叉证据才能正确定位。
"""

import json
from typing import Any

# ===== 场景定义 =====

SCENARIOS: dict[str, dict[str, Any]] = {
    "normal": {
        "description": "一切正常 — 基线状态",
        "jetson": {
            "temperature": "52°C",
            "gpu_load": "35%",
            "cpu_usage": "28%",
            "memory_usage": "2.1GB / 8GB",
            "power": "8.5W",
        },
        "vision": {
            "fps": 30,
            "inference_latency_ms": 33,
            "frame_drop_count": 0,
            "model_name": "yolov8n",
            "input_resolution": "640x480",
        },
        "camera": {
            "status": "connected",
            "fps": 30,
            "resolution": "640x480",
            "device": "/dev/video0",
        },
        "pipeline": {
            "ring_buffer_usage": "12/64",
            "shared_memory_status": "ok",
            "producer_fps": 30,
            "consumer_fps": 30,
            "dropped_frames": 0,
        },
        "logs": [],
    },

    "gpu_thermal_throttle": {
        "description": "GPU 过热导致降频，视觉推理变慢",
        "jetson": {
            "temperature": "88°C",
            "gpu_load": "95%",
            "cpu_usage": "45%",
            "memory_usage": "5.2GB / 8GB",
            "power": "14.8W",
        },
        "vision": {
            "fps": 8,
            "inference_latency_ms": 320,
            "frame_drop_count": 47,
            "model_name": "yolov8n",
            "input_resolution": "640x480",
        },
        "camera": {
            "status": "connected",
            "fps": 30,
            "resolution": "640x480",
            "device": "/dev/video0",
        },
        "pipeline": {
            "ring_buffer_usage": "58/64",
            "shared_memory_status": "ok",
            "producer_fps": 30,
            "consumer_fps": 8,
            "dropped_frames": 47,
        },
        "logs": [
            "[WARN] GPU temperature 88°C exceeds threshold 80°C",
            "[WARN] Thermal throttling activated, GPU clock reduced to 600MHz",
            "[WARN] Vision pipeline frame drop rate > 50%",
        ],
    },

    "camera_disconnect": {
        "description": "相机断开连接，无帧输入",
        "jetson": {
            "temperature": "48°C",
            "gpu_load": "5%",
            "cpu_usage": "12%",
            "memory_usage": "1.8GB / 8GB",
            "power": "6.2W",
        },
        "vision": {
            "fps": 0,
            "inference_latency_ms": 0,
            "frame_drop_count": 0,
            "model_name": "yolov8n",
            "input_resolution": "640x480",
        },
        "camera": {
            "status": "disconnected",
            "fps": 0,
            "resolution": "N/A",
            "device": "/dev/video0",
        },
        "pipeline": {
            "ring_buffer_usage": "0/64",
            "shared_memory_status": "ok",
            "producer_fps": 0,
            "consumer_fps": 0,
            "dropped_frames": 0,
        },
        "logs": [
            "[ERROR] Camera /dev/video0 open failed: No such device",
            "[ERROR] GStreamer pipeline failed to start",
            "[WARN] Vision pipeline idle — no input frames for 30s",
        ],
    },

    "memory_pressure": {
        "description": "显存/内存不足导致 OOM 风险",
        "jetson": {
            "temperature": "72°C",
            "gpu_load": "78%",
            "cpu_usage": "65%",
            "memory_usage": "7.6GB / 8GB",
            "power": "13.2W",
        },
        "vision": {
            "fps": 5,
            "inference_latency_ms": 580,
            "frame_drop_count": 120,
            "model_name": "yolov8n",
            "input_resolution": "640x480",
        },
        "camera": {
            "status": "connected",
            "fps": 30,
            "resolution": "640x480",
            "device": "/dev/video0",
        },
        "pipeline": {
            "ring_buffer_usage": "64/64",
            "shared_memory_status": "full",
            "producer_fps": 30,
            "consumer_fps": 5,
            "dropped_frames": 120,
        },
        "logs": [
            "[WARN] Memory usage 95% — approaching OOM",
            "[WARN] Ring buffer full, producer blocking",
            "[ERROR] Shared memory allocation failed: No space left",
            "[WARN] Vision inference latency spike: 580ms (baseline 33ms)",
        ],
    },

    "pipeline_buffer_full": {
        "description": "Ring buffer 满导致生产者阻塞，消费者跟不上",
        "jetson": {
            "temperature": "62°C",
            "gpu_load": "90%",
            "cpu_usage": "55%",
            "memory_usage": "4.5GB / 8GB",
            "power": "11.5W",
        },
        "vision": {
            "fps": 10,
            "inference_latency_ms": 200,
            "frame_drop_count": 85,
            "model_name": "yolov8n",
            "input_resolution": "1280x720",
        },
        "camera": {
            "status": "connected",
            "fps": 30,
            "resolution": "1280x720",
            "device": "/dev/video0",
        },
        "pipeline": {
            "ring_buffer_usage": "64/64",
            "shared_memory_status": "ok",
            "producer_fps": 30,
            "consumer_fps": 10,
            "dropped_frames": 85,
        },
        "logs": [
            "[WARN] Ring buffer full (64/64), dropping oldest frame",
            "[WARN] Consumer (inference) lagging: 10 fps vs producer 30 fps",
            "[INFO] Input resolution 1280x720 — consider downscaling to 640x480",
        ],
    },
}


class JetsonSimulator:
    """
    通过切换 scenario 来模拟不同故障状态。
    所有工具函数从 simulator 读数据。

    用法:
        sim = JetsonSimulator("gpu_thermal_throttle")
        print(sim.get_jetson_status("temperature"))  # "88°C"
        sim.set_scenario("camera_disconnect")         # 切换场景
    """

    def __init__(self, scenario: str = "normal"):
        self._scenario_name = scenario
        self._data = SCENARIOS[scenario]

    @property
    def scenario_name(self) -> str:
        return self._scenario_name

    @property
    def description(self) -> str:
        return self._data["description"]

    def set_scenario(self, name: str):
        if name not in SCENARIOS:
            raise ValueError(
                f"未知场景 '{name}'，可选: {list(SCENARIOS.keys())}"
            )
        self._scenario_name = name
        self._data = SCENARIOS[name]
        import logging
        logging.getLogger("simulator").info("已切换到场景: %s — %s", name, self._data['description'])

    def list_scenarios(self) -> list[str]:
        return [
            f"{k}: {v['description']}" for k, v in SCENARIOS.items()
        ]

    # ----- 以下方法供 tools 调用 -----

    def get_jetson_status(self, metric: str) -> str:
        value = self._data["jetson"].get(metric)
        if value is None:
            available = list(self._data["jetson"].keys())
            return f"未知指标 '{metric}'，可用: {available}"
        return str(value)

    def get_vision_metrics(self) -> str:
        return json.dumps(self._data["vision"], ensure_ascii=False)

    def get_camera_status(self) -> str:
        return json.dumps(self._data["camera"], ensure_ascii=False)

    def get_pipeline_status(self) -> str:
        return json.dumps(self._data["pipeline"], ensure_ascii=False)

    def get_recent_logs(self, n: int = 10) -> str:
        logs = self._data["logs"][:n]
        if not logs:
            return "无最近日志"
        return "\n".join(logs)

    def get_system_overview(self) -> str:
        overview = {
            "scenario": self._scenario_name,
            "jetson": self._data["jetson"],
            "vision_fps": self._data["vision"]["fps"],
            "camera_status": self._data["camera"]["status"],
            "buffer_usage": self._data["pipeline"]["ring_buffer_usage"],
        }
        return json.dumps(overview, ensure_ascii=False)
