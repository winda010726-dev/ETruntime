#!/bin/sh
set -eu

# Default values
TIMEOUT=300
CARDS="dwceqos0 dwceqos1"
OUTPUT_DIR="$(pwd)/output"

while [ $# -gt 0 ]; do
  case "$1" in
    -c)
      shift
      if [ $# -eq 0 ]; then
        echo "Error: -c requires at least one card name"
        exit 1
      fi
      CARDS=""
      while [ $# -gt 0 ] && [ "${1#-}" = "$1" ]; do
        CARDS="$CARDS $1"
        shift
      done
      ;;
    -t)
      shift
      if [ $# -eq 0 ]; then
        echo "Error: -t requires timeout seconds"
        exit 1
      fi
      TIMEOUT="$1"
      shift
      ;;
    -o)
      shift
      if [ $# -eq 0 ]; then
        echo "Error: -o requires output directory"
        exit 1
      fi
      OUTPUT_DIR="$1"
      shift
      ;;
    *)
      echo "Unknown option: $1"
      exit 1
      ;;
  esac
done

mkdir -p "$OUTPUT_DIR"
echo "Start ETH Bandwidth monitoring, output -> $OUTPUT_DIR"
echo "Timeout: ${TIMEOUT}s"
echo "Network cards: $CARDS"

if [ -z "$CARDS" ]; then
  echo "No cards specified."
  exit 1
fi

PMAP="/tmp/eth_pids_$$.map"
: >"$PMAP"

for IFNAME in $CARDS; do
  OUT="$OUTPUT_DIR/eth_${IFNAME}_bandwidth.txt"
  echo "Monitoring interface: $IFNAME -> $OUT"

  timeout "$TIMEOUT" /system/usr/bin/netstat -I "$IFNAME" 1 >>"$OUT" 2>&1 &
  PID=$!
  echo "$PID $IFNAME" >>"$PMAP"
done

while read -r PID IFNAME; do
  if wait "$PID"; then
    STATUS=$?
  else
    STATUS=$?
  fi

  if [ "$STATUS" -eq 124 ]; then
    echo "$IFNAME: monitoring stopped due to timeout ($TIMEOUT seconds). Output: $OUTPUT_DIR/eth_${IFNAME}_bandwidth.txt"
  else
    echo "$IFNAME: monitoring finished (exit $STATUS). Output: $OUTPUT_DIR/eth_${IFNAME}_bandwidth.txt"
  fi
done <"$PMAP"

rm -f "$PMAP"
echo "All done."
