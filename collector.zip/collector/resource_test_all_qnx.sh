#!/bin/bash
echo "#############################################"
echo "## MPC4 J6B Resource Data Collection V2.9 ##"
echo "#############################################"

export PATH=$PATH:/proc/boot:/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/bin:/system/bin:/system/sbin:/system/usr/bin:/system/usr/sbin:/opt/bin

WORK_DIR="$(pwd)"
CARDS="dwceqos0 dwceqos1"
MODE_MINIMAL=0
TOTAL_TIME=300
INTERVAL=10
OUTPUT_DIR=""
SUFFIX=""

while getopts "mt:i:o:c:s:" opt; do
  case "$opt" in
    m) MODE_MINIMAL=1 ;;
    t) TOTAL_TIME="$OPTARG" ;;
    i) INTERVAL="$OPTARG" ;;
    o) OUTPUT_DIR="$OPTARG" ;;
    c) CARDS="$OPTARG" ;;
    s) SUFFIX="$OPTARG" ;;
    *)
      echo "Usage: $0 [-m] [-t total_time] [-i interval] [-o output_dir] [-c cards] [-s suffix]" >&2
      exit 1
      ;;
  esac
done

echo "[INFO] Granting execution permissions to all files in $WORK_DIR"
chmod +x -R "$WORK_DIR" 2>/dev/null

Board_Name=$(cat /sys/class/boardinfo/board_name)

if [ "$MODE_MINIMAL" -eq 0 ]; then
  Platform="ET_etna"
  Date=$(date +%Y/%m/%d)
  Date_compact=$(date +%Y%m%d)
  TR_NUMBER="NA"
  TR_Link="NA"
else
  Platform="Minimal_Platform"
  Date=$(date +%Y/%m/%d)
  Date_compact=$(date +%Y%m%d)
  TR_NUMBER="SmokeTest"
  TR_Link="NA"
  echo "[Mode] Minimal Mode detected."
fi

if [ -z "$OUTPUT_DIR" ]; then
  if [ "$MODE_MINIMAL" -eq 1 ]; then
    OUTPUT_DIR="$WORK_DIR/output"
  else
    OUTPUT_DIR="${WORK_DIR}/System_Resource_Raw_Data_${Platform}_${Date_compact}"
  fi
fi

if [ -n "$SUFFIX" ]; then
  OUTPUT_DIR="${OUTPUT_DIR}_${SUFFIX}"
fi

case "$OUTPUT_DIR" in
  /*) ;;
  *) OUTPUT_DIR="$WORK_DIR/$OUTPUT_DIR" ;;
esac

echo "[INFO] Output directory: $OUTPUT_DIR"

[ -d "$OUTPUT_DIR" ] && rm -rf "$OUTPUT_DIR"
mkdir -p "$OUTPUT_DIR" || exit 1

LOG_FILE="$OUTPUT_DIR/resource_collection.log"
echo "Resource Collection Start: $(date)" >"$LOG_FILE"
{
  echo "=== Test Information ==="
  echo "Date: $Date"
  echo "TR_Link: $TR_Link"
  echo "TR_NUMBER: $TR_NUMBER"
  echo "Platform: $Platform"
  echo "Board_Name: $Board_Name"
  echo "Suffix: ${SUFFIX:-None}"
  echo "========================"
} >>"$LOG_FILE"

exec > >(tee -a "$LOG_FILE") 2>&1

{
  echo "=== Version Info ==="
  echo "Date: $Date"
  echo "Platform: $Platform"
  echo "Board_Name: $Board_Name"
  echo -e "\nSystem Version Information:"
  cat /opt/version 2>/dev/null || echo "Cannot access /opt/version file"
} >"$OUTPUT_DIR/version.txt"

declare -a PIDS=()
cleanup() {
  echo "[$(date)] Cleanup: Killing all background tasks..."
  for pid in "${PIDS[@]}"; do
    kill -0 "$pid" 2>/dev/null && kill -9 "$pid" 2>/dev/null
  done
  echo "Resource Collection End: $(date)"
  exit
}
trap cleanup SIGINT SIGTERM

if [ -f "$WORK_DIR/collect_pmap.sh" ]; then
  chmod +x "$WORK_DIR/collect_pmap.sh"
  "$WORK_DIR/collect_pmap.sh" -o "$OUTPUT_DIR" >"$OUTPUT_DIR/pmap_output.txt" 2>&1 &
  PIDS+=("$!")
  echo "collect_pmap.sh started (pid=${PIDS[-1]})"
fi

if [ "$MODE_MINIMAL" -eq 0 ]; then
  [ -f "$WORK_DIR/runtime_tool_QNX8" ] && {
    chmod +x "$WORK_DIR/runtime_tool_QNX8"
    on -p 100f "$WORK_DIR/runtime_tool_QNX8" -t 50 -r 250 -csv >"$OUTPUT_DIR/runtime_log.csv" 2>&1 &
    PIDS+=("$!")
  }
  [ -f "$WORK_DIR/bandwidth.sh" ] && {
    chmod +x "$WORK_DIR/bandwidth.sh"
    "$WORK_DIR/bandwidth.sh" -o "$OUTPUT_DIR" "$TOTAL_TIME" 250000 >"$OUTPUT_DIR/bandwidth_output.txt" 2>&1 &
    PIDS+=("$!")
  }
  [ -f "$WORK_DIR/eth_bandwidth.sh" ] && {
    chmod +x "$WORK_DIR/eth_bandwidth.sh"
    "$WORK_DIR/eth_bandwidth.sh" -t "$TOTAL_TIME" -c "$CARDS" -o "$OUTPUT_DIR" >"$OUTPUT_DIR/eth_bandwidth_output.txt" 2>&1 &
    PIDS+=("$!")
  }
fi

if [ -f "$WORK_DIR/system_trace.sh" ]; then
  chmod +x "$WORK_DIR/system_trace.sh"
  ST_ARGS="-t $TOTAL_TIME -o $OUTPUT_DIR"
  [ "$MODE_MINIMAL" -eq 1 ] && ST_ARGS="$ST_ARGS -m"
  "$WORK_DIR/system_trace.sh" $ST_ARGS >"$OUTPUT_DIR/system_trace_output.txt" 2>&1 &
  PIDS+=("$!")
  echo "system_trace.sh started (pid=${PIDS[-1]})"
fi

HEADER="Collected at: $(date)\nTest Info: $Platform - $Date\n"

if [ -f "/sys/kernel/debug/ion/heaps/all_heap_info" ]; then
  echo -e "=== ION Heap Info ===\n$HEADER" >"$OUTPUT_DIR/ion_usage.txt"
  cat /sys/kernel/debug/ion/heaps/all_heap_info >>"$OUTPUT_DIR/ion_usage.txt" 2>&1
fi

if command -v boottime >/dev/null 2>&1; then
  echo -e "=== Boot Time Info ===\n$HEADER" >"$OUTPUT_DIR/boottime.txt"
  boottime >>"$OUTPUT_DIR/boottime.txt" 2>&1
fi

if command -v pidin >/dev/null 2>&1; then
  echo -e "=== System Page ASINFO ===\n$HEADER" >"$OUTPUT_DIR/syspage_asinfo.txt"
  pidin syspage=asinfo >>"$OUTPUT_DIR/syspage_asinfo.txt" 2>&1
fi

for ((elapsed = 0; elapsed < TOTAL_TIME; elapsed += INTERVAL)); do
  echo "[Progress] Elapsed: ${elapsed}s | Remaining: $((TOTAL_TIME - elapsed))s | $((elapsed * 100 / TOTAL_TIME))%"
  sleep $INTERVAL
done

cleanup
