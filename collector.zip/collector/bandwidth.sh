#!/bin/sh

# --- Configuration ---
TOOL_NAME="hrut_ddr_V2"
TOOL_PATH="./hrut_ddr_V2"

# Add all conflicting process names to this list (space-separated)
CONFLICT_LIST="ddr_monitor system/sbin/ddr_monitor"

CURRENT_MEASURE_PID=""

# Function to clean up background processes on interruption
cleanup() {
  echo ""
  echo "Interrupted, cleaning up..."
  if [ -n "$CURRENT_MEASURE_PID" ]; then
    kill -TERM "$CURRENT_MEASURE_PID" 2>/dev/null
    sleep 1
    kill -9 "$CURRENT_MEASURE_PID" 2>/dev/null
  fi
  exit 1
}

trap cleanup INT TERM

# Parse command line options
OUTPUT_DIR=""
while getopts "o:" opt; do
  case "$opt" in
    o) OUTPUT_DIR="$OPTARG" ;;
    *)
      echo "Invalid option: $opt" >&2
      exit 1
      ;;
  esac
done

shift $((OPTIND - 1))

if [ -z "$OUTPUT_DIR" ]; then
  OUTPUT_DIR="$(pwd)/output"
fi

mkdir -p "$OUTPUT_DIR"
echo "=== Bandwidth Monitoring Started ==="

# 1. Clean up all targets: The tool itself and all conflicting processes
# We combine TOOL_NAME and CONFLICT_LIST into one list for iteration
ALL_TARGETS="$TOOL_NAME $CONFLICT_LIST"

echo "Initializing environment and clearing conflicting processes..."

for proc_to_check in $ALL_TARGETS; do
  # Identify PIDs using awk (matching the process name in the last column)
  # We use ~ for partial match or == for exact match. $NF is usually the process name in pidin.
  existing_pids=$(pidin | awk -v proc="$proc_to_check" '$NF ~ proc {print $1}' | sort -u)

  if [ -n "$existing_pids" ]; then
    echo "Found process matching '$proc_to_check': PIDs ($existing_pids)"
    for pid in $existing_pids; do
      echo "  - Terminating PID $pid..."
      kill -9 "$pid" 2>/dev/null

      # Wait briefly and verify termination
      i=0
      while [ "$i" -lt 5 ]; do
        if ! kill -0 "$pid" 2>/dev/null; then break; fi
        sleep 0.5
        i=$((i + 1))
      done
    done
  fi
done
echo "Environment cleanup completed."

# 2. Set measurement parameters
TIMEOUT=${1:-600}
SAMPLE_PERIOD=${2:-250000} # microseconds
LOG_FILE="$OUTPUT_DIR/bandwidth_log.csv"

echo ""
echo "=== Starting Bandwidth Measurement ==="
echo "Primary Tool: $TOOL_NAME"
echo "Duration: ${TIMEOUT} seconds"
echo "Sample period: ${SAMPLE_PERIOD} microseconds"
echo "Output file: $LOG_FILE"
echo ""

# 3. Start the tool
# Executed via timeout in the background to allow the script to catch signals (trap)
timeout "$TIMEOUT" "$TOOL_PATH" -t "rr_all" -p "$SAMPLE_PERIOD" >"$LOG_FILE" &
CURRENT_MEASURE_PID=$!

# Wait for the measurement process to complete
wait $CURRENT_MEASURE_PID
measurement_exit=$?

# 4. Handle exit status
echo ""
if [ $measurement_exit -eq 124 ]; then
  echo "Measurement reached timeout (${TIMEOUT}s) and was stopped."
elif [ $measurement_exit -ne 0 ]; then
  echo "Measurement exited with error code $measurement_exit"
else
  echo "Measurement completed successfully."
fi

echo "Data saved to: $LOG_FILE"
echo "=== Bandwidth Monitoring Finished ==="

exit $measurement_exit
