#!/bin/sh

start_time=$(date +%s.%3N)

OUTPUT_DIR=""
while getopts "o:" opt; do
  case "$opt" in
    o) OUTPUT_DIR="$OPTARG" ;;
    *)
      echo "Invalid option: $opt" >&2
      exit 1
      ;;
  esac
done

if [ -z "$OUTPUT_DIR" ]; then
  OUTPUT_DIR="$(pwd)/output"
fi

# Define output directory
TEMP_DIR="$OUTPUT_DIR/pmap_collection_$$"

# Clean old file
rm -rf "$TEMP_DIR" 2>/dev/null

# Create temp file
mkdir -p "$TEMP_DIR" || {
  echo "Failed to create temp file $TEMP_DIR" >&2
  exit 1
}

# Step 1: Collect all pmap data quickly (only PID)
echo "Step 1: Collecting pmap data for all processes..."
pidin -F "%a" | while read -r pid; do
  [ -z "$pid" ] && continue
  [ ! -f "/proc/$pid/pmap" ] && continue

  # Write pmap data with .txt extension for better readability
  cat "/proc/$pid/pmap" 2>/dev/null >"${TEMP_DIR}/pid_${pid}_pmap.txt"
done

# Step 2: Collect process name list separately
echo "Step 2: Collecting process name list..."
{
  echo "PID ProcessName CmdlineName"
  echo "--------------------------"
  pidin -F "%a %N" | while read -r pid name; do
    [ -z "$pid" ] && continue
    # Get process name from cmdline for more accuracy, avoid extra subprocesses
    cmdline=$(cat "/proc/$pid/cmdline" 2>/dev/null | tr '\0' ' ')
    cmdline_name=${cmdline%% *}
    cmdline_base=${cmdline_name##*/}
    echo "$pid \"$name\" \"$cmdline_base\""
  done
} >"${TEMP_DIR}/process_names.csv"

# Create archive with both pmap data and name list
echo "Step 4: Creating archive..."
if (cd "$TEMP_DIR" && tar -cf "${OUTPUT_DIR}/pmap_collection.tar" *.txt process_names.csv 2>/dev/null); then
  echo "Collection completed!"
  echo "Files saved in: ${OUTPUT_DIR}/pmap_collection.tar"
else
  echo "Archive creation failed" >&2
  exit 1
fi

# Clean up temp files
rm -rf "$TEMP_DIR"

end_time=$(date +%s.%3N)

# Calculate and print duration
duration=$(awk "BEGIN {print $end_time - $start_time}")
echo "Total duration: ${duration} seconds"
exit 0
