#!/bin/sh

# Default values
OUTPUT_DIR="$(pwd)/output"
MODE_MINIMAL=0
TOTAL_TIME=300

while getopts "mt:o:" opt; do
  case "$opt" in
    m) MODE_MINIMAL=1 ;;
    t) TOTAL_TIME="$OPTARG" ;;
    o) OUTPUT_DIR="$OPTARG" ;;
    *)
      echo "Invalid option: $opt" >&2
      exit 1
      ;;
  esac
done

mkdir -p "${OUTPUT_DIR}"

SYS_LOG="${OUTPUT_DIR}/system_trace.txt"

run_once() {
  {
    echo "========================================"
    echo "Execution started at: $(date)"
    echo "========================================"
  } >>"${SYS_LOG}"

  # top
  echo "--- $(date) Executing: top -i 1 ---" | tee -a "${SYS_LOG}" >>"${OUTPUT_DIR}/top_trace.txt"
  top -b -i 1 -d 5 2>&1 | tee -a "${SYS_LOG}" >>"${OUTPUT_DIR}/top_trace.txt"

  # pidin
  echo "--- $(date) Executing: pidin ---" | tee -a "${SYS_LOG}" >>"${OUTPUT_DIR}/pidin_trace.txt"
  pidin 2>&1 | tee -a "${SYS_LOG}" >>"${OUTPUT_DIR}/pidin_trace.txt"

  # pidin mem
  # echo "--- $(date) Executing: pidin mem ---" >> "${OUTPUT_DIR}/pidin_mem_trace.txt"
  # pidin mem >> "${OUTPUT_DIR}/pidin_mem_trace.txt" 2>&1

  # hogs
  echo "--- $(date) Executing: hogs -m etsp -S m -l 30 ---" | tee -a "${SYS_LOG}" >>"${OUTPUT_DIR}/hogs_trace.txt"
  hogs -i 1 -m etsp -S m -l 30 -s 1 2>&1 | tee -a "${SYS_LOG}" >>"${OUTPUT_DIR}/hogs_trace.txt"

  # hrut_somstatus
  echo "--- $(date) Executing: hrut_somstatus ---" | tee -a "${SYS_LOG}" >>"${OUTPUT_DIR}/hrut_somstatus.txt"
  hrut_somstatus 2>&1 | tee -a "${SYS_LOG}" >>"${OUTPUT_DIR}/hrut_somstatus.txt"

  {
    echo "========================================"
    echo "Execution finished at: $(date)"
    echo "========================================"
  } >>"${SYS_LOG}"
}

if [ "$MODE_MINIMAL" -eq 1 ]; then
  echo "[system_trace] Minimal mode: run once."
  run_once
  exit 0
fi

echo "[system_trace] Normal mode: continuous trace for ${TOTAL_TIME} seconds."

END_TIME=$(($(date +%s) + TOTAL_TIME))

while [ "$(date +%s)" -lt $END_TIME ]; do
  run_once
  REMAINING=$((END_TIME - $(date +%s)))
  if [ $REMAINING -lt 3 ]; then
    echo "[system_trace] Remaining time ($REMAINING seconds) less than 30s, exiting."
    break
  fi
  sleep 2
done

echo "[system_trace] Completed ${TOTAL_TIME} seconds of tracing."
