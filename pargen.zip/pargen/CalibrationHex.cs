using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Runtime.InteropServices;
using System.Globalization;

namespace parsrv
{
    // Write Intel-Hex-File
    public class cIntelHexWriter
    {
        private List<int> my_values;
        private bool check_endianness;

        public cIntelHexWriter()
        {
            this.my_values = new List<int>();
        }

        public void OutputStart(ref StreamWriter my_writer, int start_address, string endianness)
        {
            int i;

            // Number of data bytes - always 2.
            Add(1, 2, endianness);

            // Address (big endian) - always 0.
            Add(2, 0, endianness);

            // Record type - always 4
            Add(1, 4, endianness);


            if (endianness == "LITTLE")
            {
                // Set to true for LITTLE endian (i.e while writing address to HEX).
                check_endianness = true;   
            }

            // Data (big endian).
            Add(2, (start_address >> 16), endianness);

            // Crc.
            AddCRC();

            // Write data to output stream.
            my_writer.Write(":");

            for (i = 0; i < my_values.Count; i++)
            {
                my_writer.Write("{0:X2}", my_values[i]);
            }

            my_writer.WriteLine("");

            this.my_values.Clear();
        }

        public void OutputEnd(ref StreamWriter my_writer)
        {
            my_writer.WriteLine(":00000001FF");
        }

        public void OutputData(ref StreamWriter my_writer, int start_address, List<int> data, int data_offset, int data_number, string endianness)
        {
            int i;

            // Number of data bytes.
            Add(1, data_number, endianness);

            // Address (little and big endian).
            if (endianness == "LITTLE")
            {
                // Set to true for LITTLE endian (i.e while writing address to HEX).
                check_endianness = true;           
            }

            Add(2, start_address & 0x0000FFFF, endianness);

            // Record type - always 0.
            Add(1, 0, endianness);

            // Data.
            for (i = 0; i < data_number; i++)
            {
                my_values.Add(data[data_offset + i]);
            }

            // Crc.
            AddCRC();

            // Write data to output stream.
            my_writer.Write(":");

            for (i = 0; i < my_values.Count; i++)
            {
                my_writer.Write("{0:X2}", my_values[i]);
            }

            my_writer.WriteLine("");

            this.my_values.Clear();
        }

        // Computes the CRC and adds it at the end of the value list.
        public void AddCRC()
        {
            int sum = 0;

            // Sum up all data bytes ...
            foreach (int value in this.my_values)
            {
                sum += value;
            }

            // Invert ...
            sum = ~sum;

            // Two's complement.
            sum = sum + 1;

            // And add the CRC at the end - but only the low byte.
            my_values.Add(sum & 0x000000FF);
        }

        // Adds new data of the list. depending on the size, up to 4 bytes, the values will be extracted from the input integer value.
        public void Add(int my_number, int my_value, string endianness)
        {
            // The function can handle up to 4 bytes data types
            switch (my_number)
            {
                case 1:
                    // 1 byte type
                    my_values.Add(my_value & 0x000000FF);
                    break;

                case 2:
                    // 2 byte type
                    if (endianness == "LITTLE")
                    {
                        if (check_endianness == true)
                        {
                            my_values.Add((my_value >> 8) & 0x000000FF);
                            my_values.Add(my_value & 0x000000FF);
                            check_endianness = false;
                        }
                        else
                        {
                            my_values.Add(my_value & 0x000000FF);
                            my_values.Add((my_value >> 8) & 0x000000FF);
                        }
                    }
                    else if (endianness == "BIG")
                    {
                        my_values.Add((my_value >> 8) & 0x000000FF);
                        my_values.Add(my_value & 0x000000FF);
                    }
                    break;

                case 3:
                    // 3 byte type
                    if (endianness == "LITTLE")
                    {
                        my_values.Add(my_value & 0x000000FF);
                        my_values.Add((my_value >> 8) & 0x000000FF);
                        my_values.Add((my_value >> 16) & 0x000000FF);
                    }
                    else if (endianness == "BIG")
                    {
                        my_values.Add((my_value >> 16) & 0x000000FF);
                        my_values.Add((my_value >> 8) & 0x000000FF);
                        my_values.Add(my_value & 0x000000FF);
                    }
                    break;

                case 4:
                    // 4 byte type
                    if (endianness == "LITTLE")
                    {
                        my_values.Add(my_value & 0x000000FF);
                        my_values.Add((my_value >> 8) & 0x000000FF);
                        my_values.Add((my_value >> 16) & 0x000000FF);
                        my_values.Add((my_value >> 24) & 0x000000FF);
                    }
                    else if (endianness == "BIG")
                    {
                        my_values.Add((my_value >> 24) & 0x000000FF);
                        my_values.Add((my_value >> 16) & 0x000000FF);
                        my_values.Add((my_value >> 8) & 0x000000FF);
                        my_values.Add(my_value & 0x000000FF);
                    }
                    break;

                default:
                    break;
            }
        }
    }

    // Helper class to handle the data of a CAL-section.
    public class cNECFx3_CALSectionHelper
    {
        private List<int> my_values;
        private int my_alignment;

        // Below declaration works like union   
        // Ex: union{                                         ______float var (4 Bytes)______
        // float f_var;                       In memory    {_______________________________}
        // byte  b_var_0;                                  | byte3 | byte2 | byte1 | byte0|  
        // byte  b_var_1;
        // byte  b_var_2;                                   
        // byte  b_var_2;
        // }

        [StructLayout(LayoutKind.Explicit)]
        public struct MyUnion
        {
            [FieldOffset(0)]
            public float value;

            [FieldOffset(0)]
            public Byte byte0;

            [FieldOffset(1)]
            public Byte byte1;

            [FieldOffset(2)]
            public Byte byte2;

            [FieldOffset(3)]
            public Byte byte3;

        }

        public List<int> Values
        {
            get { return my_values; }
            set { my_values = value; }
        }

        public cNECFx3_CALSectionHelper()
        {
            this.my_values = new List<int>();
            this.my_alignment = 4;
        }

        public cNECFx3_CALSectionHelper(List<int> new_values, int new_alignment)
        {
            this.my_values = new_values;
            this.my_alignment = new_alignment;
        }

        // Calculate the flash test crc.
        public uint GetCRC(int start_idx, int stop_idx)
        {
            int index;
            uint crc;

            // Init crc.
            crc = 0xFFFFFFFF;

            for (index = start_idx; index < stop_idx; index++)
            {
                int bit_pos;

                crc ^= (uint)(my_values[index]);

                for (bit_pos = 8; bit_pos > 0; bit_pos--)
                {
                    // Save the value before the bottom bit is shifted out.
                    uint crc_save = crc;
                    crc >>= 1;

                    if (0 != (crc_save & 1))
                    {
                        crc ^= 0xEDB88320;
                    }
                }
            }

            // Post process crc.
            crc ^= 0xFFFFFFFF;

            return crc;
        }

        // Get the number of data bytes in the value list
        public int GetSize()
        {
            return my_values.Count;
        }

        // Determine the number of necessary padding/stuff bytes for a given address/offset and alignment.
        public int GetNummberOfPaddingBytes(int offset, int alignment)
        {
            return ((alignment - (offset % alignment)) % alignment);
        }

        // Adds new data of the list. depending on the size, up to 4 bytes, the values will be extracted from the input integer value.
        public void Add(int my_number, int my_value, string endianness)
        {
            // The function can handle up to 4 bytes data types
            // this function is handle
            switch (my_number)
            {
                case 1:
                    // 1 byte type.
                    my_values.Add(my_value & 0x000000FF);
                    break;

                case 2:
                    // 2 byte type.
                    if (endianness == "LITTLE")
                    {
                        my_values.Add(my_value & 0x000000FF);
                        my_values.Add((my_value >> 8) & 0x000000FF);
                    }
                    else if (endianness == "BIG")
                    {
                        my_values.Add((my_value >> 8) & 0x000000FF);
                        my_values.Add(my_value & 0x000000FF);
                    }
                    break;

                case 3:
                    // 3 byte type.
                    if (endianness == "LITTLE")
                    {
                        my_values.Add(my_value & 0x000000FF);
                        my_values.Add((my_value >> 8) & 0x000000FF);
                        my_values.Add((my_value >> 16) & 0x000000FF);
                    }
                    else if (endianness == "BIG")
                    {
                        my_values.Add((my_value >> 16) & 0x000000FF);
                        my_values.Add((my_value >> 8) & 0x000000FF);
                        my_values.Add(my_value & 0x000000FF);
                    }
                    break;

                case 4:
                    // 4 byte type.
                    if (endianness == "LITTLE")
                    {
                        my_values.Add(my_value & 0x000000FF);
                        my_values.Add((my_value >> 8) & 0x000000FF);
                        my_values.Add((my_value >> 16) & 0x000000FF);
                        my_values.Add((my_value >> 24) & 0x000000FF);
                    }
                    else if (endianness == "BIG")
                    {
                        my_values.Add((my_value >> 24) & 0x000000FF);
                        my_values.Add((my_value >> 16) & 0x000000FF);
                        my_values.Add((my_value >> 8) & 0x000000FF);
                        my_values.Add(my_value & 0x000000FF);
                    }
                    break;

                default:
                    break;
            }
        }

        // By Gasser for CAL-section.
        // Adds new data of the list. Depending on the size, only for 4 bytes values. The values will be extracted from
        // the input UInt32 value. For all other Types see overload Add function.
        public void Add(int my_number, uint my_value, string endianness)
        {
            byte[] byteArray = BitConverter.GetBytes(my_value);

            if (endianness == "LITTLE")
            {
                my_values.Add(Convert.ToInt32(byteArray[0]));
                my_values.Add(Convert.ToInt32(byteArray[1]));
                my_values.Add(Convert.ToInt32(byteArray[2]));
                my_values.Add(Convert.ToInt32(byteArray[3]));
            }
            else if (endianness == "BIG")
            {
                my_values.Add(Convert.ToInt32(byteArray[3]));
                my_values.Add(Convert.ToInt32(byteArray[2]));
                my_values.Add(Convert.ToInt32(byteArray[1]));
                my_values.Add(Convert.ToInt32(byteArray[0]));
            }
        }

        // Clears the value list.
        public void Empty()
        {
            // Remove all elements from the internal list.
            my_values.Clear();
        }

        // Processes one sub-variant using the data from sub_var and the parameter definitions from parameter_definitions.
        public int ProcessCluster(List<cParameterDefinition> parameter_definitions, cSubVariant sub_var, string endianness)
        {
            // Address counter.
            int address = 0;

            // Bitfield control data.
            int bitfield_current_count = 0;
            int bitfield_value = 0;
            int bitfield_base_address = 0;
            int bitfield_base_offset = 0;

            // Loop variable.
            int i = 0;

            // Iterate over all parameters.
            foreach (cParameterDefinition para_def in parameter_definitions)
            {
                // Check for bitfields
                if (para_def.IsBitfield() == false)
                {
                    // Handle non-bitfield parameters.

                    // Check if previous parameter was a bitfield and write it into the output stream.
                    if (bitfield_current_count > 0)
                    {
                        // Write bitfield.
                        this.Add(((bitfield_current_count + 7) / 8), bitfield_value, endianness);

                        // Update address.
                        address += ((bitfield_current_count + 7) / 8);

                        // Clear bitfield.
                        bitfield_value = 0;
                        bitfield_current_count = 0;
                    }

                    // Data alignment.
                    {
                        int num_alignment_bytes = GetNummberOfPaddingBytes(address, Math.Min(my_alignment, para_def.GetSizeOfType()));

                        // Write padding bytes.
                        this.Add(num_alignment_bytes, 0, endianness);

                        // Update address.
                        address += num_alignment_bytes;
                    }

                    // Data.
                    {
                        foreach (string my_value in sub_var.ParameterValues[i].Values)
                        {
                            // Add by Gasser for CAL-section.
                            // my_value = UInt32 max  = 4294967295
                            // my_value = Int32 max   =  2147483647
                            if (para_def.GetNameOfType() == "UInt32")
                            {
                                // This overload Add function is handling only UInt32 for my_value.
                                this.Add(para_def.GetSizeOfType(), Convert.ToUInt32(my_value), endianness);
                            }
                            else if (para_def.GetNameOfType() == "Float32")
                            {
                                // VND6KOR: Added the IFormat to treat '.' as '.' instead of ',' in other languages.
                                float var = Convert.ToSingle(my_value, System.Globalization.CultureInfo.InvariantCulture);

                                // Variable of union.
                                MyUnion union;

                                // All the member of union should be initialized.
                                union.byte0 = 0;
                                union.byte1 = 0;
                                union.byte2 = 0;
                                union.byte3 = 0;

                                // Float value updated into union member value of type float.
                                // Data will be stored as little endian as we are working on PC .
                                union.value = var;
                                if (endianness == "BIG")
                                {
                                    // Add each and every byte into list.
                                    this.Add(1, union.byte3, endianness);
                                    this.Add(1, union.byte2, endianness);
                                    this.Add(1, union.byte1, endianness);
                                    this.Add(1, union.byte0, endianness);
                                }
                                else if (endianness == "LITTLE")
                                {
                                    // Add each and every byte into list.
                                    this.Add(1, union.byte0, endianness);
                                    this.Add(1, union.byte1, endianness);
                                    this.Add(1, union.byte2, endianness);
                                    this.Add(1, union.byte3, endianness);
                                }
                            }
                            else
                            {
                                // This overload Add function is handling only Types except UInt32 for my_value.
                                this.Add(para_def.GetSizeOfType(), Convert.ToInt32(my_value), endianness);
                            }
                        }

                        // Update address.
                        address += para_def.GetSizeOfType() * Convert.ToInt32(para_def.Number);
                    }
                }
                else
                {
                    // Handle bitfield parameters.
                    int bitfield_base_width = para_def.GetBitfieldWidth();
                    int bitfield_current_width = Convert.ToInt32(para_def.Number);
                    int bitfield_byte_size = para_def.GetSizeOfType();

                    // Start of a new bitfield.
                    if (bitfield_current_count == 0)
                    {
                        // New bitfield.

                        // Check if the current alignment offers enough space for the bitfield - if not align according to the base type.
                        if (8 * (bitfield_byte_size - (address % bitfield_byte_size)) < bitfield_current_width)
                        {
                            int num_alignment_bytes = GetNummberOfPaddingBytes(address, Math.Min(my_alignment, para_def.GetSizeOfType()));

                            // Write padding bytes.
                            this.Add(num_alignment_bytes, 0, endianness);

                            // Update address.
                            address += num_alignment_bytes;
                        }

                        // Update bitfield address information.
                        bitfield_base_address = address - (address % 4);
                        bitfield_base_offset = address % 4;

                        // Update bitfield data.
                        bitfield_value = Convert.ToInt32(sub_var.ParameterValues[i].Values[0]);
                        bitfield_current_count = bitfield_current_width;
                    }
                    else
                    {
                        // Extend existing bitfield.

                        // Enough space left.
                        if ((8 * (my_alignment - bitfield_base_offset) - bitfield_current_count) < bitfield_current_width)
                        {
                            // not enough space left

                            // Flush bitfield.
                            if (bitfield_current_count > 0)
                            {
                                // Write bitfield.
                                this.Add(((bitfield_current_count + 7) / 8), bitfield_value, endianness);

                                // Update address.
                                address += ((bitfield_current_count + 7) / 8);
                            }

                            // Align for basetype.
                            {
                                int num_alignment_bytes = GetNummberOfPaddingBytes(address, Math.Min(my_alignment, para_def.GetSizeOfType()));

                                // Write padding bytes.
                                this.Add(num_alignment_bytes, 0, endianness);

                                // Update address.
                                address += num_alignment_bytes;
                            }

                            // Update bitfield address information.
                            bitfield_base_address = address - (address % 4);
                            bitfield_base_offset = address % 4;

                            // Update bitfield data.
                            bitfield_value = Convert.ToInt32(sub_var.ParameterValues[i].Values[0]);
                            bitfield_current_count = bitfield_current_width;
                        }
                        else
                        {
                            // Enough space left.

                            // Check whether current bit position aligns with new base type.
                            int start_bit = bitfield_base_offset * 8 + bitfield_current_count;
                            int stop_bit = bitfield_base_offset * 8 + bitfield_current_count + bitfield_current_width;

                            int start_bit_adr_offset = (start_bit == 0) ? 0 : (start_bit - 1) / bitfield_base_width;
                            int stop_bit_adr_offset = (stop_bit == 0) ? 0 : (stop_bit - 1) / bitfield_base_width;

                            // Alignment_possible.
                            if (start_bit_adr_offset == stop_bit_adr_offset)
                            {
                                // Alignment possible.
                                bitfield_value += Convert.ToInt32(sub_var.ParameterValues[i].Values[0]) << bitfield_current_count;
                                bitfield_current_count += bitfield_current_width;
                            }
                            else
                            {
                                // Alignment impossible.

                                // Move to next possible aligned position.
                                // Bitfield_value = unchanged.
                                bitfield_current_count = (bitfield_base_width * stop_bit_adr_offset) - (8 * bitfield_base_offset);


                                // Enough space left.
                                if ((8 * (my_alignment - bitfield_base_offset) - bitfield_current_count) < bitfield_current_width)
                                {
                                    // Not enough space left.

                                    // Flush bitfield.
                                    if (bitfield_current_count > 0)
                                    {
                                        // Write bitfield.
                                        this.Add(((bitfield_current_count + 7) / 8), bitfield_value, endianness);

                                        // Update address.
                                        address += ((bitfield_current_count + 7) / 8);
                                    }

                                    // Align for basetype.
                                    {
                                        int num_alignment_bytes = GetNummberOfPaddingBytes(address, Math.Min(my_alignment, para_def.GetSizeOfType()));

                                        // Write padding bytes.
                                        this.Add(num_alignment_bytes, 0, endianness);

                                        // Update address.
                                        address += num_alignment_bytes;
                                    }

                                    // Update bitfield address information.
                                    bitfield_base_address = address - (address % 4);
                                    bitfield_base_offset = address % 4;

                                    // Update bitfield data.
                                    bitfield_value = Convert.ToInt32(sub_var.ParameterValues[i].Values[0]);
                                    bitfield_current_count = bitfield_current_width;
                                }
                                else
                                {
                                    // Enough space left.
                                    bitfield_value += Convert.ToInt32(sub_var.ParameterValues[i].Values[0]) << bitfield_current_count;
                                    bitfield_current_count += bitfield_current_width;
                                }
                            }
                        }
                    }
                }

                // Next element.
                i++;
            }

            // Check if previous parameter was a bitfield and write it into the output stream.
            if (bitfield_current_count > 0)
            {
                // Write bitfield.
                this.Add(((bitfield_current_count + 7) / 8), bitfield_value, endianness);

                // Update address.
                address += ((bitfield_current_count + 7) / 8);

                // Clear bitfield.
                bitfield_value = 0;
                bitfield_current_count = 0;
            }

            // Data alignment.
            {
                int num_alignment_bytes = GetNummberOfPaddingBytes(address, my_alignment);

                // Write padding bytes.
                this.Add(num_alignment_bytes, 0, endianness);

                // Update address.
                address += num_alignment_bytes;
            }

            return address;
        }
    }

    // Flash test section class.
    public class cFlashTestSection
    {
        // Marker.
        private uint my_marker;

        // Crc descriptor table.
        private uint my_crc_descriptor_table;

        // Layout version.
        private uint my_layout_version;

        // Start address.
        private int my_start_address;

        // End address.
        private int my_end_address;

        // Cal section crc.
        private uint my_cal_section_crc; 

        // Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - Start
        // Change of memory Layout of CRC FlsTst Block in ParGen
        // version1 supports 24 bytes and version2 supports 20 bytes
        // Adding new variable. In case of version2, the flash memory
        // is 20 bytes. Fill the last 4 bytes with 0x00000000

        // Fill the empty data.
        private uint my_fill_empty_bytes; 

        // Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - End

        public uint Marker
        {
            get { return my_marker; }
            set { my_marker = value; }
        }

        public uint CRCDescriptorTable
        {
            get { return my_crc_descriptor_table; }
            set { my_crc_descriptor_table = value; }
        }

        public uint LayoutVersion
        {
            get { return my_layout_version; }
            set { my_layout_version = value; }
        }

        public int StartAddress
        {
            get { return my_start_address; }
            set { my_start_address = value; }
        }

        public int EndAddress
        {
            get { return my_end_address; }
            set { my_end_address = value; }
        }

        public uint CALSectionCRC
        {
            get { return my_cal_section_crc; }
            set { my_cal_section_crc = value; }
        }

        // Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - Start
        // Change of memory Layout of CRC FlsTst Block in ParGen
        // version1 supports 24 bytes and version2 supports 20 bytes
        public uint FillEmptyBytes
        {
            get { return my_fill_empty_bytes; }
            set { my_fill_empty_bytes = value; }
        }
        // Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - End

        // Default Constructor.
        public cFlashTestSection()
        {
            this.my_marker = 0;
            this.my_crc_descriptor_table = 0;
            this.my_layout_version = 0;
            this.my_start_address = 0;
            this.my_end_address = 0;
            this.my_cal_section_crc = 0;
            //Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - Start
            //Change of memory Layout of CRC FlsTst Block in ParGen
            //version1 supports 24 bytes and version2 supports 20 bytes
            this.my_fill_empty_bytes = 0;
            //Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - End
        }

        // Parameterized Constructor.
        public cFlashTestSection(uint new_marker,
                                  uint new_crc_descriptor_table,
                                  uint new_layout_version,
                                  int new_start_address,
                                  int new_end_address,
                                  uint new_cal_section_crc,
                                  uint new_fill_empty_bytes)
        {
            this.my_marker = new_marker;
            this.my_crc_descriptor_table = new_crc_descriptor_table;
            this.my_layout_version = new_layout_version;
            this.my_start_address = new_start_address;
            this.my_end_address = new_end_address;
            this.my_cal_section_crc = new_cal_section_crc;
            // Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - Start
            this.my_fill_empty_bytes = new_fill_empty_bytes;
            // Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - End
        }
    }

    class CalibrationHex
    {
        // Generate the CAL-section file (rbp_cal_section_gen.hex).
        // Return -1 if any issues or else return 1.
        public int PrintGenNEC_CAL_Section(ref cParameterSet my_ps,
                                                    ref String my_ps_file_name,
                                                    String my_output_path,
                                                    String my_FileName_Suffix,
                                                    ref DateTime my_dt,
                                                    ref cGeneralConfiguration my_gc,
                                                    ref cHashes my_hashes,
                                                    ref cGMConfiguration my_gmc,
                                                    ref cFlashTestSection my_flash_test_section)
        {
            // Output path for rbp_cal_section_gen.hex.

            // Overwrite output path.
            if (my_gc.ST_CHORUS_CALSection_OutputPath != "")
            {
                my_output_path = my_gc.ST_CHORUS_CALSection_OutputPath;

                // Determine whether the directory exists.
                Program.DirectoryCreateDirectory(my_output_path);
            }

            // Obtain absolute path of output file.
            var outputPath = Path.Combine(Path.GetFullPath(my_output_path), "rbp_cal_section" + my_FileName_Suffix +"_gen.hex");

            // Delete old file automatically if existing.
            try
            {
                Program.FileDelete(outputPath);
            }
            catch
            {
                // Do not care about exceptions.
            }

            cNECFx3_CALSectionHelper my_output_helper = new cNECFx3_CALSectionHelper(new List<int>(), Convert.ToInt32(my_gc.ST_CHORUS_CALSection_StructureAlignment));

            //! Add contents of hex file into my_output_helper.
            {
                // Security related variable
                Secure_Flash Security = new Secure_Flash(my_gc);

                byte ST_No_of_certificates = 0;     // Number of certificates.
                int PKI_Struct_Reference_Size = 0;  // PKI Reference structure size.
                int PKI_Structure_Size = 0;         // PKI Structure Size = 52 bytes , Size with 16-byte alignment = 64.
                int Certificate_Size = 0;           // Certificate section size.
                int Signature_Size = 0;             // Signature section size.
                bool Warning = false;               // To verify if any warning is present.
                List<string> Warning_msg = new List<string>();  // List to store the Warning message.

                int CalHeaderLowSize = 0;
                int CalBlockStatusSize = 0;
                int CalHeaderHighSize = 0;
                int CalPSIValidSize = 0;
                int Cal_CUSSecurityHeaderLowSize = 0;
                int Cal_CUSSecurityHeaderHighSize = 0;

                // Check for CAL Header Low size only if mode is PF and CAL Header Low is enabled.
                if ((my_gc.ST_CHORUS_CALSection_Mode != "GM") && (my_gc.ST_CHORUS_CALSection_SupportHeaderLow == "true"))
                {
                    CalHeaderLowSize = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_HeaderLowSize, 16);

                    if (CalHeaderLowSize % 16 != 0)
                    {
                        Warning_msg.Add("-> CAL HeaderLow size configured is not multiple of 16 bytes.                  ");
                        Warning_msg.Add("   Hence default 16 bytes will be considered.                                   ");
                        Warning = true;
                    }

                    // If CAL Header Low Size is a multiple of 16 proceed, else make CAL Header Low size = 16 Bytes, if size > 0.
                    CalHeaderLowSize = (CalHeaderLowSize % 16 == 0) ? CalHeaderLowSize : 16;

                    if (CalHeaderLowSize == 0)
                    {
                        Warning_msg.Add("-> CAL HeaderLow is enabled and size configured is zero.                       ");
                        Warning = true;
                    }
                }

                if (my_gc.ST_CHORUS_CALSection_SupportBlockStatusSection == "true")
                {
                    // Check for the CAL block status Size.
                    CalBlockStatusSize = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_SupportBlockStatusSize, 16);

                    if (CalBlockStatusSize % 16 != 0)
                    {
                        Warning_msg.Add("-> CAL BlockStatus size configured is not multiple of 16 bytes.                ");
                        Warning_msg.Add("   Hence default 32 bytes will be considered.                                  ");
                        Warning = true;
                    }

                    // If CAL Block status is a multiple of 16 proceed, else make CAL Block status 32 Bytes, if size > 0.
                    CalBlockStatusSize = (CalBlockStatusSize % 16 == 0) ? CalBlockStatusSize : 32;

                    if (CalBlockStatusSize == 0)
                    {
                        Warning_msg.Add("-> CAL BlockStatus is enabled and size configured is zero                      ");
                        Warning = true;
                    }
                }

                if (my_gc.ST_CHORUS_CALSection_Support_CUS_SecurityHeaderLow == "true")
                {
                    // Check for the CAL CUS Security Header Low Size.
                    Cal_CUSSecurityHeaderLowSize = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_CUS_SecurityHeaderLowSize, 16);

                    if (Cal_CUSSecurityHeaderLowSize % 16 != 0)
                    {
                        Warning_msg.Add("-> CAL CUS Security HeaderLow size configured is not multiple of 16 bytes.                 ");
                        Warning_msg.Add("   Hence default 16 bytes will be considered.                                   ");
                        Warning = true;
                    }

                    // If CAL CUS Security HeaderLow is a multiple of 16 proceed, else make CUS Security HeaderLow 32 Bytes, if size > 0.
                    Cal_CUSSecurityHeaderLowSize = (Cal_CUSSecurityHeaderLowSize % 16 == 0) ? Cal_CUSSecurityHeaderLowSize : 16;

                    if (Cal_CUSSecurityHeaderLowSize == 0)
                    {
                        Warning_msg.Add("-> CAL CUS Security HeaderLow is enabled and size configured is zero                      ");
                        Warning = true;
                    }
                }

                if (my_gc.ST_CHORUS_CALSection_Support_CUS_SecurityHeaderHigh == "true")
                {
                    // Check for the CAL CUS Security Header Low Size.
                    Cal_CUSSecurityHeaderHighSize = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_CUS_SecurityHeaderHighSize, 16);

                    if (Cal_CUSSecurityHeaderHighSize % 16 != 0)
                    {
                        Warning_msg.Add("-> CAL CUS Security HeaderHigh size configured is not multiple of 16 bytes.                 ");
                        Warning_msg.Add("   Hence default 16 bytes will be considered.                                   ");
                        Warning = true;
                    }

                    // If CAL CUS Security HeaderHigh is a multiple of 16 proceed, else make CAL CUS Security HeaderLow 32 Bytes, if size > 0.
                    Cal_CUSSecurityHeaderHighSize = (Cal_CUSSecurityHeaderHighSize % 16 == 0) ? Cal_CUSSecurityHeaderHighSize : 16;

                    if (Cal_CUSSecurityHeaderHighSize == 0)
                    {
                        Warning_msg.Add("-> CAL CUS Security HeaderHigh is enabled and size configured is zero                      ");
                        Warning = true;
                    }
                }

                if (my_gc.ST_CHORUS_CALSection_SupportHeaderHigh == "true")
                {
                    // Check for the CAL Header High Size.
                    CalHeaderHighSize = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_HeaderHighSize, 16);

                    if (CalHeaderHighSize % 16 != 0)
                    {
                        Warning_msg.Add("-> CAL HeaderHigh size configured is not multiple of 16 bytes.                 ");
                        Warning_msg.Add("   Hence default 16 bytes will be considered.                                   ");
                        Warning = true;
                    }

                    // If CAL Header High Size is a multiple of 16 proceed, else make CAL Header High size = 16 Bytes, if size > 0.
                    CalHeaderHighSize = (CalHeaderHighSize % 16 == 0) ? CalHeaderHighSize : 16;

                    if (CalHeaderHighSize == 0)
                    {
                        Warning_msg.Add("-> CAL HeaderHigh is enabled and size configured is zero.                      ");
                        Warning = true;
                    }
                }

                if (my_gc.ST_CHORUS_CALSection_SupportPSIValid == "true")
                {
                    // Check for the CAL PSI Valid Size.
                    CalPSIValidSize = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_PSIValidSize, 16);

                    if (CalPSIValidSize % 16 != 0)
                    {
                        Warning_msg.Add("-> CAL PSIValid size configured is not multiple of 16 bytes.                   ");
                        Warning_msg.Add("   Hence default 16 bytes will be considered.                                  ");
                        Warning = true;
                    }

                    // If CAL PSI Valid status is a multiple of 16 proceed, else make CAL PSI Valid status 16 Bytes, if size > 0.
                    CalPSIValidSize = (CalPSIValidSize % 16 == 0) ? CalPSIValidSize : 16;

                    if (CalPSIValidSize == 0)
                    {
                        Warning_msg.Add("-> CAL PSIValid is enabled and size configured is zero.                        ");
                        Warning = true;
                    }
                }

                if (Warning == true)
                {
                    Console.BackgroundColor = ConsoleColor.Yellow;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.WriteLine("================================ WARNING =======================================");
                    for (byte index_u8 = 0 ; index_u8 < Warning_msg.Count ; index_u8++)
                    {
                        Console.WriteLine("{0}", Warning_msg[index_u8]);
                    }
                    Console.WriteLine("Note: CAL HeaderLow, CAL HeaderHigh, CAL BlockStatus, CAL PSIValidStatus, CAL CUS_Security HeaderLow and CAL CUS_Security HeaderHigh ");
                    Console.WriteLine("      sizes should be in multiples of 16 bytes.                                 ");
                    Console.WriteLine("================================================================================");
                    Console.ResetColor();
                }

                if(my_gc.RB_Secure_Flash == "true")
                {
                     // Check for the Input data validity.
                     Security.Check_PKI_Structure_Data_Validty(ref my_gc);
                    
                     // Get Security variables value.
                     Security.Get_Security_Member_Data(ref ST_No_of_certificates, ref PKI_Struct_Reference_Size, ref PKI_Structure_Size, ref Certificate_Size, ref Signature_Size);
       
                }

                // CAL Header Low.

                // GM only.
                if (my_gc.ST_CHORUS_CALSection_Mode == "GM")
                {
                    // 16 bytes of GM header in the beginning of CAL.
                    GMHelperClass.printGen_NEC_CAL_SectionGM_1(ref my_output_helper, ref my_gmc, ref my_gc);
                }
                else if(my_gc.ST_CHORUS_CALSection_SupportHeaderLow == "true")
                {
                    // Calculate HeaderLow content length.
                    // E.g.: Let my_gc.ST_CHORUS_CALSection_HeaderLowContent = 0x1234
                    //       HdrLow_Length = (6 - 2)/2 = 2 i.e. 12 34 -> 2 bytes
                    //       2 is subtracted from length to remove 0x and divided by 2 to get number of bytes.
                    int HdrLow_Length = (my_gc.ST_CHORUS_CALSection_HeaderLowContent.Length - 2) / 2;

                    // Add CAL HeaderLow section.
                    if (Add_CALSections_Data("CAL_HeaderLow", CalHeaderLowSize, HdrLow_Length, ref my_gc, ref my_output_helper) != false)
                    {
                        // Size configured is less than data length.
                        return -1;
                    }
                }

                // CAL Block status.
                if (my_gc.ST_CHORUS_CALSection_SupportBlockStatusSection == "true")
                {
                    // Add CAL Block Status section and fill with 0xFF.
                    for (int value = 0; value < CalBlockStatusSize; value++)
                    {
                        my_output_helper.Add(1, 0xFF, my_gc.ST_CHORUS_Endianness);
                    }
                }

                if (my_gc.RB_Secure_Flash == "true")
                {
                    // Add the size of CALHdrLow and CALBlockStatus if enabled to get the start address of the CAL Security Block
                    // CALHdrLow and CALBlockStatus is considered for the Signature process.
                    int temp_sec_offset = my_output_helper.GetSize();   

                  // PKI Reference Structure Data.
                    Security.Print_Security_CAL_PKI_RefStruct(ref my_output_helper,ref my_gc, temp_sec_offset);
                }

                // CAL CUS Security Header Low.
                if (my_gc.ST_CHORUS_CALSection_Support_CUS_SecurityHeaderLow == "true")
                {
                    // Calculate CUS Security HeaderLow Content length.
                    //       CUS_SecurityHdrLow_Length = (6 - 2)/2 = 2 i.e. 12 34 -> 2 bytes
                    //       2 is subtracted from length to remove 0x and divided by 2 to get number of bytes.
                    int CUS_SecurityHdrLow_Length = (my_gc.ST_CHORUS_CALSection_CUS_SecurityHeaderLowContent.Length - 2) / 2;

                    // Add CAL CUS Security HeaderLow section.
                    if (Add_CALSections_Data("CAL_CUS_Security_HeaderLow", Cal_CUSSecurityHeaderLowSize, CUS_SecurityHdrLow_Length, ref my_gc, ref my_output_helper) != false)
                    {
                        // Size configured is less than data length.
                        return -1;
                    }
                }

                // Info header.
                {
                    // 16 bytes section delimiter.
                    {
                        const string section_delimiter = "CAL-SectionStart";
                        for (int i = 0; i < section_delimiter.Length; i++)
                        {
                            my_output_helper.Add(1, section_delimiter[i], my_gc.ST_CHORUS_Endianness);
                        }
                    }

                    // 64 bytes version identifier.
                    {
                        string tmp_string = my_gc.ST_CHORUS_CALSection_Version.Substring(0, Math.Min(64, my_gc.ST_CHORUS_CALSection_Version.Length));
                        tmp_string = tmp_string.PadRight(64, '_');

                        for (int i = 0; i < tmp_string.Length; i++)
                        {
                            my_output_helper.Add(1, tmp_string[i], my_gc.ST_CHORUS_Endianness);
                        }
                    }

                    // 20 bytes CAL-hash @start.
                    {
                        foreach (byte my_byte in my_hashes.CALHashByteArray)
                        {
                            my_output_helper.Add(1, my_byte, my_gc.ST_CHORUS_Endianness);
                        }
                    }

                    // 20 bytes CAL-Range resolution hash.
                    {
                        foreach (byte my_byte in my_hashes.CALRRHashByteArray)
                        {
                            my_output_helper.Add(1, my_byte, my_gc.ST_CHORUS_Endianness);
                        }
                    }

                    // 6 bytes date information.
                    {
                        my_output_helper.Add(2, Convert.ToInt32(my_ps.ParameterSetInfo.Year), my_gc.ST_CHORUS_Endianness);
                        my_output_helper.Add(1, Convert.ToInt32(my_ps.ParameterSetInfo.Month), my_gc.ST_CHORUS_Endianness);
                        my_output_helper.Add(1, Convert.ToInt32(my_ps.ParameterSetInfo.Day), my_gc.ST_CHORUS_Endianness);
                        my_output_helper.Add(1, Convert.ToInt32(my_ps.ParameterSetInfo.Hours), my_gc.ST_CHORUS_Endianness);
                        my_output_helper.Add(1, Convert.ToInt32(my_ps.ParameterSetInfo.Minutes), my_gc.ST_CHORUS_Endianness);
                    }

                    // 2 bytes reserve.
                    {
                        for (int i = 0; i < 2; i++)
                        {
                            my_output_helper.Add(1, 0x00, my_gc.ST_CHORUS_Endianness);
                        }
                    }
                }

                {
                    foreach (cComponent component in my_ps.Components)
                    {
                        foreach (cParameterCluster cluster in component.ParameterClusters)
                        {
                            if ((cluster.MemoryArea == "ROM") || (cluster.MemoryArea == "NVM_INIT") || (cluster.MemoryArea == "RAM_INIT"))
                            {
                                foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                                {
                                    foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                    {
                                        foreach (cSubVariant sub_var in min_var.SubVariants)
                                        {
                                            // Process single cluster.
                                            my_output_helper.ProcessCluster(cluster.ParameterDefinitions, sub_var, my_gc.ST_CHORUS_Endianness);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 20 bytes CAL-hash @END OF PARAMETER DATA.
                {
                    foreach (byte my_byte in my_hashes.CALHashByteArray)
                    {
                        my_output_helper.Add(1, my_byte, my_gc.ST_CHORUS_Endianness);
                    }
                }

                // Fill empty areas.
                {
                    int temp_CAL_size_req = my_output_helper.GetSize();    // To check the actual CAL size required to to write CAL sections and Security id enabled. 

                    if (my_gc.ST_CHORUS_CALSection_SupportFlashTestSection == "true")
                    {
                        if (my_gc.ST_CHORUS_CALSection_FlsTst_CRC_Memory_Layout == "version1")
                        {
                            // Flash test -> not yet included (see below).
                            temp_CAL_size_req += 24; 
                        }
                        else if (my_gc.ST_CHORUS_CALSection_FlsTst_CRC_Memory_Layout == "version2")
                        {
                            // Flash test -> not yet included (see below).
                            temp_CAL_size_req += 20;
                        }
                    }

                    if(my_gc.ST_CHORUS_CALSection_SupportHeaderHigh == "true")
                    {
                        temp_CAL_size_req += CalHeaderHighSize;
                    }

                    if (my_gc.ST_CHORUS_CALSection_SupportPSIValid == "true")
                    {
                        temp_CAL_size_req += CalPSIValidSize;
                    }

                    if(my_gc.ST_CHORUS_CALSection_Support_CUS_SecurityHeaderHigh == "true")
                    {
                        temp_CAL_size_req += Cal_CUSSecurityHeaderHighSize;
                    }

                    if (my_gc.RB_Secure_Flash == "true")
                    {
                        if (my_gc.RB_Secure_Block.ToUpper() == "INDIVIDUAL")
                        {
                            temp_CAL_size_req += (Certificate_Size + Signature_Size + PKI_Structure_Size);
                        }
                    }

                    int num_fill_up_bytes = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_Size,16) - temp_CAL_size_req;

                    if (num_fill_up_bytes < 0)
                    {
                        Console.BackgroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("=============================================================================");
                        Console.WriteLine("::: ERROR :::: CAL size is more than the allocated size                      ");
                        Console.WriteLine("Allocated size =  :{0}                                                       ",
                                           Convert.ToInt32(my_gc.ST_CHORUS_CALSection_Size,16));
                        Console.WriteLine("Actual CAL size = {0}                                                      ",temp_CAL_size_req);
                        Console.WriteLine("Please increase the CAL size or Update the Coniguration XML with proper value");
                        Console.WriteLine("=============================================================================");
                        Console.ResetColor();
                        return -1;
                    }

                    // Fill remaining Empty bytes with 0XFF.
                    int fill_byte = Int32.Parse(my_gc.ST_CHORUS_CALSection_FillByte.Substring(2), System.Globalization.NumberStyles.HexNumber);

                    for (int i = 0; i < num_fill_up_bytes; i++)
                    {
                        my_output_helper.Add(1, fill_byte, my_gc.ST_CHORUS_Endianness);
                    }
                }

                // Flash Test.
                if (my_gc.ST_CHORUS_CALSection_SupportFlashTestSection == "true")
                {
                    // Start/end address CAL-data (only area with crc).
                    int start_adr = Int32.Parse(my_gc.ST_CHORUS_CALSection_StartAddress.Substring(2), System.Globalization.NumberStyles.HexNumber);
                    int end_adr = start_adr + Int32.Parse(my_gc.ST_CHORUS_CALSection_Size.Substring(2), System.Globalization.NumberStyles.HexNumber);

                    // GM only.
                    if (my_gc.ST_CHORUS_CALSection_Mode == "GM")
                    {
                        // GM header section in the beginning, add 16 bytes more to the start address.
                        GMHelperClass.printGen_NEC_CAL_SectionGM_2(ref start_adr);
                    }
                    else if(my_gc.ST_CHORUS_CALSection_SupportHeaderLow == "true")
                    {
                        // Excluding CAL Header low from Flash test CRC calculation.
                        start_adr += CalHeaderLowSize;
                    }

                    if (my_gc.ST_CHORUS_CALSection_SupportBlockStatusSection == "true")
                    {
                        // Excluding CAL Block status from Flash test CRC calculation.
                        start_adr += CalBlockStatusSize;
                    }

                    if (my_gc.RB_Secure_Flash == "true")
                    {
                        // Secure Flash enabled. Excluding PKI Reference Security section from Flash test CRC calculation.
                        start_adr += PKI_Struct_Reference_Size; // PKI Reference structure -> 32 bytes
                    }

                    if (my_gc.ST_CHORUS_CALSection_Support_CUS_SecurityHeaderLow == "true")
                    {
                        // Excluding CAL CUS Header Low from Flash test CRC calculation.
                        start_adr += Cal_CUSSecurityHeaderLowSize;
                    }

                    if (my_gc.ST_CHORUS_CALSection_SupportFlashTestSection == "true")
                    {
                        if (my_gc.ST_CHORUS_CALSection_FlsTst_CRC_Memory_Layout == "version1")
                        {
                            // Excluding "Flash test" section at the end.
                            end_adr -= 24;
                        }
                        else if (my_gc.ST_CHORUS_CALSection_FlsTst_CRC_Memory_Layout == "version2")
                        {
                            // Excluding "Flash test" section at the end.
                            end_adr -= 20;
                        }
                    }


                    if (my_gc.ST_CHORUS_CALSection_Support_CUS_SecurityHeaderHigh == "true")
                    {
                        // Excluding CAL CUS Header High from Flash test CRC calculation.
                        end_adr -= Cal_CUSSecurityHeaderHighSize;
                    }

                    if (my_gc.RB_Secure_Flash == "true")
                    {
                        if (my_gc.RB_Secure_Block.ToUpper() == "INDIVIDUAL")
                        {
                            // Secure Flash enabled. Excluding Security section from Flash test CRC calculation.
                            end_adr -= (PKI_Structure_Size + Certificate_Size + Signature_Size);
                        }
                    }

                    if (my_gc.ST_CHORUS_CALSection_SupportHeaderHigh == "true")
                    {
                        // Excluding CAL Header High Section from Flash test CRC calculation.
                        end_adr -= CalHeaderHighSize;
                    }

                    if (my_gc.ST_CHORUS_CALSection_SupportPSIValid == "true")
                    {
                        // Excluding CAL PSI Valid Sections from Flash test CRC calculation.
                        end_adr -= CalPSIValidSize;
                    }

                    // Cal Flash CRC.
                    uint crc_cal;
                    {
                        int start_idx = start_adr - Int32.Parse(my_gc.ST_CHORUS_CALSection_StartAddress.Substring(2), System.Globalization.NumberStyles.HexNumber);
                        int end_idx = end_adr - Int32.Parse(my_gc.ST_CHORUS_CALSection_StartAddress.Substring(2), System.Globalization.NumberStyles.HexNumber);
                        crc_cal = my_output_helper.GetCRC(start_idx, end_idx);
                    }

                    // Compute the crc of the descriptor table.
                    cNECFx3_CALSectionHelper my_output_helper_descriptor_table = new cNECFx3_CALSectionHelper(new List<int>(), 4);

                    // Layout version.
                    my_output_helper_descriptor_table.Add(4, 0x00000001, my_gc.ST_CHORUS_Endianness);

                    // Start address.
                    my_output_helper_descriptor_table.Add(4, start_adr, my_gc.ST_CHORUS_Endianness);

                    // End address + 1.
                    my_output_helper_descriptor_table.Add(4, end_adr, my_gc.ST_CHORUS_Endianness);

                    // Cal section crc.
                    my_output_helper_descriptor_table.Add(1, (int)((crc_cal) & 0x000000FF), my_gc.ST_CHORUS_Endianness);
                    my_output_helper_descriptor_table.Add(1, (int)((crc_cal >> 8) & 0x000000FF), my_gc.ST_CHORUS_Endianness);
                    my_output_helper_descriptor_table.Add(1, (int)((crc_cal >> 16) & 0x000000FF), my_gc.ST_CHORUS_Endianness);
                    my_output_helper_descriptor_table.Add(1, (int)((crc_cal >> 24) & 0x000000FF), my_gc.ST_CHORUS_Endianness);

                    uint crc_descriptor_table = my_output_helper_descriptor_table.GetCRC(0, my_output_helper_descriptor_table.GetSize());

                    // Flash test section.

                    // Marker.
                    my_output_helper.Add(4, 0x31415926, my_gc.ST_CHORUS_Endianness);
                    my_flash_test_section.Marker = 0x31415926;

                    // Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - Start
                    // Change of memory Layout of CRC FlsTst Block in ParGen
                    // version1 supports 24 bytes and version2 supports 20 bytes
                    // version2 don't use descriptor table

                    // Descriptor table crc.
                    if (my_gc.ST_CHORUS_CALSection_FlsTst_CRC_Memory_Layout == "version1")
                    {
                        my_output_helper.Add(1, (int)((crc_descriptor_table) & 0x000000FF), my_gc.ST_CHORUS_Endianness);
                        my_output_helper.Add(1, (int)((crc_descriptor_table >> 8) & 0x000000FF), my_gc.ST_CHORUS_Endianness);
                        my_output_helper.Add(1, (int)((crc_descriptor_table >> 16) & 0x000000FF), my_gc.ST_CHORUS_Endianness);
                        my_output_helper.Add(1, (int)((crc_descriptor_table >> 24) & 0x000000FF), my_gc.ST_CHORUS_Endianness);
                        my_flash_test_section.CRCDescriptorTable = crc_descriptor_table;
                    }
                    // Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - End.

                    // Layout version.
                    my_output_helper.Add(4, 0x00000001, my_gc.ST_CHORUS_Endianness);
                    my_flash_test_section.LayoutVersion = 0x00000001;

                    // Start address.
                    my_output_helper.Add(4, start_adr, my_gc.ST_CHORUS_Endianness);
                    my_flash_test_section.StartAddress = start_adr;

                    // End address + 1.
                    my_output_helper.Add(4, end_adr, my_gc.ST_CHORUS_Endianness);
                    my_flash_test_section.EndAddress = end_adr;

                    // Cal section crc.
                    my_output_helper.Add(1, (int)((crc_cal >> 24) & 0x000000FF), my_gc.ST_CHORUS_Endianness);
                    my_output_helper.Add(1, (int)((crc_cal >> 16) & 0x000000FF), my_gc.ST_CHORUS_Endianness);
                    my_output_helper.Add(1, (int)((crc_cal >> 8) & 0x000000FF), my_gc.ST_CHORUS_Endianness);
                    my_output_helper.Add(1, (int)((crc_cal) & 0x000000FF), my_gc.ST_CHORUS_Endianness);
                    my_flash_test_section.CALSectionCRC = crc_cal;

                    // Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - Start
                    // Change of memory Layout of CRC FlsTst Block in ParGen
                    // version1 supports 24 bytes and version2 supports 20 bytes
                    // In case of version, fill the last 4 bytes with 0x00000000
                    // Fill empty 4 bytes
                    // if (my_gc.ST_CHORUS_CALSection_FlsTst_CRC_Memory_Layout == "version2")
                    // {
                    //    my_output_helper.Add(4, 0x00000000, my_gc.ST_CHORUS_Endianness);
                    //    my_flash_test_section.FillEmptyBytes = 0x00000000;
                    // }
                    // Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - End
                }

                // CAL CUS Security Header High.
                if (my_gc.ST_CHORUS_CALSection_Support_CUS_SecurityHeaderHigh == "true")
                {
                    // Calculate CUS Security HeaderHigh Content length.
                    //       CUS_SecurityHdrHigh_Length = (6 - 2)/2 = 2 i.e. 12 34 -> 2 bytes
                    //       2 is subtracted from length to remove 0x and divided by 2 to get number of bytes.
                    int CUS_SecurityHdrHigh_Length = (my_gc.ST_CHORUS_CALSection_CUS_SecurityHeaderHighContent.Length - 2) / 2;

                    // Add CAL CUS Security HeaderHigh section.
                    if (Add_CALSections_Data("CAL_CUS_Security_HeaderHigh", Cal_CUSSecurityHeaderHighSize, CUS_SecurityHdrHigh_Length, ref my_gc, ref my_output_helper) != false)
                    {
                        // Size configured is less than data length.
                        return -1;
                    }
                }

                if (my_gc.RB_Secure_Flash == "true")
                {
                    if (my_gc.RB_Secure_Block.ToUpper() == "INDIVIDUAL")
                    {
                        // Security Section Data: PKI Structure, Certificate, Signature.
                        Security.Print_Secuity_CAL_PKI_Struct_Cert_Sig(ref my_output_helper, ref my_gc);
                    }
                }
                
                if (my_gc.ST_CHORUS_CALSection_SupportHeaderHigh == "true")
                {
                    // Calculate HeaderHigh content length.
                    //       HdrHigh_Length = (6 - 2)/2 = 2 i.e. 12 34 -> 2 bytes
                    //       2 is subtracted from length to remove 0x and divided by 2 to get number of bytes.
                    int HdrHigh_Length = (my_gc.ST_CHORUS_CALSection_HeaderHighContent.Length - 2) / 2;

                    // Add CAL HeaderHigh Section.
                    if (Add_CALSections_Data("CAL_HeaderHigh",CalHeaderHighSize,HdrHigh_Length,ref my_gc,ref my_output_helper) != false)
                    {
                        // Size configured is less than data length.
                        return -1;
                    }
                }

                if (my_gc.ST_CHORUS_CALSection_SupportPSIValid == "true")
                {
                    // Add CAL PSI Valid section and fill with 0xFF..
                    for (int index_u8 = 0; index_u8 < CalPSIValidSize; index_u8++)
                    {
                        my_output_helper.Add(1, 0xFF, my_gc.ST_CHORUS_Endianness);
                    }
                }


                // High header.
                // Empty
            } //! @end: Add contents of hex file into my_output_helper.

            //! Generate the file rbp_cal_section_gen.hex
            {
                // Open output file.
                var writer = Program.CreateStreamWriter(outputPath, false, Encoding.ASCII);
                Console.WriteLine("generating: {0}", outputPath);

                // Write the intel hex file.
                {
                    cIntelHexWriter my_hex_writer = new cIntelHexWriter();

                    my_hex_writer.OutputStart(ref writer,
                                              Int32.Parse(my_gc.ST_CHORUS_CALSection_StartAddress.Substring(2),
                                                          System.Globalization.NumberStyles.HexNumber),
                                              my_gc.ST_CHORUS_Endianness);

                    {
                        // Initialize the variables.
                        int current_offset = 0;
                        int previous_offset = 0;
                        int current_length = 0;
                        int current_address = 0;
                        int previous_address = 0;

                        while (current_offset < my_output_helper.Values.Count)
                        {
                            // Linewise output (32 data bytes per line).
                            if ((my_output_helper.Values.Count - current_offset) >= 32)
                            {
                                current_length = 32;
                            }
                            else
                            {
                                current_length = my_output_helper.Values.Count - current_offset;
                            }

                            previous_address = Int32.Parse(my_gc.ST_CHORUS_CALSection_StartAddress.Substring(2),
                                                           System.Globalization.NumberStyles.HexNumber) + previous_offset;

                            current_address = Int32.Parse(my_gc.ST_CHORUS_CALSection_StartAddress.Substring(2),
                                                          System.Globalization.NumberStyles.HexNumber) + current_offset;

                            previous_address = (previous_address >> 16) & 0XFFFF;

                            current_address = (current_address >> 16) & 0XFFFF;

                            // This if statement is used to Cross check the address where we have writing the hex file.
                            if (previous_address != current_address)
                            {
                                // For debugging purpose
                                // Console.WriteLine(" previous_address {0:X}", previous_address);
                                // Console.WriteLine(" current_address {0:X}", current_address);

                                my_hex_writer.OutputStart(ref writer,
                                                          Int32.Parse(my_gc.ST_CHORUS_CALSection_StartAddress.Substring(2),
                                                                      System.Globalization.NumberStyles.HexNumber) + current_offset,
                                                          my_gc.ST_CHORUS_Endianness);
                            }

                            my_hex_writer.OutputData(ref writer,
                                                      Int32.Parse(my_gc.ST_CHORUS_CALSection_StartAddress.Substring(2),
                                                                  System.Globalization.NumberStyles.HexNumber) + current_offset,
                                                      my_output_helper.Values,
                                                      current_offset,
                                                      current_length,
                                                      my_gc.ST_CHORUS_Endianness);

                            previous_offset = current_offset;

                            current_offset += current_length;
                        }
                    }

                    // Last line of hex file.
                    my_hex_writer.OutputEnd(ref writer);
                }

                // Debugging output
                // foreach (int value in my_output_helper.Values)
                // {
                //  writer.WriteLine("{0}", value);
                // }

                // Close output file.
                writer.Close();
            } //! @end: Generate the file rbp_cal_section_gen.hex

            // GM only.
            if (my_gc.ST_CHORUS_CALSection_Mode == "GM")
            {
                // Generate the file gen_nec_cal_section_gm_cal_data.hex.
                GMHelperClass.printGen_NEC_CAL_SectionGM_3(my_output_path, ref my_output_helper, ref my_gc);
            }

            // GM only.
            if (my_gc.ST_CHORUS_CALSection_Mode == "GM")
            {
                // Generate the file gen_nec_cal_section_gm_header.hex.
                GMHelperClass.printGen_NEC_CAL_SectionGM_4(my_output_path, ref my_output_helper, ref my_gc);
            }

            // No issues while generating hex file return 1.
            return 1;
        }

        /// <summary>
        /// To add the CAL sections content for the requested CAL Section.
        /// </summary>
        /// <param name="my_section_name">CAL Section Name.</param>   
        /// <param name="SectionSize">Size/Length of the Section.</param>
        /// <param name="SectionDataLength">Data Length for the section.</param>
        /// <param name="my_gc">General Configuration.</param>
        /// <param name="my_output_helper">To add the data to been written into hex file.</param>
        /// <returns>true if data length is greater than size configured, else false.</returns>
        static public bool Add_CALSections_Data(string my_section_name,int SectionSize,int SectionDataLength,ref cGeneralConfiguration my_gc,ref cNECFx3_CALSectionHelper my_output_helper)
        {
            bool error_b = false;

            // Check whether provided data length is less or equal to configured size.
            if (SectionDataLength <= SectionSize)
            {
                for (int index_u8 = 0 ; index_u8 < SectionDataLength ; index_u8++)
                {
                    int data = 0;

                    if (my_section_name == "CAL_HeaderLow")
                    {
                        // Read data provided for the CAL HeaderLow.
                        data = int.Parse(my_gc.ST_CHORUS_CALSection_HeaderLowContent.Substring(2 + (index_u8 * 2),2),NumberStyles.AllowHexSpecifier);
                    }
                    else if(my_section_name == "CAL_HeaderHigh")
                    {
                        // Read data provided for the CAL HeaderHigh.
                        data = int.Parse(my_gc.ST_CHORUS_CALSection_HeaderHighContent.Substring(2 + (index_u8 * 2),2),NumberStyles.AllowHexSpecifier);
                    }
                    else if (my_section_name == "CAL_CUS_Security_HeaderLow")
                    {
                        // Read data provided for the CAL CUS_Security HeaderLow.
                        data = int.Parse(my_gc.ST_CHORUS_CALSection_CUS_SecurityHeaderLowContent.Substring(2 + (index_u8 * 2),2),NumberStyles.AllowHexSpecifier);
                    }
                    else if (my_section_name == "CAL_CUS_Security_HeaderHigh")
                    {
                        // Read data provided for the CAL CUS_Security HeaderHigh.
                        data = int.Parse(my_gc.ST_CHORUS_CALSection_CUS_SecurityHeaderHighContent.Substring(2 + (index_u8 * 2),2),NumberStyles.AllowHexSpecifier);
                    }

                    // Add the data.
                    my_output_helper.Add(1, data, my_gc.ST_CHORUS_Endianness);
                }

                // Fill the remaining location with 0xFF.
                for (int index_u8 = 0 ; index_u8 < (SectionSize - SectionDataLength) ; index_u8++)
                {
                    my_output_helper.Add(1, 0xFF, my_gc.ST_CHORUS_Endianness);
                }
            }
            else
            {
                Console.BackgroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("===========================================================================================");
                Console.WriteLine("::: ERROR :::: {0} section content size is more than configured size            ",my_section_name);
                Console.WriteLine("{0} allocated size =  {1} bytes                                                 ",my_section_name,SectionSize);
                Console.WriteLine("Actual {0} Data size = {1} bytes                                                ",my_section_name,SectionDataLength);
                Console.WriteLine("Please increase the {0} size or Update the Configuration XML with proper value  ",my_section_name);
                Console.WriteLine("===========================================================================================");
                Console.ResetColor();
                error_b = true;
            }

            return error_b;
        }
    }
}
