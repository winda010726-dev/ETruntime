using System;
using System.Collections.Generic;
using System.IO;

namespace parsrv
{
    /// <summary>
    /// Helper functions used everywhere in ParGen.
    /// </summary>
    class HelperFunctions
    {
        /// <summary>
        /// Simply linewise writes a list to a given output stream.
        /// </summary>

        public static void PrintStringList(ref StreamWriter my_writer, int indent, List<string> my_list)
        {
            foreach (string my_string in my_list)
            {
                my_writer.WriteLine("{0}{1}", new String(' ', indent), my_string);
            }
        }

        // For indentation purpose.
        public static string Spacing(int count)
        {
            return "".PadLeft(count);
        }
    }
}
