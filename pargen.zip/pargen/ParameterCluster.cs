using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Serialization;


namespace parsrv
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Xml;
    using System.Xml.Serialization;

    /// <summary>
    /// A class to handle a parameter cluster; mainly holds all the data from the imported XML-file.
    /// </summary>

    public class cParameterCluster
    {
        // Parameter Cluster name.
        private string my_name;

        // Memory type on the target (ECU) (ex : ROM,RAM_INIT,NMV_INIT,NVM).
        private string my_memory_area;

        // Variant application for this cluster(ex: SINGLE,MINOR_ALL).
        private string my_variant_application;

        // Cluster sorting key.
        private string my_cluster_key; 

        // Description of the cluster.
        private string my_description; 

        // PID value of an NVM block.
        private string my_PID;   
 
        // Parameter definitions.
        private List<cParameterDefinition> my_parameter_definitions;

        // Major/Vehicle variants.
        private List<cVariantImplementation> my_variants; 

        // Parameter Cluster name.
        [XmlElement("Name")]
        public string Name
        {
            get { return my_name; }
            set { my_name = value; }
        }

        // Residing memory area in ECU.
        [XmlElement("MemoryArea")]
        public string MemoryArea
        {
            get { return my_memory_area; }
            set { my_memory_area = value; }
        }

        // Cluster type (i.e SINGLE/MINOR_ALL).
        [XmlElement("VariantApplication")]
        public string VariantApplication
        {
            get { return my_variant_application; }
            set { my_variant_application = value; }
        }

        // Cluster sorting key.
        [XmlElement("ClusterKey")]
        public string ClusterKey
        {
            get { return my_cluster_key; }
            set { my_cluster_key = value; }
        }

        // Persistance ID for NVM Clusters.
        [XmlElement("PID")]
        public string PID
        {
            get { return my_PID; }
            set { my_PID = value; }
        }

        // Information of the parameter cluster.
        [XmlElement("Description")]
        public string Description
        {
            get { return my_description; }
            set { my_description = value; }
        }

        // Members of the parameter clusters.
        [XmlArray("ParameterDefinitionList")]
        [XmlArrayItem("ParameterDefinition")]
        public List<cParameterDefinition> ParameterDefinitions
        {
            get { return my_parameter_definitions; }
            set { my_parameter_definitions = value; }
        }

        // Variant application for this cluster(ex: SINGLE,MINOR_ALL).
        [XmlArray("VariantImlementationList")]
        [XmlArrayItem("VariantImlementation")]
        public List<cVariantImplementation> VariantsImlementations
        {
            get { return my_variants; }
            set { my_variants = value; }
        }

        // Default constructor.
        public cParameterCluster()
        {
            this.my_name = "ClusterX";
            this.my_memory_area = "MemoryAreaX";
            this.my_variant_application = "SINGLE";
            this.my_cluster_key = "65535";
            this.my_PID = "601";
            this.my_description = "no description available";
            this.my_parameter_definitions = new List<cParameterDefinition>();
            this.my_variants = new List<cVariantImplementation>();
        }

        // Parameterized constructor.
        public cParameterCluster(string new_name,
                                  string new_memory_area,
                                  string new_variant_application,
                                  string new_cluster_key,
                                  string new_PID,
                                  string new_description,
                                  List<cParameterDefinition> new_parameter_definitions,
                                  List<cVariantImplementation> new_variants)
        {
            this.my_name = new_name;
            this.my_memory_area = new_memory_area;
            this.my_variant_application = new_variant_application;
            this.my_cluster_key = new_cluster_key;
            this.my_PID = new_PID;
            this.my_description = new_description;
            this.my_parameter_definitions = new_parameter_definitions;
            this.my_variants = new_variants;
        }


        public static int CompareByClusterKey(cParameterCluster x, cParameterCluster y)
        {
            UInt32 a = Convert.ToUInt32(x.ClusterKey);
            UInt32 b = Convert.ToUInt32(y.ClusterKey);

            if (a == b)
            {
                return 0;
            }
            else if (a > b)
            {
                return 1;
            }
            else
            {
                return -1;
            }
        }
    }

    // A class to handle the implementation of a global-variant
    public class cVariantImplementation
    {
        // A list with names of the global major\vehicle variants the variant implementation is valid for.
        private List<string> my_assigned_major_variants;

        // List of minor variants implementations
        private List<cMinorVariant> my_minor_variants; 

        // List of major variants.
        [XmlArray("MajorVariantList")]
        [XmlArrayItem("MajorVariant")]
        public List<string> MajorVariants
        {
            get { return my_assigned_major_variants; }
            set { my_assigned_major_variants = value; }
        }

        // List of Minor variants.
        [XmlArray("MinorVariantList")]
        [XmlArrayItem("MinorVariant")]
        public List<cMinorVariant> MinorVariants
        {
            get { return my_minor_variants; }
            set { my_minor_variants = value; }
        }

        // Default constructor.
        public cVariantImplementation()
        {
            this.my_assigned_major_variants = new List<string>();
            this.my_minor_variants = new List<cMinorVariant>();
        }

        // Parameterized Constructor.
        public cVariantImplementation(List<string> new_assigned_major_variants,
                                       List<cMinorVariant> new_minor_variants)
        {
            this.my_assigned_major_variants = new_assigned_major_variants;
            this.my_minor_variants = new_minor_variants;
        }
    }
    

    // A class to handle the values of a parameter.
    public class cParameterValue
    {
        // To be able to handle arrays my_values is implemented as a list.
        private List<string> my_values;

        // Value list for array
        [XmlArray("ValueList")]
        [XmlArrayItem("Value")]
        public List<string> Values
        {
            get { return my_values; }
            set { my_values = value; }
        }

        // Default constructor.
        public cParameterValue()
        {
            this.my_values = new List<string>();
        }

        // Parameterized constructor.
        public cParameterValue(List<string> new_values)
        {
            this.my_values = new_values;
        }
    }

    // A class to handle the implementation of a sub-variant.
    public class cSubVariant
    {
        // Name of the sub-variant.
        private string my_name;

        // List with parameter values
        private List<cParameterValue> my_parameter_values;

        // Name of the sub-variant.
        [XmlElement("Name")]
        public string Name
        {
            get { return my_name; }
            set { my_name = value; }
        }

        // List of Parameter values.
        [XmlArray("ParameterValueList")]
        [XmlArrayItem("ParameterValue")]
        public List<cParameterValue> ParameterValues
        {
            get { return my_parameter_values; }
            set { my_parameter_values = value; }
        }

        // Default Constructor.
        public cSubVariant()
        {
            this.my_name = "SubVariantX";
            this.my_parameter_values = new List<cParameterValue>();
        }

        // Parameterized constructor.
        public cSubVariant(string new_name,
                            List<cParameterValue> new_parameter_values)
        {
            this.my_name = new_name;
            this.my_parameter_values = new_parameter_values;
        }
    }

    // A class to handle the implementation of a minor-variant.
    public class cMinorVariant
    {
        // Name of the minor-variant.
        private string my_name;

        // List with sub-variant implementations.
        private List<cSubVariant> my_sub_variants;

        // Name of the minor-variant.
        [XmlElement("Name")]
        public string Name
        {
            get { return my_name; }
            set { my_name = value; }
        }

        // List with sub-variant implementations.
        [XmlArray("SubVariantList")]
        [XmlArrayItem("SubVariant")]
        public List<cSubVariant> SubVariants
        {
            get { return my_sub_variants; }
            set { my_sub_variants = value; }
        }

        // Default constructors.
        public cMinorVariant()
        {
            this.my_name = "MinorVariantX";
            this.my_sub_variants = new List<cSubVariant>();
        }

        // Parameterized constructor.
        public cMinorVariant(string new_name,
                              List<cSubVariant> new_sub_variants)
        {
            this.my_name = new_name;
            this.my_sub_variants = new_sub_variants;
        }
    }
}
