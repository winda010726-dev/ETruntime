using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;


namespace parsrv
{
    public class cWrapper_XML_2_x
    {
        // Default Constructor.
        public cWrapper_XML_2_x()
        {

        }

        /// <summary>
        /// Update the enumeration name. Remove "Type_" from the enumeration name.
        /// </summary>
        /// <param name="my_ps"></param>
        public void Update_XML_enum_name(ref cParameterSet my_ps)
        {
            int index = "Type_".Length;
            bool updated_enum = false;

            // Iterate through each enumeration.
            foreach (cEnumeration my_enum_type in my_ps.DataTypes.Enumerations)
            {
                // Iterate through each component.
                foreach (cComponent component in my_ps.Components)
                {
                    foreach (cDefine my_define in component.Defines)
                    {
                        if (my_enum_type.Name == my_define.TypeInModel)
                        {
                            if (my_enum_type.Name.StartsWith("Type_"))
                            {
                                // Remove the "Type_" from the TypeInModel of define.
                                my_define.TypeInModel = my_enum_type.Name.Substring(index);
                                updated_enum = true;
                            }
                        }
                    }

                    foreach (cParameterCluster cluster in component.ParameterClusters)
                    {
                        foreach(cParameterDefinition para_def in cluster.ParameterDefinitions)
                        {
                            if (my_enum_type.Name == para_def.TypeInModel)
                            {
                                if (my_enum_type.Name.StartsWith("Type_"))
                                {
                                    // Remove the "Type_" from the TypeInModel of parameter definition.
                                    para_def.TypeInModel = my_enum_type.Name.Substring(index);
                                    updated_enum = true;
                                }
                            }
                        }
                    }
                }

                if (updated_enum != false)
                {
                    if (my_enum_type.Name.StartsWith("Type_"))
                    {
                        // Remove the "Type_" from the enumeration name.
                        my_enum_type.Name = my_enum_type.Name.Substring(index);
                        updated_enum = false;
                    }
                }
            }

        }

        /// <summary>
        /// Update the type of the Defines (Constant/Switches).
        /// </summary>
        /// <param name="my_ps"></param>
        /// <returns></returns>

        public bool Update_XML_DefineType(ref cParameterSet my_ps)
        {
            // Variable to check if match is found.
            bool l_match_found = false;

            // Iterate through each component.
            foreach (cComponent component in my_ps.Components)
            {
                // Iterate through each define within the component.
                foreach (cDefine my_define in component.Defines)
                {
                    // Iterate through each custom type.
                    foreach (cCustomType my_customtype in my_ps.DataTypes.CustomTypes)
                    {
                        // Check whether Define Type is a customtype.
                        if (my_define.TypeInModel == my_customtype.Name)
                        {
                            // Define is of type Constant.
                            // Update the Define Type with the value available in TypeInPlatform of custom type, exit from the loop.
                            my_define.Type = my_customtype.TypeInPlatform;
                            l_match_found = true;
                            break;
                        }
                    }

                    // Is Define type already updated ?
                    if (l_match_found != true)
                    {
                        // Check whether Define is of Type cont (continuous), disc (discrete), logical (Boolean).
                        if ((my_define.TypeInModel == "cont") || (my_define.TypeInModel == "disc") || (my_define.TypeInModel == "logical"))
                        {
                            // Define is of type Constant.
                            // Define Type is already available within TypeInPlatform. Update it to Type.
                            my_define.Type = my_define.TypeInPlatform;
                            l_match_found = true;
                        }
                        // Define is of type Enumeration or type is not valid.
                        else
                        {
                            foreach (cEnumeration my_enum_type in my_ps.DataTypes.Enumerations)
                            {
                                // Check whether Type of define is Enumeration
                                if (my_define.TypeInModel == my_enum_type.Name)
                                {
                                    // Define is of Type SWITCH, Update and exit loop.
                                    my_define.Type = "switch";
                                    l_match_found = true;
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        // Define Type is considered from Custom Type.
                    }

                    try
                    {
                        if (my_define.Type == "TypeX")
                        {
                            // Define type is Invalid.
                            // TypeInModel does not match any of the above cases, throw exception.
                            string my_error_message = "  Check TypeInModel of the define '"+ my_define.Name + "' in parameter set file.";
                            throw (new Exception(my_error_message));
                        }
                        else
                        {
                            // Type updated. Reset the variable to false. Go to next define.
                            l_match_found = false;
                        }
                    }
                    catch (Exception Invalid_Define_Data_type)
                    {
                        Console.BackgroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("======================================================================================");
                        Console.WriteLine("                               ### ERROR ###                                          ");
                        Console.WriteLine("          Invalid TypeInModel or Type tag is not updated.                             ");
                        Console.WriteLine(Invalid_Define_Data_type.Message);
                        Console.WriteLine("======================================================================================");
                        Console.ResetColor();
                        return false;
                    }
                }
            }
            return true;
        }


        
        /// <summary>
        /// Determine the type of enum based on minimum and maximum value of its literal/External XML Tag configuration.
        /// Update \<Min\> and \<Max\> tag value.
        /// </summary>
        /// <param name="my_ps"></param>
        /// <param name="my_gc"></param>
        /// <returns></returns>
        public bool Update_XML_Para_Def_EnumInfo(ref cParameterSet my_ps,ref cGeneralConfiguration my_gc)
        {
            foreach (cComponent component in my_ps.Components)
            {
                // Iterate through each cluster in the component.
                foreach (cParameterCluster cluster in component.ParameterClusters)
                {
                    // Iterate through each parameter in the cluster.
                    foreach (cParameterDefinition para_def in cluster.ParameterDefinitions)
                    {
                        // Iterate through each enumeration in the parameter.
                        foreach (cEnumeration my_enum in my_ps.DataTypes.Enumerations)
                        {
                            // Variable to return the Enumeration type.
                            string my_enum_type = "";

                            // Variable to store exception message.
                            string my_exception_message = "";
                            bool invalid_enum_b = false;

                            // Check whether TypeInModel of Parameter Definition matches the Enumeration Name.
                            if (para_def.TypeInModel == my_enum.Name)
                            {
                                // Variable to loop over the enum values.
                                int loop_var = 0;

                                // Variables to store the min and max values of the enumeration.
                                // Long type is used to store data of range 0 to 4294967296.
                                long my_min_enum_val = 0;
                                long my_max_enum_val = 0;

                                // Array to store the list of enumeration values as long type.
                                // Array size is the count of enum values available. 
                                long[] my_enum_array = new long[my_enum.Literal.Count];

                                // Convert the Enum values from String to Long type. 
                                foreach (cLiteral literal_val in my_enum.Literal)
                                {
                                    my_enum_array[loop_var++] = Convert.ToInt64(literal_val.Value);
                                }

                                // Sorting in ascending order (i.e. smallest to largest number) in order to determine the type of Enumeration Type.
                                Array.Sort(my_enum_array);

                                // Copy the smallest(i.e. minimum) enum value.
                                my_min_enum_val = my_enum_array[0];

                                // Copy the largest(i.e. maximum) enum literal value.
                                my_max_enum_val = my_enum_array[my_enum.Literal.Count - 1];

                                // Enum max value is determined after sorting the enums literal values in ascending order.
                                // Since only non negative literal values exist, determine the range based on maximum value of enum literal value.
                                // To be on safer side check for >= 0 is made.
                                if ((my_min_enum_val >= 0) && (my_max_enum_val < 4294967296))
                                {
                                    if (my_max_enum_val < 2147483648)
                                    {
                                        if (my_max_enum_val < 65536)
                                        {
                                            if (my_max_enum_val < 256)
                                            {
                                                // Range 0 to 255.
                                                my_enum_type = "UInt8";
                                                para_def.TypeInPlatform = my_enum_type;
                                            }
                                            else
                                            {
                                                // Range 0 to 65535.
                                                my_enum_type = "UInt16";
                                                para_def.TypeInPlatform = my_enum_type;
                                            }
                                        }
                                        else
                                        {
                                            // Range 0 to 2147483647, Only Postive values are considered. 
                                            my_enum_type = "SInt32";
                                            para_def.TypeInPlatform = my_enum_type;
                                        }
                                    }
                                    else
                                    {
                                        // Range 0 to 4294967295.
                                        my_enum_type = "UInt32";
                                        para_def.TypeInPlatform = my_enum_type;
                                    }
                                }
                                else
                                {
                                    // Out of UInt32 range.
                                    invalid_enum_b = true;
                                    my_exception_message = "Either Enum value is Negative or Out of UInt32 range. Check enum -> " + my_enum.Name;
                                }
                                try
                                {
                                    if (invalid_enum_b != true)
                                    {
                                        // Check for external configuration type provided for the enum.
                                        if (my_gc.Enum_Type != "short_enum")
                                        {
                                            // Check for cases when <Enum_Type> does not match determined enum type.
                                            // Enum_Type: UInt8; my_enum_type = UInt8/UInt16/UInt32/SInt32.
                                            if(my_gc.Enum_Type == "UInt8")
                                            {
                                                if (my_enum_type == "UInt8")
                                                {
                                                    // Update the enum type provided within Confguration XML file.
                                                    my_enum_type = my_gc.Enum_Type;
                                                }
                                                else
                                                {
                                                    // Error. my_enum_type = UInt16/SInt32/UInt32.
                                                    my_exception_message = "Provide correct Enum_Type. Determined Enum Type:" + my_enum_type + ", Enum_Type provided in Config xml:" + my_gc.Enum_Type;
                                                    invalid_enum_b = true;
                                                }
                                            }
                                            // Enum_Type: UInt16; my_enum_type = UInt8/UInt16/SInt32/UInt32.
                                            else if (my_gc.Enum_Type == "UInt16")
                                            {
                                                if ((my_enum_type == "UInt8") || (my_enum_type == "UInt16"))
                                                {
                                                    // Update the enum type provided within Confguration XML file.
                                                    my_enum_type = my_gc.Enum_Type;
                                                }
                                                else
                                                {
                                                    // Error. my_enum_type = UInt32/SInt32
                                                    my_exception_message = "Provide correct Enum_Type. Determined Enum Type:" + my_enum_type + ", Enum_Type provided in Config xml:" + my_gc.Enum_Type;
                                                    invalid_enum_b = true;
                                                }
                                            }
                                            // Enum_Type: SInt32; my_enum_type = UInt8/UInt16/SInt32/UInt32.
                                            else if (my_gc.Enum_Type == "SInt32")
                                            {
                                                if ((my_enum_type == "UInt8") || (my_enum_type == "UInt16") || (my_enum_type == "SInt32"))
                                                {
                                                    // Update the enum type provided within Confguration XML file.
                                                    my_enum_type = my_gc.Enum_Type;
                                                }
                                                else
                                                {
                                                    // Error. my_enum_type = UInt32
                                                    my_exception_message = "Provide correct Enum_Type. Determined Enum Type:" + my_enum_type + ", Enum_Type provided in Config xml:" + my_gc.Enum_Type;
                                                    invalid_enum_b = true;
                                                }
                                            }
                                            // Enum_Type: UInt32; my_enum_type = UInt8/UInt16/SInt32/UInt32.
                                            else if (my_gc.Enum_Type == "UInt32")
                                            {
                                                // Update the enum type provided within Confguration XML file.
                                                my_enum_type = my_gc.Enum_Type;
                                            }
                                            // Invalid Enum_Type tag in config xml.
                                            else
                                            {
                                                my_exception_message = "Invalid Enum_Type tag value in configuration xml.";
                                                invalid_enum_b = true;
                                            }
                                        }
                                        else
                                        {
                                            // Configuration is "short_enum"
                                            // Update the enum type based on the enum range.
                                        }
                                    }
                                    else
                                    {
                                        // Error. Enum value out of range.
                                    }

                                    if (invalid_enum_b != true)
                                    {
                                        // Update enumeration type.
                                        para_def.Type = my_enum_type;

                                        // Enum min and max is within UInt32 range
                                        // Update <Min> and <Max> tag values.
                                        para_def.Min = Convert.ToString(my_min_enum_val);
                                        para_def.Max = Convert.ToString(my_max_enum_val);

                                        // Update the enumeration values.
                                        string message = Update_XML_enum_value(my_ps,cluster,para_def);
                                        if (message != "VALID_ENUM")
                                        {
                                            // Enumeration name is not available.
                                            throw (new Exception(message));
                                        }
                                    }
                                    else
                                    {
                                        // Invalid Type.
                                        throw (new Exception(my_exception_message));
                                    }
                                }
                                catch (Exception Invalid_Enum_Type)
                                {
                                    // Print error message on the console.
                                    Console.BackgroundColor = ConsoleColor.DarkRed;
                                    Console.WriteLine("=============================================================================================");
                                    Console.WriteLine("                                      ### ERROR ###                                          ");
                                    Console.WriteLine(Invalid_Enum_Type.Message);
                                    Console.WriteLine("=============================================================================================");
                                    Console.ResetColor();
                                    return false;
                                }
                            }
                        }
                    }
                }
            }
            return true;
        }


        /// <summary>
        /// Update the Values of the enumeration within the Variant Implementations.
        /// </summary>
        /// <param name="my_ps"></param>
        /// <param name="cluster"></param>
        /// <param name="para_def"></param>
        public static string Update_XML_enum_value(cParameterSet my_ps, cParameterCluster cluster, cParameterDefinition para_def)
        {
            List<string> update_literal = new List<string>();
            bool l_val_found = false;
            string l_message = "VALID_ENUM";

            // Iterate through each Variant implementations in the cluster.
            foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
            {
                // Iterate through each minor variant of the Variant implementation.
                foreach (cMinorVariant min_var in var_imp.MinorVariants)
                {
                    // Iterate through each sub variant of the minor variant.
                    foreach (cSubVariant sub_var in min_var.SubVariants)
                    {
                        foreach (cParameterValue val_list in sub_var.ParameterValues)
                        {
                            foreach (string val in val_list.Values)
                            {
                                double temp_val = 0.0;
                                // Check whether value is a enumeration / numbers.
                                if (!(double.TryParse(val,out temp_val)))
                                {   
                                    // Value is an enumeration.
                                    foreach (cEnumeration my_enum_ in my_ps.DataTypes.Enumerations)
                                    {
                                        foreach (cLiteral literal_val in my_enum_.Literal)
                                        {
                                            if (val == literal_val.Name)
                                            {
                                                // Enumeration name is available within the Enumeration Type.
                                                update_literal.Add(literal_val.Value);
                                                l_val_found = true;
                                                break;
                                            }
                                        }
                                    }
                                    if (l_val_found != true)
                                    {
                                        // Enumeration name is not available within the Enumeration Type
                                        l_message = "INVALID_ENUM : '" + val + "' not available in input PAR XML." ;
                                        return l_message;
                                    }
                                }
                                else
                                {
                                    update_literal.Add(val);
                                }
                            }
                            for (int i = 0 ; i < update_literal.Count ; i++)
                            {
                                // Update the values.
                                val_list.Values[i] = update_literal[i];
                            }

                            update_literal.Clear();
                        }
                    }
                }
            }
            return l_message;
        }

        /// <summary>
        /// Update \<Type\> tag for parameter definitions.
        /// </summary>
        /// <param name="my_ps"></param>
        /// <returns></returns>
        public bool Update_XML_Para_Def_CustomTypeInfo(ref cParameterSet my_ps)
        {
            // Variable to check if match is found.
            bool l_match_found = false;

            // Iterate through each component.
            foreach (cComponent component in my_ps.Components)
            {
                foreach (cParameterCluster cluster in component.ParameterClusters)
                {
                    foreach (cParameterDefinition para_def in cluster.ParameterDefinitions)
                    {
                        foreach (cCustomType my_customtype in my_ps.DataTypes.CustomTypes)
                        {
                            if (l_match_found != true)
                            {
                                // Check whether TypeInModel of para_def matches the CustomType name.
                                if (para_def.TypeInModel == my_customtype.Name)
                                {
                                    // Match found, update the info.
                                    para_def.Type = my_customtype.TypeInPlatform;
                                    para_def.Min = my_customtype.Range.Min;
                                    para_def.Max = my_customtype.Range.Max;
                                    para_def.Offset = my_customtype.Offset;
                                    para_def.Resolution = my_customtype.Resolution;
                                    para_def.Unit = my_customtype.Unit; 
                                    // Match found set the variable to true.
                                    l_match_found = true;
                                }
                                // Check if TypeInModel is cont (Continuous).TypeInPlatform can be either Float32/SInt32.
                                else if (para_def.TypeInModel == "cont")
                                {
                                    // Parameter Type is available within TypeInPlatform. Update it to Type Tag.
                                    para_def.Type = para_def.TypeInPlatform;
                                    if (para_def.TypeInPlatform == "Float32")
                                    {
                                        para_def.Min = "-3.4028234664E38";
                                        para_def.Max = "3.4028234664E38";
                                    }
                                    else
                                    {
                                        // TypeInPlatform is SInt32.
                                        // Case when floating point support not enabled during generation of par xml.
                                        para_def.Min = "-2147483648";
                                        para_def.Max = "2147483647";
                                    }

                                    l_match_found = true;
                                }
                                // Check if TypeInModel is disc. Always TypeInPlatform will be SInt32.
                                else if (para_def.TypeInModel == "disc")
                                {
                                    // para_def Type is available within TypeInPlatform. Update it to Type.
                                    para_def.Type = para_def.TypeInPlatform;
                                    para_def.Min = "-2147483648";
                                    para_def.Max = "2147483647";
                                    // Match found set the variable to true.
                                    l_match_found = true;
                                }
                                // Check if TypeInModel is logical. Parameter of type Logical.
                                else if (para_def.TypeInModel == "logical")
                                {
                                    // para_def Type is available within TypeInPlatform. Update it to Type.
                                    para_def.Type = para_def.TypeInPlatform;
                                    para_def.Min = "0";
                                    para_def.Max = "1";
                                    // Match found set the variable to true.
                                    l_match_found = true;
                                }
                                else
                                {
                                    // Match not found, go to next iteration.
                                }
                            }
                        }
                        try
                        {
                            if ((para_def.Type == "TypeX") || (para_def.Min == "MinX") || (para_def.Max == "MaxX"))
                            {
                                // TypeInModel does not match any of the above cases, throw error.
                                // Type/Min/Max not upated correctly.
                                string exception_message = "Check TypeInModel of the para_def '" + para_def.Name + "' in parameter set file.";
                                throw (new Exception(exception_message));
                            }
                            else
                            {
                                // Type updated. Reset the variable to false. Go to next para_def.
                                l_match_found = false;
                            }
                        }
                        catch (Exception Invalid_Type)
                        {
                            Console.BackgroundColor = ConsoleColor.DarkRed;
                            Console.WriteLine("=============================================================================================");
                            Console.WriteLine("                                      ### ERROR ###                                          ");
                            Console.WriteLine("Invalid TypeInModel or Type/Min/Max value is not updated.                                    ");
                            Console.WriteLine(Invalid_Type.Message);
                            Console.WriteLine("=============================================================================================");
                            Console.ResetColor();
                            return false;
                        }
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// Provide the enumeration name for the provided value.
        /// </summary>
        /// <param name="my_ps"></param>
        /// <param name="my_ps_def"></param>
        /// <param name="enum_val"></param>
        /// <returns></returns>
        public string Get_enum_name(cParameterSet my_ps, cParameterDefinition my_ps_def ,string enum_val)
        {
            foreach(cEnumeration my_enum in my_ps.DataTypes.Enumerations)
            {
                // Check whether TypeInModel is of type Enumeration.
                if (my_ps_def.TypeInModel == my_enum.Name)
                {
                    foreach (cLiteral literal_val in my_enum.Literal)
                    {
                        // Check for the enum value.
                        if (enum_val == literal_val.Value)
                        {
                            // Update the enumeration name.
                            enum_val = "rbp_" + literal_val.Name + "_enm";
                        }
                    }
                }
            }

            return enum_val;
        }

        /// <summary>
        ///  Provides the type of the parameter (enumeration/basic data types)
        /// </summary>
        /// <param name="my_ps"></param>
        /// <param name="my_para_def"></param>
        /// <returns></returns>
        public string Get_para_def_Type(cParameterSet my_ps, cParameterDefinition my_para_def)
        {
            string l_para_def_type = "";
            bool l_type_enum_b = false;

            if (my_ps.ParameterSetInfo.Version != "1.0")
            {
                foreach (cEnumeration my_enum in my_ps.DataTypes.Enumerations)
                {
                    // Check whether parameter is of enum type.
                    if (my_para_def.TypeInModel == my_enum.Name)
                    {
                        // Parameter Defintion type is enumeration Type. Add prefix and suffix.
                        l_para_def_type = "rbp_Type_" + my_para_def.TypeInModel + "_en";
                        l_type_enum_b = true;
                        break;
                    }
                }
            }

            if (l_type_enum_b != true)
            {
                // Parameter Defintion is of basic type.
                l_para_def_type = my_para_def.Type;
            }

            // return the parameter type.
            return l_para_def_type;
        }

        /// <summary>
        ///  Check whether parameter is of type enumeration.
        /// </summary>
        /// <param name="my_ps"></param>
        /// <param name="my_para_def"></param>
        /// <returns></returns>
        public bool Is_para_def_enum_b(cParameterSet my_ps,cParameterDefinition my_para_def)
        {
            bool is_enum_b = false;
            if (my_ps.ParameterSetInfo.Version != "1.0")
            {
                foreach (cEnumeration my_enum in my_ps.DataTypes.Enumerations)
                {
                    // Check if parameter is type enum.
                    if (my_para_def.TypeInModel == my_enum.Name)
                    {
                        is_enum_b = true;
                    }
                }
            }

            return is_enum_b;
        }

        /// <summary>
        /// Print the Table of values for the enumeration. 
        /// </summary>
        /// <param name="my_ps"></param>
        /// <param name="para_def"></param>
        /// <param name="writer"></param>
        public void PrintA2LEnum(cParameterSet my_ps,cParameterDefinition para_def,StreamWriter writer)
        {
            // Iterate over each enumeration
            foreach (cEnumeration my_enum in my_ps.DataTypes.Enumerations)
            {
                // Check whether Paradef is of type enumeration.
                if (para_def.TypeInModel == my_enum.Name)
                {
                    foreach (cLiteral val in my_enum.Literal)
                    {
                        // Print table of content of enumeration values.
                        writer.Write("{0} \"rbp_{1}_enm\" ",val.Value,val.Name);
                    }
                    break;
                }
            }
        }

        /// <summary>
        /// Generate the "rbp_param_types_def.h" file .Contains Switches and Enumeration declarations.
        /// <param name="my_ps"></param>
        /// <param name="my_ps_file_name"></param>
        /// <param name="my_output_path"></param>
        /// <param name="my_dt"></param>
        /// <param name="my_gc"></param>
        public void PrintGenParamTypesDef(ref cParameterSet my_ps,ref String my_ps_file_name,String my_output_path,String my_FileName_Suffix,ref DateTime my_dt,ref cGeneralConfiguration my_gc)
        {
            // Initialize the necessary variables.
            Program my_program = new Program();
            string my_gen_file_name = "rbp_param_types_def" + my_FileName_Suffix + ".h";
            string my_source_file_name = "Wrapper2_x.cs";

            // Overwrite the output path if already exists.
            my_program.OverwriteOPPath(ref my_gc,ref my_output_path,my_gen_file_name);

            // Generated file header.
            my_program.PrintFileInfo(ref my_ps,ref my_ps_file_name,my_output_path,ref my_dt,my_gen_file_name, my_source_file_name);

            // Obtain absolute path of output file.
            var genFileNamePath = Path.Combine(Path.GetFullPath(my_output_path), my_gen_file_name);

            // Open output file.
            var writer = Program.CreateStreamWriter(genFileNamePath, true, Encoding.ASCII);

            writer.WriteLine("#ifndef RBP_PARAM_TYPES_DEF{0}_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("#define RBP_PARAM_TYPES_DEF{0}_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("");

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("extern \"C\"");
            writer.WriteLine("{");
            writer.WriteLine("#endif // __cplusplus");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Magic number                                                           -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#define RBP_PARAM_TYPES_MAGIC_NUMBER_GEN  0x{0:d2}{1:d2}{2:d2}{3:d2}",my_dt.Month,my_dt.Day,my_dt.Hour,my_dt.Minute);
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Component Switches                                                     -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Include files                                                          -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Exported Macros                                                        -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("");


            writer.WriteLine("// DEFINE SWITCHES ");

            // List to add and check the enumeration 
            List<string> my_define_enum = new List<string>();
            List<string> my_para_def_enum = new List<string>();

            foreach (cComponent component in my_ps.Components)
            {
                foreach (cDefine my_define in component.Defines)
                {
                    foreach (cEnumeration my_enum in my_ps.DataTypes.Enumerations)
                    {
                        if (my_define.TypeInModel == my_enum.Name)
                        {
                            // Check whether enum is already used in define.
                            if (!my_define_enum.Contains(my_define.TypeInModel))
                            {
                                // Add Enumeration to the list.
                                my_define_enum.Add(my_define.TypeInModel);

                                // Generate the #defines.
                                foreach (cLiteral my_literal in my_enum.Literal)
                                {
                                    writer.WriteLine("#define RBP_{0}  {1}",my_literal.Name.ToUpper(),my_literal.Value);
                                    writer.WriteLine("");
                                }
                            }
                            break;
                        }
                    }
                }
            }
            
            writer.WriteLine("// Enumeration Declarations");
            foreach (cComponent component in my_ps.Components)
            {
                foreach (cParameterCluster cluster in component.ParameterClusters)
                {
                    foreach (cParameterDefinition my_para_def in cluster.ParameterDefinitions)
                    {
                        foreach (cEnumeration my_enum in my_ps.DataTypes.Enumerations)
                        {
                            if (my_para_def.TypeInModel == my_enum.Name)
                            {
                                // Check whether enum is already used in parameter definition.
                                if (!my_para_def_enum.Contains(my_para_def.TypeInModel))
                                {
                                    string pre_fix = "rbp";  // Prefix for the enumeration.
                                    string post_fix = "en";  // Suffix for the enumeration.
                                    cLiteral max_val = new cLiteral();

                                    // Add Enumeration to the list.
                                    my_para_def_enum.Add(my_para_def.TypeInModel);
                                    
                                    // Add new enum with the max value of the Enum_Type for "UInt8", "UInt16", "SInt32", "UInt32"
                                    if (my_gc.Enum_Type == "UInt8") 
                                    {
                                        max_val.Name = my_para_def.TypeInModel + "_max_val";
                                        max_val.Value = "255";
                                        my_enum.Literal.Add(max_val); 
                                    }
                                    else if (my_gc.Enum_Type == "UInt16")
                                    {
                                        max_val.Name = my_para_def.TypeInModel + "_max_val";
                                        max_val.Value = "65535";
                                        my_enum.Literal.Add(max_val);    
                                    }
                                    else if (my_gc.Enum_Type == "SInt32")
                                    {
                                        max_val.Name = my_para_def.TypeInModel + "_max_val";
                                        max_val.Value = "2147483647";
                                        my_enum.Literal.Add(max_val);
                                    }
                                    else if (my_gc.Enum_Type == "UInt32")
                                    {
                                        max_val.Name = my_para_def.TypeInModel + "_max_val";
                                        max_val.Value = "4294967295";
                                        my_enum.Literal.Add(max_val);
                                    }
                                    else
                                    {
                                        // Enum_Type = short_enum, Addition of new enum value is not required.
                                    }

                                    // Get the count of enum values.
                                    int num_enum_val = my_enum.Literal.Count;

                                    // Typedef of the enumeration.
                                    writer.WriteLine("typedef enum {0}_Tag_{1}_{2} {{",pre_fix,my_para_def.TypeInModel,post_fix);
                                    for (int loop_index = 0 ; loop_index < num_enum_val ; loop_index++)
                                    {
                                        writer.Write("  {0}_{1}_enm = {2}",pre_fix,my_enum.Literal[loop_index].Name,my_enum.Literal[loop_index].Value);
                                        if (loop_index != (num_enum_val-1))
                                        {
                                            writer.WriteLine(",");
                                        }
                                        else
                                        {
                                            // Last element.
                                            writer.WriteLine("");
                                        }
                                    }
                                    writer.WriteLine("}} {0}_Type_{1}_{2};", pre_fix, my_para_def.TypeInModel, post_fix);

                                    writer.WriteLine("");
                                    writer.WriteLine("");
                                }
                                break;
                            }
                        }
                    }
                }
            }
            
            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("}");
            writer.WriteLine("#endif // __cplusplus");
            writer.WriteLine("#endif /* RBP_PARAM_TYPES_DEF{0}_H */", my_FileName_Suffix.ToUpper());

            // Close output file.
            writer.Close();
        }
    }
}
