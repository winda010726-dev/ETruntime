using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Runtime.InteropServices;

namespace parsrv
{
    // A class to handle the attributes of a nvm record member.
    public class cNVMRecordMemberDefinition
    {
        private string my_name;
        private string my_type;
        private string my_number;
        private string my_byte_offset;
        private string my_bit_mask;

        [XmlElement("Name")]
        public string Name
        {
            get { return my_name; }
            set { my_name = value; }
        }

        [XmlElement("Type")]
        public string Type
        {
            get { return my_type; }
            set { my_type = value; }
        }

        [XmlElement("Number")]
        public string Number
        {
            get { return my_number; }
            set { my_number = value; }
        }

        [XmlElement("ByteOffset")]
        public string ByteOffset
        {
            get { return my_byte_offset; }
            set { my_byte_offset = value; }
        }

        [XmlElement("BitMask")]
        public string BitMask
        {
            get { return my_bit_mask; }
            set { my_bit_mask = value; }
        }

        // Default constructor.
        public cNVMRecordMemberDefinition()
        {
            this.my_name = "NVMMemberX";
            this.my_type = "TypeX";
            this.my_number = "0";
            this.my_byte_offset = "0";
            this.my_bit_mask = "0x0";
        }

        // Parameterized Constructor.
        public cNVMRecordMemberDefinition(string new_name,
                        string new_type,
                        string new_number,
                        string new_byte_offset,
                        string new_bitmask)
        {
            this.my_name = new_name;
            this.my_type = new_type;
            this.my_number = new_number;
            this.my_byte_offset = new_byte_offset;
            this.my_bit_mask = new_bitmask;
        }
    }


    // NVM Record List.
    [XmlRoot("NVMRecordList")]
    public class cNVMRecordList
    {
        private List<cNVMRecord> my_nvm_records; // nvm records

        [XmlElement("NVMRecords")]
        public List<cNVMRecord> NVMRecords
        {
            get { return my_nvm_records; }
            set { my_nvm_records = value; }
        }

        public cNVMRecordList()
        {
            this.my_nvm_records = new List<cNVMRecord>();
        }

        public cNVMRecordList(List<cNVMRecord> new_nvm_records)
        {
            this.my_nvm_records = new_nvm_records;
        }
    }

    // A class to handle a NVM parameter cluster description.
    public class cNVMRecord
    {
        // Name.
        private string my_name;

        // Record id.
        private int my_rec_id;

        // The nvrbp_par_ameter definitions.
        private List<cNVMRecordMemberDefinition> my_nvm_member_definitions;

        [XmlElement("Name")]
        public string Name
        {
            get { return my_name; }
            set { my_name = value; }
        }

        [XmlElement("RecordId")]
        public int RecordId
        {
            get { return my_rec_id; }
            set { my_rec_id = value; }
        }

        [XmlArray("NVMMemberDefinitionList")]
        [XmlArrayItem("NVMMemberDefinition")]
        public List<cNVMRecordMemberDefinition> NVMMemberDefinition
        {
            get { return my_nvm_member_definitions; }
            set { my_nvm_member_definitions = value; }
        }

        // Default constructor.
        public cNVMRecord()
        {
            this.my_name = "NVMClusterX";
            this.my_rec_id = 0;
            this.my_nvm_member_definitions = new List<cNVMRecordMemberDefinition>();
        }

        // Parameterized constructor.
        public cNVMRecord(string new_name,
                          int new_rec_id,
                          List<cNVMRecordMemberDefinition> new_nvrbp_par_ameter_definitions)
        {
            this.my_name = new_name;
            this.my_rec_id = new_rec_id;
            this.my_nvm_member_definitions = new_nvrbp_par_ameter_definitions;
        }
    }

    // Helper class to write a single record of a RAW/XML-file.
    public class cNECFx3Fx4_DataFlashHelper
    {
        private List<int> my_values;
        private int my_alignment;

        // Below declaration works like union.   
        // Ex: union{                                         ______float var (4 Bytes)______
        // float f_var;                       In memory    {_______________________________}
        // byte  b_var_0;                                  | byte3 | byte2 | byte1 | byte0|  
        // byte  b_var_1;
        // byte  b_var_2;                                   
        // byte  b_var_2;
        // }
         
        [StructLayout(LayoutKind.Explicit)]
        public struct MyUnion
        {
            [FieldOffset(0)]
            public float value;

            [FieldOffset(0)]
            public Byte byte0;

            [FieldOffset(1)]
            public Byte byte1;

            [FieldOffset(2)]
            public Byte byte2;

            [FieldOffset(3)]
            public Byte byte3;
        }

        public List<int> Values
        {
            get { return my_values; }
            set { my_values = value; }
        }

        // Get the number of data bytes in the value list.
        public int GetSize()
        {
            return my_values.Count;
        }

        // Determine the number of necessary padding/stuff bytes for a given address/offset and alignment.
        public int GetNummberOfPaddingBytes(int offset, int alignment)
        {
            return ((alignment - (offset % alignment)) % alignment);
        }

        // Adds new data of the list. Depending on the size, up to 4 bytes, the values will be extracted from the input integer value.
        // By Gasser for all datatypes of my_value except UInt32. For Uint32 see overload Add Func. 
        public void Add(int my_number, int my_value, string endianness)
        {
            // The function can handle up to 4 bytes data types.
            switch (my_number)
            {
                case 1:
                    // 1 byte type.
                    my_values.Add(my_value & 0x000000FF);
                    break;

                case 2:
                    // 2 byte type.
                    if (endianness == "LITTLE")
                    {
                        my_values.Add(my_value & 0x000000FF);
                        my_values.Add((my_value >> 8) & 0x000000FF);
                    }
                    else if (endianness == "BIG")
                    {
                        my_values.Add((my_value >> 8) & 0x000000FF);
                        my_values.Add(my_value & 0x000000FF);
                    }
                    break;

                case 3:
                    // 3 byte type.
                    if (endianness == "LITTLE")
                    {
                        my_values.Add(my_value & 0x000000FF);
                        my_values.Add((my_value >> 8) & 0x000000FF);
                        my_values.Add((my_value >> 16) & 0x000000FF);
                    }
                    else if (endianness == "BIG")
                    {
                        my_values.Add((my_value >> 16) & 0x000000FF);
                        my_values.Add((my_value >> 8) & 0x000000FF);
                        my_values.Add(my_value & 0x000000FF);
                    }
                    break;

                case 4:
                    // 4 byte type.
                    if (endianness == "LITTLE")
                    {
                        my_values.Add(my_value & 0x000000FF);
                        my_values.Add((my_value >> 8) & 0x000000FF);
                        my_values.Add((my_value >> 16) & 0x000000FF);
                        my_values.Add((my_value >> 24) & 0x000000FF);
                    }
                    else if (endianness == "BIG")
                    {
                        my_values.Add((my_value >> 24) & 0x000000FF);
                        my_values.Add((my_value >> 16) & 0x000000FF);
                        my_values.Add((my_value >> 8) & 0x000000FF);
                        my_values.Add(my_value & 0x000000FF);
                    }
                    break;

                default:
                    break;
            }
        }

        // By Gasser for NVM-section
        // Adds new data of the list. depending on the size, only for 4 bytes values. The values will be extracted from
        // the input UInt32 value. For all other Types see overload Add func.
        public void Add(int my_number, uint my_value, string endianness)
        {
            byte[] byteArray = BitConverter.GetBytes(my_value);
            if (endianness == "LITTLE")
            {
                my_values.Add(Convert.ToInt32(byteArray[0]));
                my_values.Add(Convert.ToInt32(byteArray[1]));
                my_values.Add(Convert.ToInt32(byteArray[2]));
                my_values.Add(Convert.ToInt32(byteArray[3]));
            }
            else if (endianness == "BIG")
            {
                my_values.Add(Convert.ToInt32(byteArray[3]));
                my_values.Add(Convert.ToInt32(byteArray[2]));
                my_values.Add(Convert.ToInt32(byteArray[1]));
                my_values.Add(Convert.ToInt32(byteArray[0]));
            }
        }

        // Computes the CRC and adds it at the end of the value list.
        public void AddCRC()
        {
            int sum = 0;

            // Sum up.
            foreach (int value in this.my_values)
            {
                sum += value;
            }

            // Invert.
            sum = ~sum;

            // ... and add the CRC at the end
            // Commented this code because we need to give pure data to MCM Tool and 
            // MCM tool will internally calculate required CRC and will append it as required by Microcontroller
            /* my_values.Add(sum & 0x000000FF);
               my_values.Add((sum >> 8) & 0x000000FF);
               my_values.Add((sum >> 16) & 0x000000FF);
               my_values.Add((sum >> 24) & 0x000000FF); */
        }

        // Clears the value list.
        public void Empty()
        {
            // Remove all elements from the internal list.
            my_values.Clear();
        }

        // Write a record into the output file (Fx3).
        public void OutputFx3(ref StreamWriter my_writer,
                              string my_id,
                              int cluster_index,
                              string name,
                              int sub_var_cluster_index,
                              string name_minV,
                              string product_line)
        {
            int num_lines = 0;

            // XML format.
            if (product_line == "NRCS")
            {
                // For Coding support : Cluster Index, sub_var index , min_var name are required. 
                my_writer.WriteLine("  <Record clusterName=\"{0}\" minorVariant=\"{3}\" clusterIndex={1} arrayIndex={2}>", name, cluster_index, sub_var_cluster_index, name_minV);
            }
            else
            {
                // For PMA, no information will be provided within record tag.
                my_writer.WriteLine("  <Record>");
            }
            my_writer.WriteLine("    <ID> {0} </ID>", my_id);
            my_writer.WriteLine("    <Length> {0} </Length>", my_values.Count);
            my_writer.WriteLine("    <Data>");

            foreach (int value in my_values)
            {
                num_lines++;

                my_writer.Write("      0x{0:x2}", value);

                if (num_lines < my_values.Count)
                {
                    my_writer.WriteLine(",");
                }
                else
                {
                    my_writer.WriteLine("");
                }
            }
            // xml format.
            my_writer.WriteLine("    </Data>");
            my_writer.WriteLine("  </Record>");
        }


        // Write a record into the output file (Fx4).
        public void OutputFx4(ref StreamWriter my_writer, int my_id, string backup_option, string PersistentID)
        {
            int num_lines = 0;
            my_id = Convert.ToInt32(PersistentID);

            {
                // xml format.
                my_writer.WriteLine("  <Record>");
                my_writer.WriteLine("    <ID> {0} </ID>", my_id);
                my_writer.WriteLine("    <Length> {0} </Length>", my_values.Count);
                my_writer.WriteLine("    <Backup> {0} </Backup>", backup_option);
                my_writer.WriteLine("    <Data>");
            }

            foreach (int value in my_values)
            {
                num_lines++;

                my_writer.Write("      0x{0:x2}", value);

                if (num_lines < my_values.Count)
                {
                    my_writer.WriteLine(",");
                }
                else
                {
                    my_writer.WriteLine("");
                }
            }

            {
                // xml format.
                my_writer.WriteLine("    </Data>");
                my_writer.WriteLine("  </Record>");
            }
        }


        // Processes one sub-variant using the data from sub_var and the parameter definitions from parameter_definitions.
        public int ProcessCluster(List<cParameterDefinition> parameter_definitions,
                                  cSubVariant sub_var,
                                  bool add_fx3_crc,
                                  bool add_final_padding,
                                  ref List<cNVMRecordMemberDefinition> my_nvm_rec_member_list,
                                  string endianness,
                                  string padding_enabled)
        {
            // Address counter.
            int address = 0;

            // Bitfield control data.
            int bitfield_current_count = 0;
            int bitfield_value = 0;
            int bitfield_base_address = 0;
            int bitfield_base_offset = 0;


            // Loop variable.
            int i = 0;

            // Iterate over all parameters.
            foreach (cParameterDefinition para_def in parameter_definitions)
            {
                // Check for bitfields.
                if (para_def.IsBitfield() == false)
                {
                    // Handle non-bitfield parameters.

                    // Check if previous parameter was a bitfield and write it into the output stream.
                    if (bitfield_current_count > 0)
                    {
                        // Write bitfield.
                        this.Add(((bitfield_current_count + 7) / 8), bitfield_value, endianness);

                        // Update address.
                        address += ((bitfield_current_count + 7) / 8);

                        // Clear bitfield.
                        bitfield_value = 0;
                        bitfield_current_count = 0;
                    }

                    if ( (padding_enabled == "FULL") || (padding_enabled == "DEFAULT") )// data alignment 
                    {
                        // Commented data alignement section as we have to give pure data to MCM tool. 
                        // MCM tool internally do data alignment  
                        int num_alignment_bytes = GetNummberOfPaddingBytes(address, Math.Min(my_alignment, para_def.GetSizeOfType()));

                        // Write padding bytes.
                        this.Add(num_alignment_bytes, 0, endianness);

                        // Update address.
                        address += num_alignment_bytes; 
                    }

                    // Data.
                    {
                        my_nvm_rec_member_list.Add(new cNVMRecordMemberDefinition(para_def.Name, para_def.Type, para_def.Number,
                                                                          String.Format("{0}", address), para_def.GetBitMaskString(0)));

                        foreach (string my_value in sub_var.ParameterValues[i].Values)
                        {
                            // By Gasser for NVM-section.
                            // my_value = UInt32 max  = 4294967295
                            // my_value = Int32 max   =  2147483647
                            if (para_def.GetNameOfType() == "UInt32")
                            {
                                // This overload Add function is handling only UInt32 for my_value.
                                this.Add(para_def.GetSizeOfType(), Convert.ToUInt32(my_value), endianness);
                            }
                            else if (para_def.GetNameOfType() == "Float32")
                            {
                                // Variable of union.
                                MyUnion union;

                                //VND6KOR: Added the IFormat to treat '.' as '.' instead of ',' in other languages
                                float var = Convert.ToSingle(my_value, System.Globalization.CultureInfo.InvariantCulture);

                                // All the member of union should be initialized.
                                union.byte0 = 0;
                                union.byte1 = 0;
                                union.byte2 = 0;
                                union.byte3 = 0;

                                // Float value updated into union member value of type float.
                                // Data will be stored as little endian as we are working on PC.
                                union.value = var;

                                if (endianness == "BIG")
                                {
                                    // Add each and every byte into list.
                                    this.Add(1, union.byte3, endianness); 
                                    this.Add(1, union.byte2, endianness);
                                    this.Add(1, union.byte1, endianness);
                                    this.Add(1, union.byte0, endianness);
                                }
                                else if (endianness == "LITTLE")
                                {
                                    // Add each and every byte into list.
                                    this.Add(1, union.byte0, endianness); 
                                    this.Add(1, union.byte1, endianness);
                                    this.Add(1, union.byte2, endianness);
                                    this.Add(1, union.byte3, endianness);
                                }
                            }
                            else
                            {
                                // This overload Add function is handling only Types except UInt32 for my_value.
                                this.Add(para_def.GetSizeOfType(), Convert.ToInt32(my_value), endianness);
                            }
                        }

                        // Update address.
                        address += para_def.GetSizeOfType() * Convert.ToInt32(para_def.Number);
                    }
                }
                else
                {
                    // Handle bitfield parameters.
                    int bitfield_base_width = para_def.GetBitfieldWidth();
                    int bitfield_current_width = Convert.ToInt32(para_def.Number);
                    int bitfield_byte_size = para_def.GetSizeOfType();

                    // Start of a new bitfield.
                    if (bitfield_current_count == 0)
                    {
                        // New bitfield.

                        // Check if the current alignment offers enough space for the bitfield - if not align according to the base type.
                        if (8 * (bitfield_byte_size - (address % bitfield_byte_size)) < bitfield_current_width)
                        {
                            int num_alignment_bytes = GetNummberOfPaddingBytes(address, Math.Min(my_alignment, para_def.GetSizeOfType()));

                            // Write padding bytes.
                            this.Add(num_alignment_bytes, 0, endianness);

                            // Update address.
                            address += num_alignment_bytes;
                        }

                        // Update bitfield address information.
                        bitfield_base_address = address - (address % 4);
                        bitfield_base_offset = address % 4;

                        my_nvm_rec_member_list.Add(new cNVMRecordMemberDefinition(para_def.Name, para_def.Type, para_def.Number,
                                                    String.Format("{0}", para_def.GetSizeOfType() * ((8 * address + bitfield_current_count) / bitfield_base_width)),
                                                    para_def.GetBitMaskString((8 * address + bitfield_current_count) % bitfield_base_width)));

                        // Update bitfield data.
                        bitfield_value = Convert.ToInt32(sub_var.ParameterValues[i].Values[0]);
                        bitfield_current_count = bitfield_current_width;
                    }
                    else
                    {
                        // Extend existing bitfield.

                        // Enough space left.
                        if ((8 * (my_alignment - bitfield_base_offset) - bitfield_current_count) < bitfield_current_width)
                        {
                            // Not enough space left.

                            // Flush bitfield.
                            if (bitfield_current_count > 0)
                            {
                                // Write bitfield.
                                this.Add(((bitfield_current_count + 7) / 8), bitfield_value, endianness);

                                // Update address.
                                address += ((bitfield_current_count + 7) / 8);
                            }

                            // Align for basetype.
                            {
                                int num_alignment_bytes = GetNummberOfPaddingBytes(address, Math.Min(my_alignment, para_def.GetSizeOfType()));

                                // Write padding bytes.
                                this.Add(num_alignment_bytes, 0, endianness);

                                // Update address.
                                address += num_alignment_bytes;
                            }

                            // Update bitfield address information.
                            bitfield_base_address = address - (address % 4);
                            bitfield_base_offset = address % 4;

                            my_nvm_rec_member_list.Add(new cNVMRecordMemberDefinition(para_def.Name, para_def.Type, para_def.Number,
                                                        String.Format("{0}", para_def.GetSizeOfType() * ((8 * address + bitfield_current_count) / bitfield_base_width)),
                                                        para_def.GetBitMaskString((8 * address + bitfield_current_count) % bitfield_base_width)));

                            // Update bitfield data.
                            bitfield_value = Convert.ToInt32(sub_var.ParameterValues[i].Values[0]);
                            bitfield_current_count = bitfield_current_width;
                        }
                        else
                        {
                            // Enough space left.

                            // Check whether current bit position aligns with new base type.
                            int start_bit = bitfield_base_offset * 8 + bitfield_current_count;
                            int stop_bit = bitfield_base_offset * 8 + bitfield_current_count + bitfield_current_width;

                            int start_bit_adr_offset = (start_bit == 0) ? 0 : (start_bit - 1) / bitfield_base_width;
                            int stop_bit_adr_offset = (stop_bit == 0) ? 0 : (stop_bit - 1) / bitfield_base_width;

                            // Alignment_possible.
                            if (start_bit_adr_offset == stop_bit_adr_offset)
                            {
                                my_nvm_rec_member_list.Add(new cNVMRecordMemberDefinition(para_def.Name, para_def.Type, para_def.Number,
                                                            String.Format("{0}", para_def.GetSizeOfType() * ((8 * address + bitfield_current_count) / bitfield_base_width)),
                                                            para_def.GetBitMaskString((8 * address + bitfield_current_count) % bitfield_base_width)));

                                // Alignment possible.
                                bitfield_value += Convert.ToInt32(sub_var.ParameterValues[i].Values[0]) << bitfield_current_count;
                                bitfield_current_count += bitfield_current_width;
                            }
                            else
                            {
                                // Alignment impossible.

                                // Move to next possible aligned position.
                                // Bitfield_value = unchanged.
                                bitfield_current_count = (bitfield_base_width * stop_bit_adr_offset) - (8 * bitfield_base_offset);


                                // Enough space left.
                                if ((8 * (my_alignment - bitfield_base_offset) - bitfield_current_count) < bitfield_current_width)
                                {
                                    // Not enough space left.

                                    // Flush bitfield.
                                    if (bitfield_current_count > 0)
                                    {
                                        // Write bitfield.
                                        this.Add(((bitfield_current_count + 7) / 8), bitfield_value, endianness);

                                        // Update address.
                                        address += ((bitfield_current_count + 7) / 8);
                                    }

                                    // Align for basetype.
                                    {
                                        int num_alignment_bytes = GetNummberOfPaddingBytes(address, Math.Min(my_alignment, para_def.GetSizeOfType()));

                                        // Write padding bytes.
                                        this.Add(num_alignment_bytes, 0, endianness);

                                        // Update address.
                                        address += num_alignment_bytes;
                                    }

                                    // Update bitfield address information.
                                    bitfield_base_address = address - (address % 4);
                                    bitfield_base_offset = address % 4;

                                    my_nvm_rec_member_list.Add(new cNVMRecordMemberDefinition(para_def.Name, para_def.Type, para_def.Number,
                                                                String.Format("{0}", para_def.GetSizeOfType() * ((8 * address + bitfield_current_count) / bitfield_base_width)),
                                                                para_def.GetBitMaskString((8 * address + bitfield_current_count) % bitfield_base_width)));

                                    // Update bitfield data.
                                    bitfield_value = Convert.ToInt32(sub_var.ParameterValues[i].Values[0]);
                                    bitfield_current_count = bitfield_current_width;
                                }
                                else
                                {
                                    my_nvm_rec_member_list.Add(new cNVMRecordMemberDefinition(para_def.Name, para_def.Type, para_def.Number,
                                                                String.Format("{0}", para_def.GetSizeOfType() * ((8 * address + bitfield_current_count) / bitfield_base_width)),
                                                                para_def.GetBitMaskString((8 * address + bitfield_current_count) % bitfield_base_width)));

                                    // Enough space left.
                                    bitfield_value += Convert.ToInt32(sub_var.ParameterValues[i].Values[0]) << bitfield_current_count;
                                    bitfield_current_count += bitfield_current_width;
                                }
                            }
                        }
                    }
                }

                // Next element.
                i++;
            }


            // Check if previous parameter was a bitfield and write it into the output stream.
            if (bitfield_current_count > 0)
            {
                // Write bitfield.
                this.Add(((bitfield_current_count + 7) / 8), bitfield_value, endianness);


                // Update address.
                address += ((bitfield_current_count + 7) / 8);

                // Clear bitfield.
                bitfield_value = 0;
                bitfield_current_count = 0;
            }
            
            if (padding_enabled == "DEFAULT")
            {
                // Resetting the alignment.
                my_alignment = 1;

                // This is only for NRCS. This change doesn't cause changes in hex file.
                foreach (cParameterDefinition para_def in parameter_definitions)
                {
                    if ((para_def.Type == "UInt32") || (para_def.Type == "SInt32") || (para_def.Type == "Float32"))
                    {
                        my_alignment = 4;
                        break;
                    }
                    else if ((para_def.Type == "UInt16") || (para_def.Type == "SInt16"))
                    {
                        my_alignment = 2;
                    }
                }
            }

            // Data alignment.
            if ( (padding_enabled == "FULL") || (padding_enabled == "DEFAULT") )
            {
                // Commented data alignement section as we have to give pure data to MCM tool. 
                // MCM tool internally do data alignment             
                int num_alignment_bytes = GetNummberOfPaddingBytes(address, my_alignment);

                // Write padding bytes.
                this.Add(num_alignment_bytes, 0, endianness);

                // Update address.
                address += num_alignment_bytes; 
            }

            if (add_fx3_crc != false)
            {
                // Add CRC.
                this.AddCRC();

                address += 4;
            }

            return address;
        }

        public cNECFx3Fx4_DataFlashHelper()
        {
            this.my_values = new List<int>();
            this.my_alignment = 4;
        }

        public cNECFx3Fx4_DataFlashHelper(List<int> new_values, int new_alignment)
        {
            this.my_values = new_values;
            this.my_alignment = new_alignment;
        }
    }

    class NVM_PAR_Access : HelperFunctions
    {
        // Generate the data flash XML-file for a NEX-Fx3 (gen_par_ST_CHORUS.xml).
        public void PrintGenST_CHORUS_XML(String my_major_var_name,
                                                    ref cParameterSet my_ps,
                                                    ref String my_ps_file_name,
                                                    String my_output_path,
                                                    String my_FileName_Suffix,
                                                    ref DateTime my_dt,
                                                    ref cGeneralConfiguration my_gc,
                                                    ref cHashes my_hashes,
                                                    int time_offset)
        {
            // Size of the NVM block.
            int BlockSize = 0;

            // Number of records (without variants).
            int num_records = 0;

            // Cross check record id.
            int cross_check_id = 0;

            // List to hold the record sizes.
            List<int> record_size_list = new List<int>();

            // Overwrite output path.
            if (my_gc.ST_CHORUS_DataFlash_OutputPath != "")
            {
                my_output_path = my_gc.ST_CHORUS_DataFlash_OutputPath;

                // Determine whether the directory exists.
                Program.DirectoryCreateDirectory(my_output_path);
            }

            // Obtain absolute path of output file.
            var outputPath = Path.Combine(Path.GetFullPath(my_output_path), "gen_par_ST_CHORUS_" + my_major_var_name + my_FileName_Suffix + ".xml");

            // Delete old file automatically if existing.
            try
            {
                Program.FileDelete(outputPath);
            }
            catch
            {
                // Do not care about exceptions.
            }

            // Open output file.
            var writer = Program.CreateStreamWriter(outputPath, false, Encoding.ASCII);
            Console.WriteLine("generating: {0}", outputPath);

            writer.WriteLine("<?xml version=\"1.0\"?>");
            writer.WriteLine("");
            writer.WriteLine("<!-- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx -->");
            writer.WriteLine("<!-- x C O P Y R I G H T                                                           -->");
            writer.WriteLine("<!-- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx -->");
            writer.WriteLine("<!-- x Copyright (c) {0:d4} by Robert Bosch GmbH.               All rights reserved. -->", my_dt.Year);
            writer.WriteLine("<!-- x                                                                             -->");
            writer.WriteLine("<!-- x This file is property of Robert Bosch GmbH. Any unauthorised copy, use or   -->");
            writer.WriteLine("<!-- x distribution is an offensive act against international law and may me       -->");
            writer.WriteLine("<!-- x prosecuted under federal law. Its content is company confidential.          -->");
            writer.WriteLine("<!-- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx -->");
            writer.WriteLine("<!-- x D E S C R I P T I O N                                                       -->");
            writer.WriteLine("<!-- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx -->");
            writer.WriteLine("<!-- x $ProjectName: https://sourcecode01.de.bosch.com/scm/nrcsgen2/par_gen.git $ -->");
            writer.WriteLine("<!-- x      $Source: NVM_PAR_Access.cs $ -->");
            writer.WriteLine("<!-- x    $Revision:  $ -->");
            writer.WriteLine("<!-- x        $Date:  $ -->");
            writer.WriteLine("<!-- x       $State: in_work $ -->");
            writer.WriteLine("<!-- x -->");
            writer.WriteLine("<!-- x      Purpose: generated dataflash container for NEC FX3 in xml format -->");
            writer.WriteLine("<!-- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx -->");
            writer.WriteLine("<!-- x I N F O                                                                     -->");
            writer.WriteLine("<!-- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx -->");
            writer.WriteLine("<!-- x File:                  gen_par_ST_CHORUS_{0}{1}.xml -->", my_major_var_name, my_FileName_Suffix);
            writer.WriteLine("<!-- x Input File:            {0} -->", my_ps_file_name);
            writer.WriteLine("<!-- x Version:               {0} -->", my_ps.ParameterSetInfo.Version);
            writer.WriteLine("<!-- x Date:                  {0:d4}.{1:d2}.{2:d2} - {3:d2}:{4:d2} -->",
                                my_ps.ParameterSetInfo.Year, my_ps.ParameterSetInfo.Month, my_ps.ParameterSetInfo.Day,
                                my_ps.ParameterSetInfo.Hours, my_ps.ParameterSetInfo.Minutes);
            writer.WriteLine("<!-- x -->");
            writer.WriteLine("<!-- x Generation Date (UTC): {0:d4}.{1:d2}.{2:d2} - {3:d2}:{4:d2} -->",
                                my_dt.Year, my_dt.Month, my_dt.Day, my_dt.Hour, my_dt.Minute);
            writer.WriteLine("<!-- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx -->");
            writer.WriteLine("");
            writer.WriteLine("<!-- NVM reference hash -->");
            writer.WriteLine("<!-- {0} -->", my_hashes.NVMHash);
            writer.WriteLine("");

            writer.WriteLine("<DataFlash>");
            writer.WriteLine("  <AdministrativeSection>");
            writer.WriteLine("    <SectionSize> {0} </SectionSize>", my_gc.ST_CHORUS_DataFlash_SectionSize);
            writer.WriteLine("    <Offset> {0} </Offset>", my_gc.ST_CHORUS_DataFlash_Offset);
            writer.WriteLine("  </AdministrativeSection>");

            {
                cNECFx3Fx4_DataFlashHelper my_output_helper = new cNECFx3Fx4_DataFlashHelper(new List<int>(), 4);

                // Emulation win32 _time32() function.
                DateTime UnixEpoch = new DateTime(1970, 1, 1);
                DateTime Today = DateTime.Now;

                TimeSpan timeSpan = Today - UnixEpoch;

                int _time32 = Convert.ToInt32(timeSpan.TotalSeconds);

                // Make timestamp unique by adding an offset.
                _time32 += time_offset;

                char[] nvm_ref_hash = { 'N', 'V', 'M', '-', 'R', 'e', 'f', 'H', 'a', 's', 'h', 'S', 't', 'a', 'r', 't' };
                int l_loop_var = 0;

                if (my_gc.ST_CHORUS_DataFlash_EnableRefHash == "true")
                {
                    // Include the marker.
                    for (l_loop_var = 0; l_loop_var < 16; l_loop_var++)
                    {
                        my_output_helper.Add(1, nvm_ref_hash[l_loop_var], my_gc.ST_CHORUS_Endianness);
                    }

                    // Add the nvm ref hash.
                    for (int i = 0; i < 20; i++)
                    {
                        my_output_helper.Add(1, my_hashes.NVMHashByteArray[i], my_gc.ST_CHORUS_Endianness);
                    }
                }

                my_output_helper.Add(4, _time32, my_gc.ST_CHORUS_Endianness);
                my_output_helper.AddCRC();

                // Print comment.
                {
                    writer.WriteLine("  <!-- DataID - UNIX timestamp -->");
                }

                num_records++;

                // The PID 257 is fixed for the timestamp cluster. MUST NOT BE CHANGED.
                my_output_helper.OutputFx3(ref writer, "257",9999,"NULL",9999, "NULL",my_gc.Product_Line);

                // Log size.
                record_size_list.Add(my_output_helper.GetSize());
            }

            {
                // Add 1 record for the crosscheck data cluster - the cluster will be added at the end of the file.
                // record_index = unchanged/unused;
                num_records++;
                // Backup cross check id.
                cross_check_id = num_records;
                record_size_list.Add(16);

                // Wrong location to initialize.
                int cluster_index= -1;

                foreach (cComponent component in my_ps.Components)
                {
                    foreach (cParameterCluster cluster in component.ParameterClusters)
                    {
                        if (cluster.MemoryArea != "NVM")
                        {
                            // For counting the cluster index in ROM .
                            // Applicable only for ROM, RAM_INIT and NVM_INIT (default ROM).
                            cluster_index++;
                        }
                        if ( ((cluster.MemoryArea == "NVM") || (cluster.MemoryArea == "NVM_INIT")) || ((my_gc.Product_Line == "NRCS") && (cluster.MemoryArea == "RAM_INIT")))
                        {
                            int num_sub_var = 0;
                            int num_min_var = 0;
                            int selected_major_var_index = 0;

                            num_records++;

                            // Look for the matching major variant.
                            {
                                int tmp_index = 0;

                                foreach (cVariantImplementation my_var_imp in cluster.VariantsImlementations)
                                {
                                    // Check whether cluster has the current major variant.
                                    if (my_var_imp.MajorVariants.Contains(my_major_var_name) != false)
                                    {
                                        // Update the current major variant index.
                                        selected_major_var_index = tmp_index;
                                        break;
                                    }

                                    // Check for next major variant.
                                    tmp_index++;
                                }
                            }

                            // Variables to store current sub variant and minor variant 
                            string sub_var_name = "";
                            string min_var_name = "";

                            cVariantImplementation var_imp = cluster.VariantsImlementations[selected_major_var_index];

                            if (my_gc.RawRecordFormat != "single_cluster")
                            {
                                // PMA specific XML will be generated 
                                {
                                    // Initialization to store list of values with Alignment of 4 bytes.
                                    cNECFx3Fx4_DataFlashHelper my_output_helper = new cNECFx3Fx4_DataFlashHelper(new List<int>(), 4);

                                    // To store all min_variant as a string.
                                    string min_vars_string = "";

                                    // To store all sub_variant as a string.
                                    string sub_vars_string = "";
                                    int size_sub_var = 0;

                                    // Array to store each sub variants of the cluster.
                                    string[] min_var_list = new string[var_imp.MinorVariants.Count];

                                    foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                    {
                                        num_sub_var = 0;

                                        if (min_var.Name != "")
                                        {
                                            // For minor variants.
                                            min_var_list[num_min_var++] = min_var.Name;
                                        }
                                        else
                                        {
                                            // No sub_variants/Minor_variants.
                                            num_min_var++;
                                        }

                                        // Array to store each sub variants of the cluster.
                                        string[] sub_var_list = new string[min_var.SubVariants.Count];

                                        foreach (cSubVariant sub_var in min_var.SubVariants)
                                        {
                                            List<cNVMRecordMemberDefinition> nvm_rec_member_list = new List<cNVMRecordMemberDefinition>();

                                            if (sub_var.Name != "")
                                            {
                                                // For sub variants.
                                                sub_var_list[num_sub_var++] = sub_var.Name;
                                            }
                                            else
                                            {
                                                // No Sub_variants/Minor_variants.
                                                num_sub_var++;
                                            }

                                            // Process single cluster.
                                            my_output_helper.ProcessCluster(cluster.ParameterDefinitions, sub_var, true, true, ref nvm_rec_member_list, my_gc.ST_CHORUS_Endianness, my_gc.RawDataStructurePadding);

                                            // Get size of the block.
                                            BlockSize = my_output_helper.GetSize();

                                            // Store minor and sub_variant name.
                                            min_var_name = min_var.Name;
                                            sub_var_name = sub_var.Name;

                                            if ((num_sub_var == 1) && (num_min_var == 1))
                                            {
                                                record_size_list.Add(my_output_helper.GetSize());
                                                size_sub_var = my_output_helper.GetSize(); // Size of cluster 
                                            }
                                        }
                                        // Convert all sub_variants to single string.
                                        sub_vars_string = String.Join("|", sub_var_list);
                                    }

                                    // Convert all minor variants to single string.
                                    min_vars_string = String.Join("|", min_var_list);

                                        // For XML Format.
                                        if ((sub_var_name != "") && (min_var_name != ""))
                                        {
                                            writer.WriteLine("  <!-- {0}_{1}_\"Minor Var ->  {2}\"  \"Sub Variant -> {3}|\" -->", component.Name.ToUpper(), cluster.Name, min_vars_string, sub_vars_string);
                                            writer.WriteLine("  <!-- Length = Cluster size({0}) *number of min_var({1}) *number of sub_var({2})  -->", size_sub_var, num_min_var, num_sub_var);
                                        }
                                        else if (sub_var_name != "")
                                        {
                                            // For sub_variant case.
                                            writer.WriteLine("  <!-- {0}_{1}_{2}_|{3}| -->", component.Name.ToUpper(), cluster.Name, min_var_name, sub_vars_string);
                                            writer.WriteLine("  <!-- Length = Cluster size({0}) * number of sub_var({1})  -->", size_sub_var, num_sub_var);
                                        }
                                        else if (min_var_name != "")
                                        {
                                            // For min_variant case.
                                            writer.WriteLine("  <!-- {0}_{1}_|{2}| -->", component.Name.ToUpper(), cluster.Name, min_vars_string);
                                            writer.WriteLine("  <!-- Length = Cluster size({0}) * number of min_var({1})  -->", size_sub_var, num_min_var);
                                        }
                                        else
                                        {
                                            // No sub_variants/Minor_variants.
                                            writer.WriteLine("  <!-- {0}_{1} -->", component.Name.ToUpper(), cluster.Name);
                                        }

                                    // Print the data into XML file.
                                    if (cluster.MemoryArea == "NVM")
                                    {
                                        // For NVM cluster, cluster index will not be available.
                                        my_output_helper.OutputFx3(ref writer, cluster.PID, 9999, cluster.Name, 9999, "NULL", my_gc.Product_Line);
                                    }
                                    else
                                    {
                                        my_output_helper.OutputFx3(ref writer, cluster.PID, cluster_index, cluster.Name, 9999, "NULL", my_gc.Product_Line);
                                    }
                                }
                            }
                            else
                            {
                                int sub_var_cluster_index = 0;
                                // NRCS specific XML will be generated (i.e. for sub_variant clusters).
                                foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                {
                                    if (var_imp.MinorVariants.Count == 1)
                                    {
                                        sub_var_cluster_index = 0;
                                    }
                                    foreach (cSubVariant sub_var in min_var.SubVariants)
                                    {
                                        List<cNVMRecordMemberDefinition> nvm_rec_member_list = new List<cNVMRecordMemberDefinition>();

                                        num_sub_var++;

                                        cNECFx3Fx4_DataFlashHelper my_output_helper = new cNECFx3Fx4_DataFlashHelper(new List<int>(), 4);

                                        // Process single cluster.
                                        my_output_helper.ProcessCluster(cluster.ParameterDefinitions, sub_var, true, true, ref nvm_rec_member_list, my_gc.ST_CHORUS_Endianness, my_gc.RawDataStructurePadding);

                                        // print comment
                                        // VND6KOR: if a Cluster with subvariants is classified as NVM_INIT
                                        // Generate the cluster names in the NVM XML appending the minor variant name and sub variant name.
                                        // Check if a cluster has subvariants. If a cluster doesn't have subvariants,
                                        // the <SubVariant> >>  <Name></Name> will be empty. This is the condition checked in the loop.
                                        if (sub_var.Name != "")
                                        {
                                            // For sub_variant case.
                                            writer.WriteLine("  <!-- array elemment {4}: {0}_{1}_{2}_{3}-->", component.Name.ToUpper(), cluster.Name, min_var.Name, sub_var.Name, sub_var_cluster_index);
                                                       
                                        }
                                        else
                                        {
                                            // No sub_variants.
                                            writer.WriteLine("  <!-- array elemment {3}: {0}_{1} -->", component.Name.ToUpper(), cluster.Name, cluster_index, sub_var_cluster_index);
                                        }

                                        BlockSize = my_output_helper.GetSize();

                                        if (num_sub_var == 1)
                                        {
                                            record_size_list.Add(my_output_helper.GetSize());
                                        }

                                        // Print the data into XML file.
                                        if (cluster.MemoryArea == "NVM")
                                        {
                                            my_output_helper.OutputFx3(ref writer, cluster.PID, 9999, cluster.Name, sub_var_cluster_index, "NULL", my_gc.Product_Line);
                                        }
                                        else
                                        {
                                            my_output_helper.OutputFx3(ref writer, cluster.PID, cluster_index, cluster.Name, sub_var_cluster_index++, min_var.Name, my_gc.Product_Line);
                                        }
                                        // Log size.
                                    }
                                }
                            }
                        }
                    }
                }

                {
                    cNECFx3Fx4_DataFlashHelper my_output_helper = new cNECFx3Fx4_DataFlashHelper(new List<int>(), 4);

                    List<int> sum_array_index_list = new List<int>();

                    {
                        // Add 1 variant for the DataID record.
                        sum_array_index_list.Add(1);

                        // Add 1 variant for the crosscheck record.
                        sum_array_index_list.Add(1);

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if (((cluster.MemoryArea == "NVM") || (cluster.MemoryArea == "NVM_INIT")) || ((my_gc.Product_Line == "NRCS") && (cluster.MemoryArea == "RAM_INIT")))
                                {
                                    int selected_major_var_index = 0;
                                    int selected_major_var_num_sub_vars = 0;

                                    // Look for the variant implementation with the maximum number of sub variants.
                                    {
                                        int tmp_index = 0;

                                        foreach (cVariantImplementation my_var_imp in cluster.VariantsImlementations)
                                        {
                                            int tmp_num_sub_vars = 0;

                                            foreach (cMinorVariant min_var in my_var_imp.MinorVariants)
                                            {
                                                tmp_num_sub_vars += min_var.SubVariants.Count;
                                            }

                                            if (tmp_num_sub_vars > selected_major_var_num_sub_vars)
                                            {
                                                selected_major_var_num_sub_vars = tmp_num_sub_vars;
                                                selected_major_var_index = tmp_index;
                                            }

                                            tmp_index++;
                                        }
                                    }

                                    cVariantImplementation var_imp = cluster.VariantsImlementations[selected_major_var_index];

                                    {
                                        int num_sub_vars = 0;

                                        foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                        {
                                            num_sub_vars += min_var.SubVariants.Count;
                                        }

                                        sum_array_index_list.Add(num_sub_vars);
                                    }
                                }
                            }
                        }
                    }

                    // Compute CrossCheck_u32.
                    {
                        int cross_check = 0;
                        int index = 0;

                        for (index = 0; index < record_size_list.Count; index++)
                        {
                            cross_check += 3 * (1 + index) * (record_size_list[index] + sum_array_index_list[index]);
                        }

                        my_output_helper.Add(4, cross_check, my_gc.ST_CHORUS_Endianness);
                    }

                    // Compute SumArrayIdx_u16.
                    {
                        int sum_array_index = 0;

                        // Sum up.
                        foreach (int my_size in sum_array_index_list)
                        {
                            sum_array_index += my_size;
                        }

                        my_output_helper.Add(2, sum_array_index, my_gc.ST_CHORUS_Endianness);
                    }

                    // Compute SumLength_u16.
                    {
                        int sum_length = 0;

                        // Sum up.
                        foreach (int my_size in record_size_list)
                        {
                            sum_length += my_size;
                        }

                        my_output_helper.Add(2, sum_length, my_gc.ST_CHORUS_Endianness);
                    }

                    // Compute NumEepIdx_u8.
                    my_output_helper.Add(1, num_records, my_gc.ST_CHORUS_Endianness);

                    // Alignment bytes.
                    my_output_helper.Add(3, 0, my_gc.ST_CHORUS_Endianness);
                    my_output_helper.AddCRC();

                    // Print comment.
                    writer.WriteLine("  <!-- crosscheck data for layout check -->");

                    // Fixed record ID.
                    // The PID 513 is fixed for the layout check cluster. MUST NOT BE CHANGED.
                    my_output_helper.OutputFx3(ref writer, "513", 9999, "NULL", 9999, "NULL", my_gc.Product_Line);
                }
            }
            writer.WriteLine("</DataFlash>");

            // Close output file.
            writer.Close();
        }

        // Generate the file rbp_par_nvm_header_gen.h.
        public Boolean PrintGenNVMHeader(ref cParameterSet my_ps,
                                         ref String my_ps_file_name,
                                         String my_output_path,
                                         String my_FileName_Suffix,
                                         ref DateTime my_dt,
                                         ref cGeneralConfiguration my_gc)
        {
            // Initialize the necessary variables.
            Program my_program = new Program();
            string my_gen_file_name = "rbp_par_nvm_header" + my_FileName_Suffix + "_gen.h";
            string my_source_file_name = "NVM_PAR_Access.cs";

            // Overwrite the output path if already exists.
            my_program.OverwriteOPPath(ref my_gc, ref my_output_path, my_gen_file_name);

            // Generated file header.
            my_program.PrintFileInfo(ref my_ps, ref my_ps_file_name, my_output_path, ref my_dt, my_gen_file_name, my_source_file_name);

            // Obtain absolute path of output file.
            var genFileNamePath = Path.Combine(Path.GetFullPath(my_output_path), my_gen_file_name);

            // Open output file.
            var writer = Program.CreateStreamWriter(genFileNamePath, true, Encoding.ASCII);

            writer.WriteLine("/*-----------------------------------------------------------------------------*/");
            writer.WriteLine("//N O T E S");
            writer.WriteLine("//\\brief  NVM Handling module of component PAR                            ");
            writer.WriteLine("//\\details  This module will handle NVM Write and NVM Read requests        ");
            writer.WriteLine("//Target system: ---                                          ");
            writer.WriteLine("//Compiler: --");
            writer.WriteLine("");
            writer.WriteLine("");
            writer.WriteLine("#ifndef RBP_PAR_NVM_HEADER{0}_GEN_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("#define RBP_PAR_NVM_HEADER{0}_GEN_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("");

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("extern \"C\"");
            writer.WriteLine("{");
            writer.WriteLine("#endif // __cplusplus");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- magic number                                                           -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#define RBP_PAR_NVM_HEADER_MAGIC_NUMBER_GEN  0x{0:d2}{1:d2}{2:d2}{3:d2}",
                                my_dt.Month, my_dt.Day, my_dt.Hour, my_dt.Minute);
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- component switches                                                     -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- include files                                                          -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*!\\addtogroup RBP_PAR_M01 - exported symbolic constants                                            -*/");
            writer.WriteLine("/* \\ingroup RBP_COMPONENT_PAR");
            writer.WriteLine("@{ *//*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            Boolean RamCopyneeded = false;

            {
                int l_loop_var = 0;
                foreach (cComponent component in my_ps.Components)
                {
                    foreach (cParameterCluster cluster in component.ParameterClusters)
                    {
                        if (cluster.MemoryArea == "NVM_INIT")
                        {
                            // Indicates number of NVM_INIT Blocks available.
                            l_loop_var++;
                            RamCopyneeded = true;
                        }
                    }
                }
                if (RamCopyneeded == true)
                {
                    // If number of NVM clusters is >255, PAR component will not work properly. Delete the generated files.
                    if (l_loop_var > 255)
                    {
                        writer.Close();
                        return true;
                    }
                    else
                    {
                        writer.WriteLine("// Number of NVM_INIT Blocks");
                        writer.WriteLine("#define rbp_par_Num_NVM_Blocks_du8 {0}((UInt8)({1}))", new string(' ', 30), l_loop_var);
                        writer.WriteLine("");
                        writer.WriteLine("// Number of Group of NVM Blocks");
                        writer.WriteLine("#define rbp_par_Num_Group_NVM_Blocks_du8 {0} ((UInt8)({1})) ",new string(' ', 25),(Convert.ToBoolean(l_loop_var % 8) ? ((l_loop_var / 8) + 1) : (l_loop_var / 8)));
                        //writer.WriteLine("#define rbp_Num_Group_NVM_Blocks_u8  {0}(rbp_Num_NVM_Blocks_u8 / 8) ", new string(' ', 25));
                        // writer.WriteLine("#define rbp_Num_Group_NVM_Blocks_u8  {0}((rbp_Num_NVM_Blocks_u8 % 8) ? ((rbp_Num_NVM_Blocks_u8/8) + 1) :  (rbp_Num_NVM_Blocks_u8/8)) ", new string(' ', 25));
                    }
                }
            }

            if (RamCopyneeded == true)
            {
                // NVM Init Blocks are available
                writer.WriteLine("");
                writer.WriteLine("");
                writer.WriteLine("// NVM_INIT write access cluster index , Redefined for easy understanding to the user");

                int Block_idx = 0;
                int cluster_max_size = 0;
                string nvm_cluster_name = "";

                foreach (cComponent component in my_ps.Components)
                {
                    foreach (cParameterCluster cluster in component.ParameterClusters)
                    {
                        if ((cluster.MemoryArea == "NVM_INIT"))
                        {
                            // E.g.: cluster name - nvmVEHICLE_VARIANT
                            //       rbp_Idx_Write_nvmVEHICLE_VARIANT_du16
                            string my_string = String.Format("rbp_Idx_Write_{0}_du16", cluster.Name);

                            // E.g.: cluster name - nvmVEHICLE_VARIANT; my_string - rbp_Idx_Write_nvmVEHICLE_VARIANT_du16
                            //       #define rbp_par_nvmVEHICLE_VARIANT_Block_du16          rbp_Idx_Write_nvmVEHICLE_VARIANT_du16  
                            writer.WriteLine("#define rbp_par_{0}_Block_du16 {1}{2}", cluster.Name, new string(' ', 100 - my_string.Length), my_string);
                        }
                    }
                }

                writer.WriteLine("");
                writer.WriteLine("//Size of each configured NVM CLusters");

                foreach (cComponent component in my_ps.Components)
                {
                    foreach (cParameterCluster cluster in component.ParameterClusters)
                    {
                        int cluster_size = 0;
                        int cluster_count_sub_var = 0;
                        if ((cluster.MemoryArea == "NVM_INIT"))
                        {
                            foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                            {
                                int count_sub_var = 0;

                                foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                {
                                    // Number of Minor/Sub-Variants in available cluster.
                                    count_sub_var += min_var.SubVariants.Count;
                                }
                                cluster_count_sub_var = count_sub_var;
                            }

                            foreach (cParameterDefinition para_def in cluster.ParameterDefinitions)
                            {
                                // E.g.: If a cluster has only one parameter of type UInt16 and is an array of 10 elements.
                                //       Then cluster size will be 2*10 = 20bytes.
                                cluster_size += para_def.GetSizeOfType() * Convert.ToInt32(para_def.Number); 
                            }

                            // Cluster size = size of cluster * No of minor/sub variants.
                            cluster_size = cluster_size * cluster_count_sub_var; 

                            string my_string = String.Format("#define rbp_par_{0}_size_du16", cluster.Name);

                            writer.WriteLine("{0}{1} ((UInt16)({2}))", my_string, new string(' ', 100 - my_string.Length), cluster_size);
                            // writer.WriteLine("{0}{1} sizeof(rbp_par_NVM_MirrorData_st.ParameterMemoryRAM_st.{2}_pst) // Size : {3}", my_string, new string(' ', 60 - my_string.Length), cluster.Name, cluster_size);

                            if (cluster_max_size < cluster_size)
                            {
                                cluster_max_size = cluster_size;
                                nvm_cluster_name = cluster.Name;
                            }
                        }
                    }
                }

                writer.WriteLine("");
                writer.WriteLine("// MAX Size of the configured NVM Block");
                   writer.WriteLine("#define rbp_par_max_nvm_block_size_du16 {1} ((UInt16)({2})) // Max cluster Size :{0}", nvm_cluster_name, new string(' ', 30), cluster_max_size);

                writer.WriteLine("");
                writer.WriteLine("/*");

                writer.WriteLine("NVM BLocks Id (i.e. Not same as Configured in the NVM arxml) ");
                foreach (cComponent component in my_ps.Components)
                {
                    foreach (cParameterCluster cluster in component.ParameterClusters)
                    {
                        if ((cluster.MemoryArea == "NVM_INIT"))
                        {
                            if (Block_idx % 8 == 0)
                            {
                                writer.WriteLine("");
                                writer.WriteLine("----------------------------------------------");
                                writer.WriteLine(" Group Id {0}", (Block_idx / 8));
                                writer.WriteLine("----------------------------------------------");
                            }
                            writer.WriteLine("Bit {0} : Cluster name : {1}", (Block_idx % 8), cluster.Name);
                            Block_idx++;
                        }
                    }
                }
                if (Block_idx % 8 < 7)
                {
                    if (Block_idx % 8 == 0)
                    {
                        writer.WriteLine("");
                    }
                    else
                    {
                        writer.WriteLine("Bit {0} .. 7 : Cluster name : Unreserved", (Block_idx % 8));
                    }
                }

                writer.WriteLine("----------------------------------------------*/");

                writer.WriteLine("");

                writer.WriteLine("/*!@} *//*------------------------------------------------------------------*/");
                writer.WriteLine("/*!\\addtogroup RBP_PAR_M02           exported macros");
                writer.WriteLine("* \\ingroup RBP_COMPONENT_PAR");
                writer.WriteLine("@{ *//*--------------------------------------------------------------------*/");
                writer.WriteLine("");

                writer.WriteLine("/*!@} *//*------------------------------------------------------------------*/");
                writer.WriteLine("/*!\\addtogroup RBP_PAR_M03           exported data types");
                writer.WriteLine("* \\ingroup RBP_COMPONENT_PAR");
                writer.WriteLine("@{ *//*--------------------------------------------------------------------*/");
                writer.WriteLine("");

                writer.WriteLine("/*!@}*//*-------------------------------------------------------------------*/");
                writer.WriteLine("/*-                           external object declarations                 -*/");
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
            }    
            else
            {
                writer.WriteLine("// No NVM_INIT Clusters are available");
                writer.WriteLine("");
            }

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("}");
            writer.WriteLine("#endif // __cplusplus");
            writer.WriteLine("#endif /* RBP_PAR_NVM_HEADER{0}_GEN_H */", my_FileName_Suffix.ToUpper());

            // Close output file.
            writer.Close();
            return false;
        }
        
        // Generate the file rbp_par_nvm_gen.c.
        public void PrintGenNVMC(ref cParameterSet my_ps,
                                         ref cSegmentDefinition my_sd,
                                         ref String my_ps_file_name,
                                         String my_output_path,
                                         String my_FileName_Suffix,
                                         ref DateTime my_dt,
                                         ref cGeneralConfiguration my_gc)
        {
            // Initialize the necessary variables.
            Program my_program = new Program();
            string my_gen_file_name = "rbp_par_nvm" + my_FileName_Suffix + "_gen.c";
            string my_source_file_name = "NVM_PAR_Access.cs";

            // Overwrite the output path if already exists.
            my_program.OverwriteOPPath(ref my_gc, ref my_output_path, my_gen_file_name);

            // Generated file header.
            my_program.PrintFileInfo(ref my_ps, ref my_ps_file_name, my_output_path, ref my_dt, my_gen_file_name, my_source_file_name);

            // Obtain absolute path of output file.
            var genFileNamePath = Path.Combine(Path.GetFullPath(my_output_path), my_gen_file_name);

            // Open output file.
            var writer = Program.CreateStreamWriter(genFileNamePath, true, Encoding.ASCII);

            writer.WriteLine("/*! make component private variables and functions visible */");
            writer.WriteLine("#define RBP_COMPONENT_PAR");
            writer.WriteLine("");

            writer.WriteLine("/*!\\addtogroup RBP_COMPONENT_PAR documentation */");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- magic number                                                           -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#define RBP_PAR_NVM_MAGIC_NUMBER_GEN  0x{0:d2}{1:d2}{2:d2}{3:d2}",
                              my_dt.Month, my_dt.Day, my_dt.Hour, my_dt.Minute);
            writer.WriteLine("");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- include files-*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");

            Boolean RAMCopyNeeded = false;

            // Check if NVM_INIT clusters are available.
            foreach (cComponent component in my_ps.Components)
            {
                foreach (cParameterCluster cluster in component.ParameterClusters)
                {
                    if (cluster.MemoryArea == "NVM_INIT")
                    {
                        // NVM_INIT clusters are available, hence RAM Copy is needed. 
                        RAMCopyNeeded = true;
                    }
                }
            }

            if (RAMCopyNeeded == true)
            {
                // NVM_INIT clusters are available.

                // Include header files.
                writer.WriteLine("#include <rbp_global_include_api.h>");
                writer.WriteLine("#include <rbp_par_api.h>");
                writer.WriteLine("#include <rbp_par_nvm_header" + my_FileName_Suffix + "_gen.h>");
                writer.WriteLine("#include <rbp_par_nvm_access.h>");
                writer.WriteLine("#include <rbp_par_swcpma_api.h>");
                writer.WriteLine("#include <rbp_math_fix_lib.h>");
                writer.WriteLine("#include \"string.h\"");
                writer.WriteLine("");


                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("/*- check if compiler switches (utilised in this component) are defined    -*/");
                writer.WriteLine("/*--------------------------------------------------------------------------*/");

                // Magic number check.
                writer.WriteLine("#if (RBP_PAR_NVM_MAGIC_NUMBER_GEN != RBP_PAR_NVM_HEADER_MAGIC_NUMBER_GEN)");
                writer.WriteLine(" #error (\"Wrong version of 'rbp_par_nvm_header" + my_FileName_Suffix + "_gen.h' - check whether the generated files match!\")");
                writer.WriteLine("#endif");
            }
            else
            {
                // NVM_INIT clusters are not available.
            }
            
            writer.WriteLine("//!\\cond INTERNAL");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*!\\addtogroup RBP_PAR_L01            local symbolic constants");
            writer.WriteLine("*\\ingroup RBP_COMPONENT_PAR");
            writer.WriteLine("@{ *//*---------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/*!@} *//*------------------------------------------------------------------*/");
            writer.WriteLine("/*!\\addtogroup RBP_PAR_L02           local macros");
            writer.WriteLine("*\\ ingroup RBP_COMPONENT_PAR");
            writer.WriteLine("@{*//*----------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/*!@}*//*-------------------------------------------------------------------*/");
            writer.WriteLine("/*!\\addtogroup RBP_PAR_L03           prototypes of local functions          ");
            writer.WriteLine("*\\ ingroup RBP_COMPONENT_PAR");
            writer.WriteLine("@{*//*----------------------------------------------------------------------*/");
            writer.WriteLine("");

            if (RAMCopyNeeded == true)
            {
                // NVM_INIT clusters available.

                writer.WriteLine("/* PRQA S 2217 RBP_RULE_DEV_rbp_par_nvm_gen_c_1 */ /*(details: see end of file)*/");

                int l_no_of_NVM_blocks = 0;

                writer.WriteLine("// Function Declarations for NVM Write Request and Error Status  ");
                foreach (cComponent component in my_ps.Components)
                {
                    foreach (cParameterCluster cluster in component.ParameterClusters)
                    {
                        if (cluster.MemoryArea == "NVM_INIT")
                        {
                            writer.WriteLine("static rbp_Std_ReturnType_u8 rbp_par_{0}_Write_u8(const void *f_src_pvd);", cluster.Name);
                            writer.WriteLine("static void rbp_par_{0}_ErrorStatus_vd(void);", cluster.Name);
                            l_no_of_NVM_blocks++;
                        }
                    }
                }

                int Num_of_Blocks = 0;

                writer.WriteLine("");

                writer.WriteLine("/*!@}*//*------------------------------------------------------------------*/");
                writer.WriteLine("/*!\\addtogroup RBP_PAR_G01            Global data Objects                           ");
                writer.WriteLine("*\\ ingroup RBP_COMPONENT_PAR ");
                writer.WriteLine("@{*//*------------------------------------------------------------------*/");
                writer.WriteLine("");

                writer.WriteLine("// NVM Blocks Constant Table (Format : Write Request Function, Error status Function, RAM Structure, Cluster Number, Size of the NVM block )");
                writer.WriteLine("// Order of the blocks should be same as NVM content in rbp_par_main" + my_FileName_Suffix + "_gen.c. VERY IMPORTANT : \"DO NOT INTERCHANGE THE ORDER BY ANY CHANCE !!\"");
                writer.WriteLine("");
                writer.WriteLine("const rbp_Type_par_const_NVM_Table_st rbp_par_const_NVM_Table_st[rbp_par_Num_NVM_Blocks_du8] = {");
                {
                    string[] my_NVM_Blocks = new String[l_no_of_NVM_blocks];
                    foreach (cComponent component in my_ps.Components)
                    {
                        foreach (cParameterCluster cluster in component.ParameterClusters)
                        {
                            if ((cluster.MemoryArea == "NVM_INIT"))
                            {
                                writer.WriteLine("    {{&rbp_par_{0}_Write_u8,&rbp_par_{0}_ErrorStatus_vd,&rbp_par_NVM_MirrorData_st.ParameterMemoryNVM_RAM_Mirror_st.{0}_pst,rbp_par_{0}_Block_du16,rbp_par_{0}_size_du16}},", cluster.Name);
                            }
                        }
                    }
                }

                writer.WriteLine("};");
                writer.WriteLine("");

                writer.WriteLine("/*!\\endcond !@}*//*-------------------------------------------------------------------*/");
                writer.WriteLine("/*!\\addtogroup RBP_PAR_G02               public functions");
                writer.WriteLine("*\\ingroup RBP_COMPONENT_PAR");
                writer.WriteLine("@{*//*----------------------------------------------------------------------------------*/");

                writer.WriteLine("");
                writer.WriteLine("");
                writer.WriteLine("/* PRQA S 3673  RBP_RULE_DEV_rbp_par_nvm_gen_c_2 */ /* (details: see end of file) */");
                writer.WriteLine("/* PRQA S 1496  RBP_RULE_DEV_rbp_par_nvm_gen_c_3 */ /* (details: see end of file) */");
                writer.WriteLine("");

                //! Interfaces provided by PAR.
                {
                    writer.WriteLine("/*********************************************************************");
                    writer.WriteLine("* Interface:");
                    writer.WriteLine("* Read_[cluster_name]_RamBlockFromNvM()");
                    writer.WriteLine("*");
                    writer.WriteLine("* Description: ");
                    writer.WriteLine("*  Read functions to copy data from NVM Mirror to PAR RAM Structure ");
                    writer.WriteLine("*  Called during NVM ReadAll (Before Software Init)");
                    writer.WriteLine("*  These functions are interface function into Autosar. Hence naming");
                    writer.WriteLine("*  convention is according to Autosar.");
                    writer.WriteLine("*");
                    writer.WriteLine("* Parameters:");
                    writer.WriteLine("*  SrcPtr :PAR RAM structures address");
                    writer.WriteLine("*");
                    writer.WriteLine("* Return Value:");
                    writer.WriteLine("*  Std_ReturnType :RTE_E_OK -> Success");
                    writer.WriteLine("*********************************************************************/");

                    foreach (cComponent component in my_ps.Components)
                    {
                        foreach (cParameterCluster cluster in component.ParameterClusters)
                        {
                            if ((cluster.MemoryArea == "NVM_INIT"))
                            {
                                writer.WriteLine("Std_ReturnType Read_{0}_RamBlockFromNvM(NvM_Rb_VoidPtr SrcPtr)", cluster.Name);
                                writer.WriteLine("{");
                                writer.WriteLine("{0}(void) memcpy(&rbp_par_NVM_MirrorData_st.ParameterMemoryNVM_RAM_Mirror_st.{1}_pst,", new string(' ', 2), cluster.Name);
                                writer.WriteLine("         SrcPtr, (UInt32)sizeof(rbp_par_NVM_MirrorData_st.ParameterMemoryNVM_RAM_Mirror_st.{0}_pst));", cluster.Name);
                                writer.WriteLine("");
                                writer.WriteLine("  return RTE_E_OK;");
                                writer.WriteLine("}");
                                writer.WriteLine("");
                            }
                        }
                    }

                    writer.WriteLine("");
                    writer.WriteLine("/*********************************************************************");
                    writer.WriteLine("* Interface:");
                    writer.WriteLine("* Write_[cluster_name]_RamBlockToNvM()");
                    writer.WriteLine("*");
                    writer.WriteLine("* Description: ");
                    writer.WriteLine("*  Write functions to copy data from PAR RAM Structures to NVM Mirror ");
                    writer.WriteLine("*  Called during NVM WriteAll (During System Shutdown phase)");
                    writer.WriteLine("*  These functions are interface function into Autosar. Hence naming");
                    writer.WriteLine("*  convention is according to Autosar.");
                    writer.WriteLine("*");
                    writer.WriteLine("* Parameters:");
                    writer.WriteLine("*  DstPtr :PAR RAM structures address");
                    writer.WriteLine("*");
                    writer.WriteLine("* Return Value:");
                    writer.WriteLine("*  Std_ReturnType : RTE_E_OK -> Success");
                    writer.WriteLine("*********************************************************************/");

                    foreach (cComponent component in my_ps.Components)
                    {
                        foreach (cParameterCluster cluster in component.ParameterClusters)
                        {
                            if ((cluster.MemoryArea == "NVM_INIT"))
                            {
                                writer.WriteLine("Std_ReturnType Write_{0}_RamBlockToNvM(NvM_Rb_VoidPtr DstPtr)", cluster.Name);
                                writer.WriteLine("{");
                                writer.WriteLine("{0}(void) memcpy(DstPtr, &rbp_par_NVM_MirrorData_st.ParameterMemoryNVM_RAM_Mirror_st.{1}_pst,", new string(' ', 2), cluster.Name);
                                writer.WriteLine("         (UInt32)sizeof(rbp_par_NVM_MirrorData_st.ParameterMemoryNVM_RAM_Mirror_st.{0}_pst));", cluster.Name);
                                writer.WriteLine("");
                                writer.WriteLine("  return RTE_E_OK;");
                                writer.WriteLine("}");
                                writer.WriteLine("");
                            }
                        }
                    }

                    writer.WriteLine("");
                    writer.WriteLine("/*********************************************************************");
                    writer.WriteLine("* Interface:");
                    writer.WriteLine("* rbp_par_[cluster_name]_Write_u8(const void *f_src_pvd)");
                    writer.WriteLine("*");
                    writer.WriteLine("* Description: ");
                    writer.WriteLine("*  Called by PAR Component during Write request to NVM ");
                    writer.WriteLine("*");
                    writer.WriteLine("* Parameters:");
                    writer.WriteLine("*  const *f_NVMBuffer_pvd : local RAM Buffer address");
                    writer.WriteLine("*");
                    writer.WriteLine("* Return Value:");
                    writer.WriteLine("*  rbp_Std_ReturnType_u8");
                    writer.WriteLine("*********************************************************************/");

                    {
                        int block_id = 0;
                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if (cluster.MemoryArea == "NVM_INIT")
                                {
                                    writer.WriteLine("static rbp_Std_ReturnType_u8 rbp_par_{0}_Write_u8(const void *f_src_pvd)", cluster.Name);
                                    writer.WriteLine("{");
                                    writer.WriteLine("  rbp_Std_ReturnType_u8 l_return_type_u8 = rbp_RTE_E_OK_du8 ;");
                                    writer.WriteLine("  if (rbp_RTE_E_OK_du8 == Rte_Call_{0}_WriteBlock(f_src_pvd))", cluster.Name);
                                    writer.WriteLine("  {");
                                    writer.WriteLine("{0} // Write request is successfull ", new string(' ', 3));
                                    writer.WriteLine("{0} rbp_mtl_SetBit_u8_mac(rbp_par_NVM_Status_st.NVM_Comp_Write_Req_Placed_st.Data_u8[{1}],(UInt8){2});", new string(' ', 3), (block_id / 8), (block_id % 8));
                                    writer.WriteLine("{0} l_return_type_u8 = rbp_RTE_E_OK_du8;", new string(' ', 3));
                                    writer.WriteLine("  }");
                                    writer.WriteLine("  else");
                                    writer.WriteLine("  {");
                                    writer.WriteLine("{0} // Write request was not successfull ", new string(' ', 3));
                                    writer.WriteLine("{0} rbp_mtl_SetBit_u8_mac(rbp_par_NVM_Status_st.NVM_Block_Write_Failed_st.Data_u8[{1}],(UInt8){2}); ", new string(' ', 3), (block_id / 8), (block_id % 8));
                                    writer.WriteLine("{0} // Clear the request as Write request is failed", new string(' ', 3));
                                    writer.WriteLine("{0} rbp_mtl_ClrBit_u8_mac(rbp_par_NVM_Status_st.NVM_Comp_Write_Req_st.Data_u8[{1}], (UInt8){2});", new string(' ', 3), (block_id / 8), (block_id % 8));
                                    writer.WriteLine("{0} l_return_type_u8 = rbp_RTE_E_INVALID_du8;", new string(' ', 3));
                                    writer.WriteLine("  }");
                                    writer.WriteLine("  return l_return_type_u8;");
                                    writer.WriteLine("}");
                                    writer.WriteLine("");

                                    // Next NVM_INIT block.
                                    block_id++;
                                }
                            }
                        }

                        block_id = 0;
                        writer.WriteLine("/*********************************************************************");
                        writer.WriteLine("* Interface:");
                        writer.WriteLine("* rbp_par_[cluster_name]_ErrorStatus_vd ()");
                        writer.WriteLine("*");
                        writer.WriteLine("* Description: ");
                        writer.WriteLine("*  To get the Status of Write request for each Configured NVM Block ");
                        writer.WriteLine("*");
                        writer.WriteLine("* Parameters:");
                        writer.WriteLine("*  none");
                        writer.WriteLine("*");
                        writer.WriteLine("* Return Value:");
                        writer.WriteLine("*  void");
                        writer.WriteLine("*********************************************************************/");
                        writer.WriteLine("");

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if (cluster.MemoryArea == "NVM_INIT")
                                {
                                    writer.WriteLine("static void rbp_par_{0}_ErrorStatus_vd(void)", cluster.Name);
                                    writer.WriteLine("{");
                                    writer.WriteLine("  rbp_NvM_RequestResultType_u8 l_NVM_status_u8 = 0;");
                                    writer.WriteLine("  (void)Rte_Call_{0}_GetErrorStatus(&l_NVM_status_u8); // Get the status of NVM Block;", cluster.Name);
                                    writer.WriteLine("  rbp_par_NVM_State_Check_vd(l_NVM_status_u8,((UInt8){0}));", block_id);
                                    writer.WriteLine("}");
                                    writer.WriteLine("");

                                    // Next NVM_INIT block.
                                    block_id++;

                                    Num_of_Blocks = block_id;
                                }
                            }
                        }
                    }
                } //! @end: Interfaces provided by PAR.

                //! A2L Variables generation.
                {
                    writer.WriteLine("/*--------------------------------------------------------------------------*/");
                    writer.WriteLine("/*- Application memory parameter access for Vector A2L-Creator             -*/");
                    writer.WriteLine("/*--------------------------------------------------------------------------*/");

                    List<KeyValuePair<string, string>> my_list = new List<KeyValuePair<string, string>>()
                                                        {
                                                         new KeyValuePair<string, string>("rbp_par_NVM_Status_st.NVM_Comp_Write_Req_st", " COMP_NVM_Write_Request"), 
                                                         new KeyValuePair<string, string>("rbp_par_NVM_Status_st.NVM_Comp_Write_Req_Placed_st", "Write_Request_Placed"), 
                                                         new KeyValuePair<string, string>("rbp_par_NVM_Status_st.NVM_Comp_Write_Finished_st", "NVM_Write_Finished"), 
                                                         new KeyValuePair<string, string>("rbp_par_NVM_Status_st.NVM_Block_Write_InProgress_st", "NVM_Write_InProgress"),
                                                         new KeyValuePair<string, string>("rbp_par_NVM_Status_st.NVM_Block_Write_Failed_st", "NVM_Write_Failed"),
                                                         new KeyValuePair<string, string>("rbp_par_NVM_Block_ReadAll_Finsihed_st", "NVM_ReadAll_Status"),
                                                        };

                    string[] cluster_name = new string[Num_of_Blocks];
                    int k = 0;
                    foreach (cComponent component in my_ps.Components)
                    {
                        foreach (cParameterCluster cluster in component.ParameterClusters)
                        {
                            if (cluster.MemoryArea == "NVM_INIT")
                            {
                                cluster_name[k] = cluster.Name;
                                k++;
                            }
                        }
                    }

                    foreach (KeyValuePair<string, string> my_pair in my_list)
                    {
                        int j = 0;
                        for (int i = 0; i < (Convert.ToBoolean(Num_of_Blocks % 8) ? ((Num_of_Blocks / 8) + 1) : (Num_of_Blocks / 8)); i++)
                        {
                            writer.WriteLine("/*");
                            writer.WriteLine("@@ SYMBOL = {0}.Data_u8._{1}_", my_pair.Key, i);

                            if (my_pair.Key != "rbp_par_NVM_Status_st.NVM_Comp_Write_Req_st")
                            {
                                writer.WriteLine("@@ A2L_TYPE = MEASURE {0}_{1}", my_pair.Value, i);
                            }
                            else
                            {
                                writer.WriteLine("@@ A2L_TYPE = PARAMETER {0}_{1}", my_pair.Value, i);
                            }
                            writer.WriteLine("@@ DATA_TYPE = UBYTE [0 ... 255]");
                            writer.WriteLine("@@ ALIAS = {0}.Data_u8._{1}_", my_pair.Key, i);
                            writer.WriteLine("@@ GROUP = RBP_SRV_PAR | RBP_SRV_PAR_NVM_PARAMETER ");
                            string my_string = "";
                            string my_string_1 = "";

                            for (; j < k; )
                            {
                                my_string = " Bit " + j % 8 + ":" + "\'" + cluster_name[j] + "\'";
                                my_string_1 = my_string_1 + my_string;
                                if ((j % 8 == 7) || (j == k))
                                {
                                    j++;
                                    break;
                                }
                                else
                                {
                                    j++;
                                }
                            }
                            writer.WriteLine("@@ DESCRIPTION = \"{0}\"", my_string_1);
                            writer.WriteLine("@@ END");
                            writer.WriteLine("*/");
                            writer.WriteLine("");
                        }
                    }


                    writer.WriteLine("/*****************END OF A2L VARIABLES*********************/");
                    writer.WriteLine("");
                } //! @end: A2L Variables generation.

                //! QAC Warnings.
                {
                    writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_nvm_gen_c_1 */ /* (details: see end of file) */");
                    writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_nvm_gen_c_2 */ /* (details: see end of file) */");
                    writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_nvm_gen_c_3 */ /* (details: see end of file) */");

                    writer.WriteLine("/*****************************************************************************/");
                    writer.WriteLine("/* START OF EXPLANATION FOR RBP_RULE_DEVIATIONS: */");
                    writer.WriteLine("/*===============================*/");
                    writer.WriteLine("/* RBP_RULE_DEV_rbp_par_nvm_gen_c_1 */");
                    writer.WriteLine("/* Deviation to GPG rule number: 2217*/");
                    writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
                    writer.WriteLine("   Comments exceeds more than 130 characters.*/");
                    writer.WriteLine("/* Demonstration how safety and quality is still assured:");
                    writer.WriteLine("   Since it is comments not gonna effect safety. */");
                    writer.WriteLine("");
                    writer.WriteLine("/* RBP_RULE_DEV_rbp_par_nvm_gen_c_2 */");
                    writer.WriteLine("/* Deviation to GPG rule number: 8.13 */");
                    writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
                    writer.WriteLine("   RTE Generated declarations, so function parameter cannot be changed to const void*.");
                    writer.WriteLine("   Declaration is generated from RTE, so parameter is typdef with different name.*/");
                    writer.WriteLine("/* Demonstration how safety and quality is still assured :");
                    writer.WriteLine("   Safety is assured by not dereferencing the pointer.*/");
                    writer.WriteLine("");
                    writer.WriteLine("/* RBP_RULE_DEV_rbp_par_nvm_gen_c_3 */");
                    writer.WriteLine("/* Deviation to GPG rule number: 1496 */");
                    writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
                    writer.WriteLine("   RTE Generated declarations, so function parameter cannot be changed to const void*.*/");
                    writer.WriteLine("/* Demonstration how safety and quality is still assured :");
                    writer.WriteLine("   Safety is assured by not dereferencing the pointer.*/");
                    writer.WriteLine("/* END OF EXPLANATION FOR RBP_RULE DEVIATIONS */");
                    writer.WriteLine("/*****************************************************************************/");
                } //! @end: QAC Warnings.
            }
            else
            {
                // No NVM_INIT clusters available.
                writer.WriteLine("/*!@}*//*------------------------------------------------------------------*/");
                writer.WriteLine("");
                writer.WriteLine("// No NVM_Init Clusters available");
                writer.WriteLine("");

            }
            writer.WriteLine("/*!@}*//*================== EoF (rbp_par_nvm" + my_FileName_Suffix + "_gen.c) ===========*/");

            // Close output file.
            writer.Close();
        }
    }
}
