using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Globalization;


namespace parsrv
{
    /// <summary>
    /// The ParaServer class generates the SRV_PAR C code (rbp_par_main_gen.c) and A2L comments.
    /// </summary>
    class ParaServer : HelperFunctions
    {
        // Generate the file rbp_par_main_gen.c.
        public void PrintGenMain(ref cParameterSet my_ps,
                                         ref cSegmentDefinition my_sd,
                                         ref String my_ps_file_name,
                                         String my_output_path,
                                         String my_FileName_Suffix,
                                         ref DateTime my_dt,
                                         ref cGeneralConfiguration my_gc,
                                         ref cGMConfiguration my_gmc,
                                         ref cFlashTestSection my_flash_test_section,
                                         bool IsAccessdef_unique,
                                         string my_Selected_Dataset,
                                         string my_DatasetName)
        {
            // Initialize the necessary variables.
            Program my_program = new Program();
            Secure_Flash Security = new Secure_Flash(my_gc);
            cWrapper_XML_2_x wrapper_2_x = new cWrapper_XML_2_x();
            string my_gen_file_name = "rbp_par_main" + my_FileName_Suffix + "_gen.c";
            string my_source_file_name = "ParaServer.cs";
            Boolean my_variant_overflow_b = false;

            // Overwrite the output path if already exists.
            my_program.OverwriteOPPath(ref my_gc, ref my_output_path, my_gen_file_name);

            // Generated file header.
            my_program.PrintFileInfo(ref my_ps, ref my_ps_file_name, my_output_path, ref my_dt, my_gen_file_name, my_source_file_name);

            // Obtain absolute path of output file.
            var genFileNamePath = Path.Combine(Path.GetFullPath(my_output_path), my_gen_file_name);

            // Open output file.
            var writer = Program.CreateStreamWriter(genFileNamePath, true, Encoding.ASCII);

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- magic number                                                           -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#define RBP_PAR_MAIN_MAGIC_NUMBER_GEN  0x{0:d2}{1:d2}{2:d2}{3:d2}", my_dt.Month, my_dt.Day, my_dt.Hour, my_dt.Minute);
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- component definition                                                   -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#define RBP_COMPONENT_PAR");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- include files                                                          -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#include <rbp_global_include_api.h>");
            //writer.WriteLine("#ifndef RBP_SWCPMA_H");
            //writer.WriteLine("  #include <rbp_swcpma.h>");
            //writer.WriteLine("#endif");
            //writer.WriteLine("#include <rbp_par_switches_gen.h>");
            //writer.WriteLine("#include <rbp_par_header_gen.h>");
            //writer.WriteLine("#include <rbp_par_api.h>");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- check if compiler switches (utilised in this component) are defined    -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#if ( RBP_PAR_MAIN_MAGIC_NUMBER_GEN != RBP_PAR_SWITCHES_GEN_MAGIC_NUMBER )");
            writer.WriteLine("  #error (\"Wrong version of 'rbp_par_switches" + my_FileName_Suffix + "_gen.h' - check whether the generated files match!\")");
            writer.WriteLine("#endif");
            writer.WriteLine("");
            writer.WriteLine("#if ( RBP_PAR_MAIN_MAGIC_NUMBER_GEN != RBP_PAR_ACCESS_MAGIC_NUMBER_GEN )");
            writer.WriteLine("  #error (\"Wrong version of 'rbp_par_access" + my_FileName_Suffix + "_gen.h' - check whether the generated files match!\")");
            writer.WriteLine("#endif");
            writer.WriteLine("");
            writer.WriteLine("#if ( RBP_PAR_MAIN_MAGIC_NUMBER_GEN != RBP_PAR_DEFINE_MAGIC_NUMBER_GEN )");
            writer.WriteLine("  #error (\"Wrong version of 'rbp_par_define" + my_FileName_Suffix + "_gen.h' - check whether the generated files match!\")");
            writer.WriteLine("#endif");
            writer.WriteLine("");
            writer.WriteLine("#if ( RBP_PAR_MAIN_MAGIC_NUMBER_GEN != RBP_PAR_STRUCT_MAGIC_NUMBER_GEN )");
            writer.WriteLine("  #error (\"Wrong version of 'rbp_par_struct" + my_FileName_Suffix + "_gen.h' - check whether the generated files match!\")");
            writer.WriteLine("#endif");
            writer.WriteLine("");
            writer.WriteLine("#if ( RBP_PAR_MAIN_MAGIC_NUMBER_GEN != RBP_PAR_HEADER_MAGIC_NUMBER_GEN )");
            writer.WriteLine("  #error (\"Wrong version of 'rbp_par_header" + my_FileName_Suffix + "_gen.h' - check whether the generated files match!\")");
            writer.WriteLine("#endif");
            writer.WriteLine("");

            if (my_ps.ParameterSetInfo.Version != "1.0")
            {
                writer.WriteLine("#if ( RBP_PAR_MAIN_MAGIC_NUMBER_GEN != RBP_PARAM_TYPES_MAGIC_NUMBER_GEN )");
                writer.WriteLine("  #error (\"Wrong version of 'rbp_param_types_def" + my_FileName_Suffix + ".h' - check whether the generated files match!\")");
                writer.WriteLine("#endif");
                writer.WriteLine("");
            }

            writer.WriteLine("#if ( RBP_PAR_MAIN_MAGIC_NUMBER_GEN != RBP_PAR_READ_ACCESS_MAGIC_NUMBER_GEN )");
            writer.WriteLine("  #error (\"Wrong version of 'rbp_par_read_access" + my_FileName_Suffix + "_gen.h' - check whether the generated files match!\")");
            writer.WriteLine("#endif");
            writer.WriteLine("");
            writer.WriteLine("#if ( RBP_PAR_MAIN_MAGIC_NUMBER_GEN != RBP_PAR_VARIANT_ACCESS_MAGIC_NUMBER_GEN )");
            writer.WriteLine("  #error (\"Wrong version of 'rbp_par_variant_access" + my_FileName_Suffix + "_gen.h' - check whether the generated files match!\")");
            writer.WriteLine("#endif");
            writer.WriteLine("");
            writer.WriteLine("#if ( RBP_PAR_MAIN_MAGIC_NUMBER_GEN != RBP_PAR_WRITE_ACCESS_MAGIC_NUMBER_GEN )");
            writer.WriteLine("  #error (\"Wrong version of 'rbp_par_write_access" + my_FileName_Suffix + "_gen.h' - check whether the generated files match!\")");
            writer.WriteLine("#endif");
            writer.WriteLine("");

            if (IsAccessdef_unique == false)
            {
                // Create warning during the compilation to indicated, some of the access defines are not unique within the first 63 characters
                writer.WriteLine("#if (RBP_GS_COMPILER == RBP_GS_COMPILER_GHS)");
                writer.WriteLine(" /* PRQA S 3115 RBP_RULE_DEV_rbp_par_main_gen_c_3 */  /* checked by \"RBP_GS_COMPILER_GHS\" */");
                writer.WriteLine("  #warning (\" Warning: C99\\C11 compatible -> Identifier\\Macro name shall be unique within the first 63 characters: this is not correct for the some of the defines\")");
                writer.WriteLine("  #warning (\" Please fix the issue. Refer \"\"DefineWarningList" + my_FileName_Suffix + ".txt\"\" file within LOG folder for the list of defines and for more information.\")");
                writer.WriteLine(" /* PRQA L:    RBP_RULE_DEV_rbp_par_main_gen_c_3 */   /* checked by \"RBP_GS_COMPILER_GHS\" */");
                writer.WriteLine("#endif //(RBP_GS_COMPILER == RBP_GS_COMPILER_GHS)");
            }

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- local symbolic constants                                               -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- local macros                                                           -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/* PRQA S 2217 RBP_RULE_DEV_rbp_par_main_gen_c_1 */ /*(details : see end of file) */");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- local data types                                                       -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- local data                                                             -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- prototypes of local functions                                          -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- global data objects                                                    -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");

            if (my_gc.RB_Secure_Flash == "true")
            {
                writer.WriteLine("");
                writer.WriteLine("#if (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                writer.WriteLine("");

                // Prints extern declaration of security variables.
                Security.Print_Security_Block_Extern_Declarations(ref writer);

                writer.WriteLine("");
                writer.WriteLine("#endif // (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                writer.WriteLine("");
            }
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- RAM                                                                    -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("//");
            writer.WriteLine("// global data RAM");
            writer.WriteLine("//");
            writer.WriteLine("");
            PrintStringList(ref writer, 2, my_sd.ParDataRAMBegin);
            writer.WriteLine("  rbp_Type_par_RAMData_st rbp_par_RAMData_st;");
            PrintStringList(ref writer, 2, my_sd.ParDataRAMEnd);
            writer.WriteLine("");
            writer.WriteLine("");
            writer.WriteLine("");
            PrintStringList(ref writer, 0, my_sd.NVMSavedZoneBegin);
            writer.WriteLine(" #if (RBP_GS_PAR_CFG_INIT_NVM_MIRROR_MEM == RBP_SW_ON)");
            writer.WriteLine("   rbp_Type_par_NVM_MirrorData_st rbp_par_NVM_MirrorData_st;");
            writer.WriteLine(" #endif //(RBP_GS_PAR_CFG_INIT_NVM_MIRROR_MEM == RBP_SW_ON)");
            PrintStringList(ref writer, 0, my_sd.NVMSavedZoneEnd);
            writer.WriteLine("");

            PrintStringList(ref writer, 2, my_sd.ParApplRAMBegin);
            writer.WriteLine("#if (RBP_GS_PAR_CFG_INIT_RAM_MIRROR_MEM == RBP_SW_ON)");
            writer.WriteLine("    rbp_Type_par_RAM_INIT_MirrorData_st rbp_par_RAM_INIT_MirrorData_st;");
            writer.WriteLine("#endif //(RBP_GS_PAR_CFG_INIT_RAM_MIRROR_MEM == RBP_SW_ON) ");
            PrintStringList(ref writer, 2, my_sd.ParApplRAMEnd);

            writer.WriteLine("");
            writer.WriteLine("//");
            writer.WriteLine("// application memory");
            writer.WriteLine("//");
            writer.WriteLine("");
            writer.WriteLine("#if ( RBP_GS_PAR_CFG_APPLICATION_MODE == RBP_SW_ON )");
            PrintStringList(ref writer, 2, my_sd.ParApplRAMBegin);
            writer.WriteLine("    rbp_Type_par{0}_ApplicationMemory_st rbp_par{0}_ApplicationMemory_st;", my_DatasetName);
            PrintStringList(ref writer, 2, my_sd.ParApplRAMEnd);
            writer.WriteLine("#endif");
            writer.WriteLine("");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- ROM                                                                    -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            // Offset required to get the Start address for the Security Block
            // Add the size of CALHdrLow and CALBlockStatus if enabled
            int temp_sec_offset = 0; 

            // Cal Header Low.
            if ((my_gc.ST_CHORUS_CALSection_SupportHeaderLow == "true") || (my_gc.ST_CHORUS_CALSection_Mode == "GM"))
            {
                writer.WriteLine("//");
                writer.WriteLine("// CAL Header Low");
                writer.WriteLine("//");

                writer.WriteLine("");
                writer.WriteLine("#if (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                writer.WriteLine("");
                PrintStringList(ref writer, 0, my_sd.CALLowBegin);
                writer.WriteLine("");

                // GM mode only.
                if (my_gc.ST_CHORUS_CALSection_Mode == "GM")
                {
                    // CAL Header Low.
                    GMHelperClass.printGenMainGM_1(ref writer, ref my_gmc);
                    temp_sec_offset += 16;
                }
                else
                {
                    int CalHeaderLowSize = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_HeaderLowSize, 16);
                    // E.g.: ST_CHORUS_CALSection_HeaderLowContent = 0xABCD
                    //       HdrLow_Length = (6 - 2)/2 = 2 -> -2 is to truncate 0x and /2 is to get no of bytes.
                    int HdrLow_Length = (my_gc.ST_CHORUS_CALSection_HeaderLowContent.Length - 2) / 2;

                    // Check for the CAL Header Low Size
                    // If CAL Header Low size is a multiple of 16 proceed ,else make CAL Header Low as 16 Bytes, if size > 0.
                    CalHeaderLowSize = (CalHeaderLowSize % 16 == 0) ? CalHeaderLowSize : 16;

                    // Fail safe check to avoid array of size 0.
                    if (CalHeaderLowSize != 0)
                    {
                        writer.Write("const UInt8 rbp_par_CalHdrLow_pu8[");
                        // Array of CAL Header Low size.
                        writer.Write(CalHeaderLowSize);
                        writer.WriteLine("]=");
                        // Start of the array.
                        writer.WriteLine("{");

                        // Store the cal header low contents in a string variable starting from 2nd index(excluding 0x).
                        string tmp_string = my_gc.ST_CHORUS_CALSection_HeaderLowContent.Substring(2, (HdrLow_Length * 2));

                        // If size of content is less than the configured size, append F in the remaining space. Appending characterwise hence length is size*2.
                        tmp_string = tmp_string.PadRight((CalHeaderLowSize * 2), 'F');

                        // Print the values in rows of 16 values each.
                        for (int index_u8 = 0; index_u8 < ((CalHeaderLowSize / 16) - 1); index_u8++)
                        {
                            // Loop to print 16 values in each row.
                            for (int loop_u8 = 0; loop_u8 < 16; loop_u8++)
                            {
                                // Print the contents until last but one row.
                                writer.Write("  0x{0:X2},", int.Parse(tmp_string.Substring((index_u8 * 32) + (loop_u8 * 2), 2), NumberStyles.AllowHexSpecifier));
                            }
                            // Go to newline
                            writer.WriteLine("");
                        }
                        // Print last row.
                        for (int loop_u8 = 0; loop_u8 < 15; loop_u8++)
                        {
                            // Print the contents until last but one value.
                            writer.Write("  0x{0:X2},", int.Parse(tmp_string.Substring((((CalHeaderLowSize / 16) - 1) * 32) + (loop_u8 * 2), 2), NumberStyles.AllowHexSpecifier));
                        }
                        // Print the last byte.
                        writer.WriteLine("  0x{0:X2}", int.Parse(tmp_string.Substring(((CalHeaderLowSize - 1) * 2), 2), NumberStyles.AllowHexSpecifier));
                        writer.WriteLine("};");
                        writer.WriteLine("");
                    }
                    else
                    {
                        // CAL Header Low Size is "0". 
                    }

                    temp_sec_offset += CalHeaderLowSize;      // Add the CAL Header Low size for the offset
                }
                PrintStringList(ref writer, 0, my_sd.CALLowEnd);
                writer.WriteLine("");
                writer.WriteLine("#endif // (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                writer.WriteLine("");
                writer.WriteLine("");
            }

            // Cal Block Status.
            if (my_gc.ST_CHORUS_CALSection_SupportBlockStatusSection == "true")
            {
                writer.WriteLine("//");
                writer.WriteLine("// Block Status");
                writer.WriteLine("//");

                writer.WriteLine("");
                writer.WriteLine("#if (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                writer.WriteLine("");
                PrintStringList(ref writer, 0, my_sd.BlockStatusBegin);
                writer.WriteLine("");

                int CalBlockStatusSize = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_SupportBlockStatusSize, 16);

                // Check for the CAL block status Size
                // If CAL Block status is a multiple of 16 proceed ,else make CAL Block status 32 Bytes, if size > 0.
                CalBlockStatusSize = (CalBlockStatusSize % 16 == 0) ? CalBlockStatusSize : 32;

                if (CalBlockStatusSize != 0)
                {
                    writer.Write("const UInt8 rbp_par_CalBlockStatus_pu8[");
                    // Array of CAL block status size.
                    writer.Write(CalBlockStatusSize);
                    writer.WriteLine("]=");
                    // Start of the array.
                    writer.WriteLine("{");

                    for (int value = 1; value < CalBlockStatusSize / 16; value++)
                    {
                        writer.WriteLine("  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,");
                    }
                    writer.WriteLine("  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF");

                    writer.WriteLine("};");
                    writer.WriteLine("");
                }
                else
                {
                    // CAL Block status size is "0". 
                }

                // Add the CAL Block Status size for the offset.
                temp_sec_offset += CalBlockStatusSize; 

                PrintStringList(ref writer, 0, my_sd.BlockStatusEnd);
                writer.WriteLine("");
                writer.WriteLine("#endif // (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                writer.WriteLine("");
                writer.WriteLine("");
            }

            if (my_gc.RB_Secure_Flash == "true")
            {
                writer.WriteLine("");
                writer.WriteLine("#if (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                writer.WriteLine("");

                // Prints Certificate, Signature and Values of the PKI Structures.
                Security.Print_Security_Blocks(ref writer,ref my_gc,ref my_sd,temp_sec_offset);

                // Add RB Security PKI Structure Reference Data size to the offset.
                temp_sec_offset += 32;

                writer.WriteLine("");
                writer.WriteLine("#endif // (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                writer.WriteLine("");
                writer.WriteLine("");
            }
            
            // CAL CUS Security Header Low.
            if (my_gc.ST_CHORUS_CALSection_Support_CUS_SecurityHeaderLow == "true")
            {
                writer.WriteLine("//");
                writer.WriteLine("// CAL CUS Security Header Low");
                writer.WriteLine("//");

                writer.WriteLine("");
                writer.WriteLine("#if (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                writer.WriteLine("");
                PrintStringList(ref writer,0,my_sd.CAL_CUS_SecHdrLowBegin);
                writer.WriteLine("");
                {
                    int Cal_CUS_SecHeaderLowSize = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_CUS_SecurityHeaderLowSize,16);
                    // E.g.: ST_CHORUS_CALSection_CUS_SecurityHeaderLowContent = 0xABCD
                    //       HdrLow_Length = (6 - 2)/2 = 2 -> -2 is to truncate 0x and /2 is to get no of bytes.
                    int HdrLow_Length = (my_gc.ST_CHORUS_CALSection_CUS_SecurityHeaderLowContent.Length - 2) / 2;

                    // Check for the CAL CUS Security Header Low Size
                    // If CAL CUS Security Header Low size is a multiple of 16 proceed ,else make CAL CUS Security Header Low as 16 Bytes, if size > 0.
                    Cal_CUS_SecHeaderLowSize = (Cal_CUS_SecHeaderLowSize % 16 == 0) ? Cal_CUS_SecHeaderLowSize : 16;

                    // Fail safe check to avoid array of size 0.
                    if (Cal_CUS_SecHeaderLowSize != 0)
                    {
                        writer.Write("const UInt8 rbp_par_Cal_CUS_SecHdrLow_pu8[");
                        // Array of CAL Header Low size.
                        writer.Write(Cal_CUS_SecHeaderLowSize);
                        writer.WriteLine("]=");
                        // Start of the array.
                        writer.WriteLine("{");

                        // Store the cal cus security header low contents in a string variable starting from 2nd index(excluding 0x).
                        string tmp_string = my_gc.ST_CHORUS_CALSection_CUS_SecurityHeaderLowContent.Substring(2,(HdrLow_Length * 2));

                        // If size of content is less than the configured size, append F in the remaining space. Appending characterwise hence length is size*2.
                        tmp_string = tmp_string.PadRight((Cal_CUS_SecHeaderLowSize * 2),'F');

                        // Print the values in rows of 16 values each.
                        for (int index_u8 = 0 ; index_u8 < ((Cal_CUS_SecHeaderLowSize / 16) - 1) ; index_u8++)
                        {
                            // Loop to print 16 values in each row.
                            for (int loop_u8 = 0 ; loop_u8 < 16 ; loop_u8++)
                            {
                                // Print the contents until last but one row.
                                writer.Write("  0x{0:X2},",int.Parse(tmp_string.Substring((index_u8 * 32) + (loop_u8 * 2),2),NumberStyles.AllowHexSpecifier));
                            }
                            // Go to newline
                            writer.WriteLine("");
                        }
                        // Print last row.
                        for (int loop_u8 = 0 ; loop_u8 < 15 ; loop_u8++)
                        {
                            // Print the contents until last but one value.
                            writer.Write("  0x{0:X2},",int.Parse(tmp_string.Substring((((Cal_CUS_SecHeaderLowSize / 16) - 1) * 32) + (loop_u8 * 2),2),NumberStyles.AllowHexSpecifier));
                        }
                        // Print the last byte.
                        writer.WriteLine("  0x{0:X2}",int.Parse(tmp_string.Substring(((Cal_CUS_SecHeaderLowSize - 1) * 2),2),NumberStyles.AllowHexSpecifier));
                        writer.WriteLine("};");
                        writer.WriteLine("");
                    }
                    else
                    {
                        // CAL CUS Security Header Low Size is "0". 
                    }

                    // Add the CAL CUS Security Header Low size for the offset.
                    temp_sec_offset += Cal_CUS_SecHeaderLowSize;
                }
                PrintStringList(ref writer,0,my_sd.CAL_CUS_SecHdrLowEnd);
                writer.WriteLine("");
                writer.WriteLine("#endif // (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                writer.WriteLine("");
                writer.WriteLine("");
            }

            {
                // Only applicable for individual run of multiple dataset. i.e.: for below configuration.
                // Product_Line = NRCS
                // DataSet_Type = MULTIPLE 
                if ((my_gc.Product_Line == "NRCS") && (my_gc.DataSet_Type == "MULTIPLE") && (my_Selected_Dataset != "main"))
                {
                    // Add the offset to the cal start address.
                    // 128 bytes additional offset is to exclude info adder.
                    int Dataset_StartAdr = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_StartAddress, 16) + temp_sec_offset + 128;

                    // Print rbp_par_Type_<DSX>IndexTable_st
                    writer.WriteLine("const struct rbp_Type_par_{0}IndexTable_st  rbp_par_{0}IndexTable_st = ", my_Selected_Dataset);
                    writer.WriteLine("{");
                    writer.WriteLine("  /* DataSet Start pattern --> \'MulDataStart\' */ ");
                    writer.WriteLine("  { 0x4d, 0x75, 0x6c, 0x44, 0x61, 0x74, 0x61, 0x53, 0x74, 0x61, 0x72, 0x74}, ");
                    writer.WriteLine(string.Format("  0x{0:X2}", Dataset_StartAdr) + ", // Start address of the DataSet"); 
                    writer.WriteLine("  {//" + string.Format("{0,-45}{1,-68}{2}", "Cluster_Index", "  (sizeof(Cluster)*(no of minor var * no of sub var))", "Cluster Name"));

                    foreach (cComponent component in my_ps.Components)
                    {
                        foreach (cParameterCluster cluster in component.ParameterClusters)
                        {
                            if (cluster.MemoryArea != "NVM")
                            {
                                int max_count_sub_var = 0; 
                                foreach (cVariantImplementation var in cluster.VariantsImlementations)
                                {
                                    int count_sub_var = 0;  // Clear the count.
                                    foreach (cMinorVariant min_var in var.MinorVariants)
                                    {
                                        // Get the sub variant count for the given parameter.
                                        count_sub_var+= min_var.SubVariants.Count;
                                    }
                                    
                                    // Check and update the max sub variant count.
                                    if (count_sub_var > max_count_sub_var)
                                    {
                                        max_count_sub_var = count_sub_var;
                                    }
                                }
                                // E.g.: cluster.Name = PAS_DispFoV
                                //       idx_name = rbp_Idx_PAS_DispFoV_du16
                                //       size_of_clu = sizeof(rbp_par_Type_PAS_DispFoV_st)
                                string idx_name = "rbp_Idx_" + cluster.Name + "_du16";
                                string size_of_clu = "sizeof(rbp_Type_par_" + cluster.Name + "_st)";
                                // E.g.: 
                                // {rbp_Idx_PAS_DispFoV_du16                     , (sizeof(rbp_par_Type_PAS_DispFoV_st)                     * 1)},// PAS_DispFoV
                                writer.Write("    {" + string.Format("{0,-45}, ({1,-55} * {2})",idx_name, size_of_clu, max_count_sub_var) + "},");
                                writer.WriteLine("// {0}",cluster.Name);
                            }
                            else
                            {
                                // do nothing
                            }
                        }
                    }
                    writer.WriteLine("  },");
                    writer.WriteLine("  /* DataSet End pattern --> \'MulDataEnd__\' */ ");
                    writer.WriteLine("  { 0x4d, 0x75, 0x6c, 0x44, 0x61, 0x74, 0x61, 0x45, 0x6e, 0x64, 0x5f, 0x5f}");
                    writer.WriteLine("};");
                }
                else
                {
                    // Do nothing
                }
            }

            //! Global data ROM.
            {
                writer.WriteLine("//");
                writer.WriteLine("// global data ROM");
                writer.WriteLine("//");
                writer.WriteLine("");
                writer.WriteLine("#if (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                writer.WriteLine("");
                PrintStringList(ref writer, 0, my_sd.CALDataBegin);
                writer.WriteLine("");
                writer.WriteLine("const rbp_Type_par{0}_ROMData_st rbp_par{0}_ROMData_st =", my_DatasetName);
                writer.WriteLine("{");

                //! Version Information.
                {
                    writer.WriteLine("  //");
                    writer.WriteLine("  // version information");
                    writer.WriteLine("  //");
                    writer.WriteLine("");
                    writer.WriteLine("  {");
                    writer.WriteLine("   // CAL-SectionStart");
                    writer.WriteLine("   { 67, 65, 76, 45, 83, 101, 99, 116, 105, 111, 110, 83, 116, 97, 114, 116 },");
                    string tmp_string = my_gc.ST_CHORUS_CALSection_Version.Substring(0, Math.Min(64, my_gc.ST_CHORUS_CALSection_Version.Length));
                    tmp_string = tmp_string.PadRight(64, '_');
                    writer.Write("   // {0}", tmp_string);
                    writer.WriteLine("");
                    writer.Write("   {");
                    for (int i = 0; i < 63; i++)
                    {
                        writer.Write(" {0},", Convert.ToInt32(tmp_string[i]));
                    }
                    writer.Write(" {0}", Convert.ToInt32(tmp_string[63]));
                    writer.Write("}");
                    writer.WriteLine(",");
                    //writer.Write    ("    rbp_Cal_Stringify_mac(rbp_par_VersionInfo_pc),");
                    writer.WriteLine("    rbp_par_cal{0}_StructureIntegrityHash_mac,", my_DatasetName);
                    writer.WriteLine("    rbp_par_cal{0}_RangeResHash_mac,", my_DatasetName);
                    writer.WriteLine("{0,8},", Convert.ToInt32(my_ps.ParameterSetInfo.Year));
                    writer.WriteLine("{0,6},", Convert.ToInt32(my_ps.ParameterSetInfo.Month));
                    writer.WriteLine("{0,6},", Convert.ToInt32(my_ps.ParameterSetInfo.Day));
                    writer.WriteLine("{0,6},", Convert.ToInt32(my_ps.ParameterSetInfo.Hours));
                    writer.WriteLine("{0,6},", Convert.ToInt32(my_ps.ParameterSetInfo.Minutes));
                    writer.WriteLine("    { 0x00, 0x00 }");
                    writer.WriteLine("  },");
                    writer.WriteLine("");
                } //! @end: Version Information.

                //! Parameter memory ROM.
                {
                    writer.WriteLine("  //");
                    writer.WriteLine("  // parameter memory ROM");
                    writer.WriteLine("  //");
                    writer.WriteLine("");
                    writer.WriteLine("  {");

                    {
                        int num_cluster_lines = 0;
                        int num_cluster = 0;

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if ((cluster.MemoryArea == "ROM") || (cluster.MemoryArea == "NVM_INIT") || (cluster.MemoryArea == "RAM_INIT"))
                                {
                                    num_cluster += 1;
                                }
                                else
                                {
                                    // Memory area is NVM, do nothing.
                                }
                            }
                        }

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if ((cluster.MemoryArea == "ROM") || (cluster.MemoryArea == "NVM_INIT") || (cluster.MemoryArea == "RAM_INIT"))
                                {
                                    // Write cluster name before writing data.
                                    // E.g.: cluster name - CTL_PAS -> // cluster: CTL_PAS
                                    writer.WriteLine("    // cluster: {0}", cluster.Name);

                                    int num_sub_var = 0;

                                    foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                                    {
                                        foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                        {
                                            num_sub_var += min_var.SubVariants.Count;
                                        }
                                    }

                                    writer.WriteLine("    {");

                                    int num_sub_var_lines = 0;

                                    foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                                    {
                                        foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                        {
                                            foreach (cSubVariant sub_var in min_var.SubVariants)
                                            {
                                                bool is_array = false;

                                                num_sub_var_lines++;
                                                // Write major variant name(s), minor variant name and sub variant names if available.
                                                // If name is not available write not labeled.
                                                {
                                                    string var_string = "";

                                                    var_string = "global var(s): ";

                                                    foreach (string my_string in var_imp.MajorVariants)
                                                    {
                                                        var_string += my_string;
                                                        var_string += " ";
                                                    }

                                                    if (min_var.Name != "")
                                                    {
                                                        var_string += string.Format("| min var: {0}", min_var.Name);
                                                    }
                                                    else
                                                    {
                                                        var_string += "| min var: not labeled";
                                                    }

                                                    if (sub_var.Name != "")
                                                    {
                                                        var_string += string.Format(" | sub var: {0}", sub_var.Name);
                                                    }
                                                    else
                                                    {
                                                        var_string += " | sub var: not labeled";
                                                    }

                                                    writer.WriteLine("      // {0}", var_string);
                                                }

                                                writer.WriteLine("      {");

                                                int num_values = 0;

                                                foreach (cParameterValue para_value in sub_var.ParameterValues)
                                                {
                                                    num_values++;

                                                    // Check for arrays.
                                                    is_array = (para_value.Values.Count > 1)
                                                    && (cluster.ParameterDefinitions[num_values - 1].Type != "Bitfield8")
                                                    && (cluster.ParameterDefinitions[num_values - 1].Type != "Bitfield16")
                                                    && (cluster.ParameterDefinitions[num_values - 1].Type != "Bitfield32");

                                                    if (!is_array)
                                                    {
                                                        foreach (string my_value in para_value.Values)
                                                        {
                                                            if (cluster.ParameterDefinitions[num_values - 1].Type == "Boolean")
                                                            {
                                                                if (my_value == "1")
                                                                {
                                                                    writer.Write("{0}true", new string(' ', 8));
                                                                }
                                                                else
                                                                {
                                                                    writer.Write("{0}false", new string(' ', 8));
                                                                }

                                                            }
                                                            else if (cluster.ParameterDefinitions[num_values - 1].Type == "Float32")
                                                            {
                                                                    writer.Write("{0}{1}f", new string(' ', 8), my_value);       
                                                            }
                                                            else
                                                            {
                                                                if (my_ps.ParameterSetInfo.Version != "1.0")
                                                                {
                                                                    writer.Write("{0}{1}",new string(' ',8),wrapper_2_x.Get_enum_name(my_ps,cluster.ParameterDefinitions[num_values - 1],my_value));
                                                                }
                                                                else
                                                                {
                                                                    writer.Write("{0}{1}",new string(' ',8),my_value);
                                                                }
                                                            }

                                                            if (num_values < sub_var.ParameterValues.Count)
                                                            {
                                                                writer.Write(",");
                                                            }
                                                            else
                                                            {
                                                                writer.Write("");
                                                            }

                                                            writer.Write(" // {0}_", cluster.ParameterDefinitions[num_values - 1].Name);

                                                            if ((cluster.ParameterDefinitions[num_values - 1].Type != "Bitfield8")
                                                                && (cluster.ParameterDefinitions[num_values - 1].Type != "Bitfield16")
                                                                && (cluster.ParameterDefinitions[num_values - 1].Type != "Bitfield32"))
                                                            {
                                                                if (Convert.ToInt32(cluster.ParameterDefinitions[num_values - 1].Number) > 1)
                                                                {
                                                                    writer.Write("p");
                                                                }
                                                            }

                                                            if (wrapper_2_x.Is_para_def_enum_b(my_ps,cluster.ParameterDefinitions[num_values - 1]) != true)
                                                            {
                                                                // Parameter is of type Basic data types.
                                                                if (cluster.ParameterDefinitions[num_values - 1].Type == "UInt8") { writer.Write("u8"); }
                                                                else if (cluster.ParameterDefinitions[num_values - 1].Type == "UInt16") { writer.Write("u16"); }
                                                                else if (cluster.ParameterDefinitions[num_values - 1].Type == "UInt32") { writer.Write("u32"); }
                                                                else if (cluster.ParameterDefinitions[num_values - 1].Type == "SInt8") { writer.Write("s8"); }
                                                                else if (cluster.ParameterDefinitions[num_values - 1].Type == "SInt16") { writer.Write("s16"); }
                                                                else if (cluster.ParameterDefinitions[num_values - 1].Type == "SInt32") { writer.Write("s32"); }
                                                                else if (cluster.ParameterDefinitions[num_values - 1].Type == "Boolean") { writer.Write("b"); }
                                                                else if (cluster.ParameterDefinitions[num_values - 1].Type == "Bitfield8") { writer.Write("bf{0}",cluster.ParameterDefinitions[num_values - 1].Number); }
                                                                else if (cluster.ParameterDefinitions[num_values - 1].Type == "Bitfield16") { writer.Write("bf{0}",cluster.ParameterDefinitions[num_values - 1].Number); }
                                                                else if (cluster.ParameterDefinitions[num_values - 1].Type == "Bitfield32") { writer.Write("bf{0}",cluster.ParameterDefinitions[num_values - 1].Number); }
                                                                else if (cluster.ParameterDefinitions[num_values - 1].Type == "Float32") { writer.Write("f32"); }
                                                                else { writer.Write("unknown"); }
                                                            }
                                                            else 
                                                            { 
                                                                // Parameter is of type enumeration.
                                                                writer.Write("en"); 
                                                            }

                                                            // Check for arrays.
                                                            if ((cluster.ParameterDefinitions[num_values - 1].Type != "Bitfield8")
                                                                && (cluster.ParameterDefinitions[num_values - 1].Type != "Bitfield16")
                                                                && (cluster.ParameterDefinitions[num_values - 1].Type != "Bitfield32"))
                                                            {
                                                                if (Convert.ToInt32(cluster.ParameterDefinitions[num_values - 1].Number) > 1)
                                                                {
                                                                    writer.Write("[{0}]", cluster.ParameterDefinitions[num_values - 1].Number);
                                                                }
                                                            }

                                                            // Bitfields.
                                                            if ((cluster.ParameterDefinitions[num_values - 1].Type == "Bitfield8")
                                                                || (cluster.ParameterDefinitions[num_values - 1].Type == "Bitfield16")
                                                                || (cluster.ParameterDefinitions[num_values - 1].Type == "Bitfield32"))
                                                            {
                                                                writer.Write(" : {0}", cluster.ParameterDefinitions[num_values - 1].Number);
                                                            }

                                                            writer.WriteLine("");
                                                        }
                                                    }
                                                    else
                                                    {
                                                        writer.Write("        // {0}_p", cluster.ParameterDefinitions[num_values - 1].Name);

                                                        if (wrapper_2_x.Is_para_def_enum_b(my_ps,cluster.ParameterDefinitions[num_values - 1]) != true)
                                                        {
                                                            // Parameter is of type Basic data types.
                                                            if (cluster.ParameterDefinitions[num_values - 1].Type == "UInt8") { writer.Write("u8"); }
                                                            else if (cluster.ParameterDefinitions[num_values - 1].Type == "UInt16") { writer.Write("u16"); }
                                                            else if (cluster.ParameterDefinitions[num_values - 1].Type == "UInt32") { writer.Write("u32"); }
                                                            else if (cluster.ParameterDefinitions[num_values - 1].Type == "SInt8") { writer.Write("s8"); }
                                                            else if (cluster.ParameterDefinitions[num_values - 1].Type == "SInt16") { writer.Write("s16"); }
                                                            else if (cluster.ParameterDefinitions[num_values - 1].Type == "SInt32") { writer.Write("s32"); }
                                                            else if (cluster.ParameterDefinitions[num_values - 1].Type == "Boolean") { writer.Write("b"); }
                                                            else if (cluster.ParameterDefinitions[num_values - 1].Type == "Bitfield8") { writer.Write("bf8"); }
                                                            else if (cluster.ParameterDefinitions[num_values - 1].Type == "Bitfield16") { writer.Write("bf16"); }
                                                            else if (cluster.ParameterDefinitions[num_values - 1].Type == "Bitfield32") { writer.Write("bf32"); }
                                                            else if (cluster.ParameterDefinitions[num_values - 1].Type == "Float32") { writer.Write("f32"); }
                                                            else { writer.Write("unknown"); }
                                                        }
                                                        else 
                                                        {
                                                            // Parameter is of type enumeration.
                                                            writer.Write("en"); 
                                                        }

                                                        // Check for arrays.
                                                        if ((cluster.ParameterDefinitions[num_values - 1].Type != "Bitfield8")
                                                            && (cluster.ParameterDefinitions[num_values - 1].Type != "Bitfield16")
                                                            && (cluster.ParameterDefinitions[num_values - 1].Type != "Bitfield32"))
                                                        {
                                                            if (Convert.ToInt32(cluster.ParameterDefinitions[num_values - 1].Number) > 1)
                                                            {
                                                                writer.Write("[{0}]", cluster.ParameterDefinitions[num_values - 1].Number);
                                                            }
                                                        }

                                                        writer.WriteLine("");
                                                        writer.WriteLine("        {");

                                                        int num_array_elements = 0;

                                                        foreach (string my_value in para_value.Values)
                                                        {
                                                            num_array_elements++;

                                                            // Is first element of line.
                                                            if ((num_array_elements % 16) == 1)
                                                            {
                                                                writer.Write("{0}", new string(' ', 10));
                                                            }

                                                            if (cluster.ParameterDefinitions[num_values - 1].Type == "Boolean")
                                                            {
                                                                if (my_value == "1") 
                                                                { 
                                                                    writer.Write("true"); 
                                                                }
                                                                else 
                                                                {
                                                                    writer.Write("false"); 
                                                                }
                                                            }
                                                            else if (cluster.ParameterDefinitions[num_values - 1].Type == "Float32")
                                                            {
                                                                    writer.Write("{0}f", my_value);
                                                            }
                                                            else
                                                            {
                                                                if (my_ps.ParameterSetInfo.Version != "1.0")
                                                                {
                                                                    writer.Write("{0}",wrapper_2_x.Get_enum_name(my_ps,cluster.ParameterDefinitions[num_values - 1],my_value));
                                                                }
                                                                else
                                                                {
                                                                    writer.Write("{0}",my_value);
                                                                }
                                                            }

                                                            // Is last array element.
                                                            if (num_array_elements < para_value.Values.Count)
                                                            {
                                                                writer.Write(", ");
                                                            }

                                                            // Is last element of line.
                                                            if ((num_array_elements % 16) == 0)
                                                            {
                                                                writer.WriteLine("");
                                                            }
                                                        }

                                                        writer.WriteLine("");

                                                        if (num_values < sub_var.ParameterValues.Count)
                                                        {
                                                            writer.WriteLine("        },");
                                                        }
                                                        else
                                                        {
                                                            writer.WriteLine("        }");
                                                        }
                                                    }
                                                }

                                                if (num_sub_var_lines < num_sub_var)
                                                {
                                                    writer.WriteLine("      },");
                                                }
                                                else
                                                {
                                                    writer.WriteLine("      }");
                                                }
                                            }
                                        }
                                    }

                                    // Next cluster.
                                    num_cluster_lines++;

                                    if (num_cluster_lines < num_cluster)
                                    {
                                        // End of one cluster.
                                        writer.WriteLine("    },");
                                    }
                                    else
                                    {
                                        // End of last cluster.
                                        writer.WriteLine("    }");
                                    }
                                }
                                else
                                {
                                    // Memory area is NVM, do nothing.
                                }
                            }
                        }
                    }

                    writer.WriteLine("  },");
                } //! @end: Parameter memory ROM.

                writer.WriteLine("    rbp_par_cal{0}_StructureIntegrityHash_mac", my_DatasetName);

                writer.WriteLine("};");
            }//! @end: Global data ROM.

            writer.WriteLine("");
            PrintStringList(ref writer, 0, my_sd.CALDataEnd);
            writer.WriteLine("");
            writer.WriteLine("#elif (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_APPL_ONLY)");
            writer.WriteLine("  // not included in this configuration");
            writer.WriteLine("#else");
            writer.WriteLine("  #error 'invalid configuration!'");
            writer.WriteLine("#endif");
            writer.WriteLine("");
            writer.WriteLine("");

            // CAL CUS Security Header High
            if (my_gc.ST_CHORUS_CALSection_Support_CUS_SecurityHeaderHigh == "true")
            {
                writer.WriteLine("//");
                writer.WriteLine("// CAL CUS Security Header High");
                writer.WriteLine("//");

                writer.WriteLine("");
                writer.WriteLine("#if (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                writer.WriteLine("");
                PrintStringList(ref writer,0,my_sd.CAL_CUS_SecHdrHighBegin);
                writer.WriteLine("");
                {
                    int Cal_CUS_SecHeaderHighSize = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_CUS_SecurityHeaderHighSize,16);
                    // E.g.: ST_CHORUS_CALSection_CUS_SecurityHeaderHighContent = 0xABCD
                    //       HdrHigh_Length = (6 - 2)/2 = 2 -> -2 is to truncate 0x and /2 is to get no of bytes.
                    int HdrHigh_Length = (my_gc.ST_CHORUS_CALSection_CUS_SecurityHeaderHighContent.Length - 2) / 2;

                    // Check for the CAL CUS Security Header High Size
                    // If CAL CUS Security Header High size is a multiple of 16 proceed ,else make CAL CUS Security Header High as 16 Bytes, if size > 0.
                    Cal_CUS_SecHeaderHighSize = (Cal_CUS_SecHeaderHighSize % 16 == 0) ? Cal_CUS_SecHeaderHighSize : 16;

                    // Fail safe check to avoid array of size 0.
                    if (Cal_CUS_SecHeaderHighSize != 0)
                    {
                        writer.Write("const UInt8 rbp_par_Cal_CUS_SecHdrHigh_pu8[");
                        // Array of CAL Header High size.
                        writer.Write(Cal_CUS_SecHeaderHighSize);
                        writer.WriteLine("]=");
                        // Start of the array.
                        writer.WriteLine("{");

                        // Store the cal cus security header high contents in a string variable starting from 2nd index(excluding 0x).
                        string tmp_string = my_gc.ST_CHORUS_CALSection_CUS_SecurityHeaderHighContent.Substring(2,(HdrHigh_Length * 2));

                        // If size of content is less than the configured size, append F in the remaining space. Appending characterwise hence length is size*2.
                        tmp_string = tmp_string.PadRight((Cal_CUS_SecHeaderHighSize * 2),'F');

                        // Print the values in rows of 16 values each.
                        for (int index_u8 = 0 ; index_u8 < ((Cal_CUS_SecHeaderHighSize / 16) - 1) ; index_u8++)
                        {
                            // Loop to print 16 values in each row.
                            for (int loop_u8 = 0 ; loop_u8 < 16 ; loop_u8++)
                            {
                                // Print the contents until last but one row.
                                writer.Write("  0x{0:X2},",int.Parse(tmp_string.Substring((index_u8 * 32) + (loop_u8 * 2),2),NumberStyles.AllowHexSpecifier));
                            }
                            // Go to newline
                            writer.WriteLine("");
                        }
                        // Print last row.
                        for (int loop_u8 = 0 ; loop_u8 < 15 ; loop_u8++)
                        {
                            // Print the contents until last but one value.
                            writer.Write("  0x{0:X2},",int.Parse(tmp_string.Substring((((Cal_CUS_SecHeaderHighSize / 16) - 1) * 32) + (loop_u8 * 2),2),NumberStyles.AllowHexSpecifier));
                        }
                        // Print the last byte.
                        writer.WriteLine("  0x{0:X2}",int.Parse(tmp_string.Substring(((Cal_CUS_SecHeaderHighSize - 1) * 2),2),NumberStyles.AllowHexSpecifier));
                        writer.WriteLine("};");
                        writer.WriteLine("");
                    }
                    else
                    {
                        // CAL CUS Security Header High Size is "0". 
                    }
                }
                PrintStringList(ref writer,0,my_sd.CAL_CUS_SecHdrHighEnd);
                writer.WriteLine("");
                writer.WriteLine("#endif // (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                writer.WriteLine("");
                writer.WriteLine("");
            }

            // Cal Header High.
            if (my_gc.ST_CHORUS_CALSection_SupportHeaderHigh == "true")
            {
                writer.WriteLine("//");
                writer.WriteLine("// CAL Header High");
                writer.WriteLine("//");

                writer.WriteLine("");
                writer.WriteLine("#if (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                writer.WriteLine("");
                PrintStringList(ref writer, 0, my_sd.CALHighBegin);
                writer.WriteLine("");

                int CalHeaderHighSize = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_HeaderHighSize, 16);

                // E.g.: ST_CHORUS_CALSection_HeaderHighContent = 0xABCD
                //       HdrHigh_Length = (6 - 2)/2 = 2 -> -2 is to truncate 0x and /2 is to get no of bytes.
                int HdrHigh_Length = (my_gc.ST_CHORUS_CALSection_HeaderHighContent.Length - 2) / 2;

                // Check for the CAL Header High Size
                // If CAL Header High size is a multiple of 16 proceed ,else make CAL Header High as 16 Bytes, if size > 0.
                CalHeaderHighSize = (CalHeaderHighSize % 16 == 0) ? CalHeaderHighSize : 16;

                // Fail safe check to avoid array of size 0.
                if (CalHeaderHighSize != 0)
                {
                    writer.Write("const UInt8 rbp_par_CalHdrHigh_pu8[");
                    // Array of CAL Header High size.
                    writer.Write(CalHeaderHighSize);
                    writer.WriteLine("]=");
                    // Start of the array.
                    writer.WriteLine("{");

                    // Store the cal header high contents in a string variable starting from 2nd index(excluding 0x).
                    string tmp_string = my_gc.ST_CHORUS_CALSection_HeaderHighContent.Substring(2, (HdrHigh_Length * 2));
                    // If size of content is less than the configured size, append F in the remaining space. Appending characterwise hence length is size*2.
                    tmp_string = tmp_string.PadRight((CalHeaderHighSize * 2), 'F');

                    // Print the values in rows of 16 values each.
                    for (int index_u8 = 0; index_u8 < ((CalHeaderHighSize / 16) - 1); index_u8++)
                    {
                        // Loop to print 16 values in each row.
                        for (int loop_u8 = 0; loop_u8 < 16; loop_u8++)
                        {
                            // Print the contents until last but one row.
                            writer.Write("  0x{0:X2},", int.Parse(tmp_string.Substring((index_u8 * 32) + (loop_u8 * 2), 2), NumberStyles.AllowHexSpecifier));
                        }
                        // Go to newline
                        writer.WriteLine("");
                    }
                    // Print last row.
                    for (int loop_u8 = 0; loop_u8 < 15; loop_u8++)
                    {
                        // Print the contents until last but one value.
                        writer.Write("  0x{0:X2},", int.Parse(tmp_string.Substring((((CalHeaderHighSize / 16) - 1) * 32) + (loop_u8 * 2), 2), NumberStyles.AllowHexSpecifier));
                    }
                    // Print the last byte.
                    writer.WriteLine("  0x{0:X2}", int.Parse(tmp_string.Substring(((CalHeaderHighSize - 1) * 2), 2), NumberStyles.AllowHexSpecifier));
                    writer.WriteLine("};");
                    writer.WriteLine("");
                }
                else
                {
                    // CAL Header High Size is "0". 
                }
                PrintStringList(ref writer, 0, my_sd.CALHighEnd);
                writer.WriteLine("");
                writer.WriteLine("#endif // (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                writer.WriteLine("");
                writer.WriteLine("");
            }

            //! Global meta data ROM.
            {
                writer.WriteLine("//");
                writer.WriteLine("// global meta data ROM");
                writer.WriteLine("//");
                writer.WriteLine("");
                writer.WriteLine("");
                writer.WriteLine("const rbp_Type_par_ROMMetaData_st rbp_par_ROMMetaData_st =");
                writer.WriteLine("{");

                //! Indirection table for parameter memory.
                {
                    writer.WriteLine("  //");
                    writer.WriteLine("  // indirection table for parameter memory");
                    writer.WriteLine("  //");
                    writer.WriteLine("");
                    writer.WriteLine("  {");

                    {
                        int num_lines = 0;
                        int max_lines = 0;

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                max_lines++;
                            }
                        }

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if (cluster.MemoryArea != "NVM")
                                {
                                    if (cluster.MemoryArea == "ROM")
                                    {
                                        writer.Write("    &(rbp_par{1}_ROMData_st.ParameterMemoryROM_st.{0}_pst[0])", cluster.Name, my_DatasetName);
                                    }
                                    else if ((cluster.MemoryArea == "NVM_INIT") || (cluster.MemoryArea == "RAM_INIT"))
                                    {
                                        if ((my_gc.Code_ExternalNVMRAMBuffer == "false") && (cluster.MemoryArea == "NVM_INIT"))
                                        {
                                            writer.Write("    &(rbp_par_NVM_MirrorData_st.ParameterMemoryNVM_RAM_Mirror_st.{0}_pst[0])",
                                                           cluster.Name);
                                        }
                                        else if ((my_gc.Code_ExternalNVMRAMBuffer == "false") && (cluster.MemoryArea == "RAM_INIT"))
                                        {
                                            writer.Write("    &(rbp_par_RAM_INIT_MirrorData_st.ParameterMemoryRAM_INIT_Mirror_st.{0}_pst[0])",
                                                           cluster.Name);
                                        }
                                        else
                                        {
                                            writer.Write("    rbp_PAR_EXT_RAM_{0}_pst", cluster.Name.ToUpper());
                                        }
                                    }
                                    else
                                    {
                                        // Do nothing.
                                    }

                                    num_lines++;

                                    if (num_lines < max_lines)
                                    {
                                        writer.WriteLine(",");
                                    }
                                    else
                                    {
                                        writer.WriteLine("");
                                    }
                                }
                            }
                        }
                    }
                    writer.WriteLine("/* PRQA S 0686 RBP_RULE_DEV_rbp_par_main_gen_c_4 */ /*(details : see end of file) */");
                    writer.WriteLine("  },");
                    writer.WriteLine("/* PRQA L: RBP_RULE_DEV_rbp_par_main_gen_c_4 */ /*(details : see end of file) */");
                    writer.WriteLine("");
                } //! @end: Indirection table for parameter memory.

                //! RAM default copy table.
                {
                    writer.WriteLine("  //");
                    writer.WriteLine("  // RAM default copy table");
                    writer.WriteLine("  //");
                    writer.WriteLine("");
                    writer.WriteLine("  #if ((RBP_GS_PAR_CFG_INIT_NVM_MIRROR_MEM == RBP_SW_ON ) || (RBP_GS_PAR_CFG_INIT_RAM_MIRROR_MEM == RBP_SW_ON )) ");
                    writer.WriteLine("");

                    writer.WriteLine("/* PRQA S 0311 RBP_RULE_DEV_rbp_par_main_gen_c_2 */ /*(details : see end of file) */");

                    int num_elements = 1;
                    foreach (cComponent component in my_ps.Components)
                    {
                        foreach (cParameterCluster cluster in component.ParameterClusters)
                        {
                            if ((cluster.MemoryArea == "NVM_INIT") || (cluster.MemoryArea == "RAM_INIT"))
                            {
                                num_elements++;
                            }
                            else if ((cluster.MemoryArea == "ROM") || (cluster.MemoryArea == "NVM") || (cluster.MemoryArea == "RAM"))
                            {
                                // Do nothing.
                            }
                            else
                            {
                                // Do nothing.
                            }
                        }
                    }

                    writer.WriteLine("  {");

                    foreach (cComponent component in my_ps.Components)
                    {
                        foreach (cParameterCluster cluster in component.ParameterClusters)
                        {
                            if ((cluster.MemoryArea == "NVM_INIT") || (cluster.MemoryArea == "RAM_INIT"))
                            {
                                writer.WriteLine("    {");
                                writer.WriteLine("      (void *)(&(rbp_par{1}_ROMData_st.ParameterMemoryROM_st.{0}_pst[0])),", cluster.Name, my_DatasetName);
                                if (cluster.MemoryArea == "NVM_INIT")
                                {
                                    writer.WriteLine("      (void *)(&(rbp_par_NVM_MirrorData_st.ParameterMemoryNVM_RAM_Mirror_st.{0}_pst[0])),", cluster.Name);
                                }
                                else
                                {
                                    writer.WriteLine("      (void *)(&(rbp_par_RAM_INIT_MirrorData_st.ParameterMemoryRAM_INIT_Mirror_st.{0}_pst[0])),", cluster.Name);
                                }
                                writer.WriteLine("      (UInt32)sizeof (rbp_par{1}_ROMData_st.ParameterMemoryROM_st.{0}_pst[0]),", cluster.Name, my_DatasetName);

                                {
                                    writer.WriteLine("      // sub variant offsets");
                                    writer.WriteLine("      {");
                                    writer.Write("        ");

                                    {
                                        int major_var_index = 0;

                                        foreach (string my_string in my_ps.MajorVariants)
                                        {
                                            int sub_var_offset = 0;

                                            foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                                            {
                                                int index = var_imp.MajorVariants.IndexOf(my_string);

                                                // Ignore -1 -> element not found.
                                                if (index != -1)
                                                {
                                                    writer.Write("{0,3:d}", sub_var_offset);

                                                    if (major_var_index < (my_ps.MajorVariants.Count - 1))
                                                    {
                                                        writer.Write(", ");
                                                    }
                                                    else
                                                    {
                                                        writer.WriteLine("");
                                                    }
                                                }
                                                else
                                                {
                                                    foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                                    {
                                                        sub_var_offset += min_var.SubVariants.Count;
                                                    }
                                                }
                                            }

                                            major_var_index++;
                                        }
                                    }

                                    writer.WriteLine("      },");
                                }

                                {
                                    writer.WriteLine("      // number of sub variants");
                                    writer.WriteLine("      {");
                                    writer.Write("        ");

                                    {
                                        int major_var_index = 0;

                                        foreach (string my_string in my_ps.MajorVariants)
                                        {
                                            foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                                            {
                                                int index = var_imp.MajorVariants.IndexOf(my_string);

                                                // Ignore -1 -> element not found.
                                                if (index != -1)
                                                {
                                                    int sub_var_count = 0;

                                                    foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                                    {
                                                        sub_var_count += min_var.SubVariants.Count;
                                                    }

                                                    writer.Write("{0,3:d}", sub_var_count);

                                                    if (major_var_index < (my_ps.MajorVariants.Count - 1))
                                                    {
                                                        writer.Write(", ");
                                                    }
                                                    else
                                                    {
                                                        writer.WriteLine("");
                                                    }
                                                }
                                            }

                                            // Check for next major variant.
                                            major_var_index++;
                                        }
                                    }

                                    writer.WriteLine("      },");
                                }

                                if (cluster.MemoryArea == "NVM_INIT")
                                {
                                    writer.WriteLine("      false");
                                }
                                else if (cluster.MemoryArea == "RAM_INIT")
                                {
                                    writer.WriteLine("      true");
                                }
                                writer.WriteLine("    },");
                            }
                            else if ((cluster.MemoryArea == "ROM") || (cluster.MemoryArea == "NVM") || (cluster.MemoryArea == "RAM"))
                            {
                                // Do nothing.
                            }
                            else
                            {
                                // Do nothing.
                            }
                        }
                    }

                    writer.WriteLine("    {");
                    writer.WriteLine("      NULL,");
                    writer.WriteLine("      NULL,");
                    writer.WriteLine("      0,");
                    {
                        int i;

                        writer.Write("      {");

                        for (i = 0; i < my_ps.MajorVariants.Count; i++)
                        {
                            writer.Write("0");

                            if (i < (my_ps.MajorVariants.Count - 1))
                            {
                                writer.Write(", ");
                            }
                        }

                        writer.WriteLine("},");
                    }
                    {
                        int i;

                        writer.Write("      {");

                        for (i = 0; i < my_ps.MajorVariants.Count; i++)
                        {
                            writer.Write("0");

                            if (i < (my_ps.MajorVariants.Count - 1))
                            {
                                writer.Write(", ");
                            }
                        }

                        writer.WriteLine("},");
                        writer.WriteLine("      true");
                    }
                    writer.WriteLine("    }");
                    writer.WriteLine("  },");
                    writer.WriteLine("");
                    writer.WriteLine("/* PRQA L: RBP_RULE_DEV_rbp_par_main_gen_c_2 */ /*(details: see end of file)*/");
                    writer.WriteLine("");
                    writer.WriteLine("  #endif //((RBP_GS_PAR_CFG_INIT_NVM_MIRROR_MEM == RBP_SW_ON ) || (RBP_GS_PAR_CFG_INIT_RAM_MIRROR_MEM == RBP_SW_ON ))");
                    writer.WriteLine("");
                    writer.WriteLine("");
                } //! @end: RAM default copy table.

                //! Application memory cluster pointer.
                {
                    writer.WriteLine("  //");
                    writer.WriteLine("  // application memory cluster pointer");
                    writer.WriteLine("  //");
                    writer.WriteLine("");
                    writer.WriteLine("  #if ( RBP_GS_PAR_CFG_APPLICATION_MODE == RBP_SW_ON )");
                    writer.WriteLine("");
                    writer.WriteLine("  {");

                    {
                        int max_num_clusters = 0;

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if (cluster.MemoryArea != "NVM")
                                {
                                    max_num_clusters++;
                                }
                            }
                        }

                        int num_clusters = 0;

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if (cluster.MemoryArea != "NVM")
                                {
                                    if (cluster.MemoryArea == "ROM")
                                    {
                                        num_clusters++;

                                        if ((cluster.VariantApplication.ToUpper() == "SINGLE") || (cluster.VariantApplication.ToUpper() == "MINOR_ALL"))
                                        {
                                            // SINGLE | MINOR_ALL
                                            writer.Write("    &(rbp_par{1}_ApplicationMemory_st.{0}_pst[0])",
                                                           cluster.Name, my_DatasetName);
                                        }

                                    }
                                    else if (cluster.MemoryArea == "NVM_INIT")
                                    {
                                        num_clusters++;
                                        writer.Write("    &(rbp_par_NVM_MirrorData_st.ParameterMemoryNVM_RAM_Mirror_st.{0}_pst[0])",
                                                       cluster.Name);
                                    }
                                    else if (cluster.MemoryArea == "RAM_INIT")
                                    {
                                        num_clusters++;
                                        writer.Write("    &(rbp_par_RAM_INIT_MirrorData_st.ParameterMemoryRAM_INIT_Mirror_st.{0}_pst[0])",
                                                    cluster.Name);
                                    }

                                    if (num_clusters < max_num_clusters)
                                    {
                                        writer.WriteLine(",");
                                    }
                                    else
                                    {
                                        writer.WriteLine("");
                                    }
                                }
                            }
                        }
                    }

                    writer.WriteLine("  },");
                    writer.WriteLine("");
                    writer.WriteLine("  #endif //( RBP_GS_PAR_CFG_APPLICATION_MODE == RBP_SW_ON )");
                    writer.WriteLine("");
                    writer.WriteLine("");
                } //! @end: Application memory cluster pointer.

                //! Cluster size.
                {
                    writer.WriteLine("  //");
                    writer.WriteLine("  // cluster size");
                    writer.WriteLine("  //");
                    writer.WriteLine("");
                    writer.WriteLine("  {");

                    {
                        int max_num_clusters = 0;

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if (cluster.MemoryArea != "NVM")
                                {
                                    max_num_clusters++;
                                }
                            }
                        }

                        int num_clusters = 0;

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if (cluster.MemoryArea != "NVM")
                                {
                                    num_clusters++;

                                    writer.Write("    sizeof (rbp_Type_par_{0}_st)",
                                                  cluster.Name);

                                    if (num_clusters < max_num_clusters)
                                    {
                                        writer.WriteLine(",");
                                    }
                                    else
                                    {
                                        writer.WriteLine("");
                                    }
                                }
                            }
                        }
                    }

                    writer.WriteLine("  },");
                    writer.WriteLine("");
                    writer.WriteLine("");
                } //! @end: Cluster size.

                //! Sub variant application mode.
                {
                    writer.WriteLine("  //");
                    writer.WriteLine("  // sub variant application mode");
                    writer.WriteLine("  //");
                    writer.WriteLine("  // 0 = SINGLE | 1 = MINOR_ALL");
                    writer.WriteLine("  //");
                    writer.WriteLine("  //");
                    writer.WriteLine("");
                    writer.WriteLine("  #if ( RBP_GS_PAR_CFG_APPLICATION_MODE == RBP_SW_ON )");
                    writer.WriteLine("");
                    writer.WriteLine("  {");

                    {
                        int max_num_clusters = 0;

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if (cluster.MemoryArea != "NVM")
                                {
                                    max_num_clusters++;
                                }
                            }
                        }

                        int num_clusters = 0;

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if (cluster.MemoryArea != "NVM")
                                {
                                    int sub_var_appl_mode = 0;

                                    if (cluster.VariantApplication.ToUpper() == "SINGLE")
                                    {
                                        sub_var_appl_mode = 0;
                                    }
                                    else
                                    {
                                        if (cluster.VariantApplication.ToUpper() == "MINOR_ALL")
                                        {
                                            sub_var_appl_mode = 1;
                                        }
                                        else
                                        {
                                            // Use single variant application as default.
                                            sub_var_appl_mode = 0;
                                        }
                                    }

                                    num_clusters++;

                                    writer.Write("    {0}", sub_var_appl_mode);

                                    if (num_clusters < max_num_clusters)
                                    {
                                        writer.Write(",");
                                    }
                                    else
                                    {
                                        writer.Write(" ");
                                    }

                                    writer.WriteLine("  // {0}", cluster.Name);
                                }
                            }
                        }
                    }

                    writer.WriteLine("  },");
                    writer.WriteLine("");
                    writer.WriteLine("  #endif //( RBP_GS_PAR_CFG_APPLICATION_MODE == RBP_SW_ON )");
                    writer.WriteLine("");
                    writer.WriteLine("");
                } //! @end: Cluster size.

                //! Maximum number of subvariants.
                {
                    writer.WriteLine("  //");
                    writer.WriteLine("  // max sub variants");
                    writer.WriteLine("");
                    writer.WriteLine("  #if ( RBP_GS_PAR_CFG_APPLICATION_MODE == RBP_SW_ON )");
                    writer.WriteLine("");
                    writer.WriteLine("  {");

                    {
                        int max_num_clusters = 0;

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if (cluster.MemoryArea != "NVM")
                                {
                                    max_num_clusters++;
                                }
                            }
                        }

                        int num_clusters = 0;

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if (cluster.MemoryArea != "NVM")
                                {
                                    int max_sub_vars = 0;

                                    if (cluster.VariantApplication.ToUpper() == "SINGLE")
                                    {
                                        max_sub_vars = cluster.VariantsImlementations[0].MinorVariants.Count;
                                    }
                                    else
                                    {
                                        if (cluster.VariantApplication.ToUpper() == "MINOR_ALL")
                                        {
                                            // Find the minor variant with the maximum number of subvariants in the current cluster.
                                            foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                                            {
                                                int num_sub_vars = 0;

                                                foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                                {
                                                    num_sub_vars += min_var.SubVariants.Count;
                                                }
                                                
                                                if (num_sub_vars > max_sub_vars)
                                                {
                                                    max_sub_vars = num_sub_vars;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            // Use single variant application as default.
                                            max_sub_vars = 1;
                                        }
                                    }

                                    num_clusters++;

                                    writer.Write("    {0}", max_sub_vars);

                                    if (num_clusters < max_num_clusters)
                                    {
                                        writer.Write(",");
                                    }
                                    else
                                    {
                                        writer.Write(" ");
                                    }

                                    writer.WriteLine("  // {0}", cluster.Name);
                                }
                            }
                        }
                    }

                    writer.WriteLine("  },");
                    writer.WriteLine("");
                    writer.WriteLine("  #endif //( RBP_GS_PAR_CFG_APPLICATION_MODE == RBP_SW_ON )");
                    writer.WriteLine("");
                    writer.WriteLine("");
                } //! @end: Maximum number of subvariants.

                //! Major variant meta data.
                {
                    // Major variant Index count.
                    int mjv_var_index_count = 0;

                    writer.WriteLine("  //");
                    writer.WriteLine("  // major variant meta data");
                    writer.WriteLine("  //");
                    writer.WriteLine("");
                    writer.WriteLine("  {");

                    {
                        int num_lines = 0;
                        int max_lines = 0;

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if (cluster.MemoryArea != "NVM")
                                {
                                    max_lines++;
                                }
                            }
                        }

                        int num_var_imps = 0;

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if (cluster.MemoryArea != "NVM")
                                {
                                    writer.Write("    { { ");

                                    {
                                        int major_var_index = 0;

                                        foreach (string my_string in my_ps.MajorVariants)
                                        {
                                            int variant_index = 0;

                                            foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                                            {
                                                int index = var_imp.MajorVariants.IndexOf(my_string);

                                                // Ignore -1 -> element not found.
                                                if (index != -1)
                                                {
                                                    writer.Write("{0,3:d}", num_var_imps + variant_index);

                                                    if (major_var_index < (my_ps.MajorVariants.Count - 1))
                                                    {
                                                        writer.Write(", ");
                                                    }
                                                }

                                                variant_index++;
                                            }

                                            major_var_index++;
                                        }
                                    }

                                    writer.Write(" }");
                                    writer.Write(" }");

                                    num_var_imps += cluster.VariantsImlementations.Count;
                                    mjv_var_index_count = num_var_imps;

                                    num_lines++;

                                    if (num_lines < max_lines)
                                    {
                                        writer.Write(",");
                                    }
                                    else
                                    {
                                        writer.Write(" ");
                                    }

                                    writer.WriteLine("  // {0}", cluster.Name);
                                }
                            }
                        }
                    }
                    writer.WriteLine("  },");

                    if (mjv_var_index_count >= 65535)
                    {
                        // Major variant metadata overflowed.
                        my_variant_overflow_b = true;

                        Console.WriteLine(" ");
                        Console.BackgroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("==================================================== #ERROR ============================================================");
                        Console.WriteLine(" Major Variant metadata crosses the limit (>=65535). Reduce the number of Major\\Minor\\Sub variants count within PAR_XML");
                        Console.WriteLine("========================================================================================================================");
                        Console.ResetColor();
                        Console.WriteLine(" ");

                        writer.WriteLine(" ");
                        writer.WriteLine("  #error(\"Major Variant metadata crosses the limit (>=65535). Reduce the number of Major\\MInor\\Sub variants count within PAR_XML\") ");
                    }

                    writer.WriteLine("");
                    writer.WriteLine("");
                } //! @end: Major variant meta data.

                //! Minor variant meta data.
                {
                    // Minor variant Index count.
                    int min_var_index_count = 0;

                    writer.WriteLine("  //");
                    writer.WriteLine("  // minor variant meta data");
                    writer.WriteLine("  //");
                    writer.WriteLine("");
                    writer.WriteLine("  {");

                    {
                        int num_lines = 0;
                        int max_lines = 0;

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if (cluster.MemoryArea != "NVM")
                                {
                                    foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                                    {
                                        max_lines++;
                                    }
                                }
                            }
                        }

                        int num_minor_variants = 0;

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if (cluster.MemoryArea != "NVM")
                                {
                                    foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                                    {
                                        writer.Write("    {{ {0,3:d}, {1,3:d} }}", var_imp.MinorVariants.Count, num_minor_variants);
                                        num_lines++;

                                        num_minor_variants += var_imp.MinorVariants.Count;
                                        min_var_index_count = num_minor_variants;

                                        if (num_lines < max_lines)
                                        {
                                            writer.Write(",");
                                        }
                                        else
                                        {
                                            writer.Write(" ");
                                        }

                                        writer.WriteLine("  // {0}", cluster.Name);
                                    }
                                }
                            }
                        }
                    }

                    writer.WriteLine("  },");

                    if (min_var_index_count >= 65535)
                    {
                        // Minor variant metadata overflowed.
                        my_variant_overflow_b = true;

                        Console.WriteLine(" ");
                        Console.BackgroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("==================================================== #ERROR ============================================================");
                        Console.WriteLine(" Minor Variant metadata crosses the limit (>=65535). Reduce the number of Major\\Minor\\Sub variants count within PAR_XML");
                        Console.WriteLine("========================================================================================================================");
                        Console.ResetColor();
                        Console.WriteLine(" ");

                        writer.WriteLine(" ");
                        writer.WriteLine(" #error(\" Minor Variant metadata crosses the limit (>=65535). Reduce the number of Major\\Minor\\Sub variants count within PAR_XML\") ");
                    }

                    writer.WriteLine("");
                    writer.WriteLine("");
                } //! @end: Minor variant meta data.

                //! Sub variant meta data.
                {
                    // Sub variant index count.
                    Boolean sub_var_index_outofrange = false;
                    string cluster_name = "";

                    writer.WriteLine("  //");
                    writer.WriteLine("  // sub variant meta data");
                    writer.WriteLine("  //");
                    writer.WriteLine("");
                    writer.WriteLine("  {");

                    {
                        int max_lines = 0;
                        int num_lines = 0;
  
                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if (cluster.MemoryArea != "NVM")
                                {
                                    foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                                    {
                                        foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                        {
                                            max_lines++;
                                        }
                                    }
                                }
                            }
                        }

                        foreach (cComponent component in my_ps.Components)
                        {
                            foreach (cParameterCluster cluster in component.ParameterClusters)
                            {
                                if (cluster.MemoryArea != "NVM")
                                {
                                    int count_sub_var = 0;

                                    foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                                    {
                                        if ((cluster.MemoryArea == "NVM_INIT") || (cluster.MemoryArea == "RAM_INIT"))
                                        {
                                            // Reset sub variant offset - all major variants use the same memory.
                                            count_sub_var = 0;
                                        }
                                        else
                                        {
                                            // Memory area is ROM, do nothing.
                                        }

                                        foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                        {
                                            num_lines++;

                                            writer.Write("    {{ {0,3:d}, {1,3:d} }}", min_var.SubVariants.Count, count_sub_var);

                                            if (num_lines < max_lines)
                                            {
                                                writer.Write(",");
                                            }
                                            else
                                            {
                                                writer.Write(" ");
                                            }

                                            writer.WriteLine("  // {0}", cluster.Name);

                                            count_sub_var += min_var.SubVariants.Count;

                                            if (count_sub_var >= 65535)
                                            {
                                                sub_var_index_outofrange = true;
                                                cluster_name = cluster.Name;
                                            }

                                        }
                                    }
                                }
                            }
                        }
                    }

                    writer.WriteLine("  }");

                    // Comparison for the max subvariant index supported in SRV_PAR.
                    if (sub_var_index_outofrange != false)
                    {
                        // Sub variant metadata overflow.
                        my_variant_overflow_b = true;

                        Console.WriteLine();
                        Console.BackgroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("==================================================== #ERROR ============================================================");
                        Console.WriteLine(" Sub Variant metadata crosses the limit (>=65535). Reduce the number of Major\\Minor\\Sub variants count within PAR_XML ");
                        Console.WriteLine(" Cluster Name : {0}                                                                 ",cluster_name);
                        Console.WriteLine("========================================================================================================================");
                        Console.ResetColor();
                        Console.WriteLine(" ");

                        writer.WriteLine(" ");
                        writer.WriteLine("  #error(\"Subvariant Variant metadata crosses the limit (>=65535). Reduce the number of Major\\Minor\\Sub variants count within PAR_XML.\") ");
                    }

                } //! @end: Sub variant meta data.

                writer.WriteLine("};");
                writer.WriteLine("");
            } //! @end: Global meta data ROM.
           
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- definition of local functions                                          -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- public functions                                                       -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            if ((my_gc.Product_Line == "USS") || ((my_gc.DisableVariantMismatchCheck != "true") && (my_gc.Product_Line == "NRCS")))
            {
                PrintA2L(ref my_ps, ref writer, ref my_dt, ref my_gc, my_DatasetName, false);
                //this statement should not be inside the condition. This is only an exception for DAI project. to be removed in future asap TODO:. 
            }


            writer.WriteLine("");
            writer.WriteLine("");
            writer.WriteLine("/* PRQA L: RBP_RULE_DEV_rbp_par_main_gen_c_1 */ /*(details: see end of file)*/");
            writer.WriteLine("");
            writer.WriteLine("/*****************************************************************************/");
            writer.WriteLine("/* START OF EXPLANATION FOR RBP_RULE_DEVIATIONS: */");
            writer.WriteLine("/*===============================*/");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_main_gen_c_1 */");
            writer.WriteLine("/* Deviation to GPG rule number: 2217*/");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Comments exceeds more than 130 characters*/");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Since it is comments not gonna effect safety */");
            writer.WriteLine("");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_main_gen_c_2 */");
            writer.WriteLine("/* Deviation to GPG rule number: 11.8*/");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation: ");
            writer.WriteLine("   In order to get the start address of the cluster through pointer arithmetic,");
            writer.WriteLine("   cast is necessary. */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   In code, care is taken that the casted pointer is used only to read data(i.e. no write).*/");
            writer.WriteLine("");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_main_gen_c_3 */");
            writer.WriteLine("/* Deviation to GPG rule number: 3115 */");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation: ");
            writer.WriteLine("   #warning is correct spelling of preprocessing directive. */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   #warning is only available in case GHS compiler is selected (GHS compiler supports #warning). */");
            writer.WriteLine("");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_main_gen_c_4 */");
            writer.WriteLine("/* Deviation to GPG rule number: 0686 */");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation: ");
            writer.WriteLine("   Size of array is equal to total number of clusters including NVM. */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Remaining array members will be initialised with 0 and is not accessed. */");
            writer.WriteLine("");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_main_gen_c_5 */");
            writer.WriteLine("/* Deviation to GPG rule number: 3108 */");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation: ");
            writer.WriteLine("   ASAP tool doesnot understand single line comment */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   It is part of a2l comments and will not affect software. */");
            writer.WriteLine("");
            writer.WriteLine("/* END OF EXPLANATION FOR RBP_RULE DEVIATIONS */");
            writer.WriteLine("/*****************************************************************************/");

            // Close output file.
            writer.Close();

            if (my_variant_overflow_b != false)
            { 
                // Throw an exception if the major\minor\sub variant metadata index >=65535.
                // Stop the parameter generation and Retain the rbp_par_main_gen.c file
                throw (new Exception(""));
            }

        }

        /// <summary>
        /// Write the A2L-comments for the parameters to the given output stream.
        /// </summary>
        /// <param name="my_ps">Reference to Parameter set.</param>
        /// <param name="writer">Reference stream writer to write contents into file.</param>
        /// <param name="my_dt">Reference for date and time.</param>
        /// <param name="my_gc">Reference for general configuration.</param>
        /// <param name="my_DatasetName">Selected Dataset Name</param>
        /// <param name="my_A2LforOEM">Flag to indicate whether the A2L is being generated within rbp_par_main_gen.c or rbp_par_oem_a2l_gen.c/rbp_par_dsx_oem_a2l_gen.c(individual run of multiple dataset) file.</param>
        public void PrintA2L(ref cParameterSet my_ps,
                                     ref StreamWriter writer,
                                     ref DateTime my_dt,
                                     ref cGeneralConfiguration my_gc,
                                     string my_DatasetName,
                                     bool my_A2LforOEM)
        {

            cWrapper_XML_2_x wrapper_2_x = new cWrapper_XML_2_x();

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Calibration parameter access for Vector A2L-Creator             -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/* PRQA S 3108 RBP_RULE_DEV_rbp_par_main_gen_c_5 */ /*(details: see end of file)*/");
            foreach (cComponent component in my_ps.Components)
            {
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("/*- {0}{1} -*/",
                                  component.Name.ToUpper(), new String(' ', 70 - component.Name.Length));
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("");
                foreach (cParameterCluster cluster in component.ParameterClusters)
                {
                    // A2L Variables will not be provided for NVM clusters.
                    if (cluster.MemoryArea != "NVM")
                    {
                        int max_sub_vars = 0;                               // Maximum number of subvariants which are applicable.
                        int num_min_vars = 0;                               // Number of minor variants for the corresponding cluster.
                        int var_impl = 0;                                   // Count of variant implementations. 
                        List<string> canape_name_list = new List<string>(); // List with the CANape aliases.

                        //!  VAR_APPL -> SINGLE
                        if (cluster.VariantApplication.ToUpper() == "SINGLE")
                        {
                            // Get number of minor variants available in a cluster.
                            num_min_vars = cluster.VariantsImlementations[0].MinorVariants.Count;

                            if (num_min_vars > 1)
                            {
                                // For ROM, RAM_INIT and NVM_INIT clusters.
                                // Execute part of this code if cluster has more than one minor variant.
                                for (int l_loop = 0; l_loop < num_min_vars; l_loop++)
                                {
                                    // Add each Minor Variant
                                    // Assuming minor variant name is same for all the variant implementations.
                                    canape_name_list.Add(cluster.VariantsImlementations[0].MinorVariants[l_loop].Name);
                                }
                            }
                            else
                            {
                                // Only one / No min var available.
                                canape_name_list.Add(cluster.VariantsImlementations[0].MinorVariants[0].SubVariants[0].Name);
                            }

                            // No Sub variants is available.
                            max_sub_vars = 1;
                        } //! @end : VAR_APPL -> SINGLE

                        //! VAR_APPL -> MINOR_ALL
                        else if ((cluster.VariantApplication.ToUpper() == "MINOR_ALL"))
                        {
                            // Find the minor variant with the maximum number of subvariants in the current cluster.
                            foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                            {
                                // Assuming similar minor and sub-variants for all the variant implementations.
                                var_impl++;

                                // Get number of min var available within the cluster variant implementation.
                                num_min_vars = var_imp.MinorVariants.Count;

                                foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                {
                                    foreach (cSubVariant sub_var in min_var.SubVariants)
                                    {
                                        string canape_list_name = "";

                                        if ((min_var.Name != ""))
                                        {
                                            // Second condition : Added because if cluster has only one minor variant, minor var name should not be part of A2L type.
                                            if ((num_min_vars > 1))
                                            {
                                                // Only for clusters having more than one minor variant.
                                                // Combine min_var and sub_var for easy understanding.
                                                canape_list_name = min_var.Name + "_" + sub_var.Name;
                                            }
                                            else
                                            {
                                                // For ROM, RAM_INIT, NVM_INIT clusters (i.e. one min var only)
                                                canape_list_name = sub_var.Name;
                                                num_min_vars = 1;
                                            }
                                        }
                                        else
                                        {
                                            // Minor variant name is empty. This case will not be there.
                                            canape_list_name = sub_var.Name;
                                        }

                                        // Adding list for one variant implementation is enough (i.e. Assuming minor and sub variant name are identical)
                                        if (var_impl == 1)
                                        {
                                            canape_name_list.Add(canape_list_name);
                                        }
                                    }

                                    if (min_var.SubVariants.Count > max_sub_vars)
                                    {
                                        // Max number of sub_variants available.
                                        max_sub_vars = min_var.SubVariants.Count;
                                    }
                                }
                            }
                        } //! @end : VAR_APPL -> MINOR_ALL

                        // Loop variables for minor and sub variants .
                        int sub_var_idx = 0;
                        int min_var_idx = 0;

                        // Loop over all minor variants of the given cluster
                        for (min_var_idx = 0; min_var_idx < num_min_vars; min_var_idx++)
                        {
                            // Loop over all sub_variants of the given cluster
                            for (sub_var_idx = 0; sub_var_idx < max_sub_vars; sub_var_idx++)
                            {
                                // Note: For below configuration generate A2L for only NVM_INIT and RAM_INIT clusters.
                                //       A2L_AllRefersROM == "false", my_gc.A2L_UseRAMMirror == "true" and my_A2LforOEM == false
                                if (!((my_gc.A2L_AllRefersROM == "false") && (my_gc.A2L_UseRAMMirror == "true") && (cluster.MemoryArea == "ROM") && (my_A2LforOEM == false)))
                                {
                                    foreach (cParameterDefinition para_def in cluster.ParameterDefinitions)
                                    {
                                        // If printing for oem, proceed only if diclosure property is external( !=internal)
                                        if ((my_A2LforOEM != true) || ((my_A2LforOEM == true) && (para_def.Disclosure != "internal")))
                                        {
                                            // True :  Parameter is an array and has Canape name for each array member.
                                            // False : Parameter is not an array/ Array with no canape name for each element. 
                                            bool split_array;

                                            // Check if parameter is bitfield.
                                            if (para_def.IsBitfield() != false)
                                            {
                                                split_array = false;
                                            }
                                            else
                                            {
                                                // Not a Bitfield.
                                                // Check if parameter is a array or not.
                                                if (Convert.ToInt32(para_def.Number) > 1)
                                                {
                                                    // Check if Canape alias name is available for each array member.
                                                    if (para_def.CANapeAliases.Count == Convert.ToInt32(para_def.Number))
                                                    {
                                                        // Each member has an Canape alias name.
                                                        split_array = true;
                                                    }
                                                    else
                                                    {
                                                        // Canape Alias name not available for each member of the array.
                                                        // This case is not available, if it occurs then the PAR XML is modified w.r.t Canape Alias
                                                        split_array = false;
                                                    }
                                                }
                                                else
                                                {
                                                    // Not an array.
                                                    split_array = false;
                                                }
                                            }

                                            // Parameter Data Type.
                                            string a2l_data_type;

                                            if (para_def.Type == "UInt8") { a2l_data_type = "UBYTE"; }
                                            else if (para_def.Type == "UInt16") { a2l_data_type = "UWORD"; }
                                            else if (para_def.Type == "UInt32") { a2l_data_type = "ULONG"; }
                                            else if (para_def.Type == "SInt8") { a2l_data_type = "SBYTE"; }
                                            else if (para_def.Type == "SInt16") { a2l_data_type = "SWORD"; }
                                            else if (para_def.Type == "SInt32") { a2l_data_type = "SLONG"; }
                                            else if (para_def.Type == "Boolean") { a2l_data_type = "UBYTE"; }
                                            else if (para_def.Type == "Bitfield8") { a2l_data_type = "UBYTE"; }
                                            else if (para_def.Type == "Bitfield16") { a2l_data_type = "UWORD"; }
                                            else if (para_def.Type == "Bitfield32") { a2l_data_type = "ULONG"; }
                                            else if (para_def.Type == "Float32") { a2l_data_type = "FLOAT"; }
                                            else { a2l_data_type = "unknown"; }

                                            // Parameter Min and Max values
                                            string min_string = para_def.Min;
                                            string max_string = para_def.Max;

                                            if (min_string == "")
                                            {
                                                // Minimum value is not provided.
                                                if (para_def.Type == "UInt8") { min_string = "0"; }
                                                else if (para_def.Type == "UInt16") { min_string = "0"; }
                                                else if (para_def.Type == "UInt32") { min_string = "0"; }
                                                else if (para_def.Type == "SInt8") { min_string = "-128"; }
                                                else if (para_def.Type == "SInt16") { min_string = "-32768"; }
                                                else if (para_def.Type == "SInt32") { min_string = "-2147483648"; }
                                                else if (para_def.Type == "Boolean") { min_string = "0"; }
                                                else if (para_def.Type == "Float32") { min_string = "-3.4028234664E38"; }
                                                else { min_string = "0"; }
                                            }
                                            if (max_string == "")
                                            {
                                                // Maximum value is not provided.
                                                if (para_def.Type == "UInt8") { max_string = "255"; }
                                                else if (para_def.Type == "UInt16") { max_string = "65535"; }
                                                else if (para_def.Type == "UInt32") { max_string = "4294967295"; }
                                                else if (para_def.Type == "SInt8") { max_string = "127"; }
                                                else if (para_def.Type == "SInt16") { max_string = "32767"; }
                                                else if (para_def.Type == "SInt32") { max_string = "2147483647"; }
                                                else if (para_def.Type == "Boolean") { max_string = "1"; }
                                                else if (para_def.Type == "Float32") { max_string = "3.4028234664E38"; }
                                                else { max_string = "0"; }
                                            }

                                            // Description about the parameter.
                                            string para_description = para_def.Description;

                                            // Variable to set A2L type to PARAMETER or PARAMETER READ_ONLY.
                                            // reload_cond -> true -> A2L Type: PARAMETER -> Changeable online.
                                            // reload_cond -> false -> A2L Type: PARAMETER READ_ONLY -> not changeable online.
                                            bool reload_cond = false;

                                            // Check whether description is available or not.
                                            if (para_description != "")
                                            {
                                                // To save the a2l error if description is greater than 250 characters.
                                                if (para_description.Length > 250)
                                                {
                                                    // Limit the description, as A2L can't parse description more than 250 characters.
                                                    para_description = para_description.Substring(0, 250);
                                                }

                                                string check_backslash = para_description.Substring(para_description.Length - 1, 1);

                                                // Check whether last character is '\' or not
                                                if (check_backslash == "\\")
                                                {
                                                    // To save the a2l error if last character of description is "\".
                                                    para_description = para_description.Substring(0, para_description.Length - 1) + "/>";
                                                }
                                                else
                                                {
                                                    // Do nothing.
                                                }

                                                // Check for reload condition only if A2L do not refer to ROM
                                                // A2L if referencing to ROM are made as PARAMETER READ_ONLY, hence check is not required.
                                                if (my_A2LforOEM == false)
                                                {
                                                    string parameter_description = para_description.ToUpper();
                                                    if (parameter_description.StartsWith("@RELOAD_COND"))
                                                    {
                                                        // Reload condition exists -> A2L Type will be PARAMETER.
                                                        // For ROM clusters A2L will be PARAMETER only if ApplicationMemory is true(i.e. refers to RAM).
                                                        if ((my_gc.A2L_AllRefersROM == "false") && (((cluster.MemoryArea == "ROM") && (my_gc.A2L_ApplicationMemory == "true")) || (cluster.MemoryArea != "ROM")))
                                                        {
                                                            reload_cond = true;
                                                        }
                                                        else
                                                        {
                                                            // A2L for ROM clusters refer to ROM. Hence A2L_TYPE is PARAMETER READ_ONLY.
                                                        }
                                                    }
                                                    else
                                                    {
                                                        // Reload condition is not available within description, A2L Type will be PARAMETER READ_ONLY.
                                                    }
                                                }
                                                else
                                                {
                                                    // A2L refers to ROM. Hence A2L Type will be PARAMETER READ_ONLY irrespective of @RELOAD_COND/cluster memory area.
                                                }
                                            }


                                            if (split_array != false)
                                            {
                                                // Parameter is of type array and each element has Canape alias name.
                                                // This code part handles arrays which have to split element wise in single signals only.
                                                int element_index;

                                                for (element_index = 0; element_index < (Convert.ToInt32(para_def.Number)); element_index++)
                                                {
                                                    // Canape Name.
                                                    string alias_string = "";

                                                    if ((max_sub_vars > 1) || (num_min_vars > 1))
                                                    {
                                                        // Cluster has Multiple Minor\ Sub \ Minor and Sub variants.
                                                        // i.e. SINGLE ( >1 Minor variant), MINOR ALL
                                                        alias_string = string.Format("{1}_{0}",
                                                                        canape_name_list[sub_var_idx + (max_sub_vars * min_var_idx)],
                                                                        para_def.CANapeAliases[element_index]);
                                                    }
                                                    else
                                                    {
                                                        // Part of code will be executed if cluster has no min/sub variant.
                                                        alias_string = string.Format("{0}", para_def.CANapeAliases[element_index]);
                                                    }

                                                    // Function to get symbol and alias name for the given parameter

                                                    // Parameters : split_array  : True -> Parameter is an array 
                                                    //              cluster      : Name of the cluster
                                                    //              para_def     : Parameter Name  
                                                    //              min_var_idx  : Current working minor variant index
                                                    //              sub_var_idx  : Current working sub variant index
                                                    //              max_sub_vars : Maximum sub varinats for the given cluster
                                                    //              my_gc        : General Configuration -> To get the settings of "A2L_UseRAMMirror", "A2L_ApplicationMemory" and "A2L_AllRefersROM".
                                                    //              my_DatasetName:To infix dataset name in the ROM/RAM structure
                                                    //              my_A2LforOEM : true -> a2l is being generated for oem in rbp_par<_dsname>_oem_a2l_gen.c
                                                    string symbol_string = Get_A2L_Symbol_Alias_Name(split_array, cluster, para_def, min_var_idx, sub_var_idx, max_sub_vars, my_gc, my_DatasetName, my_A2LforOEM);

                                                    if (wrapper_2_x.Is_para_def_enum_b(my_ps, para_def) != true)
                                                    {
                                                        // Parameter is of Basic Data types.
                                                        if (para_def.Type == "UInt8") { symbol_string += ("u8"); }
                                                        else if (para_def.Type == "UInt16") { symbol_string += ("u16"); }
                                                        else if (para_def.Type == "UInt32") { symbol_string += ("u32"); }
                                                        else if (para_def.Type == "SInt8") { symbol_string += ("s8"); }
                                                        else if (para_def.Type == "SInt16") { symbol_string += ("s16"); }
                                                        else if (para_def.Type == "SInt32") { symbol_string += ("s32"); }
                                                        else if (para_def.Type == "Boolean") { symbol_string += ("b"); }
                                                        else if (para_def.Type == "Float32") { symbol_string += ("f32"); }
                                                        else { symbol_string += ("unknown"); }
                                                    }
                                                    else
                                                    {
                                                        // Parameter is of type enumeration.
                                                        symbol_string += ("en");
                                                    }
                                                    symbol_string += string.Format("._{0}_", element_index);

                                                    writer.WriteLine("/*");
                                                    writer.WriteLine("@@ SYMBOL = {0}", symbol_string);
                                                    if (reload_cond == true)
                                                    {
                                                        writer.WriteLine("@@ A2L_TYPE = PARAMETER {0}", alias_string);
                                                    }
                                                    else
                                                    {
                                                        writer.WriteLine("@@ A2L_TYPE = PARAMETER READ_ONLY {0}", alias_string);
                                                    }
                                                    writer.WriteLine("@@ DATA_TYPE = {0} [{1} ... {2}]", a2l_data_type, min_string, max_string);
                                                    writer.WriteLine("@@ ALIAS = {0}", symbol_string);
                                                    writer.WriteLine("@@ GROUP = {0} | {0}_Parameter | {0}_Parameter_{1}", component.Name.ToUpper(), cluster.Name);

                                                    if (wrapper_2_x.Is_para_def_enum_b(my_ps, para_def) != true)
                                                    {
                                                        writer.WriteLine("@@ CONVERSION = LINEAR {0} {1} \"{2}\"",
                                                                            para_def.Resolution,
                                                                            String.Format(System.Globalization.CultureInfo.InvariantCulture, "{0:r}", Convert.ToDouble(para_def.Offset, System.Globalization.CultureInfo.InvariantCulture) * -1.0),
                                                                            para_def.Unit);
                                                    }
                                                    else
                                                    {
                                                        // Parameter is of type enumeration
                                                        // Print Table for the enumerations.
                                                        writer.Write("@@ CONVERSION = TABLE ");
                                                        wrapper_2_x.PrintA2LEnum(my_ps, para_def, writer);
                                                        writer.WriteLine("");
                                                    }

                                                    writer.WriteLine("@@ DESCRIPTION = \"{0}\"", para_description);
                                                    writer.WriteLine("@@ END");
                                                    writer.WriteLine("*/");
                                                    writer.WriteLine("");
                                                }
                                            }
                                            else
                                            {
                                                // Parameter is not an array / Parameter is of type array , with no canape alias name for each element (i.e. A2L will be provided for the first element of the array). 

                                                //! Bit fields : No used. In future there can be usage of this.
                                                int a2l_bitmask = 1;

                                                if (para_def.IsBitfield() != false)
                                                {
                                                    for (int i = 0; i < (Convert.ToInt32(para_def.Number) - 1); i++)
                                                    {
                                                        a2l_bitmask <<= 1;
                                                        a2l_bitmask += 1;
                                                    }
                                                }

                                                int bitfield_width = -1;
                                                int bitfield_count = 0;
                                                {
                                                    if (para_def.IsBitfield() != false)
                                                    {
                                                        // handle bitfield parameters

                                                        if (bitfield_width == para_def.GetBitfieldWidth())
                                                        {
                                                            // bitfield width remains the same as for the previous parameter

                                                            if ((Convert.ToInt32(bitfield_count) + Convert.ToInt32(para_def.Number)) > bitfield_width)
                                                            {
                                                                // no space left in the current bitfield

                                                                // shift bit mask
                                                                a2l_bitmask <<= 0;

                                                                // bitfield_width = unchanged
                                                                bitfield_count = Convert.ToInt32(para_def.Number);
                                                            }
                                                            else
                                                            {
                                                                // space left in the current bitfield

                                                                // shift bit mask
                                                                a2l_bitmask <<= bitfield_count;

                                                                // bitfield_width = unchanged
                                                                bitfield_count += Convert.ToInt32(para_def.Number);
                                                            }
                                                        }
                                                        else
                                                        {
                                                            // bitfield width has changed

                                                            // shift bit mask
                                                            a2l_bitmask <<= 0;

                                                            bitfield_width = para_def.GetBitfieldWidth();
                                                            bitfield_count = Convert.ToInt32(para_def.Number);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        // handle non-bitfield parameters

                                                        bitfield_width = -1;
                                                        bitfield_count = 0;
                                                    }
                                                } //! @end: Bit fields : No used. In future there can be usage of this.

                                                // Function to get symbol and alias name for the given parameter.s

                                                // Parameters : split_array  : False -> Parameter is not an array 
                                                //              cluster      : Name of the cluster
                                                //              para_def     : Parameter Name  
                                                //              min_var_idx  : Current working minor variant index
                                                //              sub_var_idx  : Current working sub variant index
                                                //              max_sub_vars : Maximum sub variants for the given cluster
                                                //              my_gc        : General Configuration -> To get the settings of "A2L_UseRAMMirror", "A2L_ApplicationMemory" and "A2L_AllRefersROM"
                                                //              my_DatasetName:To infix dataset name in the ROM/RAM structure
                                                //              my_A2LforOEM : true -> a2l is being generated for oem in rbp_par<_dsname>_oem_a2l_gen.c
                                                string symbol_string = Get_A2L_Symbol_Alias_Name(split_array, cluster, para_def, min_var_idx, sub_var_idx, max_sub_vars, my_gc, my_DatasetName, my_A2LforOEM);

                                                // Check for arrays.
                                                if ((para_def.Type != "Bitfield8") && (para_def.Type != "Bitfield16") && (para_def.Type != "Bitfield32"))
                                                {
                                                    if (Convert.ToInt32(para_def.Number) > 1)
                                                    {
                                                        // Parameter is of type array, but Canape alias name not available.
                                                        symbol_string += ("p");
                                                    }
                                                }

                                                {
                                                    string tmp_str;

                                                    if (wrapper_2_x.Is_para_def_enum_b(my_ps, para_def) != true)
                                                    {
                                                        // Parameter is of Basic Data types.
                                                        if (para_def.Type == "UInt8") { tmp_str = ("u8"); }
                                                        else if (para_def.Type == "UInt16") { tmp_str = ("u16"); }
                                                        else if (para_def.Type == "UInt32") { tmp_str = ("u32"); }
                                                        else if (para_def.Type == "SInt8") { tmp_str = ("s8"); }
                                                        else if (para_def.Type == "SInt16") { tmp_str = ("s16"); }
                                                        else if (para_def.Type == "SInt32") { tmp_str = ("s32"); }
                                                        else if (para_def.Type == "Boolean") { tmp_str = ("b"); }
                                                        else if (para_def.Type == "Bitfield8") { tmp_str = string.Format("bf{0}", para_def.Number); }
                                                        else if (para_def.Type == "Bitfield16") { tmp_str = string.Format("bf{0}", para_def.Number); }
                                                        else if (para_def.Type == "Bitfield32") { tmp_str = string.Format("bf{0}", para_def.Number); }
                                                        else if (para_def.Type == "Float32") { tmp_str = ("f32"); }
                                                        else { tmp_str = ("unknown"); }
                                                    }
                                                    else
                                                    {
                                                        // Parameter is of type enumeration.
                                                        tmp_str = ("en");
                                                    }

                                                    symbol_string += tmp_str;
                                                }

                                                // Check for arrays.
                                                if ((para_def.Type != "Bitfield8") && (para_def.Type != "Bitfield16") && (para_def.Type != "Bitfield32"))
                                                {
                                                    if (Convert.ToInt32(para_def.Number) > 1)
                                                    {
                                                        symbol_string += ("._0_");
                                                    }
                                                }

                                                string alias_string;

                                                if ((para_def.CANapeAliases.Count == 0) || ((para_def.CANapeAliases.Count == 1) && (para_def.CANapeAliases[0] == "")))
                                                {
                                                    // Executes when there is no Canape alias name/ Canape alias tag in the cluster.

                                                    if ((max_sub_vars > 1) || (num_min_vars > 1))
                                                    {
                                                        // Part of code will be executed if cluster has mutiple sub-var and one or more min var.
                                                        alias_string = string.Format("{1}_{0}_{2}",
                                                                        canape_name_list[sub_var_idx + (max_sub_vars * min_var_idx)],
                                                                        cluster.Name, para_def.Name);
                                                    }
                                                    else
                                                    {
                                                        // Part of code will be executed if cluster has no min/sub variant
                                                        alias_string = string.Format("{0}_{1}", cluster.Name, para_def.Name);
                                                    }
                                                }
                                                else
                                                {
                                                    // Executes when Canape alias name available.
                                                    if ((max_sub_vars > 1) || (num_min_vars > 1))
                                                    {
                                                        alias_string = string.Format("{1}_{0}",
                                                                        canape_name_list[sub_var_idx + (max_sub_vars * min_var_idx)],
                                                                        para_def.CANapeAliases[0]);
                                                    }
                                                    else
                                                    {
                                                        // Part of code will be executed if cluster has no min/sub variant.
                                                        alias_string = string.Format("{0}", para_def.CANapeAliases[0]);
                                                    }
                                                }

                                                // Empty string -> use the minimum value of the given data type.
                                                if (min_string == "")
                                                {
                                                    if (para_def.Type == "Bitfield8") { min_string = "0"; }
                                                    else if (para_def.Type == "Bitfield16") { min_string = "0"; }
                                                    else if (para_def.Type == "Bitfield32") { min_string = "0"; }
                                                }

                                                // Empty string -> use the maximum value of the given data type.
                                                if (max_string == "")
                                                {
                                                    if (para_def.Type == "Bitfield8") { max_string = string.Format("0x{0}", a2l_bitmask); }
                                                    else if (para_def.Type == "Bitfield16") { max_string = string.Format("0x{0}", a2l_bitmask); }
                                                    else if (para_def.Type == "Bitfield32") { max_string = string.Format("0x{0}", a2l_bitmask); }
                                                }

                                                writer.WriteLine("/*");
                                                writer.WriteLine("@@ SYMBOL = {0}", symbol_string);
                                                if (reload_cond == true)
                                                {
                                                    writer.WriteLine("@@ A2L_TYPE = PARAMETER {0}", alias_string);
                                                }
                                                else
                                                {
                                                    writer.WriteLine("@@ A2L_TYPE = PARAMETER READ_ONLY {0}", alias_string);
                                                }
                                                writer.WriteLine("@@ DATA_TYPE = {0} [{1} ... {2}]", a2l_data_type, min_string, max_string);

                                                if (para_def.IsBitfield() != false)
                                                {
                                                    // handle bitfields
                                                    // do nothing
                                                }
                                                else
                                                {
                                                    if (Convert.ToInt32(para_def.Number) > 1)
                                                    {
                                                        // Handle arrays.
                                                        writer.WriteLine("@@ DIMENSION = {0}", para_def.Number);
                                                    }
                                                    else
                                                    {
                                                        // Handle the rest.
                                                        // Do nothing.
                                                    }
                                                }

                                                writer.WriteLine("@@ ALIAS = {0}", symbol_string);
                                                writer.WriteLine("@@ GROUP = {0} | {0}_Parameter | {0}_Parameter_{1}", component.Name.ToUpper(), cluster.Name);

                                                if (wrapper_2_x.Is_para_def_enum_b(my_ps, para_def) != true)
                                                {
                                                    writer.WriteLine("@@ CONVERSION = LINEAR {0} {1} \"{2}\"",
                                                                        para_def.Resolution,
                                                                        String.Format(System.Globalization.CultureInfo.InvariantCulture, "{0:r}", Convert.ToDouble(para_def.Offset, System.Globalization.CultureInfo.InvariantCulture) * -1.0),
                                                                        para_def.Unit);
                                                }
                                                else
                                                {
                                                    // Parameter is of type enumeration.
                                                    // Print Table for the enumerations.
                                                    writer.Write("@@ CONVERSION = TABLE ");
                                                    wrapper_2_x.PrintA2LEnum(my_ps, para_def, writer);
                                                    writer.WriteLine("");
                                                }
                                                writer.WriteLine("@@ DESCRIPTION = \"{0}\"", para_description);
                                                writer.WriteLine("@@ END");
                                                writer.WriteLine("*/");
                                                writer.WriteLine("");
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            writer.WriteLine("/* PRQA L: RBP_RULE_DEV_rbp_par_main_gen_c_5 */ /*(details: see end of file)*/");
        }

        // Provides the Symbol/ Alias name for the A2L variable.
        public string Get_A2L_Symbol_Alias_Name(bool split_array,
                                                     cParameterCluster cluster,
                                                     cParameterDefinition para_def,
                                                     int min_var_idx,
                                                     int sub_var_idx,
                                                     int max_sub_vars,
                                                     cGeneralConfiguration my_gc,
                                                     string my_DatasetName,
                                                     bool my_A2LforOEM)
        {
            string symbol_string = "";

            if (my_A2LforOEM == false)
            {
                if (my_gc.A2L_AllRefersROM == "false")
                {
                    // A2L reference depends on cluster memory area and A2L_UseRAMMirror and A2L_ApplicationMemory tag configurations.
                    if ((cluster.MemoryArea == "ROM") && (my_gc.A2L_UseRAMMirror == "false"))
                    {
                        //! Part of code for A2L with and without Application memory.
                        if ((my_gc.A2L_ApplicationMemory == "true"))
                        {
                            // Application mode is ON.
                            // A2L variable symbols for ROM clusters. Provide ApplicationMemory structure as application mode is ON.
                            if ((cluster.VariantApplication.ToUpper() == "SINGLE") || (cluster.VariantApplication.ToUpper() == "MINOR_ALL"))
                            {
                                symbol_string = string.Format("rbp_par{3}_ApplicationMemory_st.{0}_pst._{1}_.{2}_",
                                                        cluster.Name, (sub_var_idx + (max_sub_vars * min_var_idx)), para_def.Name, my_DatasetName);
                            }
                        }
                        else
                        {
                            // Application mode is OFF.
                            // A2L varible symbol for ROM cluster. Provide ROMData structure as application mode is OFF.
                            if ((cluster.VariantApplication.ToUpper() == "SINGLE") || (cluster.VariantApplication.ToUpper() == "MINOR_ALL"))
                            {
                                // SINGLE | MINOR_ALL
                                symbol_string = string.Format("rbp_par{3}_ROMData_st.ParameterMemoryROM_st.{0}_pst._{1}_.{2}_",
                                            cluster.Name, (sub_var_idx + (max_sub_vars * min_var_idx)), para_def.Name, my_DatasetName);
                            }
                        }
                    }
                    else
                    {
                        // Do nothing, A2L Variables will be generated for RAM_INIT and NVM_INIT Clusters.
                    }

                    // Irrespective of my_gc.A2L_UseRAMMirror state , A2L symbol variable will be provided for RAM_INIT and NVM_INIT clusters.
                    if (cluster.MemoryArea == "NVM_INIT")
                    {
                        // A2L variable symbol for NVM_INIT clusters.
                        symbol_string = string.Format("rbp_par_NVM_MirrorData_st.ParameterMemoryNVM_RAM_Mirror_st.{0}_pst._{1}_.{2}_",
                                                        cluster.Name, (sub_var_idx + (max_sub_vars * min_var_idx)), para_def.Name);
                    }
                    else if (cluster.MemoryArea == "RAM_INIT")
                    {
                        // A2L variable symbol for RAM_INIT clusters.
                        symbol_string = string.Format("rbp_par_RAM_INIT_MirrorData_st.ParameterMemoryRAM_INIT_Mirror_st.{0}_pst._{1}_.{2}_",
                                                    cluster.Name, (sub_var_idx + (max_sub_vars * min_var_idx)), para_def.Name);
                    }
                }
                else // my_gc.A2L_AllRefersROM is 'true')
                {
                    // A2L variable symbol irrespective of cluster memory area referencing ROMData
                    if ((cluster.VariantApplication.ToUpper() == "SINGLE") || (cluster.VariantApplication.ToUpper() == "MINOR_ALL"))
                    {
                        // SINGLE | MINOR_ALL
                        symbol_string = string.Format("rbp_par{3}_ROMData_st.ParameterMemoryROM_st.{0}_pst._{1}_.{2}_",
                                    cluster.Name, (sub_var_idx + (max_sub_vars * min_var_idx)), para_def.Name, my_DatasetName);
                    }
                }
            }
            else // my_A2LforOEM is true)
            {
                // A2L variable symbol irrespective of cluster memory area referencing ROMData
                if ((cluster.VariantApplication.ToUpper() == "SINGLE") || (cluster.VariantApplication.ToUpper() == "MINOR_ALL"))
                {
                    // SINGLE | MINOR_ALL
                    symbol_string = string.Format("rbp_par{3}_ROMData_st.ParameterMemoryROM_st.{0}_pst._{1}_.{2}_",
                                cluster.Name, (sub_var_idx + (max_sub_vars * min_var_idx)), para_def.Name, my_DatasetName);
                }
            }

            if (split_array != false)
            {
                // Paramter is of type array, Suffix add "p".
                symbol_string += "p";
            }
            else
            {
                // Do nothing.
            }

            return symbol_string;
        }

        /// <summary>
        /// PrintGenOemA2L function generates a new .c file containing only A2L comments for parameters visible to customers and referencing to ROM. <br />
        /// File name: rbp_par_oem_a2l_gen.c -> USS product line, NRCS 'SINGLE' dataset run and NRCS 'MULTIPLE' dataset overall run. <br />
        /// File name: rbp_par<_dsx>_oem_a2l_gen.c -> NRCS 'MULTIPLE' dataset individual run where dsx refers to selected dataset name.
        /// </summary>
        /// <param name="my_ps">Reference to Parameter set.</param>
        /// <param name="my_ps_file_name">Reference to Input file name.</param>
        /// <param name="my_output_path">Output path for the generated file.</param>
        /// <param name="my_FileName_Suffix">Suffix to be appended in file name to distinguish files containing different datasets.</param>
        /// <param name="my_dt">Reference for date and time.</param>
        /// <param name="my_gc">Reference for general configuration.</param>
        /// <param name="my_DatasetName">Selected Dataset Name</param>
        public void PrintGenOemA2L(ref cParameterSet my_ps,
                                               ref String my_ps_file_name,
                                               String my_output_path,
                                               string my_FileName_Suffix,
                                               ref DateTime my_dt,
                                               ref cGeneralConfiguration my_gc,
                                               string my_DatasetName)
        {
            Program my_program = new Program();
            string my_gen_file_name = "rbp_par" + my_FileName_Suffix + "_oem_a2l_gen.c";
            string my_source_file_name = "ParaServer.cs";

            // Overwrite the output path if already exists.
            my_program.OverwriteOPPath(ref my_gc, ref my_output_path, my_gen_file_name);

            // Generated file header.
            my_program.PrintFileInfo(ref my_ps, ref my_ps_file_name, my_output_path, ref my_dt, my_gen_file_name, my_source_file_name);

            // Obtain absolute path of output file.
            var genFileNamePath = Path.Combine(Path.GetFullPath(my_output_path), my_gen_file_name);

            // Open output file.
            var writer = Program.CreateStreamWriter(genFileNamePath, true, Encoding.ASCII);

            writer.WriteLine("// ! make component private variables and functions visible");
            writer.WriteLine("#define RBP_COMPONENT_PAR");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Magic number                                                           -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#define RBP_PAR_OEM_A2L_MAGIC_NUMBER_GEN  0x{0:d2}{1:d2}{2:d2}{3:d2}", my_dt.Month, my_dt.Day, my_dt.Hour, my_dt.Minute);
            writer.WriteLine("");

            writer.WriteLine("// This file contains A2L variable definitions for parameters visible to customers(references ROM).");
            writer.WriteLine("// This file is not meant to be read by the C compiler and must not contain C-code. Comments only!");
            writer.WriteLine("");

            bool A2LforOEM = true;

            if ((my_gc.Product_Line == "USS") || ((my_gc.DisableVariantMismatchCheck != "true") && (my_gc.Product_Line == "NRCS")))
            {
                PrintA2L(ref my_ps, ref writer, ref my_dt, ref my_gc, my_DatasetName, A2LforOEM);
                //this statement should not be inside the condition. This is only an exception for DAI project. to be removed in future asap TODO:. 
            }

            writer.WriteLine("/*========================= EoF (rbp_par{0}_oem_a2l_gen.c) ===========*/", my_FileName_Suffix);
            writer.WriteLine("");

            // Close output file.
            writer.Close();
        }
    }
}