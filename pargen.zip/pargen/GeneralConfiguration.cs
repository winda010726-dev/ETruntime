using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;


namespace parsrv
{
    // General configuration.
    [XmlRoot("GeneralConfiguration")]
    public class cGeneralConfiguration
    {
        // Parameter input files.
        private List<string> my_input_files;

        // NEC-Fx3 size of the data flash section.
        private string my_ST_CHORUS_DataFlash_SectionSize;

        // NEC-Fx3 data flash offset.
        private string my_ST_CHORUS_DataFlash_Offset;

        // NEC-Fx3 output path of the RAW- and XML-file.
        private string my_ST_CHORUS_DataFlash_OutputPath;

        // NEC-Fx4 include the ref-hash in the data flash.
        private string my_ST_CHORUS_DataFlash_EnableRefHash;

        // Selection of CAL Hash Computation with/without Defines.
        private string my_CAL_HASH_COMPATIBILITY;

        // Selection of CAL Hash Computation with/without Defines.
        private string my_NVM_HASH_COMPATIBILITY;

        // Endianness selection.
        private string my_ST_CHORUS_Endianness;

        // Mode (eg. PF or GM - depends on the project).
        private string my_ST_CHORUS_CALSection_Mode;

        // Output path of the generated CAL-section.
        private string my_ST_CHORUS_CALSection_OutputPath;

        // Version string in the info section of the CAL-section.
        private string my_ST_CHORUS_CALSection_Version;

        // Start address of the CAL-section.
        private string my_ST_CHORUS_CALSection_StartAddress;

        // Size of the CAL-section.
        private string my_ST_CHORUS_CALSection_Size;

        // Fill byte for empty areas of the CAL-section.
        private string my_ST_CHORUS_CALSection_FillByte;

        // Structure alignment.
        private string my_ST_CHORUS_CALSection_StructureAlignment;

        // Text to change the structure alignment to the above value.
        private string my_ST_CHORUS_CALSection_StructureAlignmentBegin;

        // Text to change the structure alignment back to its default value.
        private string my_ST_CHORUS_CALSection_StructureAlignmentEnd;

        // Support flash test section.
        private string my_ST_CHORUS_CALSection_SupportFlashTestSection;

        // Support block status section.
        private string my_ST_CHORUS_CALSection_SupportBlockStatusSection;

        // Configurable block status size.
        private string my_ST_CHORUS_CALSection_SupportBlockStatusSize;

        // Support Header Low section.
        private string my_ST_CHORUS_CALSection_SupportHeaderLow;

        // Configurable Header Low size.
        private string my_ST_CHORUS_CALSection_HeaderLowSize;

        // CAL Header Low Content.
        private string my_ST_CHORUS_CALSection_HeaderLowContent;

        // Support Header High section.
        private string my_ST_CHORUS_CALSection_SupportHeaderHigh;

        // Configurable Header High size.
        private string my_ST_CHORUS_CALSection_HeaderHighSize;

        // CAL Header High Content.
        private string my_ST_CHORUS_CALSection_HeaderHighContent;

        // Support PSI Valid section.
        private string my_ST_CHORUS_CALSection_SupportPSIValid;

        // Configurable PSI Valid size.
        private string my_ST_CHORUS_CALSection_PSIValidSize;

        // Support CUS Security Header Low section.
        private string my_ST_CHORUS_CALSection_Support_CUS_SecurityHeaderLow;

        // Configurable CUS Security Header Low size.
        private string my_ST_CHORUS_CALSection_CUS_SecurityHeaderLowSize;

        //  CUS Security Header Low Content.
        private string my_ST_CHORUS_CALSection_CUS_SecurityHeaderLowContent;

        // Support CUS Security Header High section.
        private string my_ST_CHORUS_CALSection_Support_CUS_SecurityHeaderHigh;

        // Configurable CUS Security Header High size.
        private string my_ST_CHORUS_CALSection_CUS_SecurityHeaderHighSize;

        //  CUS Security Header High Content.
        private string my_ST_CHORUS_CALSection_CUS_SecurityHeaderHighContent;

        // Flag to throw Warning/Error for Structure Holes.
        private string my_Structure_Holes_Flag; 

        //Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - Start
        //Change of memory Layout of CRC FlsTst Block in ParGen
        // Version1 supports 24 bytes and version2 supports 20 bytes.
        private string my_ST_CHORUS_CALSection_FlsTst_CRC_Memory_Layout;
        //Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - End

        // Output path of the PAR-code (template(s) and configuration files).
        private string my_Code_OutputPath;

        // NVM-Shadow-RAM is defined outside the PAR-component.
        private string my_Code_ExternalNVMRAMBuffer;

        // Output path of the log files.
        private string my_Log_OutputPath;

        // Option to determine whether the A2L comments shall be genearted for only RAM_INIT and NVM_INIT clusters (saves RAM) or not.
        private string my_A2L_UseRAMMirror;
        
        // Option to determine whether the A2L comments for ROM clusters reference the Application memory structure or ROM Data structure.
        private string my_A2L_ApplicationMemory;

        // Option to set A2L comments reference to ROM Data structure.
        private string my_A2L_AllRefersROM;
        
        // Option to enable or disable padding in the raw xml used for NRCS.
        private string my_RawDataStructurePadding;

        // Used for selecting the way cluster records are generated in raw xml.
        private string my_RawRecordFormat;

        // Product line the pargen tool is used for. 
        private string my_Product_Line;

        // Option to determine whether the parameters are being generated for SINGLE or MULTIPLE dataset.
        private string my_DataSet_Type;

        // Option to select value to be updated in <Type> tag in my_ps structure for 2.0 and 2.1.
        private string my_Enum_Type;

        // Option to enable or disable minor/sub variant mismatch check.
        private string my_DisableVariantMismatchCheck;

        // Enable/Disable RB Secure Flash.
        private string my_RB_Secure_Flash;

        // Option to select the signature for INDIVIDUAL(CAL) or COMBINED Block (CAL + APPL) 
        private string my_RB_Secure_Block;

        // Length of Secure Block 
        private string my_RB_Secure_Block_Length;

        // Number of certificates 
        private string my_ST_No_of_Certificates;

        // RB Secure Flash PKI Structure.

        // Structure ID : 0x11
        private string my_ST_Structure_ID;
        
        // Certificate Type : 0x01.
        private string my_ST_Certificate_Type;

        // Signature Type : 0x01;
        private string my_ST_Signature_Type;

        // Authorization Flag : 0x22.
        private string my_ST_Authorization_Flag;

        // Authorization Object ID. 
        private string my_ST_Authorization_Obj_ID;

        // CAL Certificate length. 
        private string my_ST_CAL_Certificate_Length;

        // CAL Signature length.
        private string my_ST_CAL_Signature_Length;

        // Address of CAL PKI Entry point 
        private string my_ST_CAL_PKIStructureStart;
        

        [XmlArray("InputFiles")]
        [XmlArrayItem("File")]
        public List<string> InputFiles
        {
            get { return my_input_files; }
            set { my_input_files = value; }
        }

        [XmlElement("ST_CHORUS_DataFlash_SectionSize")]
        public string ST_CHORUS_DataFlash_SectionSize
        {
            get { return my_ST_CHORUS_DataFlash_SectionSize; }
            set { my_ST_CHORUS_DataFlash_SectionSize = value; }
        }

        [XmlElement("ST_CHORUS_DataFlash_Offset")]
        public string ST_CHORUS_DataFlash_Offset
        {
            get { return my_ST_CHORUS_DataFlash_Offset; }
            set { my_ST_CHORUS_DataFlash_Offset = value; }
        }

        [XmlElement("ST_CHORUS_DataFlash_OutputPath")]
        public string ST_CHORUS_DataFlash_OutputPath
        {
            get { return my_ST_CHORUS_DataFlash_OutputPath; }
            set { my_ST_CHORUS_DataFlash_OutputPath = value; }
        }

        [XmlElement("ST_CHORUS_DataFlash_EnableRefHash")]
        public string ST_CHORUS_DataFlash_EnableRefHash
        {
            get { return my_ST_CHORUS_DataFlash_EnableRefHash; }
            set { my_ST_CHORUS_DataFlash_EnableRefHash = value; }
        }

        [XmlElement("CAL_HASH_COMPATIBILITY")]
        public string CAL_HASH_COMPATIBILITY
        {
            get { return my_CAL_HASH_COMPATIBILITY; }
            set { my_CAL_HASH_COMPATIBILITY = value; }
        }

        [XmlElement("NVM_HASH_COMPATIBILITY")]
        public string NVM_HASH_COMPATIBILITY
        {
            get { return my_NVM_HASH_COMPATIBILITY; }
            set { my_NVM_HASH_COMPATIBILITY = value; }
        }

        [XmlElement("ST_CHORUS_Endianness")]
        public string ST_CHORUS_Endianness
        {
            get { return my_ST_CHORUS_Endianness; }
            set { my_ST_CHORUS_Endianness = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_Mode")]
        public string ST_CHORUS_CALSection_Mode
        {
            get { return my_ST_CHORUS_CALSection_Mode; }
            set { my_ST_CHORUS_CALSection_Mode = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_OutputPath")]
        public string ST_CHORUS_CALSection_OutputPath
        {
            get { return my_ST_CHORUS_CALSection_OutputPath; }
            set { my_ST_CHORUS_CALSection_OutputPath = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_Version")]
        public string ST_CHORUS_CALSection_Version
        {
            get { return my_ST_CHORUS_CALSection_Version; }
            set { my_ST_CHORUS_CALSection_Version = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_StartAddress")]
        public string ST_CHORUS_CALSection_StartAddress
        {
            get { return my_ST_CHORUS_CALSection_StartAddress; }
            set { my_ST_CHORUS_CALSection_StartAddress = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_Size")]
        public string ST_CHORUS_CALSection_Size
        {
            get { return my_ST_CHORUS_CALSection_Size; }
            set { my_ST_CHORUS_CALSection_Size = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_FillByte")]
        public string ST_CHORUS_CALSection_FillByte
        {
            get { return my_ST_CHORUS_CALSection_FillByte; }
            set { my_ST_CHORUS_CALSection_FillByte = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_StructureAlignment")]
        public string ST_CHORUS_CALSection_StructureAlignment
        {
            get { return my_ST_CHORUS_CALSection_StructureAlignment; }
            set { my_ST_CHORUS_CALSection_StructureAlignment = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_StructureAlignmentBegin")]
        public string ST_CHORUS_CALSection_StructureAlignmentBegin
        {
            get { return my_ST_CHORUS_CALSection_StructureAlignmentBegin; }
            set { my_ST_CHORUS_CALSection_StructureAlignmentBegin = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_StructureAlignmentEnd")]
        public string ST_CHORUS_CALSection_StructureAlignmentEnd
        {
            get { return my_ST_CHORUS_CALSection_StructureAlignmentEnd; }
            set { my_ST_CHORUS_CALSection_StructureAlignmentEnd = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_SupportFlashTestSection")]
        public string ST_CHORUS_CALSection_SupportFlashTestSection
        {
            get { return my_ST_CHORUS_CALSection_SupportFlashTestSection; }
            set { my_ST_CHORUS_CALSection_SupportFlashTestSection = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_SupportBlockStatusSection")]
        public string ST_CHORUS_CALSection_SupportBlockStatusSection
        {
            get { return my_ST_CHORUS_CALSection_SupportBlockStatusSection; }
            set { my_ST_CHORUS_CALSection_SupportBlockStatusSection = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_SupportBlockStatusSize")]
        public string ST_CHORUS_CALSection_SupportBlockStatusSize
        {
            get { return my_ST_CHORUS_CALSection_SupportBlockStatusSize; }
            set { my_ST_CHORUS_CALSection_SupportBlockStatusSize = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_SupportHeaderLow")]
        public string ST_CHORUS_CALSection_SupportHeaderLow
        {
            get { return my_ST_CHORUS_CALSection_SupportHeaderLow; }
            set { my_ST_CHORUS_CALSection_SupportHeaderLow = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_HeaderLowSize")]
        public string ST_CHORUS_CALSection_HeaderLowSize
        {
            get { return my_ST_CHORUS_CALSection_HeaderLowSize; }
            set { my_ST_CHORUS_CALSection_HeaderLowSize = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_HeaderLowContent")]
        public string ST_CHORUS_CALSection_HeaderLowContent
        {
            get { return my_ST_CHORUS_CALSection_HeaderLowContent; }
            set { my_ST_CHORUS_CALSection_HeaderLowContent = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_SupportHeaderHigh")]
        public string ST_CHORUS_CALSection_SupportHeaderHigh
        {
            get { return my_ST_CHORUS_CALSection_SupportHeaderHigh; }
            set { my_ST_CHORUS_CALSection_SupportHeaderHigh = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_HeaderHighSize")]
        public string ST_CHORUS_CALSection_HeaderHighSize
        {
            get { return my_ST_CHORUS_CALSection_HeaderHighSize; }
            set { my_ST_CHORUS_CALSection_HeaderHighSize = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_HeaderHighContent")]
        public string ST_CHORUS_CALSection_HeaderHighContent
        {
            get { return my_ST_CHORUS_CALSection_HeaderHighContent; }
            set { my_ST_CHORUS_CALSection_HeaderHighContent = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_SupportPSIValid")]
        public string ST_CHORUS_CALSection_SupportPSIValid
        {
            get { return my_ST_CHORUS_CALSection_SupportPSIValid; }
            set { my_ST_CHORUS_CALSection_SupportPSIValid = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_PSIValidSize")]
        public string ST_CHORUS_CALSection_PSIValidSize
        {
            get { return my_ST_CHORUS_CALSection_PSIValidSize; }
            set { my_ST_CHORUS_CALSection_PSIValidSize = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_Support_CUS_SecurityHeaderLow")]
        public string ST_CHORUS_CALSection_Support_CUS_SecurityHeaderLow
        {
            get { return my_ST_CHORUS_CALSection_Support_CUS_SecurityHeaderLow; }
            set { my_ST_CHORUS_CALSection_Support_CUS_SecurityHeaderLow = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_CUS_SecurityHeaderLowSize")]
        public string ST_CHORUS_CALSection_CUS_SecurityHeaderLowSize
        {
            get { return my_ST_CHORUS_CALSection_CUS_SecurityHeaderLowSize; }
            set { my_ST_CHORUS_CALSection_CUS_SecurityHeaderLowSize = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_CUS_SecurityHeaderLowContent")]
        public string ST_CHORUS_CALSection_CUS_SecurityHeaderLowContent
        {
            get { return my_ST_CHORUS_CALSection_CUS_SecurityHeaderLowContent; }
            set { my_ST_CHORUS_CALSection_CUS_SecurityHeaderLowContent = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_Support_CUS_SecurityHeaderHigh")]
        public string ST_CHORUS_CALSection_Support_CUS_SecurityHeaderHigh
        {
            get { return my_ST_CHORUS_CALSection_Support_CUS_SecurityHeaderHigh; }
            set { my_ST_CHORUS_CALSection_Support_CUS_SecurityHeaderHigh = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_CUS_SecurityHeaderHighSize")]
        public string ST_CHORUS_CALSection_CUS_SecurityHeaderHighSize
        {
            get { return my_ST_CHORUS_CALSection_CUS_SecurityHeaderHighSize; }
            set { my_ST_CHORUS_CALSection_CUS_SecurityHeaderHighSize = value; }
        }

        [XmlElement("ST_CHORUS_CALSection_CUS_SecurityHeaderHighContent")]
        public string ST_CHORUS_CALSection_CUS_SecurityHeaderHighContent
        {
            get { return my_ST_CHORUS_CALSection_CUS_SecurityHeaderHighContent; }
            set { my_ST_CHORUS_CALSection_CUS_SecurityHeaderHighContent = value; }
        }

        //Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - Start
        //Change of memory Layout of CRC FlsTst Block in ParGen
        //version1 supports 24 bytes and version2 supports 20 bytes
        [XmlElement("ST_CHORUS_CALSection_FlsTst_CRC_Memory_Layout")]
        public string ST_CHORUS_CALSection_FlsTst_CRC_Memory_Layout
        {
            get { return my_ST_CHORUS_CALSection_FlsTst_CRC_Memory_Layout; }
            set { my_ST_CHORUS_CALSection_FlsTst_CRC_Memory_Layout = value; }
        }
        //Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - End


        [XmlElement("Code_OutputPath")]
        public string Code_OutputPath
        {
            get { return my_Code_OutputPath; }
            set { my_Code_OutputPath = value; }
        }

        [XmlElement("Structure_Holes_Flag")]
        public string Structure_Holes_Flag
        {
            get { return my_Structure_Holes_Flag; }
            set { my_Structure_Holes_Flag = value; }
        }

        [XmlElement("Code_ExternalNVMRAMBuffer")]
        public string Code_ExternalNVMRAMBuffer
        {
            get { return my_Code_ExternalNVMRAMBuffer; }
            set { my_Code_ExternalNVMRAMBuffer = value; }
        }

        [XmlElement("Log_OutputPath")]
        public string Log_OutputPath
        {
            get { return my_Log_OutputPath; }
            set { my_Log_OutputPath = value; }
        }

        [XmlElement("A2L_UseRAMMirror")]
        public string A2L_UseRAMMirror
        {
            get { return my_A2L_UseRAMMirror; }
            set { my_A2L_UseRAMMirror = value; }
        }

        [XmlElement("A2L_ApplicationMemory")]
        public string A2L_ApplicationMemory
        {
            get { return my_A2L_ApplicationMemory; }
            set { my_A2L_ApplicationMemory = value; }
        }

        [XmlElement("A2L_AllRefersROM")]
        public string A2L_AllRefersROM
        {
            get { return my_A2L_AllRefersROM; }
            set { my_A2L_AllRefersROM = value; }
        }

        [XmlElement("RawDataStructurePadding")]
        public string RawDataStructurePadding
        {
            get { return my_RawDataStructurePadding; }
            set { my_RawDataStructurePadding = value; }
        }

        [XmlElement("RawRecordFormat")]
        public string RawRecordFormat
        {
            get { return my_RawRecordFormat; }
            set { my_RawRecordFormat = value; }
        }

        [XmlElement("Product_Line")]
        public string Product_Line
        {
            get { return my_Product_Line; }
            set { my_Product_Line = value; }
        }

        [XmlElement("DataSet_Type")]
        public string DataSet_Type
        {
            get { return my_DataSet_Type; }
            set { my_DataSet_Type = value; }
        }

        [XmlElement("Enum_Type")]
        public string Enum_Type
        {
            get { return my_Enum_Type; }
            set { my_Enum_Type = value; }
        }

        [XmlElement("DisableVariantMismatchCheck")]
        public string DisableVariantMismatchCheck
        {
            get { return my_DisableVariantMismatchCheck; }
            set { my_DisableVariantMismatchCheck = value; }
        }

        [XmlElement("RB_Secure_Flash")]
        public string RB_Secure_Flash
        {
            get { return my_RB_Secure_Flash; }
            set { my_RB_Secure_Flash = value; }
        }

        [XmlElement("RB_Secure_Block")]
        public string RB_Secure_Block
        {
            get { return my_RB_Secure_Block; }
            set { my_RB_Secure_Block = value; }
        }

        [XmlElement("RB_Secure_Block_Length")]
        public string RB_Secure_Block_Length
        {
            get { return my_RB_Secure_Block_Length; }
            set { my_RB_Secure_Block_Length = value; }
        }

        [XmlElement("ST_No_of_Certificates")]
        public string ST_No_of_Certificates
        {
            get { return my_ST_No_of_Certificates; }
            set { my_ST_No_of_Certificates = value; }
        }
        
        [XmlElement("ST_Structure_ID")]
        public string ST_Structure_ID
        {
            get { return my_ST_Structure_ID; }
            set { my_ST_Structure_ID = value; }
        }
        
        [XmlElement("ST_Certificate_Type")]
        public string ST_Certificate_Type
        {
            get { return my_ST_Certificate_Type; }
            set { my_ST_Certificate_Type = value; }
        }
        
        [XmlElement("ST_Signature_Type")]
        public string ST_Signature_Type
        {
            get { return my_ST_Signature_Type; }
            set { my_ST_Signature_Type = value; }
        }

        [XmlElement("ST_Authorization_Flag")]
        public string ST_Authorization_Flag
        {
            get { return my_ST_Authorization_Flag; }
            set { my_ST_Authorization_Flag = value; }
        }

        [XmlElement("ST_Authorization_Obj_ID")]
        public string ST_Authorization_Obj_ID
        {
            get { return my_ST_Authorization_Obj_ID; }
            set { my_ST_Authorization_Obj_ID = value; }
        }
       
        [XmlElement("ST_CAL_Certificate_Length")]
        public string ST_CAL_Certificate_Length
        {
            get { return my_ST_CAL_Certificate_Length; }
            set { my_ST_CAL_Certificate_Length = value; }
        }
       
        [XmlElement("ST_CAL_Signature_Length")]
        public string ST_CAL_Signature_Length
        {
            get { return my_ST_CAL_Signature_Length; }
            set { my_ST_CAL_Signature_Length = value; }
        }

        [XmlElement("ST_CAL_PKIStructureStart")]
        public string ST_CAL_PKIStructureStart
        {
            get { return my_ST_CAL_PKIStructureStart; }
            set { my_ST_CAL_PKIStructureStart = value; }
        }
        
        // Default constructor.
        public cGeneralConfiguration()
        {
            this.my_input_files = new List<string>();
            this.my_ST_CHORUS_DataFlash_SectionSize = "0x16000";
            this.my_ST_CHORUS_DataFlash_Offset = "0x0000";
            this.my_ST_CHORUS_DataFlash_OutputPath = "";
            this.my_ST_CHORUS_DataFlash_EnableRefHash = "false";
            this.my_CAL_HASH_COMPATIBILITY = "HASH_WITH_DEFINES";
            this.my_NVM_HASH_COMPATIBILITY = "HASH_WITH_DEFINES";
            this.my_ST_CHORUS_Endianness = "BIG";
            this.my_ST_CHORUS_CALSection_Mode = "PF";
            this.my_ST_CHORUS_CALSection_OutputPath = "";
            this.my_ST_CHORUS_CALSection_Version = "CP2.0 Test";
            this.my_ST_CHORUS_CALSection_StartAddress = "0x0000";
            this.my_ST_CHORUS_CALSection_Size = "0x4000";
            this.my_ST_CHORUS_CALSection_FillByte = "0x00";
            this.my_ST_CHORUS_CALSection_StructureAlignment = "4";
            this.my_ST_CHORUS_CALSection_StructureAlignmentBegin = "#pragma ghs struct_min_alignment(4)";
            this.my_ST_CHORUS_CALSection_StructureAlignmentEnd = "#pragma ghs struct_min_alignment()";
            this.my_ST_CHORUS_CALSection_SupportFlashTestSection = "true";
            this.my_ST_CHORUS_CALSection_SupportBlockStatusSection = "true";
            this.my_ST_CHORUS_CALSection_SupportBlockStatusSize = "0x20";
            this.my_ST_CHORUS_CALSection_SupportHeaderLow = "false";
            this.my_ST_CHORUS_CALSection_HeaderLowSize = "0x00";
            this.my_ST_CHORUS_CALSection_HeaderLowContent = "0xFF";
            this.my_ST_CHORUS_CALSection_SupportHeaderHigh = "false";
            this.my_ST_CHORUS_CALSection_HeaderHighSize = "0x00";
            this.my_ST_CHORUS_CALSection_HeaderHighContent = "0xFF";
            this.my_ST_CHORUS_CALSection_SupportPSIValid = "false";
            this.my_ST_CHORUS_CALSection_PSIValidSize = "0x00";
            this.my_ST_CHORUS_CALSection_Support_CUS_SecurityHeaderLow = "false";
            this.my_ST_CHORUS_CALSection_CUS_SecurityHeaderLowSize = "0x00";
            this.my_ST_CHORUS_CALSection_CUS_SecurityHeaderLowContent = "0xFF";
            this.my_ST_CHORUS_CALSection_Support_CUS_SecurityHeaderHigh = "false";
            this.my_ST_CHORUS_CALSection_CUS_SecurityHeaderHighSize = "0x00";
            this.my_ST_CHORUS_CALSection_CUS_SecurityHeaderHighContent = "0xFF";
            this.my_Structure_Holes_Flag = "false";
            this.my_RawDataStructurePadding = "NO";
            this.my_RawRecordFormat = "cluster_array";
            this.my_Product_Line = "USS";
            this.my_DataSet_Type = "SINGLE";
            this.my_Enum_Type = "short_enum";
            this.my_DisableVariantMismatchCheck = "false";

            //Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - Start
            //Change of memory Layout of CRC FlsTst Block in ParGen
            //version1 supports 24 bytes and version2 supports 20 bytes
            this.my_ST_CHORUS_CALSection_FlsTst_CRC_Memory_Layout = "";
            //Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - End

            this.my_Code_OutputPath = "";
            // <Code_ExternalNVMRAMBuffer> tag is removed from the configuration xml, 
            // since currently there is no usecase for it.
            // Code related to this part is retained in the source files.
            // In future if required the tag can be provided to the user in the configuration xml.
            this.my_Code_ExternalNVMRAMBuffer = "false"; 
            this.my_Log_OutputPath = "";
            this.my_A2L_UseRAMMirror = "false";
            this.my_A2L_ApplicationMemory = "true";
            this.my_A2L_AllRefersROM = "false";

            // RB Secure flash.
            this.my_RB_Secure_Flash = "false";
            this.my_RB_Secure_Block = "INDIVIDUAL";
            this.my_RB_Secure_Block_Length = "0x00";
            this.my_ST_No_of_Certificates = "0x01";
            this.my_ST_Structure_ID = "0x01";
            this.my_ST_Certificate_Type = "0x01";
            this.my_ST_Signature_Type = "0x11";
            this.my_ST_Authorization_Flag = "0x22";
            this.my_ST_Authorization_Obj_ID = "0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF";
            this.my_ST_CAL_PKIStructureStart = "0x00FFFFFF";
            this.my_ST_CAL_Certificate_Length = "0x400";
            this.my_ST_CAL_Signature_Length = "0x100";
        }

        // Parameterized constructor.
        public cGeneralConfiguration(List<string> new_input_files,
                                      string new_ST_CHORUS_DataFlash_SectionSize,
                                      string new_ST_CHORUS_DataFlash_Offset,
                                      string new_ST_CHORUS_DataFlash_OutputPath,
                                      string new_ST_CHORUS_DataFlash_EnableRefHash,
                                      string new_CAL_HASH_COMPATIBILITY,
                                      string new_NVM_HASH_COMPATIBILITY,
                                      string new_ST_CHORUS_Endianness,
                                      string new_ST_CHORUS_CALSection_Mode,
                                      string new_ST_CHORUS_CALSection_OutputPath,
                                      string new_ST_CHORUS_CALSection_Version,
                                      string new_ST_CHORUS_CALSection_StartAddress,
                                      string new_ST_CHORUS_CALSection_Size,
                                      string new_ST_CHORUS_CALSection_FillByte,
                                      string new_ST_CHORUS_CALSection_StructureAlignment,
                                      string new_ST_CHORUS_CALSection_StructureAlignmentBegin,
                                      string new_ST_CHORUS_CALSection_StructureAlignmentEnd,
                                      string new_ST_CHORUS_CALSection_SupportFlashTestSection,
                                      string new_ST_CHORUS_CALSection_SupportBlockStatusSection,
                                      string new_ST_CHORUS_CALSection_SupportBlockStatusSize,
                                      string new_ST_CHORUS_CALSection_SupportHeaderLow,
                                      string new_ST_CHORUS_CALSection_HeaderLowSize,
                                      string new_ST_CHORUS_CALSection_HeaderLowContent,
                                      string new_ST_CHORUS_CALSection_SupportHeaderHigh,
                                      string new_ST_CHORUS_CALSection_HeaderHighSize,
                                      string new_ST_CHORUS_CALSection_HeaderHighContent,
                                      string new_ST_CHORUS_CALSection_Support_CUS_SecurityHeaderLow,
                                      string new_ST_CHORUS_CALSection_CUS_SecurityHeaderLowSize,
                                      string new_ST_CHORUS_CALSection_CUS_SecurityHeaderLowContent,
                                      string new_ST_CHORUS_CALSection_Support_CUS_SecurityHeaderHigh,
                                      string new_ST_CHORUS_CALSection_CUS_SecurityHeaderHighSize,
                                      string new_ST_CHORUS_CALSection_CUS_SecurityHeaderHighContent,
                                      string new_ST_CHORUS_CALSection_SupportPSIValid,
                                      string new_ST_CHORUS_CALSection_PSIValidSize,
                                      string new_ST_CHORUS_CALSection_FlsTst_CRC_Memory_Layout, 
                                      string new_Code_OutputPath,
                                      string new_Code_ExternalNVMRAMBuffer,
                                      string new_Log_OutputPath,
                                      string new_A2L_UseRAMMirror,
                                      string new_A2L_ApplicationMemory,
                                      string new_A2L_AllRefersROM,
                                      string new_RawDataStructurePadding,
                                      string new_RawRecordFormat,
                                      string new_Product_Line,
                                      string new_DataSet_Type,
                                      string new_Structure_Holes_Flag,
                                      string new_Enum_Type,
                                      string new_DisableVariantMismatchCheck,
                                      string new_RB_Secure_Flash,
                                      string new_RB_Secure_Block,
                                      string new_RB_Secure_Block_Length,
                                      string new_ST_No_of_Certificates,
                                      string new_ST_Structure_ID,
                                      string new_ST_Certificate_Type,
                                      string new_ST_Signature_Type,
                                      string new_ST_Autorization_Flag,
                                      string new_ST_Autorization_Obj_ID,
                                      string new_ST_CAL_PKIStructureStart,
                                      string new_ST_CAL_Certificate_Length,
                                      string new_ST_CAL_Signature_Length  )
        {
            this.my_input_files = new_input_files;
            this.my_ST_CHORUS_DataFlash_SectionSize = new_ST_CHORUS_DataFlash_SectionSize;
            this.my_ST_CHORUS_DataFlash_Offset = new_ST_CHORUS_DataFlash_Offset;
            this.my_ST_CHORUS_DataFlash_OutputPath = new_ST_CHORUS_DataFlash_OutputPath;
            this.my_ST_CHORUS_DataFlash_EnableRefHash = new_ST_CHORUS_DataFlash_EnableRefHash;
            this.my_CAL_HASH_COMPATIBILITY = new_CAL_HASH_COMPATIBILITY;
            this.my_NVM_HASH_COMPATIBILITY = new_NVM_HASH_COMPATIBILITY;
            this.my_ST_CHORUS_Endianness = new_ST_CHORUS_Endianness;
            this.my_ST_CHORUS_CALSection_Mode = new_ST_CHORUS_CALSection_Mode;
            this.my_ST_CHORUS_CALSection_OutputPath = new_ST_CHORUS_CALSection_OutputPath;
            this.my_ST_CHORUS_CALSection_Version = new_ST_CHORUS_CALSection_Version;
            this.my_ST_CHORUS_CALSection_StartAddress = new_ST_CHORUS_CALSection_StartAddress;
            this.my_ST_CHORUS_CALSection_Size = new_ST_CHORUS_CALSection_Size;
            this.my_ST_CHORUS_CALSection_FillByte = new_ST_CHORUS_CALSection_FillByte;

            this.my_ST_CHORUS_CALSection_StructureAlignment = new_ST_CHORUS_CALSection_StructureAlignment;
            this.my_ST_CHORUS_CALSection_StructureAlignmentBegin = new_ST_CHORUS_CALSection_StructureAlignmentBegin;
            this.my_ST_CHORUS_CALSection_StructureAlignmentEnd = new_ST_CHORUS_CALSection_StructureAlignmentEnd;
            this.my_ST_CHORUS_CALSection_SupportFlashTestSection = new_ST_CHORUS_CALSection_SupportFlashTestSection;
            
            // Configurable flash section.
            this.my_ST_CHORUS_CALSection_SupportBlockStatusSection = new_ST_CHORUS_CALSection_SupportBlockStatusSection;
            this.my_ST_CHORUS_CALSection_SupportBlockStatusSize = new_ST_CHORUS_CALSection_SupportBlockStatusSize;
            this.my_ST_CHORUS_CALSection_SupportHeaderLow = new_ST_CHORUS_CALSection_SupportHeaderLow;
            this.my_ST_CHORUS_CALSection_HeaderLowSize = new_ST_CHORUS_CALSection_HeaderLowSize;
            this.my_ST_CHORUS_CALSection_HeaderLowContent = new_ST_CHORUS_CALSection_HeaderLowContent;
            this.my_ST_CHORUS_CALSection_SupportHeaderHigh = new_ST_CHORUS_CALSection_SupportHeaderHigh;
            this.my_ST_CHORUS_CALSection_HeaderHighSize =new_ST_CHORUS_CALSection_HeaderHighSize;
            this.my_ST_CHORUS_CALSection_HeaderHighContent = new_ST_CHORUS_CALSection_HeaderHighContent;
            this.my_ST_CHORUS_CALSection_SupportPSIValid = new_ST_CHORUS_CALSection_SupportPSIValid;
            this.my_ST_CHORUS_CALSection_PSIValidSize = new_ST_CHORUS_CALSection_PSIValidSize;
            this.my_ST_CHORUS_CALSection_Support_CUS_SecurityHeaderLow = new_ST_CHORUS_CALSection_Support_CUS_SecurityHeaderLow;
            this.my_ST_CHORUS_CALSection_CUS_SecurityHeaderLowSize = new_ST_CHORUS_CALSection_CUS_SecurityHeaderLowSize;
            this.my_ST_CHORUS_CALSection_CUS_SecurityHeaderLowContent = new_ST_CHORUS_CALSection_CUS_SecurityHeaderLowContent;
            this.my_ST_CHORUS_CALSection_Support_CUS_SecurityHeaderHigh = new_ST_CHORUS_CALSection_Support_CUS_SecurityHeaderHigh;
            this.my_ST_CHORUS_CALSection_CUS_SecurityHeaderHighSize = new_ST_CHORUS_CALSection_CUS_SecurityHeaderHighSize;
            this.my_ST_CHORUS_CALSection_CUS_SecurityHeaderHighContent = new_ST_CHORUS_CALSection_CUS_SecurityHeaderHighContent;

            //Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - Start
            //Change of memory Layout of CRC FlsTst Block in ParGen
            //version1 supports 24 bytes and version2 supports 20 bytes
            this.my_ST_CHORUS_CALSection_FlsTst_CRC_Memory_Layout = new_ST_CHORUS_CALSection_FlsTst_CRC_Memory_Layout;
            //Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - End

            this.my_Code_OutputPath = new_Code_OutputPath;
            this.my_Code_ExternalNVMRAMBuffer = new_Code_ExternalNVMRAMBuffer;
            this.my_Log_OutputPath = new_Log_OutputPath;
            this.my_A2L_UseRAMMirror = new_A2L_UseRAMMirror;
            this.my_A2L_ApplicationMemory = new_A2L_ApplicationMemory;
            this.my_A2L_AllRefersROM = new_A2L_AllRefersROM;
            this.my_RawDataStructurePadding = new_RawDataStructurePadding;
            this.my_RawRecordFormat = new_RawRecordFormat;
            this.my_Product_Line = new_Product_Line;
            this.my_DataSet_Type = new_DataSet_Type;
            this.my_Structure_Holes_Flag = new_Structure_Holes_Flag;
            this.my_Enum_Type = new_Enum_Type;
            this.my_DisableVariantMismatchCheck = new_DisableVariantMismatchCheck;

            // RB Secure Flash.
             this.my_RB_Secure_Flash = new_RB_Secure_Flash;
             this.my_RB_Secure_Block = new_RB_Secure_Block;
             this.my_RB_Secure_Block_Length = new_RB_Secure_Block_Length;
             this.my_ST_No_of_Certificates = new_ST_No_of_Certificates;
             this.my_ST_Structure_ID = new_ST_Structure_ID;
             this.my_ST_Certificate_Type = new_ST_Certificate_Type;
             this.my_ST_Signature_Type = new_ST_Signature_Type;
             this.my_ST_Authorization_Flag = new_ST_Autorization_Flag;
             this.my_ST_Authorization_Obj_ID = new_ST_Autorization_Obj_ID;
             this.my_ST_CAL_PKIStructureStart = new_ST_CAL_PKIStructureStart;
             this.my_ST_CAL_Certificate_Length = new_ST_CAL_Certificate_Length;
             this.my_ST_CAL_Signature_Length = new_ST_CAL_Signature_Length;
        }
    }
}
