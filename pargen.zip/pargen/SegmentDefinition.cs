using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;


namespace parsrv
{
    // Target memory segements.
    // (list of text snippets to be inserted before and after the respective variables to relocate them in the correct memory segment).

    [XmlRoot("SegmentDefinition")]
    public class cSegmentDefinition
    {
        // CAL-section Header low data (ROM).
        private List<string> my_cal_low_begin; 
        private List<string> my_cal_low_end;

        // CAL-section CUS Security Header Low (ROM)
        private List<string> my_cal_cus_sechdrlow_begin;
        private List<string> my_cal_cus_sechdrlow_end;

        // CAL-section data (ROM).
        private List<string> my_cal_data_begin;
        private List<string> my_cal_data_end;

        // CAL-section Header high data (ROM).
        private List<string> my_cal_high_begin;
        private List<string> my_cal_high_end;

        // CAL-section CUS Security Header High (ROM)
        private List<string> my_cal_cus_sechdrhigh_begin;
        private List<string> my_cal_cus_sechdrhigh_end;

        // CAL Block status (ROM).
        private List<string> my_bock_status_begin; 
        private List<string> my_bock_status_end;

        // CAL Flash test (ROM).
        private List<string> my_flash_test_begin; 
        private List<string> my_flash_test_end;

        // Data memory (RAM).
        private List<string> my_par_data_ram_begin; 
        private List<string> my_par_data_ram_end;

        // Application memory (RAM).
        private List<string> my_par_appl_ram_begin; 
        private List<string> my_par_appl_ram_end;

        // NVM memory (RAM).
        private List<string> my_nvm_saved_zone_begin;
        private List<string> my_nvm_saved_zone_end;

        // CAL-section reference hash.
        private List<string> my_par_ref_hash_begin; 
        private List<string> my_par_ref_hash_end;

        // CAL RBPKI Reference Structure.
        private List<string> my_cal_rbpki_reference_begin;
        private List<string> my_cal_rbpki_reference_end;

        // CAL RBPKI Structure.
        private List<string> my_cal_rbpki_CertInfo_begin;
        private List<string> my_cal_rbpki_CertInfo_end;

        // CAL Certificate.
        private List<string> my_cal_certificate_begin;
        private List<string> my_cal_certificate_end;

        // CAL Signature.
        private List<string> my_cal_signature_begin;
        private List<string> my_cal_signature_end;

        [XmlArray("CALLowBegin")]
        [XmlArrayItem("Line")]
        public List<string> CALLowBegin
        {
            get { return my_cal_low_begin; }
            set { my_cal_low_begin = value; }
        }

        [XmlArray("CALLowEnd")]
        [XmlArrayItem("Line")]
        public List<string> CALLowEnd
        {
            get { return my_cal_low_end; }
            set { my_cal_low_end = value; }
        }

        [XmlArray("CAL_CUS_SecHdrLowBegin")]
        [XmlArrayItem("Line")]
        public List<string> CAL_CUS_SecHdrLowBegin
        {
            get { return my_cal_cus_sechdrlow_begin; }
            set { my_cal_cus_sechdrlow_begin = value; }
        }

        [XmlArray("CAL_CUS_SecHdrLowEnd")]
        [XmlArrayItem("Line")]
        public List<string> CAL_CUS_SecHdrLowEnd
        {
            get { return my_cal_cus_sechdrlow_end; }
            set { my_cal_cus_sechdrlow_end = value; }
        }

        [XmlArray("CALDataBegin")]
        [XmlArrayItem("Line")]
        public List<string> CALDataBegin
        {
            get { return my_cal_data_begin; }
            set { my_cal_data_begin = value; }
        }

        [XmlArray("CALDataEnd")]
        [XmlArrayItem("Line")]
        public List<string> CALDataEnd
        {
            get { return my_cal_data_end; }
            set { my_cal_data_end = value; }
        }

        [XmlArray("CALHighBegin")]
        [XmlArrayItem("Line")]
        public List<string> CALHighBegin
        {
            get { return my_cal_high_begin; }
            set { my_cal_high_begin = value; }
        }

        [XmlArray("CALHighEnd")]
        [XmlArrayItem("Line")]
        public List<string> CALHighEnd
        {
            get { return my_cal_high_end; }
            set { my_cal_high_end = value; }
        }

        [XmlArray("CAL_CUS_SecHdrHighBegin")]
        [XmlArrayItem("Line")]
        public List<string> CAL_CUS_SecHdrHighBegin
        {
            get { return my_cal_cus_sechdrhigh_begin; }
            set { my_cal_cus_sechdrhigh_begin = value; }
        }

        [XmlArray("CAL_CUS_SecHdrHighEnd")]
        [XmlArrayItem("Line")]
        public List<string> CAL_CUS_SecHdrHighEnd
        {
            get { return my_cal_cus_sechdrhigh_end; }
            set { my_cal_cus_sechdrhigh_end = value; }
        }

        [XmlArray("BlockStatusBegin")]
        [XmlArrayItem("Line")]
        public List<string> BlockStatusBegin
        {
            get { return my_bock_status_begin; }
            set { my_bock_status_begin = value; }
        }

        [XmlArray("BlockStatusEnd")]
        [XmlArrayItem("Line")]
        public List<string> BlockStatusEnd
        {
            get { return my_bock_status_end; }
            set { my_bock_status_end = value; }
        }

        [XmlArray("FlashTestBegin")]
        [XmlArrayItem("Line")]
        public List<string> FlashTestBegin
        {
            get { return my_flash_test_begin; }
            set { my_flash_test_begin = value; }
        }

        [XmlArray("FlashTestEnd")]
        [XmlArrayItem("Line")]
        public List<string> FlashTestEnd
        {
            get { return my_flash_test_end; }
            set { my_flash_test_end = value; }
        }

        [XmlArray("NVMSavedZoneBegin")]
        [XmlArrayItem("Line")]
        public List<string> NVMSavedZoneBegin
        {
            get { return my_nvm_saved_zone_begin; }
            set { my_nvm_saved_zone_begin = value; }
        }

        [XmlArray("NVMSavedZoneEnd")]
        [XmlArrayItem("Line")]
        public List<string> NVMSavedZoneEnd
        {
            get { return my_nvm_saved_zone_end; }
            set { my_nvm_saved_zone_end = value; }
        }

        [XmlArray("CAL_RBPKI_RefBegin")]
        [XmlArrayItem("Line")]
        public List<string> CAL_RBPKI_RefBegin
        {
            get { return my_cal_rbpki_reference_begin; }
            set { my_cal_rbpki_reference_begin = value; }
        }

        [XmlArray("CAL_RBPKI_RefEnd")]
        [XmlArrayItem("Line")]
        public List<string> CAL_RBPKI_RefEnd
        {
            get { return my_cal_rbpki_reference_end; }
            set { my_cal_rbpki_reference_end = value; }
        }

        [XmlArray("CAL_RBPKI_CertInfoBegin")]
        [XmlArrayItem("Line")]
        public List<string> CAL_RBPKI_CertInfoBegin
        {
            get { return my_cal_rbpki_CertInfo_begin; }
            set { my_cal_rbpki_CertInfo_begin = value; }
        }

        [XmlArray("CAL_RBPKI_CertInfoEnd")]
        [XmlArrayItem("Line")]
        public List<string> CAL_RBPKI_CertInfoEnd
        {
            get { return my_cal_rbpki_CertInfo_end; }
            set { my_cal_rbpki_CertInfo_end = value; }
        }

        [XmlArray("CAL_RBPKI_CertificateBegin")]
        [XmlArrayItem("Line")]
        public List<string> CAL_RBPKI_CertificateBegin
        {
            get { return my_cal_certificate_begin; }
            set { my_cal_certificate_begin = value; }
        }

        [XmlArray("CAL_RBPKI_CertificateEnd")]
        [XmlArrayItem("Line")]
        public List<string> CAL_RBPKI_CertificateEnd
        {
            get { return my_cal_certificate_end; }
            set { my_cal_certificate_end = value; }
        }

        [XmlArray("CAL_RBPKI_SignatureBegin")]
        [XmlArrayItem("Line")]
        public List<string> CAL_RBPKI_SignatureBegin
        {
            get { return my_cal_signature_begin; }
            set { my_cal_signature_begin = value; }
        }

        [XmlArray("CAL_RBPKI_SignatureEnd")]
        [XmlArrayItem("Line")]
        public List<string> CAL_RBPKI_SignatureEnd
        {
            get { return my_cal_signature_end; }
            set { my_cal_signature_end = value; }
        }

        [XmlArray("ParDataRAMBegin")]
        [XmlArrayItem("Line")]
        public List<string> ParDataRAMBegin
        {
            get { return my_par_data_ram_begin; }
            set { my_par_data_ram_begin = value; }
        }

        [XmlArray("ParDataRAMEnd")]
        [XmlArrayItem("Line")]
        public List<string> ParDataRAMEnd
        {
            get { return my_par_data_ram_end; }
            set { my_par_data_ram_end = value; }
        }

        [XmlArray("ParApplRAMBegin")]
        [XmlArrayItem("Line")]
        public List<string> ParApplRAMBegin
        {
            get { return my_par_appl_ram_begin; }
            set { my_par_appl_ram_begin = value; }
        }

        [XmlArray("ParApplRAMEnd")]
        [XmlArrayItem("Line")]
        public List<string> ParApplRAMEnd
        {
            get { return my_par_appl_ram_end; }
            set { my_par_appl_ram_end = value; }
        }

        [XmlArray("ParRefHashBegin")]
        [XmlArrayItem("Line")]
        public List<string> ParRefHashBegin
        {
            get { return my_par_ref_hash_begin; }
            set { my_par_ref_hash_begin = value; }
        }

        [XmlArray("ParRefHashEnd")]
        [XmlArrayItem("Line")]
        public List<string> ParRefHashEnd
        {
            get { return my_par_ref_hash_end; }
            set { my_par_ref_hash_end = value; }
        }

        // Default Constructor.
        public cSegmentDefinition()
        {
            this.my_cal_low_begin = new List<string>();
            this.my_cal_low_end = new List<string>();
            this.my_cal_cus_sechdrlow_begin = new List<string>();
            this.my_cal_cus_sechdrlow_end = new List<string>();
            this.my_cal_data_begin = new List<string>();
            this.my_cal_data_end = new List<string>();
            this.my_cal_high_begin = new List<string>();
            this.my_cal_high_end = new List<string>();
            this.my_cal_cus_sechdrhigh_begin = new List<string>();
            this.my_cal_cus_sechdrhigh_end = new List<string>();
            this.my_bock_status_begin = new List<string>();
            this.my_bock_status_end = new List<string>();
            this.my_flash_test_begin = new List<string>();
            this.my_flash_test_end = new List<string>();
            this.my_par_data_ram_begin = new List<string>();
            this.my_par_data_ram_end = new List<string>();
            this.my_par_appl_ram_begin = new List<string>();
            this.my_par_appl_ram_end = new List<string>();
            this.my_par_ref_hash_begin = new List<string>();
            this.my_par_ref_hash_end = new List<string>();
        }

        // Paramterized constructor.
        public cSegmentDefinition(List<string> new_cal_low_begin,
                                   List<string> new_cal_low_end,
                                   List<string> new_cal_cus_sechdrlow_begin,
                                   List<string> new_cal_cus_sechdrlow_end,
                                   List<string> new_cal_data_begin,
                                   List<string> new_cal_data_end,
                                   List<string> new_cal_high_begin,
                                   List<string> new_cal_high_end,
                                   List<string> new_cal_cus_sechdrhigh_begin,
                                   List<string> new_cal_cus_sechdrhigh_end,
                                   List<string> new_bock_status_begin,
                                   List<string> new_bock_status_end,
                                   List<string> new_flash_test_begin,
                                   List<string> new_flash_test_end,
                                   List<string> new_par_data_ram_begin,
                                   List<string> new_par_data_ram_end,
                                   List<string> new_par_appl_ram_begin,
                                   List<string> new_par_appl_ram_end,
                                   List<string> new_par_ref_hash_begin,
                                   List<string> new_par_ref_hash_end)
        {
            this.my_cal_low_begin = new_cal_low_begin;
            this.my_cal_low_end = new_cal_low_end;
            this.my_cal_cus_sechdrlow_begin = new_cal_cus_sechdrlow_begin;
            this.my_cal_cus_sechdrlow_end = new_cal_cus_sechdrlow_end;
            this.my_cal_data_begin = new_cal_data_begin;
            this.my_cal_data_end = new_cal_data_end;
            this.my_cal_high_begin = new_cal_high_begin;
            this.my_cal_high_end = new_cal_high_end;
            this.my_cal_cus_sechdrhigh_begin = new_cal_cus_sechdrhigh_begin;
            this.my_cal_cus_sechdrhigh_end = new_cal_cus_sechdrhigh_end;
            this.my_bock_status_begin = new_bock_status_begin;
            this.my_bock_status_end = new_bock_status_end;
            this.my_flash_test_begin = new_flash_test_begin;
            this.my_flash_test_end = new_flash_test_end;
            this.my_par_data_ram_begin = new_par_data_ram_begin;
            this.my_par_data_ram_end = new_par_data_ram_end;
            this.my_par_appl_ram_begin = new_par_appl_ram_begin;
            this.my_par_appl_ram_end = new_par_appl_ram_end;
            this.my_par_ref_hash_begin = new_par_ref_hash_begin;
            this.my_par_ref_hash_end = new_par_ref_hash_end;
        }
    }
}
