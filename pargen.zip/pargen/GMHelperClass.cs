/*****************************************************************************
 | C O P Y R I G H T
 |-----------------------------------------------------------------------------
 | Copyright (c) 2009 by Robert Bosch GmbH.                All rights reserved.
 |
 | This file is property of Robert Bosch GmbH. Any unauthorised copy, use or
 | distribution is an offensive act against international law and may me
 | prosecuted under federal law. Its content is company confidential.
 |-----------------------------------------------------------------------------
 | D E S C R I P T I O N
 |-----------------------------------------------------------------------------
 | $ProjectName: d:/MKS_Data/Projects/PC/PP_NEC_PF_DEV/PAR/TOOLS/pargen/pargen.pj $
 |      $Source: GMHelperClass.cs $
 |    $Revision: 1.1 $
 |        $Date: 2016/03/08 15:53:46IST $
 |       $State: in_work $
 |
 |      Purpose: pargen - tool to generate the parameter component configuration for Gen 6 GM Projects
 |-----------------------------------------------------------------------------
 | I N F O
 |-----------------------------------------------------------------------------
 | -
 *****************************************************************************/

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Text.RegularExpressions;
using System.Security.Cryptography;
using System.Globalization;

namespace parsrv
{
    // GM Configuration.
    [XmlRoot("GMConfiguration")]
    public class cGMConfiguration
    {
        // IntegrityWord.
        private string my_IntegrityWord;

        // ConfigOptions.
        private string my_ConfigOptions;

        // ModuleID.
        private string my_ModuleID;

        // CCID.
        private string my_CCID;

        // DLS.
        private string my_DLS;

        // HEXPartNo.
        private string my_HEXPartNo;

        // IntegrityWord.
        [XmlElement("IntegrityWord")]
        public string IntegrityWord
        {
            get { return my_IntegrityWord; }
            set { my_IntegrityWord = value; }
        }

        // ConfigOptions.
        [XmlElement("ConfigOptions")]
        public string ConfigOptions
        {
            get { return my_ConfigOptions; }
            set { my_ConfigOptions = value; }
        }

        // ModuleID.
        [XmlElement("ModuleID")]
        public string ModuleID
        {
            get { return my_ModuleID; }
            set { my_ModuleID = value; }
        }

        // CCID.
        [XmlElement("CCID")]
        public string CCID
        {
            get { return my_CCID; }
            set { my_CCID = value; }
        }

        // DLS.
        [XmlElement("DLS")]
        public string DLS
        {
            get { return my_DLS; }
            set { my_DLS = value; }
        }

        // HEXPartNo.
        [XmlElement("HEXPartNo")]
        public string HEXPartNo
        {
            get { return my_HEXPartNo; }
            set { my_HEXPartNo = value; }
        }

        // Default Constructor.
        public cGMConfiguration()
        {
            this.my_IntegrityWord = "0x11AA";
            this.my_ConfigOptions = "0x0000";
            this.my_ModuleID = "0x0002";
            this.my_CCID = "0x8F06";
            this.my_DLS = "0x4141";
            this.my_HEXPartNo = "0x00CC15BC";
        }

        // Parameterized Constructor.
        public cGMConfiguration(string new_IntegrityWord,
                                   string new_ConfigOptions,
                                   string new_ModuleID,
                                   string new_CCID,
                                   string new_DLS,
                                   string new_HEXPartNo)
        {
            this.my_IntegrityWord = new_IntegrityWord;
            this.my_ConfigOptions = new_ConfigOptions;
            this.my_ModuleID = new_ModuleID;
            this.my_CCID = new_CCID;
            this.my_DLS = new_DLS;
            this.my_HEXPartNo = new_HEXPartNo;
        }
    }

    public class GMHelperClass
    {
        // PrintGenHeader extension method for GM.
        public static void printGenHeaderGM_1(ref StreamWriter writer)
        {
            writer.WriteLine("typedef struct  rbp_Tag_par_GMCALHeaderLow_st");
            writer.WriteLine("{");
            writer.WriteLine("  UInt8 IntegrityWord_pui8[2];");
            writer.WriteLine("  UInt8 ConfigOptions_pui8[2];");
            writer.WriteLine("  UInt8 ModuleID_pui8[2];");
            writer.WriteLine("  UInt8 CCID_pui8[2];");
            writer.WriteLine("  UInt8 DLS_pui8[2];");
            writer.WriteLine("  UInt8 HEXPartNo_pui8[4];");
            //Modified kby5kor, Oct.08.2015
            //18 bytes to 2
            writer.WriteLine("  UInt8 Reserved_pui8[2];");
            writer.WriteLine("}");
            writer.WriteLine("rbp_Type_par_GMCALHeaderLow_st;");
            writer.WriteLine("");
        }

        // CAL header low structure declaration.
        public static void printGenHeaderGM_2(ref StreamWriter writer)
        {
            writer.WriteLine("#if ( (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE) || (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_CAL_ONLY) )");
            writer.WriteLine("  extern const rbp_Type_par_GMCALHeaderLow_st rbp_par_GMCALHeaderLow_st;");
            writer.WriteLine("#endif");
            writer.WriteLine("");
        }

        // CAL Header Low in rbp_par_main_gen.c
        public static void printGenMainGM_1(ref StreamWriter writer, ref cGMConfiguration my_gmc)
        {
            int x;

            writer.WriteLine("const rbp_Type_par_GMCALHeaderLow_st rbp_par_GMCALHeaderLow_st =");
            writer.WriteLine("{");

            // IntegrityWord.
            x = int.Parse(my_gmc.IntegrityWord.Remove(0, 2), NumberStyles.AllowHexSpecifier);
            writer.WriteLine("  {{ 0x{0:x2}, 0x{1:x2} }}, // UInt8 IntegrityWord_pui8[2];", ((x >> 8) % 256), ((x >> 0) % 256));

            // ConfigOptions.
            x = int.Parse(my_gmc.ConfigOptions.Remove(0, 2), NumberStyles.AllowHexSpecifier);
            writer.WriteLine("  {{ 0x{0:x2}, 0x{1:x2} }}, // UInt8 ConfigOptions_pui8[2];", ((x >> 8) % 256), ((x >> 0) % 256));

            // ModuleID.
            x = int.Parse(my_gmc.ModuleID.Remove(0, 2), NumberStyles.AllowHexSpecifier);
            writer.WriteLine("  {{ 0x{0:x2}, 0x{1:x2} }}, // UInt8 ModuleID_pui8[2];", ((x >> 8) % 256), ((x >> 0) % 256));

            // CCID.
            x = int.Parse(my_gmc.CCID.Remove(0, 2), NumberStyles.AllowHexSpecifier);
            writer.WriteLine("  {{ 0x{0:x2}, 0x{1:x2} }}, // UInt8 CCID_pui8[2];", ((x >> 8) % 256), ((x >> 0) % 256));

            // DLS.
            x = int.Parse(my_gmc.DLS.Remove(0, 2), NumberStyles.AllowHexSpecifier);
            writer.WriteLine("  {{ 0x{0:x2}, 0x{1:x2} }}, // UInt8 DLS_pui8[2];", ((x >> 8) % 256), ((x >> 0) % 256));

            // HEXPartNo.
            x = int.Parse(my_gmc.HEXPartNo.Remove(0, 2), NumberStyles.AllowHexSpecifier);
            writer.WriteLine("  {{ 0x{0:x2}, 0x{1:x2}, 0x{2:x2}, 0x{3:x2} }}, // UInt8 HEXPartNo_pui8[4];", 
                                            ((x >> 24) % 256), ((x >> 16) % 256), ((x >> 8) % 256), ((x >> 0) % 256));

            //Modified kby5kor, Oct.08.2015
            //writer.WriteLine("  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 } // UInt8 Reserved_pui8[18];");

            // Reserved 2 bytes.
            writer.WriteLine("  { 0, 0 } // UInt8 Reserved_pui8[2];");
            writer.WriteLine("};");

            writer.WriteLine("");
        }

        // 16 bytes of GM header in the beginning of CAL.hex.
        public static void printGen_NEC_CAL_SectionGM_1(ref cNECFx3_CALSectionHelper my_output_helper, ref cGMConfiguration my_gmc, ref cGeneralConfiguration my_gc)
        {
            int x;

            // IntegrityWord.
            x = int.Parse(my_gmc.IntegrityWord.Remove(0, 2), NumberStyles.AllowHexSpecifier);
            my_output_helper.Add(1, ((x >> 8) % 256), my_gc.ST_CHORUS_Endianness);
            my_output_helper.Add(1, ((x >> 0) % 256), my_gc.ST_CHORUS_Endianness);

            // ConfigOptions.
            x = int.Parse(my_gmc.ConfigOptions.Remove(0, 2), NumberStyles.AllowHexSpecifier);
            my_output_helper.Add(1, ((x >> 8) % 256), my_gc.ST_CHORUS_Endianness);
            my_output_helper.Add(1, ((x >> 0) % 256), my_gc.ST_CHORUS_Endianness);

            // ModuleID.
            x = int.Parse(my_gmc.ModuleID.Remove(0, 2), NumberStyles.AllowHexSpecifier);
            my_output_helper.Add(1, ((x >> 8) % 256), my_gc.ST_CHORUS_Endianness);
            my_output_helper.Add(1, ((x >> 0) % 256), my_gc.ST_CHORUS_Endianness);

            // CCID.
            x = int.Parse(my_gmc.CCID.Remove(0, 2), NumberStyles.AllowHexSpecifier);
            my_output_helper.Add(1, ((x >> 8) % 256), my_gc.ST_CHORUS_Endianness);
            my_output_helper.Add(1, ((x >> 0) % 256), my_gc.ST_CHORUS_Endianness);

            // DLS.
            x = int.Parse(my_gmc.DLS.Remove(0, 2), NumberStyles.AllowHexSpecifier);
            my_output_helper.Add(1, ((x >> 8) % 256), my_gc.ST_CHORUS_Endianness);
            my_output_helper.Add(1, ((x >> 0) % 256), my_gc.ST_CHORUS_Endianness);

            // HEXPartNo.
            x = int.Parse(my_gmc.HEXPartNo.Remove(0, 2), NumberStyles.AllowHexSpecifier);
            my_output_helper.Add(1, ((x >> 24) % 256), my_gc.ST_CHORUS_Endianness);
            my_output_helper.Add(1, ((x >> 16) % 256), my_gc.ST_CHORUS_Endianness);
            my_output_helper.Add(1, ((x >> 8) % 256), my_gc.ST_CHORUS_Endianness);
            my_output_helper.Add(1, ((x >> 0) % 256), my_gc.ST_CHORUS_Endianness);

            //Modified kby5kor, Oct.08.2015
            //Modified from 18 to 2 bytes
            // reserved - 18 bytes

            // Reserved 2 bytes.
            for (int i = 0; i < 2; i++)
            {
                my_output_helper.Add(1, 0xFF, my_gc.ST_CHORUS_Endianness);
            }

            //Modified kby5kor, Oct.08.2015
            //Cal size is 16 bytes, so not required to fillup sector size
            // fill up (sector size 256 bytes)
            //for (int i = 0; i < (256 - 32); i++)
            //{
            //    my_output_helper.Add(1, 0xFF, my_gc.ST_CHORUS_Endianness);
            //}    
        }

        // GM header section in the beginning, add 16 bytes more to the start address.
        public static void printGen_NEC_CAL_SectionGM_2(ref int start_adr)
        {
            //Modified kby5kor, Oct.08.2015
            //cal header changed from 256 to 16 bytes
            start_adr += 16; // "GM header" section at the beginning
        }

        // Generate the file gen_nec_cal_section_gm_cal_data.hex.
        public static void printGen_NEC_CAL_SectionGM_3(string my_output_path, ref cNECFx3_CALSectionHelper my_output_helper, ref cGeneralConfiguration my_gc)
        {
            var outputPath = Path.Combine(Path.GetFullPath(my_output_path), "gen_nec_cal_section_gm_cal_data.hex");
            // Delete old file automatically if existing.
            {
                try
                {
                    Program.FileDelete(outputPath);
                }
                catch
                {
                    // Do not care about exceptions.
                }
            }

            {
                // Open output file.
                var writer = Program.CreateStreamWriter(outputPath, false, Encoding.ASCII);
                Console.WriteLine("generating: {0}", outputPath);

                // Write the intel hex file.
                {
                    cIntelHexWriter my_hex_writer = new cIntelHexWriter();

                    // Always start at address 0.
                    // First line in hex file.
                    my_hex_writer.OutputStart(ref writer, 0, my_gc.ST_CHORUS_Endianness); 

                    {
                        // Skip the GM header.
                        int current_offset = 256;
                        int current_length = 0;

                        // Linewise output (32 data bytes per line).
                        while (current_offset < my_output_helper.Values.Count)
                        {
                            if ((my_output_helper.Values.Count - current_offset) >= 32)
                            {
                                current_length = 32;
                            }
                            else
                            {
                                current_length = my_output_helper.Values.Count - current_offset;
                            }

                            // Write data into hex.
                            my_hex_writer.OutputData(ref writer,
                                                      0 + current_offset - 256, // <- Always start at address 0.
                                                      my_output_helper.Values,
                                                      current_offset,
                                                      current_length,
                                                      my_gc.ST_CHORUS_Endianness);

                            current_offset += current_length;
                        }
                    }

                    // Last line in hex file.
                    my_hex_writer.OutputEnd(ref writer);
                }

                // debugging output
                //foreach (int value in my_output_helper.Values)
                //{
                //  writer.WriteLine("{0}", value);
                //}

                // Close output file.
                writer.Close();
            }
        }

        // Generate the file gen_nec_cal_section_gm_header.hex.
        public static void printGen_NEC_CAL_SectionGM_4(string my_output_path, ref cNECFx3_CALSectionHelper my_output_helper, ref cGeneralConfiguration my_gc)
        {
            var outputPath = Path.Combine(Path.GetFullPath(my_output_path), "gen_nec_cal_section_gm_header.hex");
            // Delete old file automatically if existing.
            {
                try
                {
                    Program.FileDelete(outputPath);
                }
                catch
                {
                    // Do not care about exceptions.
                }
            }

            {
                // Open output file.
                var writer = Program.CreateStreamWriter(outputPath, false, Encoding.ASCII);
                Console.WriteLine("generating: {0}", outputPath);

                // Write the intel hex file.
                {
                    cIntelHexWriter my_hex_writer = new cIntelHexWriter();

                    // Always start at address 0.
                    // First line in hex file.
                    my_hex_writer.OutputStart(ref writer, 0, my_gc.ST_CHORUS_Endianness); 

                    {
                        // Skip the crc.
                        int current_offset = 0; 
                        int current_length = 0;
                        // Sector size - crc size.
                        int output_length = 256 - 2; 

                        // Linewise output (32 data bytes per line).
                        while (current_offset < output_length)
                        {
                            if ((output_length - current_offset) >= 32)
                            {
                                current_length = 32;
                            }
                            else
                            {
                                current_length = output_length - current_offset;
                            }

                            // Write data into hex.
                            my_hex_writer.OutputData(ref writer,
                                                      current_offset,
                                                      my_output_helper.Values,
                                                      current_offset + 2,
                                                      current_length,
                                                      my_gc.ST_CHORUS_Endianness);

                            current_offset += current_length;
                        }
                    }

                    /*
                    {
                      if ( my_output_helper.Values.Count > 32)
                      {
                        my_hex_writer.OutputData (ref writer,
                                                  0, // <- always start at address 0
                                                  my_output_helper.Values,
                                                  2, // <- skip crc
                                                  30); // do not write the crc at the beginning (32 - 2) = 30
                      }
                    }
                     */

                    // Last line in hex file.
                    my_hex_writer.OutputEnd(ref writer);
                }

                // debugging output
                //foreach (int value in my_output_helper.Values)
                //{
                //  writer.WriteLine("{0}", value);
                //}

                // Close output file.
                writer.Close();
            }
        }
    }
}
