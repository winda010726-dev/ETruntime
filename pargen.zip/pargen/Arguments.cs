using System;
using System.Collections.Specialized;
using System.Text.RegularExpressions;

namespace parsrv
{
    // A helper class to parse and evaluate the command line arguments.
    public class Arguments
    {
        // Variables.
        private StringDictionary Parameters;

        // Parameterised Constructor.
        public Arguments(string[] Args)
        {
            // Dictionary to store the argumets passed as key and values.
            Parameters = new StringDictionary();

            string Parameter = null;
            string[] Parts;

            // Regex class -> Regular expression class.
            // Splitter object to split if any of the below characters available within the passed arguments.
            Regex Spliter = new Regex(@"^-{1,2}|^/|=|:", RegexOptions.IgnoreCase | RegexOptions.Compiled);

            // Remover object to remove the below characters within the passed arguments.
            Regex Remover = new Regex(@"^['""]?(.*?)['""]?$", RegexOptions.IgnoreCase | RegexOptions.Compiled);

            // Valid parameters forms:
            // {-,/,--}param{ ,=,:}((",')value(",'))
            // Examples:
            // -param1 value1 --param2 /param3:"Test-:-work"
            // /param4=happy -param5 '--=nice=--'.
            foreach (string Txt in Args)
            {
                // Look for new parameters (-,/ or --) and a
                // possible enclosed value (=,:).

                // Split the string into 3 parts (i.e.string is splitted for these characters '-' & '=' ).
                Parts = Spliter.Split(Txt, 3);

                switch (Parts.Length)
                {
                    // Found a value (for the last parameter
                    // found (space separator))
                    case 1:
                        if (Parameter != null)
                        {
                            if (!Parameters.ContainsKey(Parameter))
                            {
                                Parts[0] =
                                  Remover.Replace(Parts[0], "$1");

                                Parameters.Add(Parameter, Parts[0]);
                            }
                            Parameter = null;
                        }
                        // else Error: no parameter waiting for a value (skipped).
                        break;

                    // Found just a parameter.
                    case 2:
                        // The last parameter is still waiting
                        // With no value, set it to true.
                        if (Parameter != null)
                        {
                            if (!Parameters.ContainsKey(Parameter))
                            {
                                Parameters.Add(Parameter, "true");
                            }
                        }
                        Parameter = Parts[1];
                        break;

                    // Parameter with enclosed value.
                    case 3:
                        // The last parameter is still waiting
                        // With no value, set it to true.
                        if (Parameter != null)
                        {
                            if (!Parameters.ContainsKey(Parameter))
                            {
                                Parameters.Add(Parameter, "true");
                            }
                        }

                        // Comand line option (i.e. 's' or 'c')
                        // Ex : -s=..\..\bin\Release\_segment_Chorus.xml -c=..\..\bin\Release\_export_configuration_Target.xml
                        // Parts[1] = s. 
                        Parameter = Parts[1];

                        // Remove possible enclosing characters (",').
                        if (!Parameters.ContainsKey(Parameter))
                        {
                            Parts[2] = Remover.Replace(Parts[2], "$1");
                            Parameters.Add(Parameter, Parts[2]);
                        }

                        Parameter = null;
                        break;
                }
            }
            // In case a parameter is still waiting.
            if (Parameter != null)
            {
                if (!Parameters.ContainsKey(Parameter))
                {
                    Parameters.Add(Parameter, "true");
                }
            }
        }

        // Retrieve a parameter value if it exists
        // (overriding C# indexer property).
        public string this[string Param]
        {
            get
            {
                return (Parameters[Param]);
            }
        }
    }
}
using System;
using System.Collections.Specialized;
using System.Text.RegularExpressions;

namespace parsrv
{
    // A helper class to parse and evaluate the command line arguments.
    public class Arguments
    {
        // Variables.
        private StringDictionary Parameters;

        // Parameterised Constructor.
        public Arguments(string[] Args)
        {
            // Dictionary to store the argumets passed as key and values.
            Parameters = new StringDictionary();

            string Parameter = null;
            string[] Parts;

            // Regex class -> Regular expression class.
            // Splitter object to split if any of the below characters available within the passed arguments.
            Regex Spliter = new Regex(@"^-{1,2}|^/|=|:", RegexOptions.IgnoreCase | RegexOptions.Compiled);

            // Remover object to remove the below characters within the passed arguments.
            Regex Remover = new Regex(@"^['""]?(.*?)['""]?$", RegexOptions.IgnoreCase | RegexOptions.Compiled);

            // Valid parameters forms:
            // {-,/,--}param{ ,=,:}((",')value(",'))
            // Examples:
            // -param1 value1 --param2 /param3:"Test-:-work"
            // /param4=happy -param5 '--=nice=--'.
            foreach (string Txt in Args)
            {
                // Look for new parameters (-,/ or --) and a
                // possible enclosed value (=,:).

                // Split the string into 3 parts (i.e.string is splitted for these characters '-' & '=' ).
                Parts = Spliter.Split(Txt, 3);

                switch (Parts.Length)
                {
                    // Found a value (for the last parameter
                    // found (space separator))
                    case 1:
                        if (Parameter != null)
                        {
                            if (!Parameters.ContainsKey(Parameter))
                            {
                                Parts[0] =
                                  Remover.Replace(Parts[0], "$1");

                                Parameters.Add(Parameter, Parts[0]);
                            }
                            Parameter = null;
                        }
                        // else Error: no parameter waiting for a value (skipped).
                        break;

                    // Found just a parameter.
                    case 2:
                        // The last parameter is still waiting
                        // With no value, set it to true.
                        if (Parameter != null)
                        {
                            if (!Parameters.ContainsKey(Parameter))
                            {
                                Parameters.Add(Parameter, "true");
                            }
                        }
                        Parameter = Parts[1];
                        break;

                    // Parameter with enclosed value.
                    case 3:
                        // The last parameter is still waiting
                        // With no value, set it to true.
                        if (Parameter != null)
                        {
                            if (!Parameters.ContainsKey(Parameter))
                            {
                                Parameters.Add(Parameter, "true");
                            }
                        }

                        // Comand line option (i.e. 's' or 'c')
                        // Ex : -s=..\..\bin\Release\_segment_Chorus.xml -c=..\..\bin\Release\_export_configuration_Target.xml
                        // Parts[1] = s. 
                        Parameter = Parts[1];

                        // Remove possible enclosing characters (",').
                        if (!Parameters.ContainsKey(Parameter))
                        {
                            Parts[2] = Remover.Replace(Parts[2], "$1");
                            Parameters.Add(Parameter, Parts[2]);
                        }

                        Parameter = null;
                        break;
                }
            }
            // In case a parameter is still waiting.
            if (Parameter != null)
            {
                if (!Parameters.ContainsKey(Parameter))
                {
                    Parameters.Add(Parameter, "true");
                }
            }
        }

        // Retrieve a parameter value if it exists
        // (overriding C# indexer property).
        public string this[string Param]
        {
            get
            {
                return (Parameters[Param]);
            }
        }
    }
}
