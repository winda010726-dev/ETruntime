using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace parsrv
{
    public class ParameterDefinitionException : Exception
    {
        public ParameterDefinitionException(string message) : base(message)
        {
        }
    }

    /// <summary>
    /// A class to handle the attributes of a parameter.
    /// </summary>
    public class cParameterDefinition
    {
        // Name of the cluster to which the parameter belongs.
        public string my_cluster_name;

        // Name of the parameter.
        private string my_name;

        // Data type of parameter.
        private string my_type;

        // Data type of parameter.
        private string my_typeInModel_TwoZero;

        // Data type of parameter.
        private string my_typeInPlatform_TwoZero;

        // Size of the parameter(i.e. array), number of elements.
        private string my_number;

        // Offset (CANape).
        private string my_offset;

        // Resolution (CANape).
        private string my_resolution;

        // Unit of the parameter.
        private string my_unit;

        // Minimum value of the parameter.
        private string my_min;

        // Maxmimum value of the parameter.
        private string my_max;

        // Information of the parameter(CANape).
        private string my_description;

        // Pesistance ID for NVM Blocks\Clusters
        private string my_pid;

        // Alias name (CANape) - Implemented as a list to be able to have individual alias for all elements of an array.
        private List<string> my_canape_aliases;

        // Tag to indicate whether the parameter shall be visible/disclosed to customers or no
        private string my_disclosure;

        // Name of the parameter.
        [XmlElement("Name")]
        public string Name
        {
            get { return my_name; }
            set { my_name = value; }
        }

        // Not available in XML 2.0 and 2.1.
        // Data type of parameter.
        [XmlElement("Type")]
        public string Type
        {
            get { return my_type; }
            set { my_type = value; }
        }

        // Data type of parameter.
        [XmlElement("TypeInModel")]
        public string TypeInModel
        {
            get { return my_typeInModel_TwoZero; }
            set { my_typeInModel_TwoZero = value; }
        }

        // Data type of parameter.
        [XmlElement("TypeInPlatform")]
        public string TypeInPlatform
        {
            get { return my_typeInPlatform_TwoZero; }
            set { my_typeInPlatform_TwoZero = value; }
        }

        // Size of the parameter(i.e. array).
        [XmlElement("Number")]
        public string Number
        {
            get { return my_number; }
            set { my_number = value; }
        }

        // Offset (CANape).
        [XmlElement("OFFSET")]
        public string Offset
        {
            get { return my_offset; }
            set { my_offset = value; }
        }

        // Resolution (CANape).
        [XmlElement("RESOLUTION")]
        public string Resolution
        {
            get { return my_resolution; }
            set { my_resolution = value; }
        }

        // Unit of the parameter.
        [XmlElement("UNIT")]
        public string Unit
        {
            get { return my_unit; }
            set { my_unit = value; }
        }

        // Minimum value of the parameter.
        [XmlElement("MIN")]
        public string Min
        {
            get { return my_min; }
            set { my_min = value; }
        }

        // Maximum value of the parameter.
        [XmlElement("MAX")]
        public string Max
        {
            get { return my_max; }
            set { my_max = value; }
        }

        // Pesistance ID for NVM Blocks
        [XmlElement("PID")]
        public string PID
        {
            get { return my_pid; }
            set { my_pid = value; }
        }

        // Information of the parameter.
        [XmlElement("DESCRIPTION")]
        public string Description
        {
            get { return my_description; }
            set { my_description = value; }
        }

        // Name displayed in the CANape.
        [XmlArray("CANAPE_ALIAS_LIST")]
        [XmlArrayItem("CANAPE_ALIAS")]
        public List<string> CANapeAliases
        {
            get { return my_canape_aliases; }
            set { my_canape_aliases = value; }
        }

        // Parameter disclosure property.
        [XmlElement("Disclosure")]
        public string Disclosure
        {
            get { return my_disclosure; }
            set { my_disclosure = value; }
        }

        // Default Constructor.
        public cParameterDefinition()
        {
            this.my_name = "ParameterX";
            this.my_type = "TypeX";
            this.my_typeInModel_TwoZero = "";
            this.my_typeInPlatform_TwoZero = "";
            this.my_number = "1";
            this.my_offset = "0";
            this.my_resolution = "1";
            this.my_unit = "";
            this.my_min = "MinX";
            this.my_max = "MaxX";
            this.my_pid = "601";
            this.my_description = "No description available!";
            this.my_canape_aliases = new List<string>();
            this.my_disclosure = "internal";
        }

        // Parameterized constructor.
        public cParameterDefinition(string new_name, 
                                    string new_type,
                                    string new_typeInModel_TwoZero,
                                    string new_typeInPlatform_TwoZero,
                                    string new_number,
                                    string new_offset, 
                                    string new_resolution, 
                                    string new_unit,
                                    string new_min, 
                                    string new_max, 
                                    string new_pid, 
                                    string new_description,
                                    List<string> new_canape_aliases,
                                    string new_disclosure)
        {
            this.my_name = new_name;
            this.my_type = new_type;
            this.my_typeInModel_TwoZero = new_typeInModel_TwoZero;
            this.my_typeInPlatform_TwoZero = new_typeInModel_TwoZero;
            this.my_number = new_number;
            this.my_offset = new_offset;
            this.my_resolution = new_resolution;
            this.my_unit = new_unit;
            this.my_min = new_min;
            this.my_max = new_max;
            this.my_pid = new_pid;
            this.my_description = new_description;
            this.my_canape_aliases = new_canape_aliases;
            this.my_disclosure = new_disclosure;
        }

        // Parameterized constructor.
        public cParameterDefinition(string new_name, string new_type, string new_number)
        {
            this.my_name = new_name;
            this.my_type = new_type;
            this.my_number = new_number;
            this.my_offset = "0";
            this.my_resolution = "1";
            this.my_unit = "";
            this.my_min = "0";
            this.my_max = "1000";
            this.my_pid = "601";
            this.my_description = "No description available!";
            this.my_canape_aliases = new List<string>();
        }

        // Returns the Data type name of the parameter
        // by Gasser for NVM-section and Cal-section.
        public string GetNameOfType()
        {
            return my_type;
        }

        // Returns size (in bytes) of the parameter.
        public int GetSizeOfType()
        {
            if      (my_type == "UInt8") { return 1; }
            else if (my_type == "UInt16") { return 2; }
            else if (my_type == "UInt32") { return 4; }
            else if (my_type == "SInt8") { return 1; }
            else if (my_type == "SInt16") { return 2; }
            else if (my_type == "SInt32") { return 4; }
            else if (my_type == "Boolean") { return 1; }
            else if (my_type == "Bitfield8") { return 1; }
            else if (my_type == "Bitfield16") { return 2; }
            else if (my_type == "Bitfield32") { return 4; }
            else if (my_type == "Float32") { return 4; }
            else
            {
                throw new ParameterDefinitionException(String.Format("Error: Unknown type {0} in parameter {1}", my_type, my_name));
            }
        }

        // Checks whether the parameter is a bitfield.
        public Boolean IsBitfield()
        {
            if (this.my_type == "Bitfield8") { return true; }
            else if (this.my_type == "Bitfield16") { return true; }
            else if (this.my_type == "Bitfield32") { return true; }
            else { return false; }
        }

        // Returns the width of a bitfield parameter.
        public int GetBitfieldWidth()
        {
            if (this.my_type == "Bitfield8") { return 8; }
            else if (this.my_type == "Bitfield16") { return 16; }
            else if (this.my_type == "Bitfield32") { return 32; }
            else { return 0; }
        }

        // Get bit mask.
        public string GetBitMaskString(int my_base_address_bit_offset)
        {
            string return_string;

            if (this.IsBitfield() != false)
            {
                // Bitfields.
                int bitmask = 1;

                for (int bit_pos = 0; bit_pos < (Convert.ToInt32(this.Number) - 1); bit_pos++)
                {
                    bitmask <<= 1;
                    bitmask += 1;
                }

                // Shift by base address bit offset.
                bitmask <<= my_base_address_bit_offset;

                if (this.Type == "Bitfield8") { return_string = string.Format("0x{0:x2}", bitmask); }
                else if (this.Type == "Bitfield16") { return_string = string.Format("0x{0:x4}", bitmask); }
                else if (this.Type == "Bitfield32") { return_string = string.Format("0x{0:x8}", bitmask); }
                else { return_string = string.Format("0x0 "); }
            }
            else
            {
                // Other datatype than bitfields.
                if      (this.Type == "UInt8")   { return_string = ("0xFF"); }
                else if (this.Type == "UInt16")  { return_string = ("0xFFFF"); }
                else if (this.Type == "UInt32")  { return_string = ("0xFFFFFFFF"); }
                else if (this.Type == "SInt8")   { return_string = ("0xFF"); }
                else if (this.Type == "SInt16")  { return_string = ("0xFFFF"); }
                else if (this.Type == "SInt32")  { return_string = ("0xFFFFFFFF"); }
                else if (this.Type == "Float32") { return_string = ("0xFFFFFFFF"); }
                else if (this.Type == "Boolean") { return_string = ("0xFF"); }
                else { return_string = ("0x0"); }
            }

            return return_string;
        }
    }
}