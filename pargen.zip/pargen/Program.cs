/*****************************************************************************
 | C O P Y R I G H T
 |-----------------------------------------------------------------------------
 | Copyright (c) 2009 by Robert Bosch GmbH.                All rights reserved.
 |
 | This file is property of Robert Bosch GmbH. Any unauthorised copy, use or
 | distribution is an offensive act against international law and may me
 | prosecuted under federal law. Its content is company confidential.
 |-----------------------------------------------------------------------------
 | D E S C R I P T I O N
 |-----------------------------------------------------------------------------
 | $ProjectName: d:/MKS_Data/Projects/PC/PP_NEC_PF_DEV/PAR/TOOLS/pargen/pargen.pj $
 |      $Source: Program.cs $
 |    $Revision: 1.225.1.90.1.1 $
 |        $Date: 2019/09/12 12:07:53IST $
 |       $State: in_work $
 |
 |      Purpose: pargen - tool to generate the parameter component configuration for Gen 6 Projects
 |-----------------------------------------------------------------------------
 | I N F O
 |-----------------------------------------------------------------------------
 | -
 *****************************************************************************/


using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Linq;
using System.Xml.Serialization;
using System.Security.Cryptography;
using System.Linq;
using System.Reflection;

namespace parsrv
{
    // A class to compute the SHA1 hashes for the structure of the CAL-section and the NVM-parameters
    // the hash only secures the integrity of the structure and is independent of the data.
    public class cHashes
    {
        // CAL-section hash as a hex string
        private string my_cal_hash;

        // NVM-section hash as a hex string
        private string my_nvm_hash;

        // CAL-section range resolution hash as a hex string
        private string my_cal_rrhash;

        // CAL-section hash as a byte array
        private byte[] my_cal_hash_byte_array;

        // NVM-section hash as a byte array
        private byte[] my_nvm_hash_byte_array;

        // CAL-section range resolution hash as a hex string
        private byte[] my_cal_rrhash_byte_array;

        public string CALHash
        {
            get { return my_cal_hash; }
            set { my_cal_hash = value; }
        }

        public string NVMHash
        {
            get { return my_nvm_hash; }
            set { my_nvm_hash = value; }
        }

        public string CALRRHash
        {
            get { return my_cal_rrhash; }
            set { my_cal_rrhash = value; }
        }

        public byte[] CALHashByteArray
        {
            get { return my_cal_hash_byte_array; }
            set { my_cal_hash_byte_array = value; }
        }

        public byte[] NVMHashByteArray
        {
            get { return my_nvm_hash_byte_array; }
            set { my_nvm_hash_byte_array = value; }
        }

        public byte[] CALRRHashByteArray
        {
            get { return my_cal_rrhash_byte_array; }
            set { my_cal_rrhash_byte_array = value; }
        }

        // Compute the Hash for CAL and NVM Section.
        public void Compute(ref cParameterSet my_ps, ref bool Hash_CAL_b, ref bool Hash_NVM_b)
        {
            // CAL Hash Computation.
            {
                string my_hash_string = "";

                // Build a giant string with all the structure information.
                foreach (cComponent component in my_ps.Components)
                {
                    // Check if Defines needs to be considered for HASH Calculation or not.
                    if (Hash_CAL_b == false)
                    {
                        // Consider Defines for CAL Hash Calculation.
                        my_hash_string += string.Format("{0}#{1}#", component.Name.ToUpper(), component.Version);

                        // Build a string with Define name and their corresponding value.
                        foreach (cDefine my_define in component.Defines)
                        {
                            my_hash_string += string.Format("{0}#{1}#", my_define.Name, my_define.Value);
                        }
                    }
                    else
                    {
                        // Defines are not considered for CAL HASH Computation.
                    }

                    foreach (cParameterCluster cluster in component.ParameterClusters)
                    {
                        // Other than NVM and RAM parameters, remaining memory area are considered(i.e. ROM, RAM_INIT, NVM_INIT)
                        if (cluster.MemoryArea != "NVM")
                        {
                            // Variant Application of the cluster (i.e. SINGLE or MINOR_ALL)
                            my_hash_string += string.Format("{0}#{1}#", cluster.Name, cluster.VariantApplication);

                            // Parameter Name and the Data Type are considered.
                            foreach (cParameterDefinition para_def in cluster.ParameterDefinitions)
                            {
                                my_hash_string += string.Format("{0}#{1}#", para_def.Name, para_def.Type);
                            }

                            foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                            {
                                // Minor variant and Sub variant names are considered.
                                foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                {
                                    my_hash_string += string.Format("{0}#", min_var.Name);

                                    foreach (cSubVariant sub_var in min_var.SubVariants)
                                    {
                                        my_hash_string += string.Format("{0}#", sub_var.Name);
                                    }
                                }
                            }
                        }
                    }
                }

                // Debug output. (Uncomment for Debug purpose).
                //Console.WriteLine ("{0}", my_hash_string);

                // Convert plain text into a byte array.
                byte[] plainTextBytes = Encoding.UTF8.GetBytes(my_hash_string);

                // Hash value.
                byte[] hash_value;

                // Create crypto provider object. 
                SHA1 sha = new SHA1CryptoServiceProvider();

                // This is one implementation of the abstract class SHA1.
                hash_value = sha.ComputeHash(plainTextBytes);

                // Hash value string.
                string hash_value_string = "";

                for (int i = 0; i < hash_value.Length; i++)
                {
                    hash_value_string += string.Format("0x{0:x2}", hash_value[i]);

                    if (i < (hash_value.Length - 1))
                    {
                        hash_value_string += string.Format(", ");
                    }
                }

                // Debug output (Uncomment for Debug Purpose).
                //Console.WriteLine ("{0}", hash_value_string);

                this.CALHash = hash_value_string;
                this.CALHashByteArray = hash_value;
            }

            // NVM Hash Computation.
            {
                string my_hash_string = "";

                // Build a giant string with all the structure information.
                foreach (cComponent component in my_ps.Components)
                {
                    // Check Defines needs to be considered for HASH Calculation or not.
                    if (Hash_NVM_b == false)
                    {
                        // Consider Defines for NVM Hash Calculation.
                        my_hash_string += string.Format("{0}#{1}#", component.Name.ToUpper(), component.Version);

                        // Build a string with Define name and their corresponding value.
                        foreach (cDefine my_define in component.Defines)
                        {
                            my_hash_string += string.Format("{0}#{1}#", my_define.Name, my_define.Value);
                        }
                    }
                    else
                    {
                        // Defines are not considered for NVM HASH Computation.
                    }

                    foreach (cParameterCluster cluster in component.ParameterClusters)
                    {
                        // Only NVM and NVM_INIT parameters are considered for NVM HASH Calculation. Others(i.e. ROM and RAM_INIT) are not considered.
                        if ((cluster.MemoryArea == "NVM") || (cluster.MemoryArea == "NVM_INIT"))
                        {
                            // Parameter Name and the Data Type are considered.
                            foreach (cParameterDefinition para_def in cluster.ParameterDefinitions)
                            {
                                my_hash_string += string.Format("{0}#{1}#", para_def.Name, para_def.Type);
                            }

                            foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                            {
                                // Minor variant and Sub variant name are considered.
                                foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                {
                                    my_hash_string += string.Format("{0}#", min_var.Name);

                                    foreach (cSubVariant sub_var in min_var.SubVariants)
                                    {
                                        my_hash_string += string.Format("{0}#", sub_var.Name);
                                    }
                                }
                            }
                        }
                    }
                }

                // Debug output. (Uncomment for Debug purpose).
                //Console.WriteLine ("{0}", my_hash_string);

                // Convert plain text into a byte array.
                byte[] plainTextBytes = Encoding.UTF8.GetBytes(my_hash_string);

                // Hash value.
                byte[] hash_value;

                // Create crypto provider object.
                SHA1 sha = new SHA1CryptoServiceProvider();

                // This is one implementation of the abstract class SHA1.
                hash_value = sha.ComputeHash(plainTextBytes);

                // Hash value string.
                string hash_value_string = "";

                for (int i = 0; i < hash_value.Length; i++)
                {
                    hash_value_string += string.Format("0x{0:x2}", hash_value[i]);

                    if (i < (hash_value.Length - 1))
                    {
                        hash_value_string += string.Format(", ");
                    }
                }

                // Debug output (Uncomment for Debug Purpose).
                //Console.WriteLine ("{0}", hash_value_string);

                this.NVMHash = hash_value_string;
                this.NVMHashByteArray = hash_value;
            }

            // CAL RRHash Computation.
            {
                string my_hash_string = "";

                // Build a giant string with all the structure information.
                foreach (cComponent component in my_ps.Components)
                {
                    foreach (cParameterCluster cluster in component.ParameterClusters)
                    {
                        // Other than NVM and RAM parameters, remaining memory area are considered(i.e. ROM, RAM_INIT, NVM_INIT)
                        if (cluster.MemoryArea != "NVM")
                        {
                            // Parameter Name and the Data Type are considered.
                            foreach (cParameterDefinition para_def in cluster.ParameterDefinitions)
                            {
                                my_hash_string += string.Format("{0}#{1}#{2}#", para_def.Min, para_def.Max, para_def.Resolution);
                            }
                        }
                    }
                }

                // Debug output. (Uncomment for Debug purpose).
                //Console.WriteLine ("{0}", my_hash_string);

                // Convert plain text into a byte array.
                byte[] plainTextBytes = Encoding.UTF8.GetBytes(my_hash_string);

                // Hash value.
                byte[] hash_value;

                // Create crypto provider object. 
                SHA1 sha = new SHA1CryptoServiceProvider();

                // This is one implementation of the abstract class SHA1.
                hash_value = sha.ComputeHash(plainTextBytes);

                // Hash value string.
                string hash_value_string = "";

                for (int i = 0; i < hash_value.Length; i++)
                {
                    hash_value_string += string.Format("0x{0:x2}", hash_value[i]);

                    if (i < (hash_value.Length - 1))
                    {
                        hash_value_string += string.Format(", ");
                    }
                }

                // Debug output (Uncomment for Debug Purpose).
                //Console.WriteLine ("{0}", hash_value_string);

                this.CALRRHash = hash_value_string;
                this.CALRRHashByteArray = hash_value;
            }
        }
    }

    // A Class to handle all the meta information of the imported XML-file.
    public class cParameterSetInfo
    {
        private string my_version;
        private string my_year;
        private string my_month;
        private string my_day;
        private string my_hours;
        private string my_minutes;

        [XmlElement("Version")]
        public string Version
        {
            get { return my_version; }
            set { my_version = value; }
        }

        [XmlElement("Year")]
        public string Year
        {
            get { return my_year; }
            set { my_year = value; }
        }

        [XmlElement("Month")]
        public string Month
        {
            get { return my_month; }
            set { my_month = value; }
        }

        [XmlElement("Day")]
        public string Day
        {
            get { return my_day; }
            set { my_day = value; }
        }

        [XmlElement("Hours")]
        public string Hours
        {
            get { return my_hours; }
            set { my_hours = value; }
        }

        [XmlElement("Minutes")]
        public string Minutes
        {
            get { return my_minutes; }
            set { my_minutes = value; }
        }

        // Default constructor.
        public cParameterSetInfo()
        {
            this.my_version = "1";
            this.my_year = "1971";
            this.my_month = "5";
            this.my_day = "1";
            this.my_hours = "15";
            this.my_minutes = "00";
        }

        // Parameterized constructor.
        public cParameterSetInfo(string new_version, string new_year, string new_month, string new_day, string new_hours, string new_minutes)
        {
            this.my_version = new_version;
            this.my_year = new_year;
            this.my_month = new_month;
            this.my_day = new_day;
            this.my_hours = new_hours;
            this.my_minutes = new_minutes;
        }
    }

    // Class to handle a complete set of parameters.
    [XmlRoot("ParameterSet")]
    public class cParameterSet
    {
        // Metadata and descriptive attributes.
        private cParameterSetInfo my_parameter_set_info;

        // A list with the names of all global variants.
        private List<string> my_major_variants;

        // The components.
        private List<cComponent> my_components;

        // List of constant available.
        private List<cConstant> my_constants;

        // Data type (i.e. enum, user-defined, constant)
        public cDataTypes my_dataTypes;

        [XmlElement("Info")]
        public cParameterSetInfo ParameterSetInfo
        {
            get { return my_parameter_set_info; }
            set { my_parameter_set_info = value; }
        }

        [XmlArray("MajorVariantList")]
        [XmlArrayItem("MajorVariant")]
        public List<string> MajorVariants
        {
            get { return my_major_variants; }
            set { my_major_variants = value; }
        }

        [XmlArray("ComponentList")]
        [XmlArrayItem("Component")]
        public List<cComponent> Components
        {
            get { return my_components; }
            set { my_components = value; }
        }

        [XmlArray("Constants")]
        [XmlArrayItem("Constant")]
        public List<cConstant> Constants
        {
            get { return my_constants; }
            set { my_constants = value; }
        }

        [XmlElement("DataTypes")]
        public cDataTypes DataTypes
        {
            get { return my_dataTypes; }
            set { my_dataTypes = value; }
        }

        // Default constructor.
        public cParameterSet()
        {
            this.my_parameter_set_info = new cParameterSetInfo();
            this.my_major_variants = new List<string>();
            this.my_components = new List<cComponent>();
            this.my_constants = new List<cConstant>();
            this.my_dataTypes = new cDataTypes();
        }

        // Parameterized constructor.
        public cParameterSet(cParameterSetInfo new_parameter_set_info,
                              List<string> new_major_variants,
                              List<cComponent> new_components,
                              List<cConstant> constants,
                              cDataTypes dataTypes)
        {
            this.my_parameter_set_info = new_parameter_set_info;
            this.my_major_variants = new_major_variants;
            this.my_components = new_components;
            this.my_constants = constants;
            this.my_dataTypes = dataTypes;
        }
    }

    // A class to handle the attributes and the data of a component.
    public class cComponent
    {
        // Name of the component.
        private string my_name;

        // Vesion.
        private string my_version;

        // Component sorting key.
        private string my_comp_key;

        // All the switches and #define-constants.
        private List<cDefine> my_defines;
        
        // The parameters (data + description).
        private List<cParameterCluster> my_parameter_clusters;

        [XmlElement("Name")]
        public string Name
        {
            get { return my_name; }
            set { my_name = value; }
        }

        // NOT AVAILABLE IN XML2.0 and 2.1.
        [XmlElement("Version")]
        public string Version
        {
            get { return my_version; }
            set { my_version = value; }
        }

        // NOT AVAILABLE IN XML2.0 and 2.1
        [XmlElement("CompKey")]
        public string CompKey
        {
            get { return my_comp_key; }
            set { my_comp_key = value; }
        }

        [XmlArray("DefineList")]
        [XmlArrayItem("Define")]
        public List<cDefine> Defines
        {
            get { return my_defines; }
            set { my_defines = value; }
        }

        [XmlArray("ParameterClusterList")]
        [XmlArrayItem("ParameterCluster")]
        public List<cParameterCluster> ParameterClusters
        {
            get { return my_parameter_clusters; }
            set { my_parameter_clusters = value; }
        }

        // Default constructor.
        public cComponent()
        {
            this.my_name = "ComponentX";
            this.my_version = "1.0";
            this.my_comp_key = "65535";
            this.my_defines = new List<cDefine>();
            this.my_parameter_clusters = new List<cParameterCluster>();
        }

        // Parameterized constructor.
        public cComponent(string new_name,
                           string new_version,
                           string new_comp_key,
                           List<cDefine> new_defines,
                           List<cParameterCluster> new_parameter_clusters)
        {
            this.my_name = new_name;
            this.my_version = new_version;
            this.my_comp_key = new_comp_key;
            this.my_defines = new_defines;
            this.my_parameter_clusters = new_parameter_clusters;
        }

        public static int CompareByCompKey(cComponent x, cComponent y)
        {
            UInt32 a = Convert.ToUInt32(x.CompKey);
            UInt32 b = Convert.ToUInt32(y.CompKey);

            if (a == b)
            {
                return 0;
            }
            else if (a > b)
            {
                return 1;
            }
            else
            {
                return -1;
            }
        }

        // Constructor to create copy of cComponent class object
        // This constructor accepts a parameter of cComponent type (the one you want to copy) 
        // and creates a new object assigned with the same value.
        public cComponent(cComponent cCopy)
        {
            this.my_name = cCopy.my_name;
            this.my_version = cCopy.my_version ;
            this.my_comp_key = cCopy.my_comp_key;
            this.my_defines = cCopy.my_defines;
            this.my_parameter_clusters = cCopy.my_parameter_clusters;
        }
    }

    // Program class.
    public class Program
    {
        // Static variables to indicates whether provided PAR XML is of version 1.0 or 2.0 or 2.1.
        private static bool is_xml_1_0;
        private static bool is_xml_2_0;
        private static bool is_xml_2_1;

        // Static variable to indicate actual version of the provided PAR XML.
        private static string xml_version;

        // Checks parameter gaps in the parameter clusters.
        static public Boolean CheckParameterGaps(ref cParameterSet my_ps, ref cGeneralConfiguration my_gc, String my_FileName_Suffix)
        {
            // LOG Folder path.
            string my_output_path = my_gc.Log_OutputPath;

            var paddingLogPath = Path.Combine(my_output_path, "Padding_log" + my_FileName_Suffix + ".txt");
            var allVariantsPath = Path.Combine(my_output_path, "All_Variants_log.txt");
            var allSubVariantsPath = Path.Combine(my_output_path, "All_SubVariants.txt");
            // Delete the generated log file if exists. No exception is thrown if file is not available.
            FileDelete(paddingLogPath);

            // Opens the file, append the data/Info and closes the file.
            FileAppendAllText(paddingLogPath, "Section 1: Padding instances within parameter cluster members\n");
            FileAppendAllText(paddingLogPath, string.Format("-------------------------------------------------------------") + "\n");
            FileAppendAllText(paddingLogPath, string.Format("{0,-30} | {1,5}", "Cluster Name", "Padding Instances |") + "\n");
            FileAppendAllText(paddingLogPath, string.Format("---------------------------------------------------|") + "\n");

            // Variable to indicate Structre holes is present/not present.
            Boolean Holes_Available_b = false;

            {
                Console.WriteLine("------------------ Structure Holes\\Gaps in clusters -------------------- ");
                Console.WriteLine("");
                foreach (cComponent component in my_ps.Components)
                {
                    // Flags for checking the gap.
                    
                    // To Get number of parameters of type UInt32/SInt32/Float32 within the cluster.
                    int flag_four;
                    
                    // To Get number of parameters of type UInt16/SInt16 with in the cluster.
                    int flag_two;

                    // To Get number of parameters of type UInt8/SInt8/Boolean with in the clusters.
                    int flag_one;

                    // To indicate the Current member type (i.e. size of type).
                    int new_flag;

                    // To indicate the Previous member type (i.e. size of type).
                    int old_flag;

                    // Indicate whether Gap/Holes is present ( Gap_present > 0 : Indicate Gap/Hole is present along with number of instances).
                    int Gap_present;

                    //this is to check remember if there was a gap already assigned when jumping from 1 byte to 2 byte. 
                    Boolean flag_one_to_two;

                    // To Get the size of the parameters of different types within the clusters (i.e Size of cluster).
                    int Member_count;

                    foreach (cParameterCluster cluster in component.ParameterClusters)
                    {
                        // Initialize all flags.
                        flag_one = 0;
                        flag_two = 0;
                        flag_four = 0;
                        flag_one_to_two = true;
                        new_flag = 0;
                        old_flag = 4;
                        Gap_present = 0;
                        Member_count = 0;

                        // Check for all differnet memory area (ROM,RAM_INIT,NVM_INIT,NVM).
                        if (cluster.MemoryArea != "")
                        {
                            foreach (cParameterDefinition para_def in cluster.ParameterDefinitions)
                            {
                                // Flags used to count the number of data types and flags used for identifying the type of datatype.
                                if (para_def.Type == "UInt8") { flag_one += Convert.ToInt32(para_def.Number); new_flag = 0x01; Member_count += (Convert.ToInt32(para_def.Number) * 1); }
                                else if (para_def.Type == "UInt16") { flag_two += Convert.ToInt32(para_def.Number); new_flag = 0x02; Member_count += (Convert.ToInt32(para_def.Number) * 2); }
                                else if (para_def.Type == "UInt32") { flag_four += Convert.ToInt32(para_def.Number); new_flag = 0x04; Member_count += (Convert.ToInt32(para_def.Number) * 4); }
                                else if (para_def.Type == "SInt8") { flag_one += Convert.ToInt32(para_def.Number); new_flag = 0x01; Member_count += (Convert.ToInt32(para_def.Number) * 1); }
                                else if (para_def.Type == "SInt16") { flag_two += Convert.ToInt32(para_def.Number); new_flag = 0x02; Member_count += (Convert.ToInt32(para_def.Number) * 2); }
                                else if (para_def.Type == "SInt32") { flag_four += Convert.ToInt32(para_def.Number); new_flag = 0x04; Member_count += (Convert.ToInt32(para_def.Number) * 4); }
                                else if (para_def.Type == "Boolean") { flag_one += Convert.ToInt32(para_def.Number); new_flag = 0x01; Member_count += (Convert.ToInt32(para_def.Number) * 1); }
                                else if (para_def.Type == "Bitfield8") { flag_one += Convert.ToInt32(para_def.Number); new_flag = 0x01; Member_count += (Convert.ToInt32(para_def.Number) * 1); }
                                else if (para_def.Type == "Bitfield16") { flag_two += Convert.ToInt32(para_def.Number); new_flag = 0x02; Member_count += (Convert.ToInt32(para_def.Number) * 2); }
                                else if (para_def.Type == "Bitfield32") { flag_four += Convert.ToInt32(para_def.Number); new_flag = 0x04; Member_count += (Convert.ToInt32(para_def.Number) * 4); }
                                else if (para_def.Type == "Float32") { flag_four += Convert.ToInt32(para_def.Number); new_flag = 0x04; Member_count += (Convert.ToInt32(para_def.Number) * 4); }
                                else { /* Do nothing. */; }

                                // Condition to check if the size of datatype increased.
                                if (new_flag > old_flag)
                                {
                                    // Size of current data type is greater than size of previous data type.
                                    if ((new_flag - old_flag) == 2)//16 >> 32
                                    {
                                        if (((flag_two % 2) != 0) && ((flag_one % 2) == 1))
                                        {
                                            // Gap is present.
                                            // Increment for every instance (i.e GAP).
                                            Gap_present++;
                                            flag_two = 0;
                                            flag_one = 0;
                                        }
                                        else if (((((flag_two * 2) + flag_one) % 4) != 0) && (flag_one_to_two))
                                        {
                                            // Gap is present.
                                            // Increment for every instance (i.e GAP).
                                            Gap_present++;
                                            flag_two = 0;
                                            flag_one = 0;
                                        }
                                    }
                                    else if ((new_flag - old_flag) == 3) // 8 >> 32
                                    {
                                        if (((flag_one + (flag_two * 2))) % 4 != 0)
                                        {
                                            // Gap is present.
                                            // Increment for every instance (i.e GAP).
                                            Gap_present++;
                                            flag_two = 0;
                                            flag_one = 0;
                                        }
                                    }
                                    else if ((new_flag - old_flag) == 1) // 8 >> 16
                                    {
                                        flag_one_to_two = true;
                                        if ((flag_one % 2) != 0)
                                        {
                                            // Gap is present.
                                            // Increment for every instance (i.e GAP).
                                            Gap_present++;
                                            flag_one = 0;
                                            flag_one_to_two = false;
                                        }
                                    }
                                }
                                else
                                {
                                    // Size of current data type is lesser than size of previous data type.
                                    // DO nothing.
                                }
                                old_flag = new_flag;
                            }

                            if (Gap_present > 0)
                            {
                                // Gap is present, print the info into the file Padding_log.txt/Padding_log_<dsx>.txt.
                                // Write the cluster name and no of instance of padding done.
                                string formatted_string = string.Format("{0,-30} | {1,5}             | ", cluster.Name, Gap_present);
                                FileAppendAllText(paddingLogPath, formatted_string + "\n");

                                // Print the message on console.
                                Console.WriteLine("=============== Structure Holes are present in the cluster \"{0}\" ================= ", cluster.Name);
                                
                                // Gap is present in the cluster. 
                                Holes_Available_b = true;
                            }
                        }
                        // Write the each cluster name and the size of the cluster information to text file, which is needed during Sub_varaint check. 
                        FileAppendAllText(allVariantsPath, string.Format("{0,-30} | {1,5}", cluster.Name, Member_count) + "\n");
                    }
                }
            }

            // Info about mandatory padding bytes required.
            FileAppendAllText(paddingLogPath, string.Format("=================================================================================================================================") + "\n\n");
            FileAppendAllText(paddingLogPath, "Section 2: Padding between minor/sub variant clusters - MANDATORY PADDING IS NEEDED FOR BELOW CLUSTERS\n");

            foreach (cComponent component in my_ps.Components)
            {
                foreach (cParameterCluster cluster in component.ParameterClusters)
                {
                    foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                    {
                        foreach (cMinorVariant min_var in var_imp.MinorVariants)
                        {
                            int sub_var_Presence = 0;
                            foreach (cSubVariant sub_var in min_var.SubVariants)
                            {
                                if (sub_var.Name != "")
                                {
                                    // Sub_varaint is available for the cluster
                                    sub_var_Presence++;
                                }
                            }

                            if (sub_var_Presence > 0)
                            {
                                foreach (var line in FileReadLines(allVariantsPath))
                                {
                                    if (!FileExists(allSubVariantsPath))
                                    {
                                        // Create a temporary files to store the cluster with sub_varinats which has Holes/Gaps issue.
                                        // Dummy for creating file.
                                        FileAppendAllText(allSubVariantsPath, ' ' + "\n");
                                        FileAppendAllText(paddingLogPath, string.Format("------------------------------------------------------------------------------------------------------") + "\n");
                                        FileAppendAllText(paddingLogPath, string.Format("{0,-30} | {1,-5}", "Cluster Name", "Actual size (in Bytes)      |") + "\n");
                                        FileAppendAllText(paddingLogPath, string.Format("-------------------------------------------------------------|") + "\n");
                                        Console.WriteLine("");
                                        Console.WriteLine("----------------------- Sub_Variants Clusters -----------------------");
                                    }

                                    if (line.Contains(cluster.Name))
                                    {
                                        // Split the line into different indexes using the ' ' as a separator to obtain the cluster name at the 0th index.
                                        string[] array = line.Split(' ');
                                        // Check if the current cluster is availble in the All_Subvariants.txt file.
                                        if (!FileReadAllText(allSubVariantsPath).Contains(cluster.Name))
                                        {
                                            // This check is required only to make sure that the current cluster is not substring of any other cluster.
                                            if ((cluster.Name) == array[0])
                                            {
                                                // Cluster is available in All_subvariants.txt file.
                                                string check = line.Remove(0, 35);
                                                int gap_available = (Convert.ToInt32(line.Remove(0, 34)));
                                                if (gap_available % 4 != 0)
                                                {
                                                    // Holes/Gaps is available for the current cluster which contains sub_variants (i.e. size of cluster is odd number).
                                                    // Print the message on console.
                                                    Console.WriteLine("<------ Structure Holes\\Gap are present in sub_variant cluster ------>\"{0}\"", cluster.Name);
                                                    FileAppendAllText(allSubVariantsPath, line + "             | \n");

                                                    // Gap is present in the cluster which has sub_varaints.
                                                    Holes_Available_b = true; 
                                                }
                                            }
                                        }   
                                    }
                                }
                            }
                        }
                    }
                }
            }

            FileAppendAllText(allSubVariantsPath, "=================================================================================================================================\n");
            FileAppendAllText(allSubVariantsPath, " \n");

            // Print additional info about how to fix gaps
            FileAppendAllText(allSubVariantsPath, "Section 3: Refer this section to fix gaps\n");
            FileAppendAllText(allSubVariantsPath, "-----------------------------------------\n");
            FileAppendAllText(allSubVariantsPath, "According to coding guideline Rule 16.5 - Elements of structures shall be arranged in that way to avoid alignment gaps.\n");
            FileAppendAllText(allSubVariantsPath, "Link to coding guidelines:\n");
            FileAppendAllText(allSubVariantsPath, "https://inside-share-hosted-apps.bosch.com/DMS/GetDocumentService/Document.svc/GetDocumentURL?documentID=P12S108958-930743451-4339" + "\n");
            FileAppendAllText(allSubVariantsPath, "------------------------------------------------------------------------\n");
            FileAppendAllText(allSubVariantsPath, "How to fix gaps in clusters mentioned in Section 1: \n");
            FileAppendAllText(allSubVariantsPath, "Rearrange the cluster members in descending order of their sizes.\n");
            FileAppendAllText(allSubVariantsPath, "e.g. structure with 3 bytes of gap in between.(padding instance is 1)\n");
            FileAppendAllText(allSubVariantsPath, "typedef struct  rbp_Tag_par_test1_st\n");
            FileAppendAllText(allSubVariantsPath, "{" + "\n");
            FileAppendAllText(allSubVariantsPath, "  UInt8  struct_elementA_u8;\n");
            FileAppendAllText(allSubVariantsPath, "  UInt32 struct_elementB_u32;\n");
            FileAppendAllText(allSubVariantsPath, "}\n");
            FileAppendAllText(allSubVariantsPath, "rbp_Type_par_test1_st; //!< copydoc rbp_Type_par_test1_st\n");
            FileAppendAllText(allSubVariantsPath, " \n");
            FileAppendAllText(allSubVariantsPath, "e.g. structure with 0 bytes of gap in between\n");
            FileAppendAllText(allSubVariantsPath, "typedef struct  rbp_Tag_par_test1_st\n");
            FileAppendAllText(allSubVariantsPath, "{\n");
            FileAppendAllText(allSubVariantsPath, "  UInt32 struct_elementB_u32;\n");
            FileAppendAllText(allSubVariantsPath, "  UInt8  struct_elementA_u8;\n");
            FileAppendAllText(allSubVariantsPath, "}\n");
            FileAppendAllText(allSubVariantsPath, "rbp_Type_par_test1_st; //!< copydoc rbp_Type_par_test1_st\n");
            FileAppendAllText(allSubVariantsPath, "------------------------------------------------------------------------\n");
            FileAppendAllText(allSubVariantsPath, "How to fix gaps mentioned in Section 2: \n");
            FileAppendAllText(allSubVariantsPath, "Add x number of dummy bytes at the end so that actual size of cluster is multiple of 4\n");
            FileAppendAllText(allSubVariantsPath, "e.g. structure with Actual size 3 bytes.\n");
            FileAppendAllText(allSubVariantsPath, "typedef struct  rbp_Tag_par_test2_st\n");
            FileAppendAllText(allSubVariantsPath, "{\n");
            FileAppendAllText(allSubVariantsPath, "  UInt16 struct_elementB_u32;\n");
            FileAppendAllText(allSubVariantsPath, "  UInt8  struct_elementA_u8;\n");
            FileAppendAllText(allSubVariantsPath, "}\n");
            FileAppendAllText(allSubVariantsPath, "rbp_Type_par_test2_st; //!< copydoc rbp_Type_par_test2_st\n");
            FileAppendAllText(allSubVariantsPath, "\n");
            FileAppendAllText(allSubVariantsPath, "e.g. structure with actual size in multiple of 4\n");
            FileAppendAllText(allSubVariantsPath, "typedef struct  rbp_Tag_par_test2_st\n");
            FileAppendAllText(allSubVariantsPath, "{\n");
            FileAppendAllText(allSubVariantsPath, "  UInt16 struct_elementB_u32;\n");
            FileAppendAllText(allSubVariantsPath, "  UInt8  struct_elementA_u8;\n");
            FileAppendAllText(allSubVariantsPath, "  UInt8  struct_dummy_u8;\n");
            FileAppendAllText(allSubVariantsPath, "} \n");
            FileAppendAllText(allSubVariantsPath, "rbp_Type_par_test2_st; //!< copydoc rbp_Type_par_test2_st\n");
            FileAppendAllText(allSubVariantsPath, "\n");
            FileAppendAllText(allSubVariantsPath, "************************************************************ NOTE: *************************************************************\n");
            FileAppendAllText(allSubVariantsPath, "- By default 4 bytes alignment is considered to determine structure padding.\n");
            FileAppendAllText(allSubVariantsPath, "- Clusters will appear in section 2 only if they have minor or sub variants and actual size is not in multiple of 4bytes.\n");
            FileAppendAllText(allSubVariantsPath, "  These gaps needs to be mandatorily fixed since it is array of structures.\n");
            FileAppendAllText(allSubVariantsPath, "- For detailed information regarding the gaps present please check the generated file rbp_par_struct" + my_FileName_Suffix + "_gen.h\n");
            FileAppendAllText(allSubVariantsPath, "  (i.e. search for the cluster name (x: rbp_Type_par_[ClusterName]_st)\n");
            FileAppendAllText(allSubVariantsPath, "=================================================================================================================================\n");
            foreach (var line in FileReadLines(allSubVariantsPath))
            {
                // Copy the sub_variant clusters which has the Holes/Gaps issue.
                FileAppendAllText(paddingLogPath, line + "\n");
            }
            // Delete the temporary files.
            FileDelete(allVariantsPath);
            FileDelete(allSubVariantsPath);

            return Holes_Available_b;
        }

        // Compare major variant lists.
        static Boolean CompareMajorVariantLists(ref cParameterSet my_ps1, ref cParameterSet my_ps2)
        {
            Boolean lists_identical;

            // Compare the major variant list.
            if ((my_ps1.MajorVariants.Count == 1) && (my_ps2.MajorVariants.Count == 1))
            {
                // Only one major variant per file ... passed.
                lists_identical = true;
            }
            else
            {
                if (my_ps1.MajorVariants.Count == my_ps2.MajorVariants.Count)
                {
                    // Both lists have the same number of elements ...
                    // Now compare the content memberwise ...
                    lists_identical = true;

                    for (int i = 0; i < my_ps1.MajorVariants.Count; i++)
                    {
                        if (my_ps1.MajorVariants[i] != my_ps2.MajorVariants[i])
                        {
                            lists_identical = false;
                        }
                    }
                }
                else
                {
                    // List do NOT contain the same number of elements and are therefore never identical.
                    lists_identical = false;
                }
            }

            return lists_identical;
        }

        // Function executed when schema is invalid.
        static void ErrorHandler(object sender,ValidationEventArgs e)
        {
            // Invalid XML version for the corresponding schema validation.
            Program.is_xml_1_0 = false;
            Program.is_xml_2_0 = false;
            Program.is_xml_2_1 = false;
        } 

        // Read the excel export file (the parameter information/data).
        static Boolean ReadParameterSet(string my_InputFileName, ref cParameterSet my_ps)
        {
            Boolean return_value = false;
            Program.xml_version = "";
            string path = "";
            // Flags to indicate if schema is available or not.
            Boolean xml_1_0_exists = false;
            Boolean xml_2_0_exists = false;
            Boolean xml_2_1_exists = false;

            Boolean schema_checked = true;
            string error_msg = "";

            try
            {
                // Get the directory of the pargen.exe 
                string temp_path = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);

                // Get Index of the folder "bin"
                int index = temp_path.LastIndexOf("bin");
                
                // Point to doc folder for the schemas.
                path = temp_path.Substring(0,(index)) + "doc";

                // Check wheteher directory exits or not.
                if (DirectoryExists(path))
                {
                    // Get the files available within the folder.
                    string[] files = DirectoryGetFiles(path);

                    // Read the input PAR XML.
                    var doc = XDocumentLoad(my_InputFileName);

                    foreach (string file in files)
                    {
                        // Check for schema(.xsd) files.
                        if (file.EndsWith(".xsd"))
                        {
                            XmlSchemaSet schemaSet = new XmlSchemaSet();

                            // Add XML Schema.
                            schemaSet.Add("", UnixfyPathString(file));

                            if (file.Contains("ParkPilotParGenParameterSet_1_0.xsd"))
                            {
                                // Schema for XML version 1.0 exists.
                                xml_1_0_exists = true;

                                // Considering input PAR XML is of version 1.0. 
                                Program.is_xml_1_0 = true;

                                // Check whether PAR XML is according to XML Schema 1.0.
                                doc.Validate(schemaSet, ErrorHandler);

                                // Check whether schema matches the provided PAR XML.
                                if (Program.is_xml_1_0 == true)
                                {
                                    // PAR XML matches with the schema.
                                    Program.xml_version = "1.0";
                                    break;
                                }
                                else
                                {
                                    // PAR XML does not match 1.0 schema, PAR XML can be of version 2.0 or 2.1
                                }
                            }
                            else if (file.Contains("ParkPilotParGenParameterSet_2_0.xsd"))
                            {
                                // Schema for XML version 2.0 exists.
                                xml_2_0_exists = true;

                                // Considering input PAR XML is of version 2.0. 
                                Program.is_xml_2_0 = true;

                                // Check whether PAR XML is according to XML Schema 2.0.
                                doc.Validate(schemaSet,ErrorHandler);

                                // Check whether schema matches the provided PAR XML.
                                if (Program.is_xml_2_0 == true)
                                {
                                    // PAR XML matches with the schema.
                                    Program.xml_version = "2.0";
                                    break;
                                }
                                else
                                {
                                    // PAR XML does not match 2.0 schema, PAR XML can be of version 1.0 or 2.1
                                }
                            }
                            else if (file.Contains("ParkPilotParGenParameterSet_2_1.xsd"))
                            {
                                // Schema for XML version 2.1 exists.
                                xml_2_1_exists = true;

                                // Considering input PAR XML is of version 2.1. 
                                Program.is_xml_2_1 = true;

                                // Check whether PAR XML is according to XML Schema 2.1.
                                doc.Validate(schemaSet, ErrorHandler);

                                // Check whether schema matches the provided PAR XML.
                                if (Program.is_xml_2_1 == true)
                                {
                                    // PAR XML matches with the schema.
                                    Program.xml_version = "2.1";
                                    break;
                                }
                                else
                                {
                                    // PAR XML does not match 2.1 schema, PAR XML can be of version 1.0 or 2.0.
                                }
                            }
                        }
                    }
                    if ((xml_1_0_exists != true) && (xml_2_0_exists != true) && (xml_2_1_exists != true))
                    {
                        // No schemas are available in doc folder. Throw error.
                        throw new Exception("Required schemas are not available in below path. XML Schema Check is not possible.");
                    }
                }
                else
                {
                    // doc folder does not exist, hence schema check not possoble, throw error.
                    throw new Exception("Below Path does not exists, XML Schema Check is not possible.");
                }
            }
            catch (Exception InvalidXML)
            {
                Console.BackgroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("=============================================================================================");
                Console.WriteLine("======================================== ### ERROR ### ======================================");
                Console.WriteLine(InvalidXML.Message);
                Console.WriteLine("{0}",path);
                Console.WriteLine("\"doc\" folder shall contain schema with file names as mentioned below.");
                Console.WriteLine("         XML 1.0 Version : \"ParkPilotParGenParameterSet_1_0.xsd\"");
                Console.WriteLine("         XML 2.0 Version : \"ParkPilotParGenParameterSet_2_0.xsd\"");
                Console.WriteLine("         XML 2.1 Version : \"ParkPilotParGenParameterSet_2_1.xsd\"");
                Console.WriteLine("=============================================================================================");
                Console.ResetColor();
                return false;
            }

            try
            {
                Console.WriteLine("reading parameter definitions from: {0}", Path.GetFullPath(my_InputFileName));
                my_ps = XmlSerializerDeserialize<cParameterSet>(my_InputFileName);

               // Check whether the XML version tag has valid value.
               if (my_ps.ParameterSetInfo.Version == "1.0" || my_ps.ParameterSetInfo.Version == "2.0" || my_ps.ParameterSetInfo.Version == "2.1")
               {
                    // Check if schema exists for the xml provided.
                    if ((my_ps.ParameterSetInfo.Version == "1.0") && (xml_1_0_exists == false))
                    {
                        error_msg = "XML Schema for 1.0 - \"ParkPilotParGenParameterSet_1_0.xsd\" does not exist in below path:\n" + path +".\nSchema check cannot be done.";
                        schema_checked = false;
                    }
                    else if ((my_ps.ParameterSetInfo.Version == "2.0") && (xml_2_0_exists == false))
                    {
                        error_msg = "XML Schema for 2.0 - \"ParkPilotParGenParameterSet_2_0.xsd\" does not exist in below path:\n" + path + ".\nSchema check cannot be done.";
                        schema_checked = false;
                    }
                    else if ((my_ps.ParameterSetInfo.Version == "2.1") && (xml_2_1_exists == false))
                    {
                        error_msg = "XML Schema for 2.1 - \"ParkPilotParGenParameterSet_2_1.xsd\" does not exist in below path:\n" + path + ".\nSchema check cannot be done.";
                        schema_checked = false;
                    }
                    else
                    {
                        // Check whether the XML version matches with the actual XML version type.
                        if ((my_ps.ParameterSetInfo.Version != Program.xml_version))
                        {
                            // Value available with in XML tag <Version> is invalid.
                            error_msg = "    Provided PAR XML does not match Schema. Calibration Parameters will not be generated.    ";
                            schema_checked = false;
                        }
                    }
                }
                else
                {
                    // Value available with in XML tag <Version> is invalid.
                    error_msg = "           Invalid PAR XML version. Calibration Parameters will not be generated.            ";
                    schema_checked = false;
                }

                if (schema_checked != true)
                {
                    Console.WriteLine("");
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("=============================================================================================");
                    Console.WriteLine("======================================== ### ERROR ### ======================================");
                    Console.WriteLine(error_msg);
                    Console.WriteLine("=============================================================================================");
                    Console.ResetColor();
                    Console.WriteLine("");
                    return false;
                }

                return_value = true;
            }
            catch
            {
                if (FileExists(my_InputFileName))
                {
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("=============================================================================================");
                    Console.WriteLine("\"parGen\", line 0: error #0: Error while reading the parameter file!");
                    Console.WriteLine("=============================================================================================");
                    Console.ResetColor();
                }
                else
                {
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("=============================================================================================");
                    Console.WriteLine("\"parGen\", line 0: error #0: Parameter file does not exist!");
                    Console.WriteLine("=============================================================================================");
                    Console.ResetColor();
                }

                return_value = false;
            }

            return return_value;
        }

        // Merge 2 parameter sets.
        static Boolean MergeParameterSets(ref cParameterSet my_ps1, ref cParameterSet my_ps2)
        {
            bool merging_successful = true;

            foreach (cComponent src_comp in my_ps2.Components)
            {
                // Get a pointer to the destination component.
                cComponent dest_comp = my_ps1.Components.Find(
                      delegate(cComponent find_comp)
                      {
                          return find_comp.Name == src_comp.Name;
                      });

                // Check if source component exists in the target object.
                if (dest_comp == null)
                {
                    // Does not yet exist ... copy it to the target.
                    my_ps1.Components.Add(src_comp);
                }
                else
                {
                    // Does already exist ... check more detailed ...

                    // Version check.
                    if ((src_comp.Version != dest_comp.Version) && (src_comp.Version != "") && (dest_comp.Version != ""))
                    {
                        // Version check failed.
                        Console.BackgroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("==================================================================================================================");
                        Console.WriteLine("\"parGen\", line 0: warning #0: Warning while merging input files - {0} component version mismatch!", src_comp.Name);
                        Console.WriteLine("==================================================================================================================");
                        Console.ResetColor();

                        // Do nothing and throw exception
                        // I removed the start of the abort sequence and transform that into a warning
                        // see nprod00220752 Gasser
                        // merging_successful = false.
                    }


                    // Check sorting key.
                    if ((src_comp.CompKey != dest_comp.CompKey) && (src_comp.CompKey != "") && (dest_comp.CompKey != ""))
                    {
                        // Component sorting keys don't match.
                        Console.BackgroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("==================================================================================================================");
                        Console.WriteLine("\"parGen\", line 0: error #0: Error while merging input files - {0} component sorting key mismatch!", src_comp.Name);
                        Console.WriteLine("==================================================================================================================");
                        Console.ResetColor();

                        // Do nothing and throw exception.
                        merging_successful = false;
                    }
                    else
                    {
                        // Sorting keys are matching.

                        // Switches.
                        if ((src_comp.Defines.Count != 0) && (dest_comp.Defines.Count != 0))
                        {
                            Console.BackgroundColor = ConsoleColor.DarkRed;
                            Console.WriteLine("===============================================================================================================");
                            Console.WriteLine("\"parGen\", line 0: error #0: Error while merging input files - {0} switches sheet exists twice!", src_comp.Name);
                            Console.WriteLine("===============================================================================================================");
                            Console.ResetColor();

                            // Do nothing and throw exception.
                            merging_successful = false;
                        }
                        else
                        {
                            // Add all source #defines to the destination list (even if it is empty - just to make the code shorter).
                            dest_comp.Defines.AddRange(src_comp.Defines);
                        }

                        // Parameters.
                        foreach (cParameterCluster src_pc in src_comp.ParameterClusters)
                        {
                            // Get a pointer to the destination parameter cluster.
                            cParameterCluster dest_pc = dest_comp.ParameterClusters.Find(
                              delegate(cParameterCluster find_pc)
                              {
                                  return find_pc.Name == src_pc.Name;
                              });

                            // Check if source parameter cluster exists in the target object.
                            if (dest_pc == null)
                            {
                                // Does not yet exist ... copy it to the target.
                                dest_comp.ParameterClusters.Add(src_pc);
                            }
                            else
                            {
                                // Does already exist ...  exists twice ... throw exception.
                                Console.BackgroundColor = ConsoleColor.DarkRed;
                                Console.WriteLine("=================================================================================================================");
                                Console.WriteLine("\"parGen\", line 0: error #0: Error while merging input files - {0} parameter sheet {1} exists twice!",
                                                   src_comp.Name, src_pc.Name);
                                Console.WriteLine("=================================================================================================================");
                                Console.ResetColor();

                                // Do nothing and throw exception.
                                merging_successful = false;
                            }
                        }
                    }
                }
            }

            return merging_successful;
        }

        // Merge 2 parameter sets.
        static Boolean ReadAllInputParameterSets(ref cParameterSet my_ps, ref List<cComponent> my_cc, ref cGeneralConfiguration my_gc, string Sorting_Order)
        {
            Boolean input_files_successfully_read = false;

            // Check whether input files have been specified at all.
            if (my_gc.InputFiles.Count > 0)
            {
                // Read base parameter set.
                input_files_successfully_read = ReadParameterSet(my_gc.InputFiles[0], ref my_ps);

                // Read and merge sub parameter sets.
                if ((my_gc.InputFiles.Count > 1) && (input_files_successfully_read != false))
                {
                    // Iterate over all remaining input parameter set files.
                    for (int cur_ps_idx = 1; ((cur_ps_idx < my_gc.InputFiles.Count) && (input_files_successfully_read != false)); cur_ps_idx++)
                    {
                        // Temporary parameter set.
                        cParameterSet tmp_ps = new cParameterSet();

                        // Read next sub parameter set.
                        if (ReadParameterSet(my_gc.InputFiles[cur_ps_idx], ref tmp_ps) != false)
                        {
                            // File read successfully - check whether major variant lists are compatible for merging.
                            if (CompareMajorVariantLists(ref my_ps, ref tmp_ps) != false)
                            {
                                // Ok - merging possible - merge.
                                if (MergeParameterSets(ref my_ps, ref tmp_ps) != false)
                                {
                                    // Merging ok.
                                    input_files_successfully_read = true;
                                }
                                else
                                {
                                    // Merge conflict.
                                    input_files_successfully_read = false;
                                }
                            }
                            else
                            {
                                // Major variant lists are not identical.
                                Console.BackgroundColor = ConsoleColor.DarkRed;
                                Console.WriteLine("=============================================================================================");
                                Console.WriteLine("\"parGen\", line 0: error #0: Major variant lists are not identical ({0}, {1})!",
                                                   my_gc.InputFiles[0], my_gc.InputFiles[cur_ps_idx]);
                                Console.WriteLine("=============================================================================================");
                                Console.ResetColor();

                                // Not ok - merging impossible.
                                input_files_successfully_read = false;
                            }
                        }
                        else
                        {
                            // Problem while reading parameter set file.
                            input_files_successfully_read = false;
                        }
                    }
                }
            }
            else
            {
                input_files_successfully_read = false;
            }

            // This split is done from Sorting. If any customer needs sorting they need to set the path for
            // the _sorting.csv file. If the path is not set then the sorting doesn't happen. 
            // Assigning component keys which will be used for sorting of elements later

            // Sorting is specific for NRCS
            if (my_gc.Product_Line == "NRCS")
            {
                // Keep copy of actual order of components(as in xml) before sorting.
                // Usecase: Required for mapping incase of individual run of multiple dataset.
                my_cc = my_ps.Components;
                List<cComponent> my_components = new List<cComponent>(my_cc);
                my_cc = my_components;

                // Sort only if sorting order is provided in _sorting.csv file.
                if (Sorting_Order != "")
                {
                    UInt32 Unique_Id = 0;

                    // Split the whole string into different indexes using the , as a separator
                    string[] array = Sorting_Order.Split(',');

                    foreach (cComponent component in my_ps.Components)
                    {
                        // Check if the component name is present in _sorting.csv file.
                        bool Csv_Contains = array.Contains(component.Name);

                        if (Csv_Contains == true)
                        {
                            for (int i = 0; i < array.Length; i++)
                            {
                                if (component.Name == array[i])
                                {
                                    // Assign CompKey according to its order in _sorting.csv file.
                                    component.CompKey = i.ToString();
                                }
                            }
                        }
                        else
                        {
                            // Add Unique_Id to CompKey to make it unique.
                            // This is to avoid undesired shuffling of components due to unstable sort.
                            UInt32 temp = Convert.ToUInt32(component.CompKey, 10) + Unique_Id;
                            component.CompKey = temp.ToString();
                        }

                        // Increment Unique_Id so that value added remains unique for every component.
                        Unique_Id++;
                    }

                    // Sorting of components and clusters.

                    // Sort components based on CompKey value.
                    my_ps.Components.Sort(cComponent.CompareByCompKey);

                    // Commented out sorting of clusters since currently there is no use case for it.
                    // Also it results in undesired shuffling of clusters due to unstable sort.

                    //// Sort clusters.
                    //foreach (cComponent component in my_ps.Components)
                    //{
                    //    component.ParameterClusters.Sort(cParameterCluster.CompareByClusterKey);
                    //}
                }
            }

            return input_files_successfully_read;
        }
        
        // Function to overwrite output path.
        public void OverwriteOPPath(ref cGeneralConfiguration my_gc, ref String my_output_path, String my_gen_file_name)
        {
            // Overwrite output path.
            if (my_gc.Code_OutputPath != "")
            {
                my_output_path = my_gc.Code_OutputPath;

                DirectoryCreateDirectory(my_output_path);
            }

            // Delete old file automatically if existing.
            try
            {
                Program.FileDelete(Path.Combine(my_output_path, my_gen_file_name));
            }
            catch
            {
                // Do not care about exceptions.
            }
        }
        
        // Print File Info in the generated file.
        public void PrintFileInfo(ref cParameterSet my_ps,
                                         ref String my_ps_file_name,
                                         String my_output_path,
                                         ref DateTime my_dt,
                                         String my_gen_file_name, 
                                         string my_source_file_name)
        {

            // Obtain absolute path of output file.
            var outputPath = Path.Combine(Path.GetFullPath(my_output_path), my_gen_file_name);

            // Open output file.
            var writer = CreateStreamWriter(outputPath, false, Encoding.ASCII);
            Console.WriteLine("generating: {0}", outputPath);

            writer.WriteLine("/*****************************************************************************/");
            writer.WriteLine("// C O P Y R I G H T");
            writer.WriteLine("//-----------------------------------------------------------------------------");
            writer.WriteLine("// Copyright (c) {0:d4} by Robert Bosch GmbH.                All rights reserved.", my_dt.Year);
            writer.WriteLine("");
            writer.WriteLine("// This file is property of Robert Bosch GmbH. Any unauthorised copy, use or ");
            writer.WriteLine("// distribution is an offensive act against international law and may me ");
            writer.WriteLine("// prosecuted under federal law. Its content is company confidential.");
            writer.WriteLine("//-----------------------------------------------------------------------------");
            writer.WriteLine("// D E S C R I P T I O N");
            writer.WriteLine("//-----------------------------------------------------------------------------");
            writer.WriteLine("// $ProjectName: https://sourcecode01.de.bosch.com/scm/nrcsgen2/par_gen.git $");
            writer.WriteLine("//      $Source: {0}$",my_source_file_name);
            writer.WriteLine("//    $Revision: $");
            writer.WriteLine("//        $Date: $");
            writer.WriteLine("//       $State: in_work $");
            writer.WriteLine("//");
            writer.WriteLine("//      Purpose: Generated component configuration file.");
            writer.WriteLine("//-----------------------------------------------------------------------------");
            writer.WriteLine("// I N F O");
            writer.WriteLine("//-----------------------------------------------------------------------------");
            writer.WriteLine("// File:                  {0}", my_gen_file_name);
            writer.WriteLine("// Input File:            {0}", my_ps_file_name);
            writer.WriteLine("// Version:               {0}", my_ps.ParameterSetInfo.Version);
            writer.WriteLine("// Date:                  {0:d4}.{1:d2}.{2:d2} - {3:d2}:{4:d2}",
                              my_ps.ParameterSetInfo.Year, my_ps.ParameterSetInfo.Month, my_ps.ParameterSetInfo.Day,
                              my_ps.ParameterSetInfo.Hours, my_ps.ParameterSetInfo.Minutes);
            writer.WriteLine("");
            writer.WriteLine("// Generation Date (UTC): {0:d4}.{1:d2}.{2:d2} - {3:d2}:{4:d2}",
                              my_dt.Year, my_dt.Month, my_dt.Day, my_dt.Hour, my_dt.Minute);
            writer.WriteLine("/*****************************************************************************/");
            writer.WriteLine("");
            writer.Close();
        }

        // Print error message on console highlighted in red background.
        public void PrintErrorInfo(string my_error_msg)
        {
            Console.BackgroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("{0}", new string('-', my_error_msg.Length + "ERROR: ".Length));
            Console.WriteLine("ERROR: {0}", my_error_msg);
            Console.WriteLine("{0}", new string('-', my_error_msg.Length + "ERROR: ".Length));
            Console.ResetColor();
        }

        // Function to check if Type/Min/Max tags are updated in case of XML 1.0.
        static bool Check_XML_1_0_Info(ref cParameterSet my_ps)
        {
            try
            {
                foreach (cComponent component in my_ps.Components)
                {
                    foreach (cDefine my_define in component.Defines)
                    {
                            if (my_define.Type != "TypeX")
                            {
                                 // Type tag is updated correctly. Do nothing.
                            }
                            else
                            {
                                // Type tag is not updated, throw exception.
                                string exception_message = "Type tag is not updated correctly for Define: '" + my_define.Name + "'";
                                throw (new Exception(exception_message));

                            }
                    }
                    foreach (cParameterCluster cluster in component.ParameterClusters)
                    {
                        foreach (cParameterDefinition para_def in cluster.ParameterDefinitions)
                        {
                                if ((para_def.Type == "TypeX") || (para_def.Min == "MinX") || (para_def.Max == "MaxX"))
                                {
                                    // One among Type/Min/Max tag is not updated. Throw Exception.
                                    string exception_message = "Type/Min/Max tag is not updated correctly for Parameter Definition: '" + para_def.Name + "'";
                                    throw (new Exception(exception_message));
                                }
                                else
                                {
                                    // Tags are updated correctly. Do nothing.
                                }
                        }
                    }
                }
            }
            catch (Exception Invalid_Info)
            {
                Console.BackgroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("======================================================================================");
                Console.WriteLine("                               ### ERROR ###                                          ");
                Console.WriteLine("                             Invalid Tag value.                                       ");
                Console.WriteLine(Invalid_Info.Message);
                Console.WriteLine("======================================================================================");
                Console.ResetColor();
                return false;
            }
            return true;
        }

        /// <summary>
        /// Run pargen after argument parsing.
        /// 
        /// </summary>
        /// <param name="SegmentDefinitionsFileName">Relative path to segment definition file.</param>
        /// <param name="GeneralConfigurationFileName">Relative path to general configuration file. Optional.</param>
        /// <param name="OutputPathName">General output path; used if no other path is specified.</param> 
        /// <param name="GMConfigurationFileName">Name (and relative path) of GM configuration file. Leave away or empty if you're not building for GM.</param>
        /// <param name="RankingOfCluster">Relative path for the .csv which contains information for the sorting order of components.</param>
        /// <param name="SelectedParameters_OutputPath">Relative path to the location where selected parameter files are generated.</param>
        /// <param name="Selected_Dataset">Selected Dataset for which the parameters shall be generated.</param>
        /// TODO: Should return error code or exceptions to the caller, to make regression and requirements based test easier!
        static public void RunParGen(
            string SegmentDefinitionsFileName,
            string GeneralConfigurationFileName,
            string GMConfigurationFileName = "",
            string OutputPathName = ".",
            string RankingOfCluster = "",
            string SelectedParameters_OutputPath = "",
            string Selected_Dataset = "")
        {
            // Input file name.
            string InputFileName = ""; 
            // File name suffix. To infix dataset name within the generated file name.
            //  Required in case of Multiple dataset individual run.
            string FileName_Suffix = "";

            // DatasetName: Required to make variables unique according to dataset names.
            string DatasetName = "";

            // Sorting order.
            string Sorting_Order = "";

            // By Default Defines are consider for HASH Calculation.
            // Variables for Hash computation.
            bool Hash_CAL_b = false; 
            bool Hash_NVM_b = false; 

            // Initialize the necessary variables.
            cSegmentDefinition sd = new cSegmentDefinition();
            cParameterSet ps = new cParameterSet();
            DateTime dt = DateTime.UtcNow;
            cGeneralConfiguration gc = new cGeneralConfiguration();
            cGMConfiguration gmc = new cGMConfiguration();
            cHashes hashes = new cHashes();
            cWrapper_XML_2_x wrapper_2_x = new cWrapper_XML_2_x();
            Program my_program = new Program();
            List<cComponent> ComponentCopy = new List<cComponent>();

            // Read the general configuration file.
            try
            {
                if (GeneralConfigurationFileName != "")
                {
                    string fullPath = Path.GetFullPath(GeneralConfigurationFileName);
                    Console.WriteLine("reading general configuration from: {0}", fullPath);
                    gc = XmlSerializerDeserialize<cGeneralConfiguration>(GeneralConfigurationFileName);
                }
                else
                {
                    Console.WriteLine("using default general configuration");
                }
            }
            catch
            {
                if (FileExists(GeneralConfigurationFileName))
                {
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("=============================================================================================");
                    Console.WriteLine("\"parGen\", line 0: error #0: Error while reading the general configuration file!");
                    Console.WriteLine("=============================================================================================");
                    Console.ResetColor();
                }
                else
                {
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("=============================================================================================");
                    Console.WriteLine("\"parGen\", line 0: error #0: General configuration file does not exist!");
                    Console.WriteLine("=============================================================================================");
                    Console.ResetColor();
                }

                return;
            }

            // Read the GM configuration file.
            if (gc.ST_CHORUS_CALSection_Mode == "GM")
            {
                try
                {
                    if (GMConfigurationFileName != "")
                    {
                        Console.WriteLine("reading GM configuration from: {0}", GMConfigurationFileName);
                        gmc = XmlSerializerDeserialize<cGMConfiguration>(GMConfigurationFileName);
                    }
                    else
                    {
                        Console.BackgroundColor = ConsoleColor.Yellow;
                        Console.ForegroundColor = ConsoleColor.Black;
                        Console.WriteLine("=============================================================================================");
                        Console.WriteLine("======== Warning: GM Configuration file not defined. Using default GM configuration =========");
                        Console.WriteLine("=============================================================================================");
                        Console.ResetColor();
                        
                    }
                }
                catch
                {
                    if (FileExists(GMConfigurationFileName))
                    {
                        Console.BackgroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("=============================================================================================");
                        Console.WriteLine("\"parGen\", line 0: error #0: Error while reading the GM configuration file!");
                        Console.WriteLine("=============================================================================================");
                        Console.ResetColor();
                    }
                    else
                    {
                        Console.BackgroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("=============================================================================================");
                        Console.WriteLine("\"parGen\", line 0: error #0: GM configuration file does not exist!");
                        Console.WriteLine("=============================================================================================");
                        Console.ResetColor();
                    }

                    return;
                }
            }

            if (gc.Product_Line == "NRCS")
            {
                if (gc.DataSet_Type == "MULTIPLE")
                {
                    // Multiple dataset generation. NRCS AUDI
                    if (Selected_Dataset == "main")
                    {
                        // Overall run.
                        // No csv file required for overall run. No sorting done.
                        // This is to have same order of components in overall run and mapping(during individual run).
                        Sorting_Order = "";

                        // Print info on console.
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("\n-------------------------------------------------------------------------------------------------");
                        Console.WriteLine("Generating calibration parameters for overall run of multiple dataset.");
                        Console.WriteLine("-------------------------------------------------------------------------------------------------\n");
                        Console.ResetColor();
                    }
                    else if (Selected_Dataset != "")
                    {
                        // File name shall not contain upper case.
                        // E.g.: _ds1
                        FileName_Suffix = "_" + Selected_Dataset.ToLower();

                        // Use the Selected Dataset as it is(casesensitive) in variable names.
                        // // E.g.: _Ds1
                        DatasetName = "_" + Selected_Dataset;

                        // Individual run.
                        try
                        {
                            // Check whether CSV file path is provided or not.
                            if (RankingOfCluster != "")
                            {
                                string fullPath = Path.GetFullPath(RankingOfCluster);
                                if (FileExists(fullPath))
                                {
                                    Console.WriteLine("Reading sorting order in csv format from: {0}", fullPath);
                                }
                                else
                                {
                                    // Print error message for missing csv
                                    my_program.PrintErrorInfo("csv file path \"" + fullPath + "\" does not exist.");
                                    return;
                                }

                                using (var sr = CreateStreamReader(RankingOfCluster))
                                {
                                    string CurrentLine; // Row of the csv file.
                                    string Dataset_List = ""; // String containing all the entries present in CSV file
                                    string[] CSV_Contents; // Array of string to store all the entries present in CSV file
                                    string[] temp_sort;
                                    string error_msg = ""; // variable to store error message
                                    var ListofDuplicateEntry = new List<string>();

                                    // CurrentLine will be null when the StreamReader reaches the end of file
                                    while ((CurrentLine = sr.ReadLine()) != null)
                                    {
                                        // Replace ';' with ',' -> usecae: if ';' is used as delimiter(e.g.: in European csv).
                                        // Further processing is done considering ',' as the delimiter
                                        // Trim trailing ',' and convert to lower case.
                                        CurrentLine = CurrentLine.Replace(';', ',').TrimEnd(',').ToLower();

                                        // Ignore empty lines.
                                        if (CurrentLine != "")
                                        {
                                            // Append all datasets in order to check for duplicates.
                                            Dataset_List += string.Format("{0},", CurrentLine);

                                            // Split the string with ',' as separator into array of string.
                                            // E.g.: "ds1,compA,compB,compC" -> {"ds1", "compA", "compB", "compC"}
                                            temp_sort = CurrentLine.Split(',');

                                            // Search(case insensitive) if the CurrentLine contains the Selected Dataset
                                            if (temp_sort.Contains(Selected_Dataset.ToLower()))
                                            {
                                                // Join the array members excluding the first index which contains the dataset info.
                                                // Assumption : First element of each dataset contains the Dataset name.
                                                // E.g.: {"ds1", "compA", "compB", "compC"} -> "compA,compB,compC"
                                                Sorting_Order = string.Join(",", temp_sort, 1, ((temp_sort.Length) - 1));
                                            }
                                        }
                                    }

                                    // Trim trailing ',' and split the string into array of strings.
                                    CSV_Contents = Dataset_List.TrimEnd(',').Split(',');

                                    // Check for below errors(considering entire csv):
                                    // - Duplicate entries
                                    // - csv does not contain the provided dataset
                                    if (CSV_Contents.Distinct().Count() != CSV_Contents.Count())
                                    {
                                        int LoopIdx1 = 0;
                                        for (LoopIdx1 = 0; LoopIdx1 < CSV_Contents.Length; LoopIdx1++)
                                        {
                                            int LoopIdx2 = 0;
                                            bool duplicate_found = false;
                                            for (LoopIdx2 = LoopIdx1 + 1; LoopIdx2 < CSV_Contents.Length; LoopIdx2++)
                                            {
                                                if (CSV_Contents[LoopIdx1] == CSV_Contents[LoopIdx2])
                                                {
                                                    // Duplicate entry found.
                                                    duplicate_found = true;
                                                }
                                            }
                                            if (duplicate_found != false)
                                            {
                                                // Create list of duplicate entries.
                                                // If multiple duplicate entries exist add to list only once.
                                                if (!ListofDuplicateEntry.Contains(CSV_Contents[LoopIdx1]))
                                                {
                                                    ListofDuplicateEntry.Add(CSV_Contents[LoopIdx1]);
                                                }
                                            }
                                        }

                                        // Print error message for duplicate entry in csv and the list of duplicate entries.
                                        error_msg += "\ncsv contains below duplicate entries:";
                                        foreach(var duplicate in ListofDuplicateEntry)
                                        {
                                            error_msg += "\n" + duplicate;
                                        }
                                        error_msg += "\nPlease provide csv without any duplicate component/dataset entries.";
                                        my_program.PrintErrorInfo(error_msg);
                                        return;
                                    }
                                    else if (CSV_Contents.Contains(Selected_Dataset.ToLower()) != true)
                                    {
                                        my_program.PrintErrorInfo("\nSelected dataset \"" + Selected_Dataset + "\" does not exist in csv.");
                                        return;
                                    }

                                    // Print info on console.
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("\n-------------------------------------------------------------------------------------------------");
                                    Console.WriteLine("Generating calibration parameters for the selected dataset \"" + Selected_Dataset + "\".");
                                    Console.WriteLine("-------------------------------------------------------------------------------------------------\n");
                                    Console.ResetColor();
                                }
                            }
                            else // (RankingOfCluster == "")
                            {
                                // Print error message for missing csv
                                my_program.PrintErrorInfo("csv file(command line option -r) is not provided. Hence parameter genertaion is not possible!");
                                return;
                            }
                        }
                        catch (Exception CSV_Issue)
                        {
                            // Issue with csv. Print exception message and exit.
                            my_program.PrintErrorInfo(CSV_Issue.Message);
                            return;
                        }
                    }
                    else
                    {
                        // Print error message for missing value for command line option -p(Selected_Dataset)
                        my_program.PrintErrorInfo("DataSet_Type is set as MULTIPLE but no value provided for command line option -p.");
                        return;
                    }
                }
                else // gc.DataSet_Type != "MULTIPLE"
                {
                    try
                    {
                        if (RankingOfCluster != "")
                        {
                            string fullPath = Path.GetFullPath(RankingOfCluster);
                            if (FileExists(fullPath))
                            {
                                Console.WriteLine("reading sorting order in csv format from: {0}", fullPath);
                            }
                            else
                            {
                                // Check to throw warning if the file is missing
                                Console.BackgroundColor = ConsoleColor.DarkRed;
                                Console.WriteLine("      ## WARNING ##              ");
                                Console.WriteLine(" *** The csv file is missing *** ");
                                Console.ResetColor();
                            }
                            using (var sr = CreateStreamReader(RankingOfCluster))
                            {
                                // Reads only the first line from the .csv file. convert all to lower case.
                                Sorting_Order = sr.ReadLine().ToLower();
                                if (Sorting_Order == null)
                                {
                                    // Added here just to avoid errors later in case the csv file is empty.
                                    Sorting_Order = "";
                                }
                            }
                        }
                    }
                    catch
                    {
                        // csv file is missing.
                        // Failsafe initialization.
                        Sorting_Order = "";
                    }
                }
            }

            {
                // This is only for changing the location of generating selected parameters.
                if (SelectedParameters_OutputPath != "")
                {
                    if ((gc.Product_Line == "NRCS") && (gc.DataSet_Type == "MULTIPLE") && (Selected_Dataset == "main"))
                    {
                        Console.BackgroundColor = ConsoleColor.Yellow;
                        Console.ForegroundColor = ConsoleColor.Black;
                        Console.WriteLine("-------------------------------------------------------------------------------------------------");
                        Console.WriteLine("Warning: Selected Parameters Output Path(command line option -d) will be ignored for overall run.");
                        Console.WriteLine("         Calibration Parameters will be generated in output path provided in configuration xml.  ");
                        Console.WriteLine("-------------------------------------------------------------------------------------------------");
                        Console.ResetColor();

                        // SelectedParameters_OutputPath will be ignored for overall run. Reset it to "" to avoid removal of components from parameterset.
                        SelectedParameters_OutputPath = "";
                    }
                    else
                    {
                        string[] output_path_gen;

                        // Changing the path of the generated folders based on the D3(incase of single dataset) or individual run(incase of multiple dataset) output path

                        // PAR_CODE folder.
                        output_path_gen = gc.Code_OutputPath.Split(new[] { Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar }, StringSplitOptions.RemoveEmptyEntries);
                        gc.Code_OutputPath = Path.Combine(SelectedParameters_OutputPath, output_path_gen[output_path_gen.Length - 1]);

                        // LOG folder.
                        output_path_gen = gc.Log_OutputPath.Split(new[] { Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar }, StringSplitOptions.RemoveEmptyEntries);
                        gc.Log_OutputPath = Path.Combine(SelectedParameters_OutputPath, output_path_gen[output_path_gen.Length - 1]);

                        // RAW folder.
                        output_path_gen = gc.ST_CHORUS_DataFlash_OutputPath.Split(new[] { Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar }, StringSplitOptions.RemoveEmptyEntries);
                        gc.ST_CHORUS_DataFlash_OutputPath = Path.Combine(SelectedParameters_OutputPath, output_path_gen[output_path_gen.Length - 1]);

                        // CAL folder.
                        output_path_gen = gc.ST_CHORUS_CALSection_OutputPath.Split(new[] { Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar }, StringSplitOptions.RemoveEmptyEntries);
                        gc.ST_CHORUS_CALSection_OutputPath = Path.Combine(SelectedParameters_OutputPath, output_path_gen[output_path_gen.Length - 1]);
                    }
                }
                else
                {
                    if ((gc.Product_Line == "NRCS") && (gc.DataSet_Type == "MULTIPLE") && (Selected_Dataset != "main"))
                    {
                        // Print error message for missing value for command line option -d(SelectedParameters_OutputPath)
                        // -d is must for generation of parameters for individual run of MULTIPLE dataset.
                        my_program.PrintErrorInfo("Selected Parameters output path(command line option -d) is not provided.");
                        return;
                    }
                }
            }

            {
                // Read input parameter sets. Return true if successfully read else false.
                Boolean input_files_successfully_read = ReadAllInputParameterSets(ref ps, ref ComponentCopy, ref gc, Sorting_Order);

                if (input_files_successfully_read != false)
                {
                    // Base parameter set = first file if everything went ok.
                    InputFileName = gc.InputFiles[0];
                }
                else
                {
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("=============================================================================================");
                    Console.WriteLine("\"parGen\", line 0: error #0: Error while reading the parameter set files!");
                    Console.WriteLine("=============================================================================================");
                    Console.ResetColor();
                    return;
                }
            }

            // Update the Parameter Set structure if input par xml version is 2.0 or 2.1.
            if (ps.ParameterSetInfo.Version != "1.0")
            {
                bool is_xml_info_updated = true;

                // Update the enumeration names, (i,e, Remove Type_ from the enumeration name if avaialble).
                wrapper_2_x.Update_XML_enum_name(ref ps);

                // Update the <Type> tag for Defines (switch \ base data types).
                is_xml_info_updated = wrapper_2_x.Update_XML_DefineType(ref ps);

                if (is_xml_info_updated != false)
                {
                    Console.WriteLine("");
                    if (ps.ParameterSetInfo.Version == "2.0")
                    {
                        Console.BackgroundColor = ConsoleColor.DarkCyan;
                        Console.ForegroundColor = ConsoleColor.Black;
                    }
                    else 
                    {
                        Console.BackgroundColor = ConsoleColor.DarkMagenta;
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    Console.WriteLine("=============================================================================================");
                    Console.WriteLine("======================= Generating parameters for PAR XML {0} Version =======================",ps.ParameterSetInfo.Version);
                    Console.WriteLine("=============================================================================================");
                    Console.ResetColor();
                    Console.WriteLine("");  
                    // Update the <Type>, <Min> and <Max> tag for Parameter definition whose TypeInModel matches enum names.
                    // For <Offset> default value will be 0, for <Resolution> default value will be 1 and <Unit> will be blank. 
                    is_xml_info_updated = wrapper_2_x.Update_XML_Para_Def_EnumInfo(ref ps, ref gc);

                    if (is_xml_info_updated != false)
                    {
                        // Update the <Type>, <Offset>, <Resolution>, <Unit>, <Min> and <Max> for parameter definition, 
                        // whose TypeInModel matches customtype names/cont/logical/disc.
                        is_xml_info_updated = wrapper_2_x.Update_XML_Para_Def_CustomTypeInfo(ref ps);
                    }
                }

                if (is_xml_info_updated == false)
                {
                    // Issue with TypeinModel tag in the PAR XML file.
                    Console.WriteLine("");
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("=============================================================================================");
                    Console.WriteLine(" Error : Issue with PAR XML {0} version. Parameter set is not updated", ps.ParameterSetInfo.Version);
                    Console.WriteLine("============================================================================================");
                    Console.ResetColor();
                    Console.WriteLine("");
                    return;
                }
            }
            else
            {
                // Input PAR XML is 1.0 version.
                Console.WriteLine("");
                Console.BackgroundColor = ConsoleColor.Cyan;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.WriteLine("=============================================================================================");
                Console.WriteLine("======================= Generating parameters for PAR XML 1.0 Version =======================");
                Console.WriteLine("=============================================================================================");
                Console.ResetColor();
                Console.WriteLine("");
                
                // Check if Type/Min/Max tags are updated in case of XML 1.0
                bool is_xml_info_updated = Check_XML_1_0_Info(ref ps);
                
                if (is_xml_info_updated == false)
                {
                    // Type/Min/Max tags is not updated correctly. Cannot proceed with parameter generation.
                    Console.WriteLine("");
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("=============================================================================================");
                    Console.WriteLine("========================= Cannot proceed with parameter generation ==========================");
                    Console.WriteLine("=============================================================================================");
                    Console.ResetColor();
                    Console.WriteLine("");
                    return;
                }
                else
                {
                     // Tags are updated correctly. Proceed with parameter generation.
                }
            }

            // Truncate unwanted components after all the parametersets are updated(E.g.: Type in case of xml 2.x)
            if (gc.Product_Line == "NRCS")
            {
                int Valid_number_ofcomponents_in_csv = 0;
                if (Sorting_Order != "")
                {
                    foreach (cComponent component in ps.Components)
                    {
                        // Split the whole string into different indexes using the , as a separator
                        string[] array = Sorting_Order.Split(',');

                        if (array.Contains(component.Name))
                        {
                            // Number of valid components present in csv.
                            Valid_number_ofcomponents_in_csv++;
                        }
                    }

                    if (Valid_number_ofcomponents_in_csv != Sorting_Order.Split(',').Length)
                    {
                        // Throws a warning if there are invalid component names present in csv file.
                        // This also covers check for empty column and if dataset is not provided as first entry in row.
                        // Addtional highlighting. Something new.
                        Console.BackgroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("                        ## WARNING ##                              ");
                        Console.WriteLine(" *** The csv file used for sorting contains unknown components *** ");
                        Console.ResetColor();
                    }
                }

                if (SelectedParameters_OutputPath != "")
                {
                    // This step is done after the sorting. This MUST be executed only for NRCS.
                    // Check the number of VALID selected components in the csv.
                    // Check the number of existing components from SharCC.
                    // Remove all the other components which are not part of selection list.           
                    int NumberOfCompnents = ps.Components.Count;
                    ps.Components.RemoveRange(Valid_number_ofcomponents_in_csv, (NumberOfCompnents - Valid_number_ofcomponents_in_csv));
                }
            }

            // Read the segment definition file.
            try
            {
                Console.WriteLine("reading segment definitions from: {0}", Path.GetFullPath(SegmentDefinitionsFileName));
                sd = XmlSerializerDeserialize<cSegmentDefinition>(SegmentDefinitionsFileName);
            }
            catch
            {
                if (FileExists(SegmentDefinitionsFileName))
                {
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("=============================================================================================");
                    Console.WriteLine("\"parGen\", line 0: error #0: Error while reading the segment definition file!");
                    Console.WriteLine("=============================================================================================");
                    Console.ResetColor();
                }
                else
                {
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("=============================================================================================");
                    Console.WriteLine("\"parGen\", line 0: error #0: Segment definition file does not exist!");
                    Console.WriteLine("=============================================================================================");
                    Console.ResetColor();
                }

                return;
            }

            Console.WriteLine("");

            // Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - Start
            // Change of memory Layout of CRC FlsTst Block in ParGen
            // Version1 supports 24 bytes and version2 supports 20 bytes.

            if (!(gc.ST_CHORUS_CALSection_FlsTst_CRC_Memory_Layout == "version1" || gc.ST_CHORUS_CALSection_FlsTst_CRC_Memory_Layout == "version2"))
            {
                Console.WriteLine("");
                Console.BackgroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("===============================================================================================");
                Console.WriteLine("                                   ####ERROR####                                               ");
                Console.WriteLine("\"parGen\", ST_CHORUS_CALSection_FlsTst_CRC_Memory_Layout supports either version1 or version2");
                Console.WriteLine("\"parGen\", Please check General Configuration file!                                           ");
                Console.WriteLine("===============================================================================================");
                Console.ResetColor();
                return;
            }

            // Just an empty line ...
            Console.WriteLine("");

            // Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - End.

            // Hash_CAL_b, Hash_NVM_b = False -> Any changes in the XML struture will result in CAL and NVM Hash Change.
            // Hash_CAL_b, Hash_NVM_b = True -> Any changes in the XML struture will result in CAL and NVM Hash Change, except Defines, Component name and its version.  

            if (gc.CAL_HASH_COMPATIBILITY.ToUpper() == "HASH_WITHOUT_DEFINES")
            {
                // Defines should not be considered for the CAL Hash Calculation. 
                Hash_CAL_b = true;
            }
            else
            {
                // Default case , Defines will be considered. 
                Hash_CAL_b = false;
            }

            if (gc.NVM_HASH_COMPATIBILITY.ToUpper() == "HASH_WITHOUT_DEFINES")
            {
                // Defines should not be considered for the NVM Hash Calculation.
                Hash_NVM_b = true;
            }
            else
            {
                // Default case , Defines will be considered.
                Hash_NVM_b = false;
            }

            // Compute the hashes (CAL-section and NVM).
            hashes.Compute(ref ps, ref Hash_CAL_b,ref Hash_NVM_b);

            // Generate the output.
            try
            {
                // NVM cluster list.
                List<string> my_nvm_clusters = new List<string>();

                // Nvm record definitions.
                cNVMRecordList my_nvm_record_list = new cNVMRecordList();

                // access defines name list.
                List<List<string[]>> access_define_list = new List<List<string[]>>();
                bool IsAccessdef_unique = true;

                // Flash test section.
                cFlashTestSection my_flash_test_section = new cFlashTestSection();

                cParameterSet my_parameters = new cParameterSet();
                Resources_Log my_resource = new Resources_Log();
                CalibrationHex my_cal_hex = new CalibrationHex();
                NVM_PAR_Access my_nvm_xml = new NVM_PAR_Access();
                Gen_Header my_gen_header = new Gen_Header();
                Gen_Defines my_gen_defines = new Gen_Defines();
                ParaServer my_paraserver = new ParaServer();
                Exception_Handler my_exception_handler = new Exception_Handler();
                NRCS my_NRCS = new NRCS("param_cfg_access" + FileName_Suffix + "_gen.c");


                Console.WriteLine("RESOURCE USAGE (ROM/NVM)");
                // Generates resourcs usage text file.
                my_resource.PrintResourceUsage(ref ps, OutputPathName, FileName_Suffix, ref gc);
                
                // Generates parameter file for all major varinats.
                my_resource.PrintParameters(ref ps, OutputPathName, FileName_Suffix, ref gc);
                Console.WriteLine("");

                Console.WriteLine("CALIBRATION SECTION (Chorus)");
                // Generates CAL hex file.
                int statusofCAL = my_cal_hex.PrintGenNEC_CAL_Section(ref ps, ref InputFileName, OutputPathName, FileName_Suffix, ref dt, ref gc, ref hashes, ref gmc, ref my_flash_test_section);
                if (statusofCAL < 0)
                {
                    throw (new Exception("cal fucked up"));
                }
                Console.WriteLine("");

                Console.WriteLine("NVM/EEPROM CONTAINERS (Chorus)");
                {
                    // All NVM-files must have an individual time stamp - therefore we add an increasing offset.
                    int time_offset = 0;

                    foreach (String tmp_str in ps.MajorVariants)
                    {
                        // Generates *.xml files (nvm files).
                        my_nvm_xml.PrintGenST_CHORUS_XML(tmp_str, ref ps, ref InputFileName, OutputPathName, FileName_Suffix, ref dt, ref gc, ref hashes, time_offset);

                        time_offset++;
                    }
                }
                Console.WriteLine("");

                Console.WriteLine("PAR EMBEDDED COMPONENT CONFIGURATION");

                // Generates Switches and Constants 
                my_gen_defines.PrintGen_Switch_Defines(ref ps, ref sd, ref InputFileName, OutputPathName, FileName_Suffix, ref dt, ref gc, ref hashes, Selected_Dataset);

                // Generates header file, parameter acccess macros, defines ,structure declarations and inline functions for parameter access
                my_gen_header.PrintGenHeader(ref ps, ref sd, ref InputFileName, OutputPathName, FileName_Suffix, ref dt, ref gc, DatasetName);
                my_gen_header.PrintGenParAccess(ref ps, ref sd, ref InputFileName, OutputPathName, FileName_Suffix, ref dt, ref gc, ref access_define_list, ref IsAccessdef_unique);
                my_gen_header.PrintGenParDefine(ref ps, ref sd, ref InputFileName, OutputPathName, FileName_Suffix, ref dt, ref gc, Selected_Dataset, ref ComponentCopy);
                my_gen_header.PrintGenParStruct(ref ps, ref sd, ref InputFileName, OutputPathName, FileName_Suffix, ref dt, ref gc, DatasetName);
            
                if ((gc.Product_Line == "NRCS") && (gc.DataSet_Type == "MULTIPLE") && (Selected_Dataset != "main"))
                {
                    my_gen_header.PrintGenDSHeader(ref ps, ref InputFileName, OutputPathName, FileName_Suffix, ref dt, ref gc, ref hashes, DatasetName);
                }

                my_gen_header.PrintGenParDefineReadAccess(ref ps, ref InputFileName, OutputPathName, FileName_Suffix, ref dt, ref gc);
                my_gen_header.PrintGenParVariantAccess(ref ps, ref InputFileName, OutputPathName, FileName_Suffix, ref dt, ref gc);
                my_gen_header.PrintGenParWriteAccess(ref ps, ref InputFileName, OutputPathName, FileName_Suffix, ref dt, ref gc);

                // Generate rbp_param_types_def.h file for PAR XML 2.0 or 2.1 Version.
                if (ps.ParameterSetInfo.Version != "1.0")
                {
                    wrapper_2_x.PrintGenParamTypesDef(ref ps, ref InputFileName, OutputPathName, FileName_Suffix, ref dt, ref gc);
                }

                if (gc.Product_Line == "NRCS")
                {
                    // Generates param_cfg_access_gen.c file.
                    my_NRCS.Print_CodingData(ref ps, ref sd, ref InputFileName, OutputPathName, ref dt, ref gc, Sorting_Order);
                }

                // Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - Start
                // Earlier, the code of  my_flash_test_section is commented in the method PrintGenMain
                // In case if the code to be uncomment in the PrintGenMain -
                // Please do the changes to support the version2 memory layout of flast test section.
                // Modified by kartheek.byggari@in.bosch.com 18-Mar-2014 - End.

                // Generates NVM Header file.
                Boolean max_cluster_reached_b = my_nvm_xml.PrintGenNVMHeader(ref ps, ref InputFileName, OutputPathName, FileName_Suffix, ref dt, ref gc);

                if (max_cluster_reached_b == true)
                {
                    // Add the list of files to be retained.
                    // E.g.: file_list.Add("rbp_par_main_gen.c");
                    List<string> file_list = new List<string>();

                    Console.WriteLine("");
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("==========================================================");
                    Console.WriteLine("####### ----------- ERROR -------------------#############");
                    Console.WriteLine("PAR should be enhanced to treat NVM cluster > 255");
                    Console.WriteLine("PAR component for NVM READ/WRITE will not work properly ");
                    Console.WriteLine("####### ----------- ERROR -------------------#############");
                    Console.WriteLine("==========================================================");
                    Console.ResetColor();

                    // Throw exception as there is an oveflow in number of NVM cluster. Delete the generated files except LOG folder and the ones mentioned in file_list. 
                    throw (new Exception_Handler("NUMBER OF NVM_INIT CLUSTERS ALLOWED is 255", ref gc, max_cluster_reached_b, file_list));
                }
                else
                {
                    // Generates NVM handling code.
                    my_nvm_xml.PrintGenNVMC(ref ps, ref sd, ref InputFileName, OutputPathName, FileName_Suffix, ref dt, ref gc);

                    //Generates Parameter server and Handling of parameters.
                    my_paraserver.PrintGenMain(ref ps, ref sd, ref InputFileName, OutputPathName, FileName_Suffix, ref dt, ref gc, ref gmc, ref my_flash_test_section, IsAccessdef_unique, Selected_Dataset, DatasetName);

                }

                if (ps.ParameterSetInfo.Version == "2.1")
                {
                    // Generates A2L comments for parameters visible to Customers (all referencing to ROM) based on Disclosure tag value.
                    // Supported from PAR XML version 2.1.
                    my_paraserver.PrintGenOemA2L(ref ps, ref InputFileName, OutputPathName, FileName_Suffix, ref dt, ref gc, DatasetName);
                }

                // Generates the log file if identical defines upto first 63 characters are available or not.
                my_resource.PrintAccessDefineList(OutputPathName, FileName_Suffix, ref gc,ref access_define_list);

                // Variable/Flag indicates Gaps/Holes are available or not.
                Boolean check_para = CheckParameterGaps(ref ps, ref gc, FileName_Suffix);

                // Try block to handle Parameter Holes/Gaps.
                try
                {
                    // Holes in Either Parameters or Sub_varinat/Minor Variant Clusters.
                    if (check_para != false)
                    {
                        Boolean structure_check_flag_b = false;

                        // Add list of files to be retained in below list.
                        List<string> file_list = new List<string>();

                        // Check for the flag whether to throw Error/Warning for Structure Holes.
                        if (gc.Structure_Holes_Flag == "false")
                        {
                            structure_check_flag_b = false;
                        }
                        else if (gc.Structure_Holes_Flag == "true")
                        {
                            structure_check_flag_b = true;
                            // Do not delete rbp_par_struct_gen.h/rbp_par_struct_<dsx>_gen.h file as it is needed to fix structure gaps.
                            file_list.Add("rbp_par_struct" + FileName_Suffix + "_gen.h");
                        }
                        // Some operations needs to de done before exiting the code
                        // Parameter : 1st : Message to be displayed
                        //             2nd : Reference to obtain Directory
                        //             3rd : Throw Warning/Error False : Warning , True : Error.
                        //             4th : List of file to be retained other than LOG folder files.

                        Console.WriteLine("");
                        Console.WriteLine("=============================================================================================");
                        Console.WriteLine("\"IMPORTANT : TAKE CARE OF STRUCTURE HOLES/GAPS FOR CLUSTERS CLASSIFIED AS NVM/NVM_INIT\"");
                        Console.WriteLine("=============================================================================================");
                        throw (new Exception_Handler("\"Holes are available in clusters, see the " + Path.GetFullPath(gc.Log_OutputPath) + "\\" + "Padding_log" + FileName_Suffix + ".txt" + " file for the list\" ", ref gc, structure_check_flag_b, file_list));
                    }
                }

                catch (Exception_Handler EH)
                {
                    Console.WriteLine(EH.Message);
                }
                Console.WriteLine("");
                Console.BackgroundColor = ConsoleColor.Green;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.WriteLine("=============================================================================================");
                Console.WriteLine("============================ Parameter Generation Successful! :) ============================");
                Console.WriteLine("============================          Pargen End!                ============================");
                Console.WriteLine("=============================================================================================");
                Console.ResetColor();
            }

            catch (Exception ex)
            {
                Console.WriteLine("");
                Console.BackgroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("=============================================================================================");
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                Console.WriteLine("==== \"parGen\", Error #0: Error while processing the data or creating the output files! ====");
                Console.WriteLine("============================ Parameter Generation Failed! :( ================================");
                Console.WriteLine("=============================================================================================");
                Console.ResetColor();
                return;
            }
        }

        /// <summary>
        /// Replaces \ with / in path names.
        /// </summary>
        /// <param name="path">Path/URI</param>
        /// <returns>Unixfied path</returns>
        /// <remarks>
        /// .NET handles under Windows '\' and '/' equally as path separator.<br/>
        /// Mono handles under Linux only '/' as path separator.<br/>
        /// ==> Therefore all path need to get separated via '/'.<br/>
        /// ==> Before a path is actually used externally it needs to get normalized to the respective platform.<br/>
        /// </remarks> 
        public static string UnixfyPathString(string path)
        {
            if (path == null)
            {
                path = string.Empty;
            }
            var result = path.Replace(@"\", @"/");
            return result;
        }

        /// <summary>
        /// Loads an XDocument from the given path.
        /// </summary>
        /// <param name="path">Path to the XDocument.</param>
        /// <returns>XDocument loaded from the given path.</returns>
        public static XDocument XDocumentLoad(string path)
        {
            path = UnixfyPathString(path);
            var rd = XmlReader.Create(path);
            var doc = XDocument.Load(rd);
            return doc;
        }

        /// <summary>
        /// Deserializes the given XML Document.
        /// </summary>
        /// <typeparam name="T">Type of the objects to be deserialized.</typeparam>
        /// <param name="path">File to be deserialized.</param>
        /// <returns>Deserialized file</returns>
        public static T XmlSerializerDeserialize<T>(string path)
        {
            using (var sr = CreateStreamReader(path))
            {
                return (T)new XmlSerializer(typeof(T)).Deserialize(sr);
            }
        }

        /// <summary>
        /// Appends the string to the given file and creates the file if it does not exist and closes the file after writing.
        /// </summary>
        /// <param name="path">Path to the file.</param>
        /// <param name="contents">String to be appended to the file.</param>
        public static void FileAppendAllText(string path, string contents)
        {
            //path = UnixfyPathString(path);
            //File.AppendAllText(path, contents);
            try
            {
                path = UnixfyPathString(path);
                File.AppendAllText(path, contents);
            }
            catch (Exception)
            {
                Console.WriteLine("Exception");
                Console.WriteLine("Path: {0}", path);
                Console.WriteLine("Exception");
                throw;
            }
        }

        /// <summary>
        /// Appends the string to the given file and creates the file if it does not exist.
        /// </summary>
        /// <param name="path">Path to the file.</param>
        /// <param name="contents">String to be appended to the file.</param>
        /// <param name="encoding">Encoding of the file.</param>
        public static void FileAppendAllText(string path, string contents, Encoding encoding)
        {
            path = UnixfyPathString(path);
            File.AppendAllText(path, contents, encoding);
        }

        /// <summary>
        /// Checks whether the given file exists.
        /// </summary>
        /// <param name="path">File to be checked.</param>
        /// <returns>true, if the file exists. false, otherwise</returns>
        public static bool FileExists(string path)
        {
            path = UnixfyPathString(path);
            return File.Exists(path);
        }

        /// <summary>
        /// Deletes a given file.
        /// </summary>
        /// <param name="path">File to be deleted.</param>
        public static void FileDelete(string path)
        {
            path = UnixfyPathString(path);

            if (FileExists(path))
            {
                var fileInfo = new FileInfo(path);
                FileSetAttributes(fileInfo.FullName, FileAttributes.Normal);
                fileInfo.Delete();
            }

            //FileDelete(path);
        }

        /// <summary>
        /// Reads all text from a file and closes the file afterwards.
        /// </summary>
        /// <param name="path">File whose text is to be read.</param>
        /// <returns>Text of the file.</returns>
        public static string FileReadAllText(string path)
        {
            path = UnixfyPathString(path);
            return File.ReadAllText(path);
        }

        /// <summary>
        /// Reads all text from a file with the given encoding and closes the file afterwards.
        /// </summary>
        /// <param name="path">File whose text is to be read.</param>
        /// <param name="encoding">Encoding of the file to be read.</param>
        /// <returns>Text of the file</returns>
        public static string FileReadAllText(string path, Encoding encoding)
        {
            path = UnixfyPathString(path);
            return File.ReadAllText(path, encoding);
        }

        /// <summary>
        /// Reads the lines of the file.
        /// </summary>
        /// <param name="path">File whose lines are to be read.</param>
        /// <returns>Lines of the file</returns>
        public static IEnumerable<string> FileReadLines(string path)
        {
            path = UnixfyPathString(path);
            return File.ReadLines(path);
        }

        /// <summary>
        /// Reads the lines of the file in the given encoding.
        /// </summary>
        /// <param name="path">File whose lines are to be read.</param>
        /// <param name="encoding">Encoding of the file to be read.</param>
        /// <returns>Lines of the file</returns>
        public static IEnumerable<string> FileReadLines(string path, Encoding encoding)
        {
            path = UnixfyPathString(path);
            return File.ReadLines(path, encoding);
        }

        /// <summary>
        /// Sets the attributes of the given file.
        /// </summary>
        /// <param name="path">File for which the attributes are to be set.</param>
        /// <param name="fileAttributes">Attribute to be set for the file.</param>
        public static void FileSetAttributes(string path, FileAttributes fileAttributes)
        {
            path = UnixfyPathString(path);
            File.SetAttributes(path, fileAttributes);
        }

        /// <summary>
        /// Checks whether the given directory exists.
        /// </summary>
        /// <param name="path">Directory to be checked.</param>
        /// <returns>true, if the directory exists. false, otherwise.</returns>
        public static bool DirectoryExists(string path)
        {
            path = UnixfyPathString(path);
            return Directory.Exists(path);
        }

        /// <summary>
        /// Sets the current directory to the given path.
        /// </summary>
        /// <param name="path">Path to which the current directory shall be set.</param>
        public static void DirectorySetCurrentDirectory(string path)
        {
            path = UnixfyPathString(path);
            Directory.SetCurrentDirectory(path);
        }

        /// <summary>
        /// Gets the current directory.
        /// </summary>
        /// <returns>Path to the current directory.</returns>
        public static string DirectoryGetCurrentDirectory()
        {
            var result = Directory.GetCurrentDirectory();
            result = UnixfyPathString(result);
            return result;
        }

        /// <summary>
        /// Returns the names of all files in the given directory.
        /// </summary>
        /// <param name="path">Directory whose file names shall be returned.</param>
        /// <returns>Name of all files in the given directory.</returns>
        public static string[] DirectoryGetFiles(string path)
        {
            path = UnixfyPathString(path);
            return Directory.GetFiles(path);
        }

        /// <summary>
        /// Returns the names of all directories in the given directory.
        /// </summary>
        /// <param name="path">Directory to search in.</param>
        /// <returns>Names of all directories in the given directory.</returns>
        public static string[] DirectoryGetDirectories(string path)
        {
            path = UnixfyPathString(path);
            return Directory.GetDirectories(path);
        }

        /// <summary>
        /// Creates the given directory if it does not exist.
        /// </summary>
        /// <param name="path">Directory to be created</param>
        public static void DirectoryCreateDirectory(string path)
        {
            path = UnixfyPathString(path);
            // Check if directory exists.
            if (!string.IsNullOrEmpty(path) && !DirectoryExists(path))
            {
                // Create the directory, it does not exist.
                Directory.CreateDirectory(path);
            }
        }

        /// <summary>
        /// Creates a new StreamReader for the given path.
        /// </summary>
        /// <param name="path">File to be read.</param>
        /// <returns>TextReader for the file.</returns>
        public static TextReader CreateStreamReader(string path)
        {
            path = UnixfyPathString(path);
            return new StreamReader(path);
        }

        /// <summary>
        /// Creates a new StreamWriter object for the given path with the specified encoding.
        /// </summary>
        /// <param name="path">File to be written to.</param>
        /// <param name="append">true if the file shall be appended, false if the file shall be overwritten.</param>
        /// <param name="encoding">Encoding of the file.</param>
        /// <returns>TextWriter for the file.</returns>
        public static StreamWriter CreateStreamWriter(string path, bool append, Encoding encoding)
        {
            path = UnixfyPathString(path);
            // Create directory, if not yet existing.
            var directory = Path.GetDirectoryName(path);
            DirectoryCreateDirectory(directory);
            // return TextWriter
            return new StreamWriter(path, append, encoding);
        }

        // The main function.
        static void Main(string[] args)
        {
            // General output path; used if no other path is specified.
            string OutputPathName = "";

            // Segment definition file.
            string SegmentDefinitionsFileName = "";

            // General configuration file.
            string GeneralConfigurationFileName = "";

            // GM configuration file.
            string GMConfigurationFileName = "";

            // Cluster ranking file.
            string RankingOfCluster = "";

            //Output path for generating the selected parameters.
            string SelectedParameters_OutputPath = ""; 

            // Selected dataset for which parameters needs to be generated.
            string Selected_DataSet = "";

            {
                // Command line parsing.
                Arguments CommandLine = new Arguments(args);

                // Command line parsing error.
                bool error = false;

                if (CommandLine["o"] != null)
                {
                    // Output path is defined.
                    OutputPathName = CommandLine["o"];
                }
                else
                {
                    // Use default.
                    OutputPathName = ".";
                }

                if (CommandLine["s"] != null)
                {
                    // Segment definition file is defined.
                    SegmentDefinitionsFileName = CommandLine["s"];
                }
                else
                {
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("=============================================================================================");
                    Console.WriteLine("\"parGen\", line 0: error #0: Parameter 'segment definition file' not defined (Option -s)!");
                    Console.WriteLine("=============================================================================================");
                    Console.ResetColor();
                    error = true;
                }

                if (CommandLine["c"] != null)
                {
                    // General configuration file is defined.
                    GeneralConfigurationFileName = CommandLine["c"];
                }
                else
                {
                    // Use default.
                    GeneralConfigurationFileName = "";
                }

                if (CommandLine["g"] != null)
                {
                    // GM configuration file is defined.
                    GMConfigurationFileName = CommandLine["g"];
                }
                else
                {
                    // Use default.
                    GMConfigurationFileName = "";
                }

                if (CommandLine["r"] != null)
                {
                    // Ranking of cluster is defined.
                    RankingOfCluster = CommandLine["r"];
                }
                else
                {
                    // Use default.
                    RankingOfCluster = "";
                }

                if (CommandLine["d"] != null)
                {
                    // Selected parameters output path is defined.
                    SelectedParameters_OutputPath = CommandLine["d"];
                }
                else
                {
                    // Use default.
                    SelectedParameters_OutputPath = "";
                }

                if (CommandLine["p"] != null)
                {
                    // Required dataset is provided.
                    Selected_DataSet = CommandLine["p"];
                }
                else
                {
                    // Use default.
                    Selected_DataSet = "";
                }

                // Print help in case of an error.
                if (error != false)
                {
                    Console.WriteLine("");
                    Console.WriteLine("ParGen (c) 2009 - 2010 Robert Bosch GmbH");
                    Console.WriteLine("");
                    Console.WriteLine("Program Usage:");
                    Console.WriteLine("pargen.exe -o=<OUPUT_PATH>");
                    Console.WriteLine("           -s=<SEGMENT_DEFINITION_FILE>");
                    Console.WriteLine("           -c=<GENERAL_CONFIGURATION_FILE>");
                    Console.WriteLine("           -g=<GM_CONFIGURATION_FILE>");
                    Console.WriteLine("           -r=<RANKING_OF_CLUSTERS>");
                    Console.WriteLine("           -d=<SELECTED_PARAMETERS_OUTPUT_PATH>");
                    Console.WriteLine("           -p=<SELECTED_DATASET>");
                    return;
                }
                else
                {
                    DirectoryCreateDirectory(OutputPathName);
                }
            }

            Console.WriteLine("INPUT DATA AQUISITION");

            // Run Pargen.
            Program.RunParGen(SegmentDefinitionsFileName, GeneralConfigurationFileName, GMConfigurationFileName, OutputPathName, RankingOfCluster, SelectedParameters_OutputPath, Selected_DataSet);
        }
    }
}
