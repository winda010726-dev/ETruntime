using System;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;


namespace parsrv
{
    // A class to handle the attributes of a switch/constant #define.
    public class cDefine
    {
        // Name of the switch/constant.
        private string my_name;

        // Datatype (E.g.: SInt16, switch, Boolean..)
        private string my_type;

        //
        private string my_typeInModel_TwoZero;

        //
        private string my_typeInPlatform_TwoZero;

        // Value of switch/constant.
        private string my_value;

        // Scope (E.g.: global)
        private string my_scope;

        // Info whether external overwrite is allowed or no.
        private string my_external_overwrite;

        // Switch/constant information.
        private string my_description;

        [XmlElement("Name")]
        public string Name
        {
            get { return my_name; }
            set { my_name = value; }
        }

        [XmlElement("Type")]
        public string Type
        {
            get { return my_type; }
            set { my_type = value; }
        }

        [XmlElement("TypeInModel")]
        public string TypeInModel
        {
            get { return my_typeInModel_TwoZero; }
            set { my_typeInModel_TwoZero = value; }
        }

        [XmlElement("TypeInPlatform")]
        public string TypeInPlatform
        {
            get { return my_typeInPlatform_TwoZero; }
            set { my_typeInPlatform_TwoZero = value; }
        }

        [XmlElement("Value")]
        public string Value
        {
            get { return my_value; }
            set { my_value = value; }
        }

        [XmlElement("Scope")]
        public string Scope
        {
            get { return my_scope; }
            set { my_scope = value; }
        }

        [XmlElement("ExternalOverwrite")]
        public string ExternalOverwrite
        {
            get { return my_external_overwrite; }
            set { my_external_overwrite = value; }
        }

        [XmlElement("Description")]
        public string Description
        {
            get { return my_description; }
            set { my_description = value; }
        }

        // Default constructor.
        public cDefine()
        {
            this.my_name = "ComponentX";
            this.my_type = "TypeX";
            this.my_typeInModel_TwoZero = "null";
            this.my_typeInPlatform_TwoZero = "null";
            this.my_value = "ValueX";
            this.my_scope = "global";
            this.my_external_overwrite = "no";
            this.my_description = "no description available";
        }

        // Parameterized constructor.
        public cDefine(string new_name,
                        string new_type,
                        string new_typeInModel_TwoZero,
                        string new_typeInPlatform_TwoZero,
                        string new_value,
                        string new_scope,
                        string new_external_overwrite,
                        string new_description)
        {
            this.my_name = new_name;
            this.my_type = new_type;
            this.my_typeInModel_TwoZero = new_typeInModel_TwoZero;
            this.my_typeInPlatform_TwoZero = new_typeInPlatform_TwoZero;
            this.my_value = new_value;
            this.my_scope = new_scope;
            this.my_external_overwrite = new_external_overwrite;
            this.my_description = new_description;
        }
    }

    class Gen_Defines
    {
        // Generate the file rbp_par_switches_gen.h.
        public void PrintGen_Switch_Defines(ref cParameterSet my_ps,
                                            ref cSegmentDefinition my_sd,
                                            ref String my_ps_file_name,
                                            String my_output_path,
                                            string my_FileName_Suffix,
                                            ref DateTime my_dt,
                                            ref cGeneralConfiguration my_gc,
                                            ref cHashes my_hashes,
                                            string my_Selected_Dataset)
        {
            // Initialize the necessary variables.
            Program my_program = new Program();
            string my_gen_file_name = "rbp_par_switches" + my_FileName_Suffix + "_gen.h";
            string my_source_file_name = "Gen_Defines.cs";

            // Overwrite the output path if already exists.
            my_program.OverwriteOPPath(ref my_gc, ref my_output_path, my_gen_file_name);

            // Generated file header.
            my_program.PrintFileInfo(ref my_ps, ref my_ps_file_name, my_output_path, ref my_dt, my_gen_file_name, my_source_file_name);

            // Obtain absolute path of output file.
            var genFileNamePath = Path.Combine(Path.GetFullPath(my_output_path), my_gen_file_name);

            // Open output file.
            var writer = Program.CreateStreamWriter(genFileNamePath, true, Encoding.ASCII);

            writer.WriteLine("#ifndef RBP_PAR_SWITCHES{0}_GEN_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("#define RBP_PAR_SWITCHES{0}_GEN_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("");
            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("extern \"C\"");
            writer.WriteLine("{");
            writer.WriteLine("#endif // __cplusplus");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- magic number                                                           -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#define RBP_PAR_SWITCHES_GEN_MAGIC_NUMBER  0x{0:d2}{1:d2}{2:d2}{3:d2}",
                              my_dt.Month, my_dt.Day, my_dt.Hour, my_dt.Minute);
            writer.WriteLine("");

            if ((my_gc.Product_Line == "NRCS") && (my_gc.DataSet_Type == "MULTIPLE") && (my_Selected_Dataset != "main"))
            {
                // Do nothing. Cal/NVM/Range Resolution Hash and CAL ID will be available in rbp_par_<DSx>_gen.h header files.
            }
            else
            {
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("/*- CAL-section structure integrity hash                                   -*/");
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("");
                writer.WriteLine("#ifdef RBP_COMPONENT_PAR");
                // CAL hash.
                writer.WriteLine("#define rbp_par_cal_StructureIntegrityHash_mac {{ {0} }}", my_hashes.CALHash);
                writer.WriteLine("#endif");
                writer.WriteLine("");

                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("/*- CAL REFERENCE ID -- Version Information                                -*/");
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                // 64 bytes version identifier. 
                {
                    string tmp_string = my_gc.ST_CHORUS_CALSection_Version;
                    tmp_string = tmp_string.PadRight(64, '_');
                    writer.WriteLine("#define CAL_VERSION_ID {0}", tmp_string);
                }

                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("/*- NVM-section structure integrity hash                                   -*/");
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("");
                writer.WriteLine("#ifdef RBP_COMPONENT_PAR");
                // NVM hash.
                writer.WriteLine("#define rbp_par_nvm_StructureIntegrityHash_mac {{ {0} }}", my_hashes.NVMHash);
                writer.WriteLine("#endif");
                writer.WriteLine("");

                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("/*- CAL-section range resolution hash                                      -*/");
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("");
                writer.WriteLine("#ifdef RBP_COMPONENT_PAR");
                // Range Resolution hash.
                writer.WriteLine("#define rbp_par_cal_RangeResHash_mac {{ {0} }}", my_hashes.CALRRHash);
                writer.WriteLine("#endif");
                writer.WriteLine("");
            }


            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- component switches                                                     -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- PAR automatically generated                                            -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            // Check if NVM_INIT, RAM_INIT clusters are available.
            // Accordingly switch ON/OFF the NVM/RAM mirror usage.
            {
                Boolean uses_nvm_init = false;
                Boolean uses_ram_init = false;

                // Check whether the configuration uses NVM_INIT, RAM_INIT.
                foreach (cComponent component in my_ps.Components)
                {
                    foreach (cParameterCluster cluster in component.ParameterClusters)
                    {
                        if ((cluster.MemoryArea == "NVM_INIT"))
                        {
                            // NVM_INIT clusters are available.
                            uses_nvm_init = true;
                        }
                        if ((cluster.MemoryArea == "RAM_INIT"))
                        {
                            // RAM_INIT clusters are available.
                            uses_ram_init = true;
                        }
                    }
                }

                if (uses_nvm_init != false)
                {
                    // NVM_INIT clusters are available, switch on the usage of the NVM-mirror.
                    writer.WriteLine("// NVM_INIT Clusters are available (i.e. in PAR XML)");
                    writer.WriteLine("#ifndef RBP_GS_PAR_CFG_INIT_NVM_MIRROR_MEM");
                    writer.WriteLine("   #define RBP_GS_PAR_CFG_INIT_NVM_MIRROR_MEM RBP_SW_ON");
                    writer.WriteLine("#endif");
                }
                else
                {
                    // NVM_INIT clusters are not available, switch off the usage of the NVM-mirror.
                    writer.WriteLine("// NVM_INIT Clusters are not available (i.e. in PAR XML)");
                    writer.WriteLine("#ifndef RBP_GS_PAR_CFG_INIT_NVM_MIRROR_MEM");
                    writer.WriteLine("   #define RBP_GS_PAR_CFG_INIT_NVM_MIRROR_MEM RBP_SW_OFF");
                    writer.WriteLine("#endif");
                }

                if (uses_ram_init != false)
                {
                    // RAM_INIT clusters are available, switch on the usage of the RAM-mirror.
                    writer.WriteLine("// RAM_INIT Clusters are available (i.e. in PAR XML)");
                    writer.WriteLine("#ifndef RBP_GS_PAR_CFG_INIT_RAM_MIRROR_MEM");
                    writer.WriteLine("   #define RBP_GS_PAR_CFG_INIT_RAM_MIRROR_MEM RBP_SW_ON");
                    writer.WriteLine("#endif");
                }
                else
                {
                    // RAM_INIT clusters are not available, switch off the usage of the RAM-mirror.
                    writer.WriteLine("// RAM_INIT Clusters are not available (i.e. in PAR XML)");
                    writer.WriteLine("#ifndef RBP_GS_PAR_CFG_INIT_RAM_MIRROR_MEM");
                    writer.WriteLine("   #define RBP_GS_PAR_CFG_INIT_RAM_MIRROR_MEM RBP_SW_OFF");
                    writer.WriteLine("#endif");
                }
            }
            
            writer.WriteLine("");

            writer.WriteLine("// Constant defines required  for variant handling");
            writer.WriteLine("#define RBP_GS_VAR_TYPE_SINGLE    0");
            writer.WriteLine("#define RBP_GS_VAR_TYPE_MULTI     1");
            writer.WriteLine("#define RBP_GS_VAR_TYPE_SRV_VAR_OFF   2");
            writer.WriteLine("");

            if (my_ps.MajorVariants.Count > 1)
            {
               // Multi set XML
                writer.WriteLine("// Multi variant support");
                writer.WriteLine("#ifndef RBP_GS_VAR_TYPE");
                writer.WriteLine("  #define RBP_GS_VAR_TYPE RBP_GS_VAR_TYPE_MULTI");
                writer.WriteLine("#endif");
            }
            else
            {
                // Single set XML.
                writer.WriteLine("// Single variant support" );
                writer.WriteLine("#ifndef RBP_GS_VAR_TYPE");
                writer.WriteLine("  #define RBP_GS_VAR_TYPE RBP_GS_VAR_TYPE_SINGLE");
                writer.WriteLine("#endif");
            }
            writer.WriteLine("");

            foreach (cComponent component in my_ps.Components)
            {
                // Print the component to which the defines belong to.
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("/*- {0}{1} -*/", component.Name.ToUpper(), new String(' ', 70 - component.Name.Length));
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("");
                writer.WriteLine("/*!\\defgroup {0}_M02           exported symbolic constants", component.Name.ToUpper());
                writer.WriteLine(" * \\ingroup RBP_COMPONENT_{0}", component.Name.ToUpper());
                writer.WriteLine(" @{ */");
                writer.WriteLine("");

                // Defines with global scope.
                foreach (cDefine my_define in component.Defines)
                {
                    if (my_define.Scope == "global")
                    {
                        String pre_fix;
                        String post_fix;
                        String my_value;


                        if (my_define.Type == "switch")
                        {
                            pre_fix = "RBP";
                            post_fix = "";
                            my_value = String.Format("{0}", my_define.Value);
                        }
                        else
                        {
                            pre_fix = "rbp";

                            if (my_define.Type == "UInt8") { post_fix = "_du8"; my_value = String.Format("((UInt8)({0}))", my_define.Value); }
                            else if (my_define.Type == "UInt16") { post_fix = "_du16"; my_value = String.Format("((UInt16)({0}))", my_define.Value); }
                            else if (my_define.Type == "UInt32") { post_fix = "_du32"; my_value = String.Format("((UInt32)({0}))", my_define.Value); }
                            else if (my_define.Type == "SInt8") { post_fix = "_ds8"; my_value = String.Format("((SInt8)({0}))", my_define.Value); }
                            else if (my_define.Type == "SInt16") { post_fix = "_ds16"; my_value = String.Format("((SInt16)({0}))", my_define.Value); }
                            else if (my_define.Type == "SInt32") { post_fix = "_ds32"; my_value = String.Format("((SInt32)({0}))", my_define.Value); }
                            else if (my_define.Type == "Boolean") { post_fix = "_db"; my_value = String.Format("((Boolean)({0}))", my_define.Value); }
                            else if (my_define.Type == "Float32") { post_fix = "_df32"; my_value = String.Format("((Float32)({0}))", my_define.Value); }
                            else { post_fix = "unknown"; my_value = String.Format("({0})", my_define.Value); }
                        }

                        if (my_define.ExternalOverwrite == "yes")
                        {
                            // E.g.: Define name: LS_CTL_DEBUG
                            //                    #ifndef RBP_LS_CTL_DEBUG
                            writer.WriteLine("#ifndef {0}_{1}{2}", pre_fix, my_define.Name, post_fix);

                            writer.Write("  ");
                        }

                        // Varma: Added this code to prefix RBP_only for switches and not for numeric constants
                        if (my_define.Type == "switch")
                        {
                            // E.g.: Define Name: LS_CTL_DEBUG
                            //                    #define RBP_LS_CTL_DEBUG RBP_SW_OFF
                            writer.WriteLine("#define {0}_{1}{2} RBP_{3}", pre_fix, my_define.Name, post_fix, my_value);
                        }
                        else
                        {
                            // E.g.: Define Name: GS_PAS_NUM_DISP_AREA_FRONT
                            //                    #define rbp_GS_PAS_NUM_DISP_AREA_FRONT_ds32 ((SInt32)(5))
                            writer.WriteLine("#define {0}_{1}{2} {3}", pre_fix, my_define.Name, post_fix, my_value);
                        }

                        if (my_define.ExternalOverwrite == "yes")
                        {
                            writer.WriteLine("#endif");
                        }
                    }
                }

                // Defines with local scope.
                {
                    writer.WriteLine("");
                    writer.WriteLine("#ifdef {0}", component.Name.ToUpper());
                    writer.WriteLine("");

                    foreach (cDefine my_define in component.Defines)
                    {
                        if (my_define.Scope == "local")
                        {
                            String pre_fix;
                            String post_fix;
                            String my_value;

                            if (my_define.Type == "switch")
                            {
                                pre_fix = "LS_";
                                post_fix = "";
                                my_value = String.Format("{0}", my_define.Value);
                            }
                            else
                            {
                                pre_fix = "rbp_";

                                if (my_define.Type == "UInt8") { post_fix = "_u8"; my_value = String.Format("((UInt8)({0}))", my_define.Value); }
                                else if (my_define.Type == "UInt16") { post_fix = "_u16"; my_value = String.Format("((UInt16)({0}))", my_define.Value); }
                                else if (my_define.Type == "UInt32") { post_fix = "_u32"; my_value = String.Format("((UInt32)({0}))", my_define.Value); }
                                else if (my_define.Type == "SInt8") { post_fix = "_s8"; my_value = String.Format("((SInt8)({0}))", my_define.Value); }
                                else if (my_define.Type == "SInt16") { post_fix = "_s16"; my_value = String.Format("((SInt16)({0}))", my_define.Value); }
                                else if (my_define.Type == "SInt32") { post_fix = "_s32"; my_value = String.Format("((SInt32)({0}))", my_define.Value); }
                                else if (my_define.Type == "Boolean") { post_fix = "_b"; my_value = String.Format("((Boolean)({0}))", my_define.Value); }
                                else if (my_define.Type == "Float32") { post_fix = "_df32"; my_value = String.Format("((Float32)({0}))", my_define.Value); }
                                else { post_fix = "unknown"; my_value = String.Format("({0})", my_define.Value); }
                            }

                            if (my_define.ExternalOverwrite == "yes")
                            {
                                writer.WriteLine("  #ifndef {0}{1}_{2}{3}", pre_fix, component.Name.ToUpper(), my_define.Name, post_fix);
                                writer.Write("  ");
                            }

                            writer.WriteLine("  #define {0}{1}_{2}{3} {4} /*!< {5} */", pre_fix, component.Name.ToUpper(), my_define.Name, post_fix, my_value, my_define.Description);

                            if (my_define.ExternalOverwrite == "yes")
                            {
                                writer.WriteLine("  #endif");
                            }
                        }
                    }

                    writer.WriteLine("");
                    writer.WriteLine("#endif");
                }

                writer.WriteLine("");
                writer.WriteLine("/*!@} */");
                writer.WriteLine("");
            }

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("}");
            writer.WriteLine("#endif // __cplusplus");
            writer.WriteLine("");
            writer.WriteLine("#endif /* RBP_PAR_SWITCHES{0}_GEN_H */", my_FileName_Suffix.ToUpper());

            // Close output file.
            writer.Close();
        }
    }
}
