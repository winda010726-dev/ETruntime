using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;

namespace parsrv
{

    /// <summary>
    ///  RB Secure Flash related sections, Certificate and Signature.
    /// </summary>

    class Secure_Flash: HelperFunctions
    {
        // Variables.
        private byte my_PKI_Struct_Reference_Size;
        private byte my_PKI_Structure_Size;
        private byte my_ST_No_of_Certificates;
        private byte my_ST_Structure_ID;
        private byte my_ST_Certificate_Type;
        private byte my_ST_Signature_Type;
        private byte my_ST_Aurhorization_Flag;
        private string my_Authorization_Obj_Id;
        private int my_Certificate_Length;
        private int my_Signature_Length;
        private int my_PKI_Struct_StartAddr;
        private string my_RB_Secure_Block;
        private int my_RB_Secure_Block_Length;

        // Default Constructor
        public Secure_Flash()
        {
           // Do nothing.
        }
        // Parameterized constructor.
        public Secure_Flash(cGeneralConfiguration my_gc)
        {
            this.my_PKI_Struct_Reference_Size = 32;
            this.my_PKI_Structure_Size = 64;
            this.my_ST_No_of_Certificates = Convert.ToByte(my_gc.ST_No_of_Certificates,16);
            this.my_ST_Structure_ID = Convert.ToByte(my_gc.ST_Structure_ID,16);
            this.my_ST_Certificate_Type = Convert.ToByte(my_gc.ST_Certificate_Type,16);
            this.my_ST_Signature_Type = Convert.ToByte(my_gc.ST_Signature_Type,16);
            this.my_ST_Aurhorization_Flag = Convert.ToByte(my_gc.ST_Authorization_Flag,16);
            this.my_Authorization_Obj_Id = my_gc.ST_Authorization_Obj_ID;
            this.my_Certificate_Length = Convert.ToInt32(my_gc.ST_CAL_Certificate_Length,16);
            this.my_Signature_Length = Convert.ToInt32(my_gc.ST_CAL_Signature_Length,16);
            this.my_PKI_Struct_StartAddr = Convert.ToInt32(my_gc.ST_CAL_PKIStructureStart,16);
            this.my_RB_Secure_Block = my_gc.RB_Secure_Block.ToUpper();
            this.my_RB_Secure_Block_Length = Convert.ToInt32(my_gc.RB_Secure_Block_Length,16);
        }

        /// <summary>
        ///  Provides the data of the Security variables.
        /// </summary>
        /// <param name="ST_No_of_certificates"></param>
        /// <param name="PKI_Struct_Reference_Size"></param>
        /// <param name="PKI_Structure_Size"></param>
        /// <param name="Certificate_Length"></param>
        /// <param name="Signature_Length"></param>
        public void Get_Security_Member_Data(ref byte ST_No_of_certificates,ref int PKI_Struct_Reference_Size,ref int PKI_Structure_Size,ref int Certificate_Length,ref int Signature_Length)
        {
            ST_No_of_certificates = this.my_ST_No_of_Certificates;
            PKI_Struct_Reference_Size = this.my_PKI_Struct_Reference_Size;
            PKI_Structure_Size = this.my_PKI_Structure_Size;
            Certificate_Length = this.my_Certificate_Length;
            Signature_Length = this.my_Signature_Length;
        }

        /// <summary>
        /// Check for the Validity of the Security Tags.
        /// </summary>
        /// <param name="my_gc"></param>
        public void Check_PKI_Structure_Data_Validty(ref cGeneralConfiguration my_gc)
        {
            bool check_success = true;
            List<string> error_msg = new List<string>();

            // Check for the Security Block Type
            if(!((this.my_RB_Secure_Block == "INDIVIDUAL") || (this.my_RB_Secure_Block == "COMBINED")))
            {
                error_msg.Add(" ERROR : Please Provide the valid value within the XML Tag RB_Secure_Block : (i.e.INDIVIDUAL\\COMBINED)");
                check_success = false;
            }

            if (this.my_RB_Secure_Block == "INDIVIDUAL")
            {
                // Check for Number of Certificates.
                if (this.my_ST_No_of_Certificates != 1)
                {
                    error_msg.Add(" ERROR : Number of Certificate supported is '0x01'");
                    check_success = false;
                }

                // Structure ID Validation
                if (this.my_ST_Structure_ID != 0x11)
                {
                    error_msg.Add(" ERROR : Supported Structure ID for Code/ Flash is '0x11' ");
                    check_success = false;
                }

                // Certificate Type Validation.
                if (this.my_ST_Certificate_Type != 0x01)
                {
                error_msg.Add(" ERROR : Supported Certificate type is '0x01' ");
                    check_success = false;
                }

                // Signature Type Validation.
                if (!(this.my_ST_Signature_Type <= 0x02))
                {
                    error_msg.Add(" ERROR : Supported Signature type is '0x01\\0x02'");
                    check_success = false;
                }

                // Authorization ID length Validation.
                if (this.my_Authorization_Obj_Id.Length != 0x42)
                {
                    error_msg.Add(" ERROR : Authorization ID Data Length is improper , Please provide Data of length 32 bytes");
                    check_success = false;
                }

                // CAL Certificate Length Validation.
                if (this.my_Certificate_Length < 0x400)
                {
                    error_msg.Add(" ERROR : Minimum Length of CAL Certificate should be 0x400 bytes ");
                    check_success = false;
                }
                else if (this.my_Certificate_Length % 16 != 0x00)
                {
                    error_msg.Add(" ERROR : CAL Certificate Length should be multiple of 16 bytes ");
                    check_success = false;
                }

                // CAL Signature Length Validation.
                if (this.my_Signature_Length < 0x100)
                {
                    error_msg.Add(" ERROR : Minimum Length of CAL Signature should be 0x100 bytes ");
                    check_success = false;
                }
                else if (this.my_Signature_Length % 16 != 0x00)
                {
                    error_msg.Add(" ERROR : CAL Signature Length should be multiple of 16 bytes ");
                    check_success = false;
                }
            }
            else
            {
                // Above checks are  not required for COMIBINED Block, as the data will be provided in the Application block
            }

            if (check_success == false)
            {
                Console.BackgroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("=============================================================================");
                for (byte index_u8 = 0 ; index_u8 < error_msg.Count ; index_u8++)
                {
                    Console.WriteLine("{0}",error_msg[index_u8]);
                }
                Console.WriteLine(" Provide proper input within the General configuration file ");
                Console.WriteLine("=============================================================================");
                Console.ResetColor();
                throw (new Exception(""));
            }
            return;
        }

        /// <summary>
        /// Prints Security Structure Declarations
        /// </summary>
        /// <param name="writer"></param>
        ///
        public void Print_Header_Security_Blocks(ref StreamWriter writer)
        {
            //! RB PKI Reference structure
            {
                writer.WriteLine("//---------------------- RB Secure Flash Structures ---------------------------");
                writer.WriteLine("");
                writer.WriteLine("// RB PKI Reference structure");
                writer.WriteLine("");
                writer.WriteLine("typedef struct rbp_Tag_CAL_PKI_SecRef_st");
                writer.WriteLine("{");
                writer.WriteLine("   UInt32 SecRefPattern_u32; // Security reference pattern");
                writer.WriteLine("   UInt8 StructID_u8;        // 0x01 ");
                writer.WriteLine("   UInt8 Endianess_u8;       // 0x55 for Little Endian, 0xAA for Big Endian ");
                writer.WriteLine("   UInt8 Reserved_u8;        // Reserved = 0xff ");
                writer.WriteLine("   UInt8 Reserved1_u8;       // Reserved = 0xff ");
                writer.WriteLine("   UInt32 BlockStart_u32;    // Start address of block ");
                writer.WriteLine("   UInt32 Length_u32;        // Length of block ");
                writer.WriteLine("   UInt32 PKIRef_u32;        // Address of PKI Structure Entry Point ");
                writer.WriteLine("}rbp_Type_CAL_PKI_SecRef_st;");

                writer.WriteLine("");
                writer.WriteLine("typedef struct rbp_Tag_CAL_PKI_Ref_st");
                writer.WriteLine("{");
                writer.WriteLine("  rbp_Type_CAL_PKI_SecRef_st CAL_PKI_SecRef_st;");
                writer.WriteLine("  UInt8 Padding_Data_pu8[12];      // Padding Bytes to maintain 16 byte aligment. ");
                writer.WriteLine("}rbp_Type_CAL_PKI_Ref_st;");

            }//! @end: RB PKI Reference structure

            if (my_RB_Secure_Block == "INDIVIDUAL")
            {
                //! RB PKI Signature structure
                {
                    writer.WriteLine("");
                    writer.WriteLine("// RB PKI Signature structure");
                    writer.WriteLine("typedef struct rbp_Tag_CAL_PKI_CertStruct_st");
                    writer.WriteLine("{");
                    writer.WriteLine("   UInt8 StructID_u8;           // 0x11 for Code/Cal block structure");
                    writer.WriteLine("   UInt8 CertType_u8;           // 0x01 ");
                    writer.WriteLine("   UInt8 SigType_u8;            // Defines algorithms for signature process");
                    writer.WriteLine("   UInt8 Auth_u8;               // Index of content of the authorization flags");
                    writer.WriteLine("   UInt8 ObjectID_pu8[32];      // Object ID ");
                    writer.WriteLine("   UInt32 Cert_Length_u32;      // Length of following certificate const");
                    writer.WriteLine("   const UInt8* Certificate_cpu8;      // Pointer to certificate");
                    writer.WriteLine("   UInt32 Sig_Length_u32;       // Signature Length");
                    writer.WriteLine("   const UInt8* Signature_cpu8; // Pointer to Signature");
                    writer.WriteLine("}rbp_Type_CAL_PKI_CertStruct_st;");
                }//! @end: RB PKI Signature structure

                //! RB PKI Certificate Info structure
                {
                    writer.WriteLine("");
                    writer.WriteLine("// RB PKI Certificate Info Structure ");
                    writer.WriteLine("typedef struct rbp_Tag_CAL_PKI_CertInfoStruct_st");
                    writer.WriteLine("{");
                    writer.WriteLine("   UInt32 NumOfCertStructs_u32;                          // Number of Certificates/Signatures");
                    writer.WriteLine("   rbp_Type_CAL_PKI_CertStruct_st CAL_PKI_CertStruct_st; // RB PKI Certificate structure");
                    writer.WriteLine("} rbp_Type_CAL_PKI_CertInfoStruct_st;");
                }//! @end:RB PKI Certificate Info structure
            }
            else
            {
                // For Combined Block (CAL+APPL), APPL will provide the PKI Certificate structure. 
            }

            writer.WriteLine("");
            writer.WriteLine("//----------------------  RB Secure Flash Structures ---------------------------");

            return;
        }

        /// <summary>
        /// Prints Security Block related variables declarations.
        /// </summary>
        /// <param name="writer"></param>
        ///
        public void Print_Security_Block_Extern_Declarations(ref StreamWriter writer)
        {
            // Print comments for making extern declarations in .c file.
            writer.WriteLine("// Exception: extern declaration in .c file, required to satisfy Helix QAC(warning 3408).");
            writer.WriteLine("// Variables are part of read only section, hence not modifiable. Thus safety is assured.");
            // For Combined Block(CAL + APPL), APPL will provide the PKI Certificate structure, Certificate and Signature.
            if (my_RB_Secure_Block == "INDIVIDUAL")
            {
                // extern declaration of rbp_CAL_Certificate_cpu8
                writer.Write("extern const UInt8 rbp_CAL_Certificate_cpu8[");
                writer.Write(this.my_Certificate_Length);
                writer.WriteLine("]; // RB CAL Certificate");

                // extern declaration of rbp_CAL_Signature_cpu8
                writer.Write("extern const UInt8 rbp_CAL_Signature_cpu8[");
                writer.Write(this.my_Signature_Length);
                writer.WriteLine("]; // RB CAL Signature");

                // extern declaration of rbp_CAL_PKI_CertInfoStruct_st
                writer.WriteLine("extern const rbp_Type_CAL_PKI_CertInfoStruct_st rbp_CAL_PKI_CertInfoStruct_st; // RB PKI Certificate Info Structure");
            }

            // extern declaration of rbp_CAL_PKI_Ref_st
            writer.WriteLine("extern const rbp_Type_CAL_PKI_Ref_st rbp_CAL_PKI_Ref_st; // RB PKI Reference structure");

        }

       /// <summary>
        /// Print Security Sections data into rbp_par_main_gen.c
       /// </summary>
       /// <param name="writer"></param>
       /// <param name="my_gc"></param>
       /// <param name="my_sd"></param>

        public void Print_Security_Blocks(ref StreamWriter writer,ref cGeneralConfiguration my_gc,ref cSegmentDefinition my_sd,int temp_sec_offset)
        {
            int Endianess = ((my_gc.ST_CHORUS_Endianness == "BIG") ? 0xAA : 0x55);                                    // Endiannes of the controller.
            int Block_Start_Address = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_StartAddress,16) + temp_sec_offset;  // CAL Block start address. (i.e. temp_sec_offset = size of CALHdrLow + size of CALBlockStatus if enabled)
            int Block_Length = my_RB_Secure_Block_Length;                                                             // Secure Block Length
            int PKI_Struct_Addr = my_PKI_Struct_StartAddr;                                                            // PKI Structure Start Address

            if (my_RB_Secure_Block == "INDIVIDUAL")
            {
                PrintStringList(ref writer, 0, my_sd.CAL_RBPKI_CertificateBegin);
                writer.WriteLine("");
                writer.WriteLine("//RB CAL Certificate");
                writer.Write("const UInt8 rbp_CAL_Certificate_cpu8[");
                writer.Write(this.my_Certificate_Length);
                writer.WriteLine("]=");
                writer.WriteLine("{");
                for (int value = 0; value < this.my_Certificate_Length / 16; value++)
                {
                    writer.WriteLine("  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,");
                }
                writer.WriteLine("};");
                PrintStringList(ref writer, 0, my_sd.CAL_RBPKI_CertificateEnd);
                writer.WriteLine("");

                PrintStringList(ref writer, 0, my_sd.CAL_RBPKI_SignatureBegin);
                writer.WriteLine("");
                writer.WriteLine("//RB CAL Signature");
                writer.Write("const UInt8 rbp_CAL_Signature_cpu8[");
                writer.Write(this.my_Signature_Length);
                writer.WriteLine("]=");
                writer.WriteLine("{");
                for (int value = 0; value < this.my_Signature_Length / 16; value++)
                {
                    writer.WriteLine("  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,");
                }
                writer.WriteLine("};");
                PrintStringList(ref writer, 0, my_sd.CAL_RBPKI_SignatureEnd);
                writer.WriteLine("");

                PrintStringList(ref writer, 0, my_sd.CAL_RBPKI_CertInfoBegin);
                writer.WriteLine("");
                writer.WriteLine("// RB PKI Certificate Info Structure ");
                writer.WriteLine("const rbp_Type_CAL_PKI_CertInfoStruct_st rbp_CAL_PKI_CertInfoStruct_st = ");
                writer.WriteLine("{");
                writer.WriteLine("  0x{0:X2},            // No of certificates", this.my_ST_No_of_Certificates);
                writer.WriteLine("  {               // RB PKI Signature structure");
                writer.WriteLine("    0x{0:X2},          // StructID_u8", this.my_ST_Structure_ID);
                writer.WriteLine("    0x{0:X2},          // CertType_u8", this.my_ST_Certificate_Type);
                writer.WriteLine("    0x{0:X2},          // SigType_u8 ", this.my_ST_Signature_Type);
                writer.WriteLine("    0x{0:X2},          // Auth_u8", this.my_ST_Aurhorization_Flag);

                writer.Write("    {");
                for (byte index_u8 = 0; index_u8 < 32; index_u8++)
                {
                    writer.Write(" 0x{0:X2},", int.Parse(this.my_Authorization_Obj_Id.Substring(2 + (index_u8 * 2), 2), System.Globalization.NumberStyles.AllowHexSpecifier));
                }
                writer.WriteLine("}, // ObjectID_pu8[32]");

                writer.WriteLine("    0x{0:X2},         // Cert_Length_u32", this.my_Certificate_Length);
                writer.WriteLine("    rbp_CAL_Certificate_cpu8,  // Certificate_cpu8");
                writer.WriteLine("    0x{0:X2},         // Sig_Length_u32", this.my_Signature_Length);
                writer.WriteLine("    rbp_CAL_Signature_cpu8    // Signature_cpu8");
                writer.WriteLine("  }");
                writer.WriteLine("};");
                PrintStringList(ref writer, 0, my_sd.CAL_RBPKI_CertInfoEnd);
            }
            else
            {
               // For Combined Block(CAL + APPL), APPL will provide the PKI Certificate structure, Certificate and Signature.
            }

            writer.WriteLine("");
            PrintStringList(ref writer,0,my_sd.CAL_RBPKI_RefBegin);
            writer.WriteLine("//RB PKI Reference structure");
            writer.WriteLine("const rbp_Type_CAL_PKI_Ref_st rbp_CAL_PKI_Ref_st = ");
            writer.WriteLine("{");
            writer.WriteLine("  {  //CAL_PKI_CertStruct_st");
            writer.WriteLine("    0x5EED45EC, // SecRefPattern_u32");
            writer.WriteLine("    0x01,       // StructID_u8");
            writer.WriteLine("    0x{0:X2},       // Endianess_u8 ",Endianess);
            writer.WriteLine("    0xFF,       // Reserved_u8");
            writer.WriteLine("    0xFF,       // Reserved1_u8");
            writer.WriteLine("    0x{0:X2},   // BlockStart_u32",Block_Start_Address);
            writer.WriteLine("    0x{0:X2},   // Block_Length",Block_Length);
            writer.WriteLine("    0x{0:X2}   // Address of PKI Structure Entry Point", PKI_Struct_Addr);
            writer.WriteLine("  },");
            writer.WriteLine("  {  //Padding_Data_pu8");
            writer.WriteLine("    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF");
            writer.WriteLine("  }");
            writer.WriteLine("};");
            PrintStringList(ref writer,0,my_sd.CAL_RBPKI_RefEnd);
            writer.WriteLine("");

            return;
        }

        /// <summary>
        ///  Fill RB Security PKI Structure Reference Data.
        /// </summary>
        /// <param name="my_output_helper"></param>
        /// <param name="my_gc"></param>

        public void Print_Security_CAL_PKI_RefStruct(ref cNECFx3_CALSectionHelper my_output_helper,ref cGeneralConfiguration my_gc,int temp_sec_offset)
        {
            int Endianess = ((my_gc.ST_CHORUS_Endianness == "BIG") ? 0xAA : 0x55);                                    // Endianess of Controller.
            int Block_Start_Address = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_StartAddress,16) + temp_sec_offset;  // CAL Block Start address. (i.e. temp_sec_offset = size of CALHdrLow + size of CALBlockStatus if enabled)
            int Block_Length = my_RB_Secure_Block_Length;                                                             // Secure Block Length.
            int PKI_Struct_Addr = my_PKI_Struct_StartAddr;                                                            // PKI Structure Start Address
              
            my_output_helper.Add(4,0x5EED45EC,my_gc.ST_CHORUS_Endianness);            // Security reference pattern.
            my_output_helper.Add(1,0x01,my_gc.ST_CHORUS_Endianness);                  // Structure ID.
            my_output_helper.Add(1,Endianess,my_gc.ST_CHORUS_Endianness);             // Endianess.
            my_output_helper.Add(1,0xFF,my_gc.ST_CHORUS_Endianness);                  // Reserved.
            my_output_helper.Add(1,0xFF,my_gc.ST_CHORUS_Endianness);                  // Reserved1.
            my_output_helper.Add(4,Block_Start_Address,my_gc.ST_CHORUS_Endianness);   // Start address of CAL Block.
            my_output_helper.Add(4,Block_Length,my_gc.ST_CHORUS_Endianness);          // CAL block length.
            my_output_helper.Add(4,PKI_Struct_Addr, my_gc.ST_CHORUS_Endianness);     // Address of PKI Structure Entry Point

            // Fill 12 bytes with 0XFF to maintain 16 byte aligment.
            my_output_helper.Add(4,0xFFFFFFFF,my_gc.ST_CHORUS_Endianness);
            my_output_helper.Add(4,0xFFFFFFFF,my_gc.ST_CHORUS_Endianness);
            my_output_helper.Add(4,0xFFFFFFFF,my_gc.ST_CHORUS_Endianness);
        }

        /// <summary>
        /// Write Security Section Data (PKI Ref Structure, PKI Structure, Certificate, Signature) to CAL.Hex 
        /// </summary>
        /// <param name="my_output_helper"></param>
        /// <param name="my_gc"></param>
        public void Print_Secuity_CAL_PKI_Struct_Cert_Sig( ref cNECFx3_CALSectionHelper my_output_helper, ref cGeneralConfiguration my_gc)
        {
            int CAL_PKI_Addr = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_StartAddress,16) + my_output_helper.GetSize();
            int ObjectId_Auth_Len = 32;
            int Certificate_Address = CAL_PKI_Addr + this.my_PKI_Structure_Size;
            int Signature_Address = Certificate_Address + this.my_Certificate_Length;

            if (this.my_PKI_Struct_StartAddr != CAL_PKI_Addr)
            {
                Console.BackgroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("=============================================================================");
                Console.WriteLine("Invalid Address PKI_Struct_StartAddr = 0x{0:x2} ", this.my_PKI_Struct_StartAddr);
                Console.WriteLine("=============================================================================");
                Console.ResetColor();
                throw (new Exception("Given PKI Structure Address is not Proper. Verify the address and provide a valid address within the Configuration XML."));
            }

            // Number of Certificates.
            my_output_helper.Add(4, this.my_ST_No_of_Certificates, my_gc.ST_CHORUS_Endianness);

            //! RB PKI Structure Data.
            {

                my_output_helper.Add(1, this.my_ST_Structure_ID, my_gc.ST_CHORUS_Endianness);
                my_output_helper.Add(1, this.my_ST_Certificate_Type, my_gc.ST_CHORUS_Endianness);
                my_output_helper.Add(1, this.my_ST_Signature_Type, my_gc.ST_CHORUS_Endianness);
                my_output_helper.Add(1, this.my_ST_Aurhorization_Flag, my_gc.ST_CHORUS_Endianness);
                for (byte index_u8 = 0; index_u8 < ObjectId_Auth_Len; index_u8++)
                {
                    int value = int.Parse(this.my_Authorization_Obj_Id.Substring(2 + (index_u8 * 2), 2), System.Globalization.NumberStyles.AllowHexSpecifier);
                    my_output_helper.Add(1, value, my_gc.ST_CHORUS_Endianness);
                }

                my_output_helper.Add(4, this.my_Certificate_Length, my_gc.ST_CHORUS_Endianness);
                my_output_helper.Add(4, Certificate_Address, my_gc.ST_CHORUS_Endianness);
                my_output_helper.Add(4, this.my_Signature_Length, my_gc.ST_CHORUS_Endianness);
                my_output_helper.Add(4, Signature_Address, my_gc.ST_CHORUS_Endianness);

                // Fill 8 bytes with 0XFF
                my_output_helper.Add(4, 0xFFFFFFFF, my_gc.ST_CHORUS_Endianness);
                my_output_helper.Add(4, 0xFFFFFFFF, my_gc.ST_CHORUS_Endianness);

            }//! @end: RB PKI Structure Data

            {
                // CAL Certificate.
                for (int value = 0; value < this.my_Certificate_Length; value++)
                {
                    my_output_helper.Add(1, 0xFF, my_gc.ST_CHORUS_Endianness);
                }

                // CAL Signature.
                for (int value = 0; value < this.my_Signature_Length; value++)
                {
                    my_output_helper.Add(1, 0xFF, my_gc.ST_CHORUS_Endianness);
                }
            }
        }
    }
}
