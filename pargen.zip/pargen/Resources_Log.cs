using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace parsrv
{
    // A class to compute the target memory usage of the CAL-section and NVM-section (Fx3 only).
    public class cMemoryUsage
    {
        private List<cParameterDefinition> my_parameter_definitions;
        private List<Boolean> my_structure_start;
        private List<Boolean> my_force_alignment;
        private int my_alignment;

        // Determine the number of necessary padding/stuff bytes for a given address/offset and alignment.
        public int GetNummberOfPaddingBytes(int offset, int alignment)
        {
            return ((alignment - (offset % alignment)) % alignment);
        }

        // Compute the size.
        public int GetSize()
        {
            // Address counter.
            int address = 0;

            // Bitfield control data.
            int bitfield_current_count = 0;
            int bitfield_base_address = 0;
            int bitfield_base_offset = 0;

            // Loop variable
            int i = 0;

            // Iterate over all parameters.
            foreach (cParameterDefinition para_def in this.my_parameter_definitions)
            {
                // Handle hard alignment.
                if (this.my_force_alignment[i] != false)
                {
                    // Data alignment.
                    address += GetNummberOfPaddingBytes(address, my_alignment);
                }

                // Force alignment for each structure.
                if (this.my_structure_start[i] != false)
                {
                    // Data alignment.
                    address += GetNummberOfPaddingBytes(address, my_alignment);
                }

                // Check for bitfields.
                if (para_def.IsBitfield() == false)
                {
                    // Handle non-bitfield parameters.

                    // Check if previous parameter was a bitfield and write it into the output stream.
                    if (bitfield_current_count > 0)
                    {
                        // Update address.
                        address += ((bitfield_current_count + 7) / 8);

                        // Clear bitfield.
                        bitfield_current_count = 0;
                    }

                    // Data alignment.
                    {
                        int num_alignment_bytes = GetNummberOfPaddingBytes(address, Math.Min(my_alignment, para_def.GetSizeOfType()));

                        // Update address.
                        address += num_alignment_bytes;
                    }

                    // Data.
                    {
                        // Update address.
                        address += para_def.GetSizeOfType() * Convert.ToInt32(para_def.Number);
                    }
                }
                else
                {
                    // Handle bitfield parameters.
                    int bitfield_base_width = para_def.GetBitfieldWidth();
                    int bitfield_current_width = Convert.ToInt32(para_def.Number);
                    int bitfield_byte_size = para_def.GetSizeOfType();

                    // Start of a new bitfield.
                    if (bitfield_current_count == 0)
                    {
                        // New bitfield

                        // Check if the current alignment offers enough space for the bitfield - if not align according to the base type.
                        if (8 * (bitfield_byte_size - (address % bitfield_byte_size)) < bitfield_current_width)
                        {
                            int num_alignment_bytes = GetNummberOfPaddingBytes(address, Math.Min(my_alignment, para_def.GetSizeOfType()));

                            // Update address.
                            address += num_alignment_bytes;
                        }

                        // Update bitfield address information.
                        bitfield_base_address = address - (address % 4);
                        bitfield_base_offset = address % 4;

                        // Update bitfield data.
                        bitfield_current_count = bitfield_current_width;
                    }
                    else
                    {
                        // Extend existing bitfield.

                        // Enough space left.
                        if ((8 * (my_alignment - bitfield_base_offset) - bitfield_current_count) < bitfield_current_width)
                        {
                            // Not enough space left.

                            // Flush bitfield.
                            if (bitfield_current_count > 0)
                            {
                                // Update address.
                                address += ((bitfield_current_count + 7) / 8);
                            }

                            // Align for basetype.
                            {
                                int num_alignment_bytes = GetNummberOfPaddingBytes(address, Math.Min(my_alignment, para_def.GetSizeOfType()));

                                // Udate address.
                                address += num_alignment_bytes;
                            }

                            // Update bitfield address information.
                            bitfield_base_address = address - (address % 4);
                            bitfield_base_offset = address % 4;

                            // Update bitfield data.
                            bitfield_current_count = bitfield_current_width;
                        }
                        else
                        {
                            // Enough space left.

                            // Check whether current bit position aligns with new base type.
                            int start_bit = bitfield_base_offset * 8 + bitfield_current_count;
                            int stop_bit = bitfield_base_offset * 8 + bitfield_current_count + bitfield_current_width;

                            int start_bit_adr_offset = (start_bit == 0) ? 0 : (start_bit - 1) / bitfield_base_width;
                            int stop_bit_adr_offset = (stop_bit == 0) ? 0 : (stop_bit - 1) / bitfield_base_width;

                            // Alignment_possible.
                            if (start_bit_adr_offset == stop_bit_adr_offset)
                            {
                                // Alignment possible.
                                bitfield_current_count += bitfield_current_width;
                            }
                            else
                            {
                                // Alignment impossible.

                                // Move to next possible aligned position
                                // bitfield_value = unchanged.
                                bitfield_current_count = (bitfield_base_width * stop_bit_adr_offset) - (8 * bitfield_base_offset);


                                // Enough space left.
                                if ((8 * (my_alignment - bitfield_base_offset) - bitfield_current_count) < bitfield_current_width)
                                {
                                    // Not enough space left.

                                    // Flush bitfield.
                                    if (bitfield_current_count > 0)
                                    {
                                        // Update address.
                                        address += ((bitfield_current_count + 7) / 8);
                                    }

                                    // Align for basetype.
                                    {
                                        int num_alignment_bytes = GetNummberOfPaddingBytes(address, Math.Min(my_alignment, para_def.GetSizeOfType()));

                                        // Update address.
                                        address += num_alignment_bytes;
                                    }

                                    // Update bitfield address information.
                                    bitfield_base_address = address - (address % 4);
                                    bitfield_base_offset = address % 4;

                                    // Update bitfield data.
                                    bitfield_current_count = bitfield_current_width;
                                }
                                else
                                {
                                    // Enough space left.
                                    bitfield_current_count += bitfield_current_width;
                                }
                            }
                        }
                    }
                }

                // Next element.
                i++;
            }

            // Check if previous parameter was a bitfield and write it into the output stream.
            if (bitfield_current_count > 0)
            {
                // Update address.
                address += ((bitfield_current_count + 7) / 8);

                // Clear bitfield.
                bitfield_current_count = 0;
            }

            // Data alignment.
            {
                int num_alignment_bytes = GetNummberOfPaddingBytes(address, my_alignment);

                // Update address.
                address += num_alignment_bytes;
            }

            // Return address / size.
            return address;
        }

        // Adds a new structure to the list.
        public void Add(cParameterDefinition new_para_def, // Parameter definition.
                         Boolean new_new_structure,        // Marks the beginning of a new structure (used to avoid to join bitfields).
                         Boolean new_force_alignment)      // Forces to align this structure.
        {
            my_parameter_definitions.Add(new_para_def);
            my_structure_start.Add(new_new_structure);
            my_force_alignment.Add(new_force_alignment);
        }

        // Empties the whole list.
        public void Reset()
        {
            my_parameter_definitions.Clear();
        }

        // Default Constructor.
        public cMemoryUsage()
        {
            this.my_parameter_definitions = new List<cParameterDefinition>();
            this.my_structure_start = new List<Boolean>();
            this.my_force_alignment = new List<Boolean>();
            this.my_alignment = 4;
        }

        // Parameterized Constructor.
        public cMemoryUsage(List<cParameterDefinition> new_parameter_definitions,
                             List<Boolean> new_structure_start,
                             List<Boolean> new_force_alignment,
                             int new_alignment)
        {
            this.my_parameter_definitions = new_parameter_definitions;
            this.my_structure_start = new_structure_start;
            this.my_force_alignment = new_force_alignment;
            this.my_alignment = new_alignment;
        }
    }

    class Resources_Log   
    {
        // Default Constructor.
        public Resources_Log()
        {
            // Do nothing.
        }

        // Function to print parameters for all the Major/Vehicle variants.
        public void PrintParameters(ref cParameterSet my_ps,
                                            String my_output_path,
                                            String my_FileName_Suffix,
                                            ref cGeneralConfiguration my_gc)
        {
            foreach (string major_var_string in my_ps.MajorVariants)
            {
                // Overwrite output path.
                if (!string.IsNullOrEmpty(my_gc.Log_OutputPath))
                {
                    my_output_path = Path.Combine(my_gc.Log_OutputPath, "parameters" + my_FileName_Suffix);

                    // Determine whether the directory exists.
                    Program.DirectoryCreateDirectory(my_output_path);
                }

                string my_filename = Path.Combine(my_output_path, major_var_string + my_FileName_Suffix + ".txt");

                // Delete old file automatically if existing.
                try
                {
                    Program.FileDelete(my_filename);
                }
                catch
                {
                    // Do not care about exceptions.
                }

                // Open output file.
                var writer = Program.CreateStreamWriter(my_filename, false, Encoding.ASCII);
                Console.WriteLine("generating: {0}", Path.GetFullPath(my_filename));

                cWrapper_XML_2_x wrapper_2_x = new cWrapper_XML_2_x();

                writer.WriteLine("////////////////////////////////////////////////////////////////////////////////");
                writer.WriteLine("// {0}", major_var_string);
                writer.WriteLine("////////////////////////////////////////////////////////////////////////////////");
                writer.WriteLine("");

                // Iterate over all components.
                foreach (cComponent component in my_ps.Components)
                {
                    {
                        writer.WriteLine("********************************************************************************");
                        writer.WriteLine("** {0}", component.Name);
                        writer.WriteLine("********************************************************************************");
                        writer.WriteLine("");


                        writer.WriteLine("////////////////////////////////////////////////////////////////////////////////");
                        writer.WriteLine("// {0} - switches", component.Name);
                        writer.WriteLine("////////////////////////////////////////////////////////////////////////////////");
                        writer.WriteLine("");

                        // Iterate over all switches.
                        foreach (cDefine my_define in component.Defines)
                        {
                            writer.Write("{0} ", component.Name.ToUpper());
                            writer.Write("{0} ", my_define.Name);
                            writer.Write("{0} ", my_define.Value);
                            writer.Write("type: {0} ", my_define.Type);
                            writer.Write("scope: {0} ", my_define.Scope);
                            writer.Write("ext_overwrite: {0} ", my_define.ExternalOverwrite);
                            writer.WriteLine("");
                        }

                        writer.WriteLine("");
                    }


                    // Iterate over all parameters.
                    foreach (cParameterCluster cluster in component.ParameterClusters)
                    {
                        writer.WriteLine("////////////////////////////////////////////////////////////////////////////////");
                        writer.WriteLine("// {0} - {1}", component.Name, cluster.Name);
                        writer.WriteLine("////////////////////////////////////////////////////////////////////////////////");
                        writer.WriteLine("");

                        int selected_major_var_index = 0;

                        // Look for the matching major variant.
                        {
                            int tmp_index = 0;

                            foreach (cVariantImplementation my_var_imp in cluster.VariantsImlementations)
                            {
                                if (my_var_imp.MajorVariants.Contains(major_var_string) != false)
                                {
                                    // Got the selected major variant.
                                    selected_major_var_index = tmp_index;
                                    break;
                                }
                              
                                // Major variant not obtained check for the next one.
                                tmp_index++;
                            }
                        }

                        // E.g.: Component: rbp_ehy_map; parameter definition name: TrckTimeMax; min variant: TrckMode_PASlight; sub variant: --- 
                        //       RBP_EHY_MAP TrckTimeMax TrckMode_PASlight --- 50   | bin: 50 type: UInt16 unit: --- min: 0 max: 60000 offset: 0 res: 1 disclosure : private 
                        cVariantImplementation var_imp = cluster.VariantsImlementations[selected_major_var_index];
                        {
                            foreach (cMinorVariant min_var in var_imp.MinorVariants)
                            {
                                foreach (cSubVariant sub_var in min_var.SubVariants)
                                {
                                    int param_def_index = 0;

                                    foreach (cParameterValue val in sub_var.ParameterValues)
                                    {
                                        writer.Write("{0} ", component.Name.ToUpper());
                                        //writer.Write ("{0} ", major_var_string);
                                        writer.Write("{0} ", cluster.ParameterDefinitions[param_def_index].Name);

                                        if (min_var.Name != "")
                                        {
                                            writer.Write("{0} ", min_var.Name);
                                        }
                                        else
                                        {
                                            writer.Write("--- ");
                                        }

                                        if (sub_var.Name != "")
                                        {
                                            writer.Write("{0} ", sub_var.Name);
                                        }
                                        else
                                        {
                                            writer.Write("--- ");
                                        }

                                        foreach (string param_val in val.Values)
                                        {
                                            //VND6KOR: Added the IFormat to treat '.' as '.' instead of ',' in other languages
                                            double bin_val = Convert.ToDouble(param_val, System.Globalization.CultureInfo.InvariantCulture);
                                            double offset = Convert.ToDouble(cluster.ParameterDefinitions[param_def_index].Offset, System.Globalization.CultureInfo.InvariantCulture);
                                            double resolution = Convert.ToDouble(cluster.ParameterDefinitions[param_def_index].Resolution, System.Globalization.CultureInfo.InvariantCulture);

                                            double phy_val = bin_val * resolution - offset;

                                            writer.Write("{0} {1} ", phy_val.ToString(System.Globalization.CultureInfo.InvariantCulture), cluster.ParameterDefinitions[param_def_index].Unit);
                                        }

                                        writer.Write(" | ");

                                        writer.Write("bin: ");
                                        foreach (string param_val in val.Values)
                                        {
                                            writer.Write("{0} ", param_val);
                                        }

                                        if (wrapper_2_x.Is_para_def_enum_b(my_ps,cluster.ParameterDefinitions[param_def_index]))
                                        {
                                            // Print enumeration data type based on the range of values.
                                            writer.Write("type: {0} ",cluster.ParameterDefinitions[param_def_index].TypeInPlatform);
                                        }
                                        else
                                        {
                                            writer.Write("type: {0} ",cluster.ParameterDefinitions[param_def_index].Type);
                                        }

                                        if (cluster.ParameterDefinitions[param_def_index].Unit != "")
                                        {
                                            writer.Write("unit: {0} ", cluster.ParameterDefinitions[param_def_index].Unit);
                                        }
                                        else
                                        {
                                            writer.Write("unit: --- ");
                                        }

                                        writer.Write("min: {0} ", cluster.ParameterDefinitions[param_def_index].Min);
                                        writer.Write("max: {0} ", cluster.ParameterDefinitions[param_def_index].Max);
                                        writer.Write("offset: {0} ", cluster.ParameterDefinitions[param_def_index].Offset);
                                        writer.Write("res: {0} ", cluster.ParameterDefinitions[param_def_index].Resolution);
                                        writer.Write("disclosure: {0} ", ((cluster.ParameterDefinitions[param_def_index].Disclosure) != "internal") ? "public" : "private");

                                        writer.WriteLine("");

                                        param_def_index++;
                                    }
                                }
                            }
                        }

                        writer.WriteLine("");
                    }
                }

                // Close output file.
                writer.Close();
            }
        }

        // Resource usage text file.
        public void PrintResourceUsage(ref cParameterSet my_ps,
                                               String my_output_path,
                                               String my_FileName_Suffix,
                                               ref cGeneralConfiguration my_gc)
        {
            // Overwrite output path.
            if (my_gc.Log_OutputPath != "")
            {
                my_output_path = my_gc.Log_OutputPath;

                // Determine whether the directory exists.
                Program.DirectoryCreateDirectory(my_output_path);
            }

            my_output_path = Path.GetFullPath(my_output_path);
            var outputPath = Path.Combine(my_output_path, "rbp_par_resources" + my_FileName_Suffix + "_gen.txt");
            var clusterSizePath = Path.Combine(my_output_path, "Cluster_Size" + my_FileName_Suffix + ".txt");
            // Delete old file automatically if existing.
            try
            {
                Program.FileDelete(outputPath);
            }
            catch
            {
                // Do not care about exceptions.
            }

            // Open output file rbp_par_resources_gen.txt.
            var writer = Program.CreateStreamWriter(outputPath, false, Encoding.ASCII);
            Console.WriteLine("generating: {0}", outputPath);

            writer.WriteLine("----------------------------------------------------------------");
            writer.WriteLine("ParGen (c) 2009 - 2010 Robert Bosch GmbH");
            writer.WriteLine("----------------------------------------------------------------");
            writer.WriteLine("Resource Usage [32 bit uC / 4 byte structure alignment]");
            writer.WriteLine("----------------------------------------------------------------");
            writer.WriteLine("");

           {
                cMemoryUsage my_memory_usage = new cMemoryUsage();

                // Delete the generated log file if exists. No exception is thrown if file is not available.
                Program.FileDelete(clusterSizePath);

                // Opens the file Cluster_Size.txt, appends the data/Info and closes the file.
                Program.FileAppendAllText(clusterSizePath, string.Format("{0,-30} | {1,5}", "Cluster Name", "  Cluster size    |") + "\n");
                Program.FileAppendAllText(clusterSizePath, string.Format("---------------------------------------------------|") + "\n");

                int size_plain = 0;
                int size_ST_CHORUS = 0;
                int num_clusters = 0;

                {
                    // Compute the necessary memory for the NVM parameters.
                    foreach (cComponent component in my_ps.Components)
                    {
                        foreach (cParameterCluster cluster in component.ParameterClusters)
                        {
                            if ((cluster.MemoryArea == "NVM") || (cluster.MemoryArea == "NVM_INIT"))
                            {
                                num_clusters++;

                                foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                                {
                                    foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                    {
                                        foreach (cSubVariant sub_var in min_var.SubVariants)
                                        {
                                            Boolean structure_start = true;

                                            my_memory_usage.Reset();

                                            foreach (cParameterDefinition para_def in cluster.ParameterDefinitions)
                                            {
                                                my_memory_usage.Add(para_def, structure_start, false);
                                                structure_start = false;
                                            }
                                            
                                            // size = size(Cluster) * number of var implementations
                                            size_plain += my_memory_usage.GetSize();


                                            // size = (size(Cluster) * size(CRC)) * number of var implementations
                                            size_ST_CHORUS += (my_memory_usage.GetSize() + 4);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Writes NVM usage info into rbp_par_resources_gen.txt file.
                writer.WriteLine("----------------------------------------------------------------");
                writer.WriteLine("Parameter NVM-Usage:");
                writer.WriteLine("----------------------------------------------------------------");
                writer.WriteLine("Number of NVM-Clusters:                       {0}", num_clusters);
                writer.WriteLine("----------------------------------------------------------------");
                writer.WriteLine("Cluster Data (plain):                         {0} bytes", size_plain);
                writer.WriteLine("Cluster Data (ST_CHORUS : +4 byte CRC/cluster): {0} bytes", size_ST_CHORUS);
                writer.WriteLine("----------------------------------------------------------------");
                writer.WriteLine("");
            }

            {
                cMemoryUsage my_memory_usage = new cMemoryUsage();

                // Initialize the required variables.
                int NumClusters = 0;
                int NumROMClusters = 0;
                int NumNVMInitClusters = 0;
                int NumMajorVariants = my_ps.MajorVariants.Count;
                int NumMinorVarMetaData = 0;
                int NumSubVarMetaData = 0;

                // Statistics.
                foreach (cComponent component in my_ps.Components)
                {
                    foreach (cParameterCluster cluster in component.ParameterClusters)
                    {
                        NumClusters++;

                        if (cluster.MemoryArea == "NVM_INIT")
                        {
                            NumNVMInitClusters++;
                        }

                        if (cluster.MemoryArea == "ROM")
                        {
                            NumROMClusters++;
                        }

                        foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                        {
                            NumMinorVarMetaData++;
                            NumSubVarMetaData += var_imp.MinorVariants.Count;
                        }
                    }
                }

                string temp_cluster_name = "0";
                int size_cluster = 0;
                int size_cluster_new = 0;
                int size_cluster_old = 0;
                int delta = 0;
                int sub_variant_size = 0;
                int min_variant_size = 0;
                int cumulative_cluster_size = 0;

                // Info section - adapt size after changing the info structure.
                my_memory_usage.Add(new cParameterDefinition("InfoStruct", "UInt8", "128"), true, false);

                // Opens Cluster_size.txt file.
                // Appends information Cluster info into text file and closes it.
                Program.FileAppendAllText(clusterSizePath, string.Format("{0,-30} |   {1,5}           |" + "\n", "Information Cluster", "128"));
                size_cluster = 0;
                {
                    // Compute the necessary memory for the ROM parameters.
                    foreach (cComponent component in my_ps.Components)
                    {
                        foreach (cParameterCluster cluster in component.ParameterClusters)
                        {
                            if ((cluster.MemoryArea == "ROM") || (cluster.MemoryArea == "NVM_INIT") || (cluster.MemoryArea == "RAM_INIT"))
                            {
                                foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                                {
                                    foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                    {
                                        foreach (cSubVariant sub_var in min_var.SubVariants)
                                        {
                                            Boolean structure_start = true;

                                            foreach (cParameterDefinition para_def in cluster.ParameterDefinitions)
                                            {
                                                my_memory_usage.Add(para_def, structure_start, false);
                                                structure_start = false;
                                            }

                                            if (temp_cluster_name != cluster.Name)
                                            {
                                                // 128 is the info cluster size.
                                                // Here the size is calculated based on the relative address.
                                                // my_memory_usage.GetSize() returns the latest address and subtracts 128 by that
                                                // size_cluster_old is the old address and size_cluster_new is the new address as the name indicates
                                                // delta is the address increment when a clusters have different values for different minor variants which is incremented 
                                                // when the same cluster pops up (checked by the if loop above).
                                                size_cluster_new = my_memory_usage.GetSize() - 128;
                                                size_cluster = size_cluster_new - size_cluster_old - delta;
                                                // In case of a cluster having multiple minor and sub variants and multiple major variants,
                                                // calculate size only for the first major variant. We have the size of sub variant cluster. 
                                                // So, size of sub variant * number of sub variants
                                                // Total size of sub variants *  number of minor variants. 
                                                sub_variant_size = (cluster.VariantsImlementations[0].MinorVariants[0].SubVariants.Count) * size_cluster;
                                                min_variant_size = (cluster.VariantsImlementations[0].MinorVariants.Count) * sub_variant_size;
                                                cumulative_cluster_size = min_variant_size;

                                                // Appends the info into Cluster_Size.txt file.
                                                Program.FileAppendAllText(clusterSizePath, string.Format("{0,-30} |   {1,5}           |" + "\n", cluster.Name, /*size_cluster + */cumulative_cluster_size));
                                                temp_cluster_name = cluster.Name;
                                                size_cluster_old = size_cluster_new - delta;
                                            }
                                            else
                                            {
                                                // Some clusters are divided over multiple variants.
                                                // This adds up. Even though the same cluster comes but it is not added as it is ignored by
                                                // the if condition check. To calculate those other major variant values, the delta is calculated 
                                                // here which is eliminated from the total cluster count.
                                                delta += size_cluster;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Opens Cluster_Size.txt file, prints the last line and closes it.
                    Program.FileAppendAllText(clusterSizePath, string.Format("---------------------------------------------------|")); ;
                }

                // Writes ROM usage info into the file rbp_par_resources_gen.txt.
                writer.WriteLine("----------------------------------------------------------------");
                writer.WriteLine("Parameter ROM-Usage:");
                writer.WriteLine("----------------------------------------------------------------");
                writer.WriteLine("Total Number of Clusters:                     {0}", NumClusters);
                writer.WriteLine("Number of ROM-Clusters:                       {0}", NumROMClusters);
                writer.WriteLine("Number of pre-initialized NVM-Clusters:       {0}", NumNVMInitClusters);
                writer.WriteLine("----------------------------------------------------------------");
                writer.WriteLine("Total (Application Mode 'switched off'):      {0} bytes", my_memory_usage.GetSize());
                writer.WriteLine("----------------------------------------------------------------");
                writer.WriteLine("");
            }

            // Close output file.
            writer.Close();
        }

        /// <summary>
        /// Function creates the log file , showing the identical defines upto first 63 characters.
        /// </summary>
        /// <param name="my_output_path"> Log File Path</param> 
        /// <param name="my_gc">Provides LOG folder path</param>
        /// <param name="my_access_define_list">Provides access defines list which are identical upto 63 characters.</param>
        public void PrintAccessDefineList( String my_output_path, String my_FileName_Suffix, ref cGeneralConfiguration my_gc,ref List<List<string[]>> my_access_define_list)
        {

            // Overwrite output path.
            if (my_gc.Log_OutputPath != "")
            {
                my_output_path = my_gc.Log_OutputPath;

                // Determine whether the directory exists.
                Program.DirectoryCreateDirectory(my_output_path);
            }

            my_output_path = Path.GetFullPath(my_output_path);
            var outputPath = Path.Combine(my_output_path,"DefineWarningList" + my_FileName_Suffix + ".txt");
            // Delete old file automatically if existing.
            try
            {
                Program.FileDelete(outputPath);
            }
            catch
            {
                // Do not care about exceptions.
            }

            // Open output file DefineWarningList.txt.
            var writer = Program.CreateStreamWriter(outputPath,false,Encoding.ASCII);
            Console.WriteLine("generating: {0}",outputPath);

            if (my_access_define_list.Count != 0)
            {
                Console.WriteLine("");
                Console.BackgroundColor = ConsoleColor.Yellow;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.WriteLine("=====================================================================================================================================================");
                Console.WriteLine(" Warning: C99\\C11 compatible -> Identifier\\Macro name shall be unique within the first 63 characters, this is not correct for the following defines present in rbp_par_access" + my_FileName_Suffix + "_gen.h file:");
                Console.WriteLine(" Refer \"{0}\" file for the list of defines and how to fix it.",outputPath);
                Console.WriteLine("=====================================================================================================================================================");
                Console.ResetColor();

                writer.Write("|----------------------------------------------------------------------------------------------------");
                writer.WriteLine("--------------------------------------------------------------------------------------|");
                writer.WriteLine(string.Format("|{0,-31} |{1,-50} |{2,-100} |","<cluster_name>\\Constant Define"," <parameter_name>\\<define_name> "," rbp_par_get_<cluster_name>_<parameter_name>_<postfix>\\rbp_par_get_<define_name>_<postfix>"));
                writer.Write("|----------------------------------------------------------------------------------------------------");
                writer.WriteLine("--------------------------------------------------------------------------------------|");

                /* Data within my_access_define_list
                 *   0 -> 
                 *     0  -> <cluster_name>\Constant Define
                 *     1  -> <parameter_name>\<define_name>
                 *     2  -> rbp_par_get_<cluster_name>_<parameter_name>_<postfix>\rbp_par_get_<define_name>_<postfix>
                 *   1 -> 
                 *     0  -> <cluster_name>\Constant Define
                 *     1  -> <parameter_name>\<define_name>
                 *     2  -> rbp_par_get_<cluster_name>_<parameter_name>_<postfix>\rbp_par_get_<define_name>_<postfix>
                 *   ..
                 *   ..
                 *   ..
                 */
                foreach (List<string[]> define_list in my_access_define_list)
                {
                    foreach (string[] define_info in define_list)
                    {
                        writer.WriteLine(string.Format("|{0,-31} |{1,-50} |{2,-100} |",define_info[0],define_info[1],define_info[2]));
                    }
                    writer.Write("|----------------------------------------------------------------------------------------------------");
                    writer.WriteLine("--------------------------------------------------------------------------------------|");
                }

                // Print the content if define list is not empty.
                writer.WriteLine("");
                writer.WriteLine("Warning: C99\\C11 compatible -> Identifier\\Macro name shall be unique within the first 63 characters: this is not correct for the above mentioned defines which is present in rbp_par_access" + my_FileName_Suffix + "_gen.h:");
                writer.WriteLine("Please fix the macros by providing unique first 63 characters. Refer below how to fix it");
                writer.WriteLine("Syntax :  Parameter define :rbp_par_get_<cluster_name>_<parameter_name>_<postfix>");
                writer.WriteLine("          Constant define  :rbp_par_get_<define_name>_<postfix>");
                writer.WriteLine(" Fixes can be provided by spliting the first 63 characters as mentioned below :");
                writer.WriteLine("   Reserved - 12 characters (rbp_par_get_) ");
                writer.WriteLine("   <cluster_name> --> 1 - 20 characters");
                writer.WriteLine("   <parameter_name> --> 1 - 30 characters");
                writer.WriteLine("   <define_name> --> 1 - 51 characters");
                writer.WriteLine(" Note: Please change\\update <cluster_name>\\<parameter_name>\\<define_name> within the .pdl file.");
            }
            else
            {
                writer.WriteLine(" All access defines within file \"rbp_par_access" + my_FileName_Suffix + "_gen.h\" are unique within the first 63 characters");
            }
            
            // Close output file.
            writer.Close();
        }
    }
}


