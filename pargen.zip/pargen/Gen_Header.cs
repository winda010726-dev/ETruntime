using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace parsrv
{
    /// <summary>
    /// The Gen_Header class generates the rbp_par_header_gen.h, rbp_par_access_gen.h, rbp_par_defines_gen.h, rbp_par_struct_gen.h
    /// </summary>
    
    class Gen_Header
    {
        // Generate the file rbp_par_header_gen.h.
        public void PrintGenHeader(ref cParameterSet my_ps,
                                           ref cSegmentDefinition my_sd,
                                           ref String my_ps_file_name,
                                           String my_output_path,
                                           string my_FileName_Suffix,
                                           ref DateTime my_dt,
                                           ref cGeneralConfiguration my_gc,
                                           string my_DatasetName)
        {
            // Initialize the necessary variables.
            Program my_program = new Program();
            string my_gen_file_name = "rbp_par_header" + my_FileName_Suffix + "_gen.h";
            string my_source_file_name = "Gen_Header.cs";

            // Overwrite the output path if already exists.
            my_program.OverwriteOPPath(ref my_gc, ref my_output_path, my_gen_file_name);

            // Generated file header.
            my_program.PrintFileInfo(ref my_ps, ref my_ps_file_name, my_output_path, ref my_dt, my_gen_file_name, my_source_file_name);

            // Obtain absolute path of output file.
            var genFileNamePath = Path.Combine(Path.GetFullPath(my_output_path), my_gen_file_name);

            // Open output file.
            var writer = Program.CreateStreamWriter(genFileNamePath, true, Encoding.ASCII);

            writer.WriteLine("#ifndef RBP_PAR_HEADER{0}_GEN_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("#define RBP_PAR_HEADER{0}_GEN_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("");

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("extern \"C\"");
            writer.WriteLine("{");
            writer.WriteLine("#endif // __cplusplus");

            writer.WriteLine("/* PRQA S 0779 RBP_RULE_DEV_rbp_par_header_gen_h_1 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA S 2217 RBP_RULE_DEV_rbp_par_header_gen_h_2 */ /*(details: see end of file)*/");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- magic number                                                           -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#define RBP_PAR_HEADER_MAGIC_NUMBER_GEN  0x{0:d2}{1:d2}{2:d2}{3:d2}", my_dt.Month, my_dt.Day, my_dt.Hour, my_dt.Minute);
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- component switches                                                     -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- include files                                                          -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");

            writer.WriteLine("#include \"rbp_param_types_def{0}.h\"", my_FileName_Suffix);
            writer.WriteLine("#include <rbp_par_switches{0}_gen.h>", my_FileName_Suffix);
            writer.WriteLine("#include <rbp_par_define{0}_gen.h>", my_FileName_Suffix);
            writer.WriteLine("#include <rbp_par_struct{0}_gen.h>", my_FileName_Suffix);
            writer.WriteLine("#include <rbp_par_access{0}_gen.h>", my_FileName_Suffix);

            writer.WriteLine("");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Exported Macros    -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("// macro to convert 'define' to a quoted string");
            writer.WriteLine("// g_QUOTE_CAL2_mac is used to encapsulate #CAL_IDstring with brackets (#CAL_IDstring)");
            writer.WriteLine("#define rbp_Cal_Stringify2_mac(CAL_IDstring)  #CAL_IDstring");
            writer.WriteLine("#define rbp_Cal_Stringify_mac(CAL_IDstring)   rbp_Cal_Stringify2_mac(CAL_IDstring)");

            writer.WriteLine("");
            writer.WriteLine("#ifdef RBP_COMPONENT_PAR");

            writer.WriteLine("//");
            writer.WriteLine("// application memory");
            writer.WriteLine("//");
            writer.WriteLine("");
            writer.WriteLine("#if ( RBP_GS_PAR_CFG_APPLICATION_MODE == RBP_SW_ON )");
            writer.WriteLine("  extern rbp_Type_par{0}_ApplicationMemory_st rbp_par{0}_ApplicationMemory_st;", my_DatasetName);
            writer.WriteLine("#endif");
            writer.WriteLine("");

            writer.WriteLine("#endif // RBP_COMPONENT_PAR");

            writer.WriteLine("");

            writer.WriteLine("//");
            writer.WriteLine("// global data RAM");
            writer.WriteLine("//");
            writer.WriteLine("");
            writer.WriteLine("  extern rbp_Type_par_RAMData_st rbp_par_RAMData_st;");
            writer.WriteLine("");
            writer.WriteLine("");
            writer.WriteLine("//If NVM_INIT clusters are available, Switch will be ON");
            writer.WriteLine("#if(RBP_GS_PAR_CFG_INIT_NVM_MIRROR_MEM == RBP_SW_ON )");
            writer.WriteLine("  extern rbp_Type_par_NVM_MirrorData_st rbp_par_NVM_MirrorData_st;");
            writer.WriteLine("#endif //(RBP_GS_PAR_CFG_INIT_NVM_MIRROR_MEM == RBP_SW_ON )");

            writer.WriteLine("");
            writer.WriteLine("//If RAM_INIT clusters are available, Switch will be ON");
            writer.WriteLine("#if(RBP_GS_PAR_CFG_INIT_RAM_MIRROR_MEM  == RBP_SW_ON )");
            writer.WriteLine("  extern rbp_Type_par_RAM_INIT_MirrorData_st rbp_par_RAM_INIT_MirrorData_st;");
            writer.WriteLine("#endif //(RBP_GS_PAR_CFG_INIT_RAM_MIRROR_MEM  == RBP_SW_ON )");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- ROM                                                                    -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#ifdef RBP_COMPONENT_PAR");
            writer.WriteLine("#endif");
            writer.WriteLine("");

            if (my_gc.ST_CHORUS_CALSection_SupportBlockStatusSection == "true")
            {
                int CalBlockStatusSize = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_SupportBlockStatusSize, 16);

                // Check for the CAL block status Size.
                // If CAL Block status is a multiple of 16 proceed, else make CAL Block status 32 Bytes.
                CalBlockStatusSize = (CalBlockStatusSize % 16 == 0) ? CalBlockStatusSize : 32;

                if (CalBlockStatusSize != 0)
                {
                    writer.WriteLine("// Cal Block Status.");
                    writer.WriteLine("#if (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");

                    writer.Write("  extern const UInt8 rbp_par_CalBlockStatus_pu8[");
                    // Array of CAL Block status size.
                    writer.Write(CalBlockStatusSize);
                    writer.WriteLine("];");

                    writer.WriteLine("#endif // (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                    writer.WriteLine("");
                }
                else
                {
                    // CalBlockStatusSize is 0.
                }
            }

            // GM only.
            if (my_gc.ST_CHORUS_CALSection_Mode == "GM")
            {
                // CAL header low structure declaration.
                GMHelperClass.printGenHeaderGM_2(ref writer);
            }
            else if (my_gc.ST_CHORUS_CALSection_SupportHeaderLow == "true")
            {
                int CalHeaderLowSize = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_HeaderLowSize, 16);

                // Check for the CAL Header Low Size
                // If CAL Header Low size is a multiple of 16 proceed, else make CAL Header Low as 16 Bytes, if size > 0.
                CalHeaderLowSize = (CalHeaderLowSize % 16 == 0) ? CalHeaderLowSize : 16;

                if (CalHeaderLowSize != 0)
                {
                    writer.WriteLine("// Cal Header Low.");
                    writer.WriteLine("#if (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");

                    writer.Write("  extern const UInt8 rbp_par_CalHdrLow_pu8[");
                    // Array of CAL Header Low size.
                    writer.Write(CalHeaderLowSize);
                    writer.WriteLine("];");

                    writer.WriteLine("#endif // (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                    writer.WriteLine("");

                }
                else
                {
                    // Cal Header Low size is 0.
                }
            }

            if (my_gc.ST_CHORUS_CALSection_SupportHeaderHigh == "true")
            {
                int CalHeaderHighSize = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_HeaderHighSize, 16);

                // Check for the CAL Header High Size.
                // If CAL Header High size is a multiple of 16 proceed, else make CAL Header High as 16 Bytes, if size > 0.
                CalHeaderHighSize = (CalHeaderHighSize % 16 == 0) ? CalHeaderHighSize : 16;

                if (CalHeaderHighSize != 0)
                {
                    writer.WriteLine("// Cal Header High.");
                    writer.WriteLine("#if (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");

                    writer.Write("  extern const UInt8 rbp_par_CalHdrHigh_pu8[");
                    // Array of CAL Header High size.
                    writer.Write(CalHeaderHighSize);
                    writer.WriteLine("];");

                    writer.WriteLine("#endif // (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                    writer.WriteLine("");
                }
                else
                {
                    // Cal Header High size is 0.
                }
            }

            if (my_gc.ST_CHORUS_CALSection_Support_CUS_SecurityHeaderLow == "true")
            {
                int Cal_CUS_SecHeaderLowSize = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_CUS_SecurityHeaderLowSize,16);

                // Check for the CAL CUS Security Header Low Size
                // If  CAL CUS Security Header Low is a multiple of 16 proceed ,else make CAL CUS Security Header Low as 16 Bytes, if size > 0.
                Cal_CUS_SecHeaderLowSize = (Cal_CUS_SecHeaderLowSize % 16 == 0) ? Cal_CUS_SecHeaderLowSize : 16;

                if (Cal_CUS_SecHeaderLowSize != 0)
                {
                    writer.WriteLine("// Cal CUS Security Header Low.");
                    writer.WriteLine("#if (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");

                    writer.Write("  extern const UInt8 rbp_par_Cal_CUS_SecHdrLow_pu8[");
                    // Array of CAL CUS Security Header Low size.
                    writer.Write(Cal_CUS_SecHeaderLowSize);
                    writer.WriteLine("];");

                    writer.WriteLine("#endif // (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                    writer.WriteLine("");
                }
                else
                {
                    // Cal CUS Security Header Low size is 0.
                }
            }

            if (my_gc.ST_CHORUS_CALSection_Support_CUS_SecurityHeaderHigh == "true")
            {
                int Cal_CUS_SecHeaderHighSize = Convert.ToInt32(my_gc.ST_CHORUS_CALSection_CUS_SecurityHeaderHighSize,16);

                // Check for the CAL CUS Security Header High Size
                // If  CAL CUS Security Header High is a multiple of 16 proceed ,else make CAL CUS Security Header High as 16 Bytes, if size > 0.
                Cal_CUS_SecHeaderHighSize = (Cal_CUS_SecHeaderHighSize % 16 == 0) ? Cal_CUS_SecHeaderHighSize : 16;

                if (Cal_CUS_SecHeaderHighSize != 0)
                {
                    writer.WriteLine("// Cal CUS Security Header High.");
                    writer.WriteLine("#if (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");

                    writer.Write("  extern const UInt8 rbp_par_Cal_CUS_SecHdrHigh_pu8[");
                    // Array of CAL CUS Security Header High size.
                    writer.Write(Cal_CUS_SecHeaderHighSize);
                    writer.WriteLine("];");

                    writer.WriteLine("#endif // (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
                    writer.WriteLine("");
                }
                else
                {
                    // Cal CUS Security Header High size is 0.
                }
            }

            writer.WriteLine("//");
            writer.WriteLine("// global data ROM");
            writer.WriteLine("//");
            writer.WriteLine("");

            writer.WriteLine("#if (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_STAND_ALONE)");
            // PrintStringList (ref writer, 2, my_sd.ParDataROMBegin);
            writer.WriteLine("  extern const rbp_Type_par{0}_ROMData_st rbp_par{0}_ROMData_st;", my_DatasetName);
            // PrintStringList (ref writer, 2, my_sd.ParDataROMEnd);
            writer.WriteLine("#elif (RBP_GS_PAR_CFG_COMP_MODE == RBP_GS_PAR_CFG_COMP_MODE_APPL_ONLY)");
            writer.WriteLine("");
            writer.WriteLine("/* PRQA S 3684 RBP_RULE_DEV_rbp_par_header_gen_h_3 */ /*(details: see end of file)*/");
            writer.WriteLine("");
            writer.WriteLine("  extern UInt8 __ghsbegin_CAL_Const[];");
            writer.WriteLine("");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_header_gen_h_3 */ /*(details: see end of file)*/");
            writer.WriteLine("");
            writer.WriteLine("  #define rbp_par{0}_ROMData_st (*((const rbp_Type_par{0}_ROMData_st *) __ghsbegin_CAL_Const))", my_DatasetName);
            writer.WriteLine("#endif");
            writer.WriteLine("");
            writer.WriteLine("  extern const rbp_Type_par_ROMMetaData_st rbp_par_ROMMetaData_st;");
            writer.WriteLine("");

            writer.WriteLine("#ifdef RBP_COMPONENT_PAR");
            writer.WriteLine("#endif // RBP_COMPONENT_PAR");
            writer.WriteLine("");

            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_header_gen_h_1 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_header_gen_h_2 */ /*(details: see end of file)*/");
            writer.WriteLine("");
            writer.WriteLine("/*****************************************************************************/");
            writer.WriteLine("/* START OF EXPLANATION FOR RBP_RULE_DEVIATIONS: */");
            writer.WriteLine("/*===============================*/");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_header_gen_h_1 */");
            writer.WriteLine("/* Deviation to GPG rule number: 1.3, 5.2*/");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Identifier name differ with minor changes. This is intended in ASW/BSW identifiers.");
            writer.WriteLine("   File is auto generated and therefore has too long Object-Macro names & structure element names.");
            writer.WriteLine("   This exception suppresses those warnings. */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Review has been done. Pargen tool doesn't generate duplicate identifiers.");
            writer.WriteLine("   Parameter names are autogenerated and require information of its content,");
            writer.WriteLine("   this assures better quality even if the names get longer.");
            writer.WriteLine("   GHS compiler allows longer #defines (U)= theoretically unlimited  */");
            writer.WriteLine("");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_header_gen_h_2 */");
            writer.WriteLine("/* Deviation to GPG rule number: 2217*/");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Comments exceeds more than 130 characters*/");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Since it is comments not gonna effect safety */");
            writer.WriteLine("");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_header_gen_h_3 */");
            writer.WriteLine("/* Deviation to GPG rule number: 3684*/");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Array is required when software is used in Application Only mode.");
            writer.WriteLine("   And the size of the array is nothing but the size of the 'rbp_par{0}_ROMData_st'. */", my_DatasetName);
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Array is pointing to the base address of 'rbp_par{0}_ROMData_st' structure. ", my_DatasetName);
            writer.WriteLine("   Hence no dereference of unknown memory location. */");
            writer.WriteLine("");
            writer.WriteLine("/* END OF EXPLANATION FOR RBP_RULE DEVIATIONS */");
            writer.WriteLine("/*****************************************************************************/");

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("}");
            writer.WriteLine("#endif // __cplusplus");
            writer.WriteLine("#endif /* RBP_PAR_HEADER{0}_GEN_H */", my_FileName_Suffix.ToUpper());

            // close output file
            writer.Close();
        }

        // Generate the file rbp_par_access_gen.h.
        public void PrintGenParAccess(ref cParameterSet my_ps,
                                   ref cSegmentDefinition my_sd,
                                   ref String my_ps_file_name,
                                   String my_output_path,
                                   string my_FileName_Suffix,
                                   ref DateTime my_dt,
                                   ref cGeneralConfiguration my_gc,
                                   ref List<List<string[]>> my_access_define_list,
                                   ref bool IsAccessdef_unique)
        {
            // Initialize the necessary variables.
            Program my_program = new Program();
            cWrapper_XML_2_x wrapper_2_x = new cWrapper_XML_2_x();
            string my_gen_file_name = "rbp_par_access" + my_FileName_Suffix + "_gen.h";
            string my_source_file_name = "Gen_Header.cs";

            // Overwrite the output path if already exists.
            my_program.OverwriteOPPath(ref my_gc, ref my_output_path, my_gen_file_name);

            // Generated file header.
            my_program.PrintFileInfo(ref my_ps,ref my_ps_file_name,my_output_path,ref my_dt,my_gen_file_name,my_source_file_name);

            // Obtain absolute path of output file.
            var genFileNamePath = Path.Combine(Path.GetFullPath(my_output_path), my_gen_file_name);

            // Open output file.
            var writer = Program.CreateStreamWriter(genFileNamePath, true, Encoding.ASCII);
            
            writer.WriteLine("#ifndef RBP_PAR_ACCESS{0}_GEN_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("#define RBP_PAR_ACCESS{0}_GEN_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("");

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("extern \"C\"");
            writer.WriteLine("{");
            writer.WriteLine("#endif // __cplusplus");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Magic number                                                           -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#define RBP_PAR_ACCESS_MAGIC_NUMBER_GEN  0x{0:d2}{1:d2}{2:d2}{3:d2}", my_dt.Month, my_dt.Day, my_dt.Hour, my_dt.Minute);
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Component Switches                                                     -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Include files                                                          -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Exported Macros                                                        -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("/* PRQA S 0779 RBP_RULE_DEV_rbp_par_access_gen_h_1 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA S 2217 RBP_RULE_DEV_rbp_par_access_gen_h_2 */ /*(details: see end of file)*/");
            writer.WriteLine("");          

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- parameter access macros                                                -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            
            // Create list of string array tp store access defines foe constant\parameters.
            List<string[]> define_list = new List<string[]>();
            // C99\C11 compatible the identifier\macro name shall be unique within the first 63 characters
            int define_configlen = 63;

            // Index required to get the necessary data (i.e.access define, isdefine validated)
            int access_def_idx = 2;
            int def_verify_idx = 3;

            foreach (cComponent component in my_ps.Components)
            {
                // Print the Component to which the access macros belong to.
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("/*- {0}{1} -*/",
                                  component.Name.ToUpper(), new String(' ', 70 - component.Name.Length));
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("");

                // Access macros for defines.
                foreach (cDefine my_define in component.Defines)
                {
                    String pre_fix;
                    String post_fix;

                    // Constants
                    if (my_define.Type != "switch")
                    {
                        // Prefix name for the constants.
                        pre_fix = "rbp_";

                        if (my_define.Type == "UInt8") { post_fix = "u8"; }
                        else if (my_define.Type == "UInt16") { post_fix = "u16"; }
                        else if (my_define.Type == "UInt32") { post_fix = "u32"; }
                        else if (my_define.Type == "SInt8") { post_fix = "s8"; }
                        else if (my_define.Type == "SInt16") { post_fix = "s16"; }
                        else if (my_define.Type == "SInt32") { post_fix = "s32"; }
                        else if (my_define.Type == "Boolean") { post_fix = "b"; }
                        else if (my_define.Type == "Float32") { post_fix = "f32"; }
                        else { post_fix = "unknown"; }
                        
                        //Ex: Parameter Define (constant) : name : max_number_traces , Type = UInt8 ->  #define rbp_par_get_max_number_traces_u8  rbp_max_number_traces_du8
                        string temp_str = "rbp_par_get_" + my_define.Name + "_" + post_fix;
                        writer.WriteLine("#define {0} {3}{1}_d{2}",temp_str, my_define.Name, post_fix,pre_fix);

                        // Update the list if length of the define is greater than configured.
                        if (temp_str.Length >= define_configlen)
                        {
                            define_list.Add(new string[] { "Constant Define",my_define.Name,temp_str,"Not Checked" });
                        }

                    }
                }

                // Access macros for parameter defines of clusters having memory area other than NVM.
                foreach (cParameterCluster cluster in component.ParameterClusters)
                {
                    if (cluster.MemoryArea != "NVM")
                    {
                        foreach (cParameterDefinition para_def in cluster.ParameterDefinitions)
                        {
                            // Variable to check for array.
                            bool array_check = false;

                            // Access macros for parameter definitions.
                            // E.g.: cluster name - CTL_PAS; parameter definition name - VCutOffPasAccelerate
                            //        rbp_par_get_CTL_PAS_VCutOffPasAccelerate_
                            string temp_str = "rbp_par_get_"+ cluster.Name + "_"+ para_def.Name + "_";

                            if ((para_def.Type != "Bitfield8") && (para_def.Type != "Bitfield16") && (para_def.Type != "Bitfield32"))
                            {
                                // Check for arrays.
                                if (Convert.ToInt32(para_def.Number) > 1)
                                {
                                    // Add p before the data type.
                                    temp_str += "p";
                                    array_check = true;
                                }
                            }

                            String post_fix;

                            if (wrapper_2_x.Is_para_def_enum_b(my_ps,para_def) != true)
                            {
                                 // Parameter is of type Basic data types.
                                if (para_def.Type == "UInt8") { post_fix = "u8"; }
                                else if (para_def.Type == "UInt16") { post_fix = "u16"; }
                                else if (para_def.Type == "UInt32") { post_fix = "u32"; }
                                else if (para_def.Type == "SInt8") { post_fix = "s8"; }
                                else if (para_def.Type == "SInt16") { post_fix = "s16"; }
                                else if (para_def.Type == "SInt32") { post_fix = "s32"; }
                                else if (para_def.Type == "Boolean") { post_fix = "b"; }
                                else if (para_def.Type == "Bitfield8") { post_fix = String.Format("bf{0}",para_def.Number); }
                                else if (para_def.Type == "Bitfield16") { post_fix = String.Format("bf{0}",para_def.Number); }
                                else if (para_def.Type == "Bitfield32") { post_fix = String.Format("bf{0}",para_def.Number); }
                                else if (para_def.Type == "Float32") { post_fix = "f32"; }
                                else { post_fix = "unknown"; }
                            }
                            else 
                            { 
                                // Parameter of type enumeration.
                                post_fix = "en"; 
                            };

                            temp_str += post_fix;

                            // E.g.: cluster name - CTL_PAS; post fix - u16; parameter definition name - VCutOffPasAccelerate
                            //        #define rbp_par_get_CTL_PAS_VCutOffPasAccelerate_u16 (((rbp_Type_par_CTL_PAS_st *)(rbp_par_RAMData_st.ClusterPointer_ppvd[rbp_Idx_CTL_PAS_du16]))->VCutOffPasAccelerate_
                            writer.Write("#define {0} (rbp_par_getParaReadAccess_{1}_cpst(rbp_Idx_{1}_du16)->{3}_",
                                           temp_str,cluster.Name,post_fix,para_def.Name);
                            
                            // Check for arrays.
                            if (array_check == true)
                            {
                                // Add p before the data type.
                                writer.Write("p");
                            }

                            // E.g.: post_fix - u16
                            //       u16)
                            writer.WriteLine("{0})",post_fix);

                            // Update the list if length of the define is greater than configured.
                            if (temp_str.Length >= define_configlen)
                            {
                                define_list.Add(new string[] { cluster.Name,para_def.Name,temp_str,"Not Checked" });
                            }
                        }
                    }
                }
                writer.WriteLine("");

                // String List to store the constant defines of the array parameters.
                List<string> array_def = new List<string>();

                foreach (cParameterCluster cluster in component.ParameterClusters)
                {
                    // Access macros for clusters parameter having memory area other than NVM.
                    if (cluster.MemoryArea != "NVM")
                    {
                        foreach (cParameterDefinition para_def in cluster.ParameterDefinitions)
                        {
                            if ((para_def.Type != "Bitfield8") && (para_def.Type != "Bitfield16") && (para_def.Type != "Bitfield32"))
                            {
                                // Check for array parameter.
                                if (Convert.ToUInt32(para_def.Number) > 1)
                                {
                                    // Access macros for parameter definitions.
                                    // E.g.: cluster name - CTL_PAS; parameter definition name - VCutOffPasAccelerate
                                    //        rbp_par_get_CTL_PAS_VCutOffPasAccelerate_Len_du32
                                    string temp_str = "rbp_par_get_" + cluster.Name + "_" + para_def.Name + "_Len_du32";

                                    if (Convert.ToUInt32(para_def.Number) > 2147483647)
                                    {
                                        // Length of the array exceeds >(2^31)-1. Throw exception
                                        throw new Exception(" Array Length exceeds 2^31-1 for parameter '"+ para_def.Name + "'. Please reduce the length of the array parameter");
                                    }

                                    // E.g.: cluster name - CTL_PAS; post fix - u16; parameter definition name - VCutOffPasAccelerate
                                    //        #define rbp_par_get_CTL_PAS_VCutOffPasAccelerate_Len_du32  ((UInt32)value)
                                    array_def.Add("#define "+ temp_str +"  ((UInt32)"+ Convert.ToUInt32(para_def.Number) +")");

                                    // Update the list if length of the define is greater than configured.
                                    if (temp_str.Length >= define_configlen)
                                    {
                                        define_list.Add(new string[] { cluster.Name,para_def.Name,temp_str,"Not Checked" });
                                    }
                                }
                                else
                                {
                                    // Not an arary parameter.
                                }
                            }
                        }
                    }
                }

                // Check whether list is empty or not
                if (array_def.Count != 0)
                {
                    writer.WriteLine(" /* Below defines provides the length of the array parameters */");
                    foreach (string array_para_def in array_def)
                    {
                        writer.WriteLine("{0}",array_para_def);
                    }
                    // Clear the List.
                    array_def.Clear();
                }
            }

            // Validate\Compare to check whether access defines(macro\identifier) unique within the first 63 characters
            foreach (string[] def_outloop_list in define_list)
            {
                // Create list to store define list not unique within first 63 chracters
                List<string[]> temp_reslist = new List<string[]>();
                bool IsList_updated = false;
                bool iscomp_list_updated = false;    // variabke 

                // Loop to check each define with  entire defines list.
                foreach (string[] def_inloop_list in define_list)
                {
                    if (!(def_outloop_list[access_def_idx].Equals(def_inloop_list[access_def_idx]))    // ignore for same access defines
                        && (0 == string.Compare(def_outloop_list[access_def_idx],0,def_inloop_list[access_def_idx],0,define_configlen)) // Check whether defines are unique for first 63 characters
                        && (def_inloop_list[def_verify_idx].Equals("Not Checked")))   // Check whether define is validated\checked already
                    {
                        // Define is not unique for first 63 characters and yet the define is not considered for the comparision
                        
                        if (iscomp_list_updated == false)
                        {
                            // Add the outer loop define to the list, required during generation and mark the define as validated.
                            temp_reslist.Add(def_outloop_list);
                            def_outloop_list[def_verify_idx] = "Checked";
                            iscomp_list_updated = true;   // Indicate comaprision define is added to result and it's not required to be added once again for every valid inner loop check.
                        }

                        // Add define to the result list and mark as validated\checked.
                        def_inloop_list[def_verify_idx] = "Checked";
                        temp_reslist.Add(def_inloop_list);
                        IsList_updated = true;   //  Result list is updated.
                    }
                }
                
                if (IsList_updated == true)
                {
                    // Update the result list.
                    my_access_define_list.Add(temp_reslist);

                    // Some of Access defines are not unique till 63 characters, print warning in the .c file 
                    IsAccessdef_unique = false;
                }
            }
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_access_gen_h_1 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_access_gen_h_2 */ /*(details: see end of file)*/");
            writer.WriteLine("");
            writer.WriteLine("/*****************************************************************************/");
            writer.WriteLine("/* START OF EXPLANATION FOR RBP_RULE_DEVIATIONS: */");
            writer.WriteLine("/*===============================*/");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_access_gen_h_1 */");
            writer.WriteLine("/* Deviation to GPG rule number: 1.3, 5.2*/");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Identifier name differ with minor changes. This is intended in ASW/BSW identifiers.");
            writer.WriteLine("   File is auto generated and therefore has too long Object-Macro names & structure element names.");
            writer.WriteLine("   This exception suppresses those warnings */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Review has been done. Pargen tool doesn't generate duplicate identifiers.");
            writer.WriteLine("   Parameter names are autogenerated and require information of its content,");
            writer.WriteLine("   this assures better quality even if the names get longer.");
            writer.WriteLine("   GHS compiler allows longer #defines (U)= theoretically unlimited  */");
            writer.WriteLine("");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_access_gen_h_2 */");
            writer.WriteLine("/* Deviation to GPG rule number: 2217*/");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:"); 
            writer.WriteLine("   Comments exceeds more than 130 characters.*/");
            writer.WriteLine("/* Demonstration how safety and quality is still assured: ");
            writer.WriteLine("   Since it is comments not gonna effect safety. */");
            writer.WriteLine("");
            writer.WriteLine("/* END OF EXPLANATION FOR RBP_RULE DEVIATIONS */");
            writer.WriteLine("/*****************************************************************************/");

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("}");
            writer.WriteLine("#endif // __cplusplus");
            writer.WriteLine("#endif /* RBP_PAR_ACCESS{0}_GEN_H */", my_FileName_Suffix.ToUpper());

            // Close output file.
            writer.Close();
        }

        // Generate the file rbp_par_define_gen.h.
        public void PrintGenParDefine(ref cParameterSet my_ps,
                                            ref cSegmentDefinition my_sd,
                                            ref String my_ps_file_name,
                                            String my_output_path,
                                            string my_FileName_Suffix,
                                            ref DateTime my_dt,
                                            ref cGeneralConfiguration my_gc,
                                            string my_selected_dataset,
                                            ref List<cComponent> my_compcopy)
        {
            // Initialize the necessary variables.
            Program my_program = new Program();
            string my_gen_file_name = "rbp_par_define" + my_FileName_Suffix + "_gen.h";
            string my_source_file_name = "Gen_Header.cs";

            // Overwrite the output path if already exists.
            my_program.OverwriteOPPath(ref my_gc, ref my_output_path, my_gen_file_name);

            // Generated file header.
            my_program.PrintFileInfo(ref my_ps, ref my_ps_file_name, my_output_path, ref my_dt, my_gen_file_name, my_source_file_name);

            // Obtain absolute path of output file.
            var genFileNamePath = Path.Combine(Path.GetFullPath(my_output_path), my_gen_file_name);

            // Open output file.
            var writer = Program.CreateStreamWriter(genFileNamePath, true, Encoding.ASCII);
            
            writer.WriteLine("#ifndef RBP_PAR_DEFINE{0}_GEN_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("#define RBP_PAR_DEFINE{0}_GEN_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("");

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("extern \"C\"");
            writer.WriteLine("{");
            writer.WriteLine("#endif // __cplusplus");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Magic number                                                           -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#define RBP_PAR_DEFINE_MAGIC_NUMBER_GEN  0x{0:d2}{1:d2}{2:d2}{3:d2}", my_dt.Month, my_dt.Day, my_dt.Hour, my_dt.Minute);
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Component Switches                                                     -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Include files                                                          -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- check if compiler switches (utilised in this component) are defined    -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- exported symbolic constants                                            -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#ifdef RBP_COMPONENT_PAR");
            writer.WriteLine("#endif // RBP_COMPONENT_PAR");
            writer.WriteLine("");
            writer.WriteLine("/* PRQA S 0779 RBP_RULE_DEV_rbp_par_define_gen_h_1 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA S 2217 RBP_RULE_DEV_rbp_par_define_gen_h_2 */ /*(details: see end of file)*/");
            writer.WriteLine("");

            Boolean variant_overflow_b = false;

            // Initialize the count variables.
            int NumClusters = 0;
            int NumMajorVariants = my_ps.MajorVariants.Count;
            int NumMinorVarMetaData = 0;
            int NumSubVarMetaData = 0;

            if (NumMajorVariants >= 255)
            {
                variant_overflow_b = true;
                Console.WriteLine("");
                Console.BackgroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("================================== ## ERROR ## =============================================================");
                Console.WriteLine(" Number of Major Variants limit crossed (i.e. >=255). Please reduce the major variants count within PAR_XML ");
                Console.WriteLine("============================================================================================================");
                Console.ResetColor();
            }
            else if((my_gc.Product_Line == "NRCS") && (my_gc.DataSet_Type == "MULTIPLE") && (NumMajorVariants > 1))
            {
                my_program.PrintErrorInfo("Parameter generation for Multiple dataset is supported for PAR_XML containing only one Major Variant.");
                throw (new Exception("Provide PAR_XML containing only one major variant."));
            }

            foreach (cComponent component in my_ps.Components)
            {
                foreach (cParameterCluster cluster in component.ParameterClusters)
                {
                    NumClusters++;

                    foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                    {
                        NumMinorVarMetaData++;

                        if (var_imp.MinorVariants.Count >= 255)
                        {
                            variant_overflow_b = true;
                            Console.WriteLine("");
                            Console.BackgroundColor = ConsoleColor.DarkRed;
                            Console.WriteLine("================================== ## ERROR ## =======================================================");
                            Console.WriteLine(" Number of Minor Variants Limit crossed (i.e. >= 255) for the cluster -> {0}", cluster.Name);
                            Console.WriteLine(" SRV_PAR does not support minor variants >=255. Please reduce the minor variants for the corresponding cluster");
                            Console.WriteLine("======================================================================================================");
                            Console.ResetColor();
                        }

                        foreach (cMinorVariant min_var in var_imp.MinorVariants)
                        {
                            if(min_var.SubVariants.Count >= 255)
                            {
                                variant_overflow_b = true;
                                Console.WriteLine("");
                                Console.BackgroundColor = ConsoleColor.DarkRed;
                                Console.WriteLine("================================== ## ERROR ## =======================================================");
                                Console.WriteLine(" Number of Subvariant Variants Limit crossed (i.e. >= 255) for the cluster -> {0}",cluster.Name);
                                Console.WriteLine(" SRV_PAR does not support sub variants >=255. Please reduce the sub variants for the corresponding cluster");
                                Console.WriteLine("======================================================================================================");
                                Console.ResetColor();
                            }

                            NumSubVarMetaData++;
                        }
                    }
                }
            }

            // Print the count of clusters, major variants, minor and sub variant meta data.
            {
                string my_cluster_num = "rbp_Num_Clusters";
                string my_mjv_num = "rbp_Num_Major_Variants";
                string my_mnv_meta_data_num = "rbp_Num_Minor_Var_Meta_Data";
                string my_subv_meta_data_num = "rbp_Num_Sub_Var_Meta_Data";

                writer.WriteLine("// Number of clusters.");
                writer.WriteLine("#define {0}_du16{1}((UInt16)({2}))", my_cluster_num, new string(' ', 75 - my_cluster_num.Length), NumClusters);
                writer.WriteLine("");

                writer.WriteLine("// Number of major variants.");
                writer.WriteLine("#define {0}_du8{1}((UInt8)({2}))", my_mjv_num, new string(' ', 76 - my_mjv_num.Length), NumMajorVariants);
                writer.WriteLine("");

                writer.WriteLine("// Number of minor var meta data entries.");
                writer.WriteLine("#define {0}_du16{1}((UInt16)({2}))", my_mnv_meta_data_num, new string(' ', 75 - my_mnv_meta_data_num.Length), NumMinorVarMetaData);
                writer.WriteLine("");

                writer.WriteLine("// Number of sub var meta data entries.");
                writer.WriteLine("#define {0}_du16{1}((UInt16)({2}))", my_subv_meta_data_num, new string(' ', 75 - my_subv_meta_data_num.Length), NumSubVarMetaData);
                writer.WriteLine("");
            }

            //! Major variant index.
            {
                // #defines for major variant index.
                int mjv_idx = 0;
                writer.WriteLine("// Major variant index.");

                foreach (string my_string in my_ps.MajorVariants)
                {
                    // E.g.: Major variant name - AUDI_AU370
                    //       tmp_string = rbp_Mjv_AUDI_AU370
                    string tmp_string = String.Format("rbp_Mjv_{0}", my_string);

                        // E.g.: tmp_string - rbp_Mjv_AUDI_AU370; mjv_idx = 0
                        //       #define rbp_Mjv_AUDI_AU370_du8      ((UInt8)(0))
                        writer.WriteLine("#define {0}_du8{1}((UInt8)({2}))", tmp_string, new string(' ', 75 - tmp_string.Length), mjv_idx);


                    mjv_idx++;
                }
            } //! @end: Major variant index.

            //! Minor variant index.
            {
                // Dictionary to store the minor-variant name as a key and Index as a value.
                Dictionary<string, int> min_var_dict = new Dictionary<string, int>();
                bool l_duplicate_names_b = false;

                foreach (cComponent component in my_ps.Components)
                {
                    foreach (cParameterCluster cluster in component.ParameterClusters)
                    {
                        foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                        {
                            int l_mnv_dict_idx = 0;

                            foreach (cMinorVariant min_var in var_imp.MinorVariants)
                            {
                                if (min_var.Name != "")
                                {
                                    // Minor variant available.
                                    // E.g.: cluster name - MAP_Trck; Minor variant name - TrckMode_FullVHM
                                    //       my_key = "rbp_Miv_MAP_Trck_TrckMode_FullVHM"
                                    string my_key = String.Format("rbp_Miv_{0}_{1}", cluster.Name, min_var.Name);

                                    if (min_var_dict.ContainsKey(my_key))
                                    {
                                        if (min_var_dict[my_key] != l_mnv_dict_idx)
                                        {
                                            // Duplicate keys.
                                            l_duplicate_names_b = true;
                                        }
                                        else
                                        {
                                            // Do not re-add element since it is same minor variant. Just variant implementation is different.
                                        }
                                    }
                                    else
                                    {
                                        // New element.
                                        min_var_dict.Add(my_key, l_mnv_dict_idx);
                                    }
                                }
                                else
                                {
                                    // Do nothing.
                                }

                                l_mnv_dict_idx++;
                            }
                        }
                    }
                }

                if (l_duplicate_names_b)
                {
                    // Error message: Duplicate definitions of minor variants are present.
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("======================================================================================================");                    
                    Console.WriteLine("                                  ## ERROR ##                                                         ");
                    Console.WriteLine(" *** Error while generating minor variant indexes in rbp_par_define" + my_FileName_Suffix + "_gen.h file.                   *** ");
                    Console.WriteLine(" *** Possible reason:                                                                             *** ");
                    Console.WriteLine(" *** 1) Different order of minor variant in differrent variant implementation within same cluster.*** ");
                    Console.WriteLine(" *** 2) Duplicate definitions of minor variants in same variant implementation.                   *** ");
                    Console.WriteLine("======================================================================================================");
                    Console.ResetColor();

                    // Below if condition is temporary. Refer T&R NRCSTWO-118129.
                    if ((my_gc.DisableVariantMismatchCheck == "true") && (my_gc.Product_Line == "NRCS"))
                    {
                        // Variant mismatch check is disabled, hence print only the default Minor variant index.
                        string my_default_mnv = "rbp_Miv_Default";
                        writer.WriteLine("");
                        writer.WriteLine("// Minor variant index.");

                        // E.g.: #define rbp_Miv_Default_du8       ((UInt8)(0))
                        writer.WriteLine("#define {0}_du8{1}((UInt8)(0))", my_default_mnv, new string(' ', 75 - my_default_mnv.Length));
                    }
                    else
                    {
                        // Variant mismatch check is enabled. Donot proceed with parameter generation.
                        // Exception to exit the file generation process.
                        throw (new Exception(" "));
                    }
                }

                else
                {
                    string my_default_mnv = "rbp_Miv_Default";
                    writer.WriteLine("");
                    writer.WriteLine("// Minor variant index.");

                    // E.g.: #define rbp_Miv_Default_du8       ((UInt8)(0))
                    writer.WriteLine("#define {0}_du8{1}((UInt8)(0))", my_default_mnv, new string(' ', 75 - my_default_mnv.Length));

                    foreach (KeyValuePair<string, int> my_pair in min_var_dict)
                    {
                        // E.g.: my_pair.my_key = rbp_Miv_MAP_Trck_TrckMode_FullVHM;  my_pair.Value = 0
                        //       #define rbp_Miv_MAP_Trck_TrckMode_FullVHM_du8              ((UInt8)(0))
                        writer.WriteLine("#define {0}_du8{1}((UInt8)({2}))", my_pair.Key, new string(' ', 75 - my_pair.Key.Length), my_pair.Value);
                    }
                }
            } //! @end: Minor variant index.

            //! Sub variant index.
            {
                // Dictionary to store the sub-variant name as a key and index as a value.
                // Flag names contain sub_var names only.
                Dictionary<string, int> sub_var_dict = new Dictionary<string, int>();

                bool l_duplicate_names_b = false;

                foreach (cComponent component in my_ps.Components)
                {
                    foreach (cParameterCluster cluster in component.ParameterClusters)
                    {
                        foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                        {
                            foreach (cMinorVariant min_var in var_imp.MinorVariants)
                            {
                                int l_subv_dict_idx = 0;

                                foreach (cSubVariant sub_var in min_var.SubVariants)
                                {
                                    if (sub_var.Name != "")
                                    {
                                        // Sub variants are available.
                                        string my_key;

                                        // E.g.: cluster name - OLO_SensFOV ; Subvariant name - 01_06
                                        //       my_key = rbp_Suv_OLO_SensFOV_Sens_01_06
                                        my_key = String.Format("rbp_Suv_{0}_{1}", cluster.Name, sub_var.Name);

                                        if (sub_var_dict.ContainsKey(my_key))
                                        {
                                            if (sub_var_dict[my_key] != l_subv_dict_idx)
                                            {
                                                // duplicate keys
                                                l_duplicate_names_b = true;
                                            }
                                            else
                                            {
                                                // Do not re-add element. Since since it is same sub variant. Just variant implemntation is different.
                                            }
                                        }
                                        else
                                        {
                                            // New element.
                                            sub_var_dict.Add(my_key, l_subv_dict_idx);
                                        }

                                        l_subv_dict_idx++;
                                    }
                                    else
                                    { 
                                        // Do nothing.
                                    }
                                }
                            }
                        }
                    }
                }

                if (l_duplicate_names_b != false)
                {
                    // Error message: Duplicate definitions of sub variants are present.
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("====================================================================================================");
                    Console.WriteLine("                                  ## ERROR ##                                                       ");
                    Console.WriteLine(" *** Error while generating sub variant indexes in rbp_par_define" + my_FileName_Suffix + "_gen.h file.                   *** ");
                    Console.WriteLine(" *** Possible reason:                                                                           *** ");
                    Console.WriteLine(" *** 1) Different order of sub variant in differrent variant implementation within same cluster.*** ");
                    Console.WriteLine(" *** 2) Duplicate definitions of sub variants in same variant implementation.                   *** ");
                    Console.WriteLine("====================================================================================================");
                    Console.ResetColor();

                    // Below if condition is short term. Refer T&R NRCSTWO-118129.
                    if ((my_gc.DisableVariantMismatchCheck == "true") && (my_gc.Product_Line == "NRCS"))
                    {
                        // Variant mismatch check is disabled, hence print only the default Minor variant index.
                        string my_default_subv = "rbp_Suv_Default";

                        writer.WriteLine("");
                        writer.WriteLine("// Sub variant index.");

                        // E.g.: #define rbp_Suv_Default_du8        ((UInt8)(0))
                        writer.WriteLine("#define {0}_du8{1}((UInt8)(0))", my_default_subv, new string(' ', 80 - my_default_subv.Length));
                    }
                    else
                    {
                        // Variant mismatch check is enabled. Donot proceed with parameter generation.
                        // Exception to exit the file generation process.
                        throw (new Exception(" "));
                    }
                }
                else
                {
                    string my_default_subv = "rbp_Suv_Default";

                    writer.WriteLine("");
                    writer.WriteLine("// Sub variant index.");

                    // E.g.: #define rbp_Suv_Default_du8        ((UInt8)(0))
                    writer.WriteLine("#define {0}_du8{1}((UInt8)(0))", my_default_subv, new string(' ', 80 - my_default_subv.Length));
                    foreach (KeyValuePair<string, int> my_pair in sub_var_dict)
                    {
                        // E.g.: Key - rbp_Suv_OLO_SensFOV_01_06 ; Value - 0
                        //       #define rbp_Suv_OLO_SensFOV_01_06_du8               ((UInt8)(0))
                        writer.WriteLine("#define {0}_du8{1}((UInt8)({2}))", my_pair.Key, new string(' ', 80 - my_pair.Key.Length), my_pair.Value);
                    }
                }
            } //! @end: Sub variant index.

            //! General cluster index.
            {
                int l_gen_cl_idx = 0;

                // #defines for general cluster index.
                writer.WriteLine("");
                writer.WriteLine("// General cluster index.");


                if ((my_gc.Product_Line == "NRCS") && (my_gc.DataSet_Type == "MULTIPLE") && (my_selected_dataset != "main"))
                {
                    // Generate cluster index for individual run of multiple dataset.
                    foreach (cComponent component in my_ps.Components)
                    {
                        l_gen_cl_idx = 0;
                        foreach (cComponent cpy_comp in my_compcopy)
                        {
                            foreach (cParameterCluster cluster in cpy_comp.ParameterClusters)
                            {
                                if (cluster.MemoryArea != "NVM")
                                {
                                    // Print the indexes only if the component is present in the selected dataset.
                                    if (component.Name == cpy_comp.Name)
                                    {
                                        // E.g.: cluster name - CTL_PAS
                                        //       my_string = rbp_Idx_CTL_PAS
                                        string my_string = String.Format("rbp_Idx_{0}", cluster.Name);

                                        // E.g.: my_string = rbp_Idx_CTL_PAS ;  l_gen_cl_idx - 0
                                        //       #define rbp_Idx_CTL_PAS_du16           ((UInt16)(0))
                                        writer.WriteLine("#define {0}_du16{1}((UInt16)({2}))", my_string, new string(' ', 80 - my_string.Length), l_gen_cl_idx);
                                    }
                                    l_gen_cl_idx++;
                                }
                                else
                                {
                                    // Do nothing.
                                }
                            }
                        }
                    }
                }
                else
                {
                    // Generate cluster index for USS, NRCS single dataset and NRCS multiple dataset overall run.
                    foreach (cComponent component in my_ps.Components)
                    {
                        foreach (cParameterCluster cluster in component.ParameterClusters)
                        {
                            if (cluster.MemoryArea != "NVM")
                            {
                                // E.g.: cluster name - CTL_PAS
                                //       my_string = rbp_Idx_CTL_PAS
                                string my_string = String.Format("rbp_Idx_{0}",cluster.Name);

                                // E.g.: my_string = rbp_Idx_CTL_PAS ;  l_gen_cl_idx - 0
                                //       #define rbp_Idx_CTL_PAS_du16           ((UInt16)(0))
                                writer.WriteLine("#define {0}_du16{1}((UInt16)({2}))",my_string,new string(' ',80 - my_string.Length),l_gen_cl_idx);
                                l_gen_cl_idx++;
                            }
                            else
                            {
                                // Do nothing.
                            }
                        }
                    }
                 }
            } //! @end: General cluster index.

            //! Write Access cluster index.
            {
                int l_wr_cl_idx = 0;
                Boolean l_write_access_cl_b = false;

                // #defines for write access cluster index.
                writer.WriteLine("");
                writer.WriteLine("// Write access cluster index.");

                if ((my_gc.Product_Line == "NRCS") && (my_gc.DataSet_Type == "MULTIPLE") && (my_selected_dataset != "main"))
                {
                    // Generate write access cluster index for individual run of multiple dataset.
                    foreach (cComponent component in my_ps.Components)
                    {
                        l_wr_cl_idx = 0;
                        foreach (cComponent cpy_comp in my_compcopy)
                        {
                            foreach (cParameterCluster cluster in cpy_comp.ParameterClusters)
                            {
                                if (cluster.MemoryArea != "NVM")
                                {
                                    if ((cluster.MemoryArea == "NVM_INIT") || (cluster.MemoryArea == "RAM_INIT"))
                                    {
                                        // Print the indexes only is component is present in selected dataset.
                                        if (component.Name == cpy_comp.Name)
                                        {
                                            // E.g.: cluster name - CTL_PAS
                                            //       my_string = rbp_Idx_Write_CTL_PAS
                                            string my_string = String.Format("rbp_Idx_Write_{0}", cluster.Name);


                                            // E.g.:my_string = rbp_Idx_Write_CTL_PAS ; l_wr_cl_idx - 0
                                            //      #define rbp_Idx_Write_CTL_PAS_du16         ((UInt16)(0))
                                            writer.WriteLine("#define {0}_du16{1}((UInt16)({2}))", my_string, new string(' ', 80 - my_string.Length), l_wr_cl_idx);
                                            l_write_access_cl_b = true;
                                        }
                                    }
                                    else
                                    {
                                        // Write access index not required for ROM and NVM clusters.
                                    }
                                    l_wr_cl_idx++;
                                }
                            }
                        }
                    }
                }
                else
                {
                    // Generate write access cluster index for USS, NRCS single dataset and NRCS multiple dataset overall run.
                    foreach (cComponent component in my_ps.Components)
                    {
                        foreach (cParameterCluster cluster in component.ParameterClusters)
                        {
                            if (cluster.MemoryArea != "NVM")
                            {
                                if ((cluster.MemoryArea == "NVM_INIT") || (cluster.MemoryArea == "RAM_INIT"))
                                {
                                    // E.g.: cluster name - CTL_PAS
                                    //       my_string = rbp_Idx_Write_CTL_PAS
                                    string my_string = String.Format("rbp_Idx_Write_{0}", cluster.Name);


                                    // E.g.:my_string = rbp_Idx_Write_CTL_PAS ; l_wr_cl_idx - 0
                                    //      #define rbp_Idx_Write_CTL_PAS_du16         ((UInt16)(0))
                                    writer.WriteLine("#define {0}_du16{1}((UInt16)({2}))", my_string, new string(' ', 80 - my_string.Length), l_wr_cl_idx);
                                    l_write_access_cl_b = true;
                                }
                                else
                                {
                                    // Write access index not required for ROM and NVM clusters.
                                }
                                l_wr_cl_idx++;
                            }
                        }
                    }
                }

                if (l_write_access_cl_b == false)
                {
                    writer.WriteLine("// NVM_INIT or RAM_INIT clusters are not available in the Input XML");
                }
                else
                {
                    // Do nothing.
                }
            } //! @end: Write Access cluster index.

            //! Cluster flag buffer size.
            {
                string my_buffer_size = "rbp_Cluster_Flag_Buffer_Size";

                writer.WriteLine("");
                writer.WriteLine("// Cluster flag buffer size.");
                // E.g.: #define rbp_Cluster_Flag_Buffer_Size_du16            ((UInt16)((rbp_Num_Clusters_du16 + 7) / 8))
                writer.WriteLine("#define {0}_du16{1}((UInt16)((rbp_Num_Clusters_du16 + 7) / 8))", my_buffer_size, new string(' ', 78 - my_buffer_size.Length));
                writer.WriteLine("");

            } //! @end: Cluster flag buffer size.

            //! Component Versions.
            {
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("/*- component versions                                                     -*/");
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("");

                foreach (cComponent component in my_ps.Components)
                {
                    writer.WriteLine("// {0} - version {1}", component.Name.ToUpper(), component.Version);

                    string[] my_str_array = component.Version.Split('.');
                    string my_mjv_str = String.Format("rbp_Comp_Version_Major_{0}", component.Name.ToUpper());
                    string my_mnv_str = String.Format("rbp_Comp_Version_Minor_{0}", component.Name.ToUpper());
                    string my_suv_str = String.Format("rbp_Comp_Version_Sub_{0}", component.Name.ToUpper());

                    // Sample:
                    // #define rbp_Comp_Version_Major_RBP_APC_CTL_du8                ((UInt8)(1))
                    // #define rbp_Comp_Version_Minor_RBP_APC_CTL_du8                ((UInt8)(0))
                    // #define rbp_Comp_Version_Sub_RBP_APC_CTL_du8                  ((UInt8)(0))
                    writer.WriteLine("#define {0}_du8{1}((UInt8)({2}))", my_mjv_str, new string(' ', 75 - my_mjv_str.Length), (my_str_array.GetUpperBound(0) >= 0) ? my_str_array[0] : "0");
                    writer.WriteLine("#define {0}_du8{1}((UInt8)({2}))", my_mnv_str, new string(' ', 75 - my_mnv_str.Length), (my_str_array.GetUpperBound(0) >= 1) ? my_str_array[1] : "0");
                    writer.WriteLine("#define {0}_du8{1}((UInt8)({2}))", my_suv_str, new string(' ', 75 - my_suv_str.Length), (my_str_array.GetUpperBound(0) >= 2) ? my_str_array[2] : "0");
                    writer.WriteLine("");
                }
            } //! @end: Component Versions.

            writer.WriteLine("");
            if (my_gc.Product_Line == "NRCS")
            {
                writer.WriteLine("");
                writer.WriteLine("");
                //Backup Code: TODO: Delete it if not needed
                //Generates a define to get the size of structures that are allocated for D3
                /* writer.WriteLine("//Start of NRCS specific code");
                 writer.Write("#define size_of_D3_clusters_ux ");
                 foreach (cComponent component in my_ps.Components)
                 {
                     string[] array = Sorting_Order.Split(',');
                     for (int i = 0; i < array.Length; i++)
                     {//component name matches with data in csv. print the size of all clusters in that component
                         if (component.Name == array[i])
                         {
                             foreach (cParameterCluster cluster in component.ParameterClusters)
                             {//checking if the cluster is an array or not
                                 if (cluster.VariantApplication.ToUpper() == "SINGLE")
                                 {
                                     writer.Write("sizeof({0}_st) + ", cluster.Name);
                                 }
                                 else
                                 {
                                     writer.Write("sizeof({0}_pst) + ", cluster.Name);
                                 }
                             }
                         }
                     }
                 }
                 writer.WriteLine("0");*/
                writer.WriteLine("");
            }
            else 
            {
                // Do nothing.
            }

            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_define_gen_h_1 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_define_gen_h_2 */ /*(details: see end of file)*/");
            writer.WriteLine("");
            writer.WriteLine("/*****************************************************************************/");
            writer.WriteLine("/* START OF EXPLANATION FOR RBP_RULE_DEVIATIONS: */");
            writer.WriteLine("/*===============================*/");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_define_gen_h_1 */");
            writer.WriteLine("/* Deviation to GPG rule number: 1.3, 5.2*/");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Identifier name differ with minor changes. This is intended in ASW/BSW identifiers.");
            writer.WriteLine("   File is auto generated and therefore has too long Object-Macro names & structure element names.");
            writer.WriteLine("   This exception suppresses those warnings */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Review has been done. Pargen tool doesn't generate duplicate identifiers.");
            writer.WriteLine("   Parameter names are autogenerated and require information of its content,");
            writer.WriteLine("   this assures better quality even if the names get longer.");
            writer.WriteLine("   GHS compiler allows longer #defines (U)= theoretically unlimited  */");
            writer.WriteLine("");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_define_gen_h_2 */");
            writer.WriteLine("/* Deviation to GPG rule number: 2217*/");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Comments exceeds more than 130 characters*/");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Since it is comments not gonna effect safety */");
            writer.WriteLine("");
            writer.WriteLine("/* END OF EXPLANATION FOR RBP_RULE DEVIATIONS */");
            writer.WriteLine("/*****************************************************************************/");

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("}");
            writer.WriteLine("#endif // __cplusplus");
            writer.WriteLine("#endif /* RBP_PAR_DEFINE{0}_GEN_H */", my_FileName_Suffix.ToUpper());

            // Close output file.
            writer.Close();
            
            if (variant_overflow_b != false)
            {
                // Add the list of files that you do not want to delete to the list file_list.
                // E.g.: file_list.Add("rbp_par_main_gen.c");
                List<string> file_list = new List<string>();
                // Throw excpetion as there is an oveflow in Major\Minor\Sub Variant. Delete the generated files except LOG folder and the ones mentioned in above list. 
                throw (new Exception_Handler("", ref my_gc, true, file_list));
            }
        }

        public void PrintGenParStruct(ref cParameterSet my_ps,
                                            ref cSegmentDefinition my_sd,
                                            ref String my_ps_file_name,
                                            String my_output_path,
                                            string my_FileName_Suffix,
                                            ref DateTime my_dt,
                                            ref cGeneralConfiguration my_gc,
                                            string my_DatasetName)
        {
            // Initialize the necessary variables.
            Program my_program = new Program();
            cWrapper_XML_2_x wrapper_2_x = new cWrapper_XML_2_x();
            Secure_Flash Security = new Secure_Flash(my_gc);
            string my_gen_file_name = "rbp_par_struct" + my_FileName_Suffix + "_gen.h";
            string my_source_file_name = "Gen_Header.cs";

            // Overwrite the output path if already exists.
            my_program.OverwriteOPPath(ref my_gc, ref my_output_path, my_gen_file_name);

            // Generated file header.
            my_program.PrintFileInfo(ref my_ps, ref my_ps_file_name, my_output_path, ref my_dt, my_gen_file_name, my_source_file_name);

            // Obtain absolute path of output file.
            var genFileNamePath = Path.Combine(Path.GetFullPath(my_output_path), my_gen_file_name);

            // Open output file.
            var writer = Program.CreateStreamWriter(genFileNamePath, true, Encoding.ASCII);

            writer.WriteLine("#ifndef RBP_PAR_STRUCT{0}_GEN_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("#define RBP_PAR_STRUCT{0}_GEN_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("");

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("extern \"C\"");
            writer.WriteLine("{");
            writer.WriteLine("#endif // __cplusplus");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Magic number                                                           -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#define RBP_PAR_STRUCT_MAGIC_NUMBER_GEN  0x{0:d2}{1:d2}{2:d2}{3:d2}", my_dt.Month, my_dt.Day, my_dt.Hour, my_dt.Minute);
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Component Switches                                                     -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Include files                                                          -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("#ifdef RBP_COMPONENT_PAR");
            writer.WriteLine("#endif // RBP_COMPONENT_PAR");
            writer.WriteLine("");

            writer.WriteLine("#if (RBP_GS_COMPILER == RBP_GS_COMPILER_VC)");
            writer.WriteLine("// remove warnings related to const members in rbp_Tag_par_ROMMetaData_st when compiling with Visual C++");
            writer.WriteLine("#pragma warning(push)");
            writer.WriteLine("#pragma warning(disable : 4510 4512 4610)");
            writer.WriteLine("#endif");
            writer.WriteLine("");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- exported symbolic constants                                            -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("/* PRQA S 0779 RBP_RULE_DEV_rbp_par_struct_gen_h_1 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA S 2217 RBP_RULE_DEV_rbp_par_struct_gen_h_2 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA S 3116 RBP_RULE_DEV_rbp_par_struct_gen_h_3 */ /*(details: see end of file)*/");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- exported data types                                                    -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#ifdef RBP_COMPONENT_PAR");
            writer.WriteLine("#endif // RBP_COMPONENT_PAR");
            writer.WriteLine("");

            //! Info data structure.
            {
                writer.WriteLine("//");
                writer.WriteLine("// info structure");
                writer.WriteLine("//");
                pragma_option_start(my_gc, writer);

                writer.WriteLine("");
                writer.WriteLine("typedef struct rbp_Tag_par_InfoData_st");
                writer.WriteLine("{");
                writer.WriteLine("  // ID-String to find the start of the CAL-section");
                writer.WriteLine("  UInt8 Header_pu8[16];");
                writer.WriteLine("");
                writer.WriteLine("  // version (hex code decimal)");
                writer.WriteLine("  UInt8 Version_pu8[64];");
                writer.WriteLine("");
                writer.WriteLine("  // structure integrity hash - 160 bit SHA1 hash");
                writer.WriteLine("  UInt8 StructureIntegrityHash_pu8[20];");
                writer.WriteLine("");
                writer.WriteLine("  // Cal range resolution hash - 160 bit SHA1 hash");
                writer.WriteLine("  UInt8 CalRangeResHash_pu8[20];");
                writer.WriteLine("");
                writer.WriteLine("  // date (hex code decimal)");
                writer.WriteLine("  UInt16 Year_u16;");
                writer.WriteLine("  UInt8 Month_u8;");
                writer.WriteLine("  UInt8 Day_u8;");
                writer.WriteLine("");
                writer.WriteLine("  // time (hex code decimal)");
                writer.WriteLine("  UInt8 Hours_u8;");
                writer.WriteLine("  UInt8 Minutes_u8;");
                writer.WriteLine("");
                writer.WriteLine("  UInt8 reserved_pu8[2];  // fill-up to reach 128 bytes");
                writer.WriteLine("}");
                writer.WriteLine("rbp_Type_par_InfoData_st;");
                writer.WriteLine("");

                pragma_option_end(my_gc, writer);
                writer.WriteLine("");
            } //! @end: Info data structure.

            if (my_gc.RB_Secure_Flash == "true")
            {
                // Security Structure declarations.
                Security.Print_Header_Security_Blocks(ref writer);
            }

            //! RAM default copy table.
            {
                writer.WriteLine("");
                writer.WriteLine("//");
                writer.WriteLine("// RAM default copy table");
                writer.WriteLine("//");
                writer.WriteLine("");
                writer.WriteLine("#if (( RBP_GS_PAR_CFG_INIT_NVM_MIRROR_MEM == RBP_SW_ON ) || ( RBP_GS_PAR_CFG_INIT_RAM_MIRROR_MEM == RBP_SW_ON ))");
                writer.WriteLine("  typedef struct  rbp_Tag_par_DefaultCopyData_st");
                writer.WriteLine("  {");
                writer.WriteLine("    void * Source_pvd;");
                writer.WriteLine("    void * Target_pvd;");
                writer.WriteLine("    UInt32 Size_six;");
                writer.WriteLine("    UInt8 SubVarOffset_pu8[rbp_Num_Major_Variants_du8];");
                writer.WriteLine("    UInt8 NumSubVars_pu8[rbp_Num_Major_Variants_du8];");
                writer.WriteLine("    Boolean Ram_Init_flag_b;");
                writer.WriteLine("  }");
                writer.WriteLine("  rbp_Type_par_DefaultCopyData_st;");
                writer.WriteLine("#endif //(( RBP_GS_PAR_CFG_INIT_NVM_MIRROR_MEM == RBP_SW_ON ) || ( RBP_GS_PAR_CFG_INIT_RAM_MIRROR_MEM == RBP_SW_ON ))");
                writer.WriteLine("");
            } //! @end: RAM default copy table.

            //! Parameter cluster.
            {
                writer.WriteLine("//");
                writer.WriteLine("// parameter cluster");
                writer.WriteLine("//");
                writer.WriteLine("");

                pragma_option_start(my_gc, writer);

                {
                    foreach (cComponent component in my_ps.Components)
                    {
                        writer.WriteLine("/*--------------------------------------------------------------------------*/");
                        writer.WriteLine("/*- {0}{1} -*/",
                                          component.Name.ToUpper(), new String(' ', 70 - component.Name.Length));
                        writer.WriteLine("/*--------------------------------------------------------------------------*/");
                        writer.WriteLine("");

                        writer.WriteLine("/*!\\defgroup {0}_M04           exported data types", component.Name.ToUpper());
                        writer.WriteLine(" * \\ingroup RBP_COMPONENT_{0}", component.Name.ToUpper());
                        writer.WriteLine(" @{ */");
                        writer.WriteLine("");

                        foreach (cParameterCluster cluster in component.ParameterClusters)
                        {
                            if (cluster.MemoryArea != "NVM")
                            {
                                writer.WriteLine("//! parameter cluster {0}: {1}", cluster.Name, cluster.Description);
                                writer.WriteLine("typedef struct  rbp_Tag_par_{0}_st", cluster.Name);
                                writer.WriteLine("{");

                                foreach (cParameterDefinition para_def in cluster.ParameterDefinitions)
                                {
                                    // Check whether PAR XML is of version "1.0" or "2.x".
                                    if (my_ps.ParameterSetInfo.Version != "1.0")
                                    {
                                        writer.Write("  {0} {1}_",wrapper_2_x.Get_para_def_Type( my_ps, para_def),para_def.Name);
                                    }
                                    else
                                    {
                                        writer.Write("  {0} {1}_",para_def.Type,para_def.Name);
                                    }

                                    // Check for arrays.
                                    if ((para_def.Type != "Bitfield8") && (para_def.Type != "Bitfield16") && (para_def.Type != "Bitfield32"))
                                    {
                                        if (Convert.ToInt32(para_def.Number) > 1)
                                        {
                                            writer.Write("p");
                                        }
                                    }

                                    if (wrapper_2_x.Is_para_def_enum_b(my_ps,para_def) != true)
                                    {
                                        // Parameter is of type Basic data types.
                                        if (para_def.Type == "UInt8") { writer.Write("u8"); }
                                        else if (para_def.Type == "UInt16") { writer.Write("u16"); }
                                        else if (para_def.Type == "UInt32") { writer.Write("u32"); }
                                        else if (para_def.Type == "SInt8") { writer.Write("s8"); }
                                        else if (para_def.Type == "SInt16") { writer.Write("s16"); }
                                        else if (para_def.Type == "SInt32") { writer.Write("s32"); }
                                        else if (para_def.Type == "Boolean") { writer.Write("b"); }
                                        else if (para_def.Type == "Bitfield8") { writer.Write("bf{0}",para_def.Number); }
                                        else if (para_def.Type == "Bitfield16") { writer.Write("bf{0}",para_def.Number); }
                                        else if (para_def.Type == "Bitfield32") { writer.Write("bf{0}",para_def.Number); }
                                        else if (para_def.Type == "Float32") { writer.Write("f32"); }
                                        else { writer.Write("unknown"); }
                                    }
                                    // Require for PAR XML 2.0 and 2.1 version.
                                    else 
                                    { 
                                        // Parameter is of type enumeration.
                                        writer.Write("en"); 
                                     }

                                    // Check for arrays.
                                    if ((para_def.Type != "Bitfield8") && (para_def.Type != "Bitfield16") && (para_def.Type != "Bitfield32"))
                                    {
                                        if (Convert.ToInt32(para_def.Number) > 1)
                                        {
                                            writer.Write("[{0}]", para_def.Number);
                                        }
                                    }

                                    // Bitfields.
                                    if ((para_def.Type == "Bitfield8") || (para_def.Type == "Bitfield16") || (para_def.Type == "Bitfield32"))
                                    {
                                        writer.Write(" : {0}", para_def.Number);
                                    }


                                    writer.WriteLine("; // {0}", para_def.Description);
                                }

                                writer.WriteLine("}");
                                writer.WriteLine("rbp_Type_par_{0}_st; //!< copydoc rbp_Type_par_{0}_st", cluster.Name);

                                writer.WriteLine("");
                                writer.WriteLine("");
                            }
                        }

                        writer.WriteLine("/*!@} */");
                        writer.WriteLine("");
                        writer.WriteLine("");
                    }
                }

                pragma_option_end(my_gc, writer);
                writer.WriteLine("");
                writer.WriteLine("");
            } //! @end: Parameter cluster.

            //! CAL Header low.
            {
                writer.WriteLine("//");
                writer.WriteLine("// CAL Header Low");
                writer.WriteLine("//");
                writer.WriteLine("");

                // GM only.
                if (my_gc.ST_CHORUS_CALSection_Mode == "GM")
                {
                    // PrintGenHeader extension method for GM.
                    GMHelperClass.printGenHeaderGM_1(ref writer);
                }
                writer.WriteLine("");
            } //! @end: CAL Header low.

            //! Parameter memory ROM.
            {
                writer.WriteLine("/* PRQA S 1039 RBP_RULE_DEV_rbp_par_struct_gen_h_4 */ /*(details: see end of file)*/");
                writer.WriteLine("//");
                writer.WriteLine("// parameter memory ROM");
                writer.WriteLine("//");
                writer.WriteLine("");

                pragma_option_start(my_gc, writer);

                writer.WriteLine("");
                writer.WriteLine("typedef struct  rbp_Tag_par_ParameterMemoryROM_st");
                writer.WriteLine("{");

                {
                    foreach (cComponent component in my_ps.Components)
                    {
                        foreach (cParameterCluster cluster in component.ParameterClusters)
                        {
                            if ((cluster.MemoryArea == "ROM") || (cluster.MemoryArea == "NVM_INIT") || (cluster.MemoryArea == "RAM_INIT"))
                            {
                                int count_sub_var = 0;

                                foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                                {
                                    foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                    {
                                        count_sub_var += min_var.SubVariants.Count;
                                    }
                                }

                                writer.WriteLine("  rbp_Type_par_{0}_st {0}_pst[{1}];", cluster.Name, count_sub_var);
                            }
                            else if ((cluster.MemoryArea == "NVM") || (cluster.MemoryArea == "RAM"))
                            {
                                // Do nothing.
                            }
                            else
                            {
                                // Do nothing.
                            }
                        }
                    }
                }

                writer.WriteLine("}");
                writer.WriteLine("rbp_Type_par_ParameterMemoryROM_st;");
                writer.WriteLine("");

                pragma_option_end(my_gc, writer);
                writer.WriteLine("");
                writer.WriteLine("");
            } //! @end: Parameter memory ROM.


            Boolean RAMCOPYNeeded = false;

            // Flag to check NVM_INIT Clusters are available.
            Boolean NVM_RAM_Mirror_Copy_b = false;

            // Flag to check RAM_INIT Clusters are available
            Boolean RAM_INIT_Mirror_Copy_b = false;

            foreach (cComponent component in my_ps.Components)
            {
                foreach (cParameterCluster cluster in component.ParameterClusters)
                {
                    if ((cluster.MemoryArea == "NVM_INIT") || (cluster.MemoryArea == "RAM_INIT"))
                    {
                        RAMCOPYNeeded = true;
                    }
                }
            }

            //! Parameter memory RAM.
            {
                if (my_gc.Code_ExternalNVMRAMBuffer == "false")
                {
                    writer.WriteLine("//");
                    writer.WriteLine("// parameter memory RAM");
                    writer.WriteLine("//");
                    writer.WriteLine("");

                    if (RAMCOPYNeeded == true)
                    {
                        {
                            writer.WriteLine("// Structure for NVM_INIT Clusters");
                            writer.WriteLine("typedef struct  rbp_Tag_par_ParameterMemoryNVM_RAM_Mirror_st");
                            writer.WriteLine("{");

                            int num_lines = 0;

                            foreach (cComponent component in my_ps.Components)
                            {
                                foreach (cParameterCluster cluster in component.ParameterClusters)
                                {
                                    int max_count_sub_var = 0;

                                    foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                                    {
                                        int count_sub_var = 0;

                                        foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                        {
                                            count_sub_var += min_var.SubVariants.Count;
                                        }

                                        if (count_sub_var > max_count_sub_var)
                                        {
                                            max_count_sub_var = count_sub_var;
                                        }
                                    }

                                    if ((cluster.MemoryArea == "NVM_INIT"))
                                    {
                                        writer.WriteLine("  rbp_Type_par_{0}_st {0}_pst[{1}];", cluster.Name, max_count_sub_var);

                                        num_lines++;
                                        NVM_RAM_Mirror_Copy_b = true;
                                    }
                                    else
                                    {
                                        // Memory area is not NVM_INIT, do nothing.
                                    }
                                }
                            }

                            if (num_lines == 0)
                            {
                                writer.WriteLine("  UInt32 Dummy_u32;");
                            }
                        }

                        writer.WriteLine("}");
                        writer.WriteLine("rbp_Type_par_ParameterMemoryNVM_RAM_Mirror_st;");
                        writer.WriteLine("");
                        writer.WriteLine("");

                        {
                            writer.WriteLine("// Structure for RAM_INIT Clusters");
                            writer.WriteLine("typedef struct  rbp_Tag_par_ParameterMemoryRAM_INIT_Mirror_st");
                            writer.WriteLine("{");

                            int num_lines = 0;

                            foreach (cComponent component in my_ps.Components)
                            {
                                foreach (cParameterCluster cluster in component.ParameterClusters)
                                {
                                    int max_count_sub_var = 0;

                                    foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                                    {
                                        int count_sub_var = 0;

                                        foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                        {
                                            count_sub_var += min_var.SubVariants.Count;
                                        }

                                        if (count_sub_var > max_count_sub_var)
                                        {
                                            max_count_sub_var = count_sub_var;
                                        }
                                    }

                                    if ((cluster.MemoryArea == "RAM_INIT"))
                                    {
                                        writer.WriteLine("  rbp_Type_par_{0}_st {0}_pst[{1}];", cluster.Name, max_count_sub_var);

                                        num_lines++;
                                        RAM_INIT_Mirror_Copy_b = true;
                                    }
                                    else
                                    {
                                        // Memory area is not RAM_INIT, hence RAM_INIT mirror copy not required, do nothing.
                                    }
                                }
                            }

                            if (num_lines == 0)
                            {
                                writer.WriteLine("  UInt32 Dummy_u32;");
                            }
                        }

                        writer.WriteLine("}");
                        writer.WriteLine("rbp_Type_par_ParameterMemoryRAM_INIT_Mirror_st;");
                        writer.WriteLine("");
                        writer.WriteLine("");
                    }
                }
            } //! @end: Parameter memory RAM.

            //! Major variant meta data structure.
            {
                writer.WriteLine("//");
                writer.WriteLine("// major variant meta data");
                writer.WriteLine("//");
                writer.WriteLine("");
                writer.WriteLine("typedef struct  rbp_Tag_par_MajorVarMetaData_st");
                writer.WriteLine("{");
                writer.WriteLine("  // index to minor variant meta data");
                writer.WriteLine("  UInt16 MinorVarMetaDataIdx_u16[rbp_Num_Major_Variants_du8];");
                writer.WriteLine("}");
                writer.WriteLine("rbp_Type_par_MajorVarMetaData_st;");
                writer.WriteLine("");
            } //! Major variant meta data structure.

            //! Minor vaiant meta data structure.
            {
                writer.WriteLine("");
                writer.WriteLine("//");
                writer.WriteLine("// minor variant meta data");
                writer.WriteLine("//");
                writer.WriteLine("");
                writer.WriteLine("typedef struct  rbp_Tag_par_MinorVarMetaData_st");
                writer.WriteLine("{");
                writer.WriteLine("  // number of variants");
                writer.WriteLine("  UInt8 NumVariants_u8;");
                writer.WriteLine("");
                writer.WriteLine("  // index of sub variant meta data");
                writer.WriteLine("  UInt16 SubVarMetaDataIdx_u16;");
                writer.WriteLine("}");
                writer.WriteLine("rbp_Type_par_MinorVarMetaData_st;");
                writer.WriteLine("");
                writer.WriteLine("");
            } //! @end: Minor vaiant meta data structure.

            //! Sub variant meta data structure.
            {
                writer.WriteLine("//");
                writer.WriteLine("// sub variant meta data");
                writer.WriteLine("//");
                writer.WriteLine("");
                writer.WriteLine("typedef struct  rbp_Tag_par_SubVarMetaData_st");
                writer.WriteLine("{");
                writer.WriteLine("  // number of variants");
                writer.WriteLine("  UInt8 NumVariants_u8;");
                writer.WriteLine("");
                writer.WriteLine("  // sub variant data offset");
                writer.WriteLine("  UInt16 DataOffset_u16;");
                writer.WriteLine("}");
                writer.WriteLine("rbp_Type_par_SubVarMetaData_st;");
                writer.WriteLine("");
                writer.WriteLine("");
            } //! @end: Sub variant meta data structure.

            //! Application memory structure.
            {
                writer.WriteLine("//");
                writer.WriteLine("// application memory");
                writer.WriteLine("//");
                writer.WriteLine("");
                writer.WriteLine("#if ( RBP_GS_PAR_CFG_APPLICATION_MODE == RBP_SW_ON )");
                writer.WriteLine("");
                writer.WriteLine("typedef struct  rbp_Tag_par{0}_ApplicationMemory_st", my_DatasetName);
                writer.WriteLine("{");

                int rom_clusters_count = 0;

                {
                    foreach (cComponent component in my_ps.Components)
                    {
                        foreach (cParameterCluster cluster in component.ParameterClusters)
                        {
                            // NVM ,NVM_INIT and RAM_INIT Clusters are not part of Application memory, because NVM_INIT cluster has RAM Copy so that is considered.
                            if ((cluster.MemoryArea != "NVM") && (cluster.MemoryArea != "NVM_INIT") && (cluster.MemoryArea != "RAM_INIT"))
                            {
                                //count the number of clusters assigned to ROM
                                rom_clusters_count++;

                                if (cluster.VariantApplication.ToUpper() == "SINGLE")
                                {
                                    // Assuming Number of Minor variant is identical for all the variant implementations.
                                    writer.WriteLine("  rbp_Type_par_{0}_st {0}_pst[{1}];",cluster.Name,cluster.VariantsImlementations[0].MinorVariants.Count);
                                }
                                else
                                {
                                    if (cluster.VariantApplication.ToUpper() == "MINOR_ALL")
                                    {
                                        int max_num_sub_vars = 0;

                                        // Find the minor variant with the maximum number of subvariants in the current cluster.
                                        foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                                        {
                                            int num_sub_vars = 0;

                                            foreach (cMinorVariant min_var in var_imp.MinorVariants)
                                            {
                                                num_sub_vars += min_var.SubVariants.Count;
                                            }

                                            if (num_sub_vars > max_num_sub_vars)
                                            {
                                                max_num_sub_vars = num_sub_vars;
                                            }
                                        }

                                        writer.WriteLine("  rbp_Type_par_{0}_st {0}_pst[{1}];",cluster.Name,max_num_sub_vars);
                                    }
                                    else
                                    {
                                        writer.WriteLine("  #error wrong sub-variant application mode");
                                    }
                                }
                            }
                        }
                    }
                }

                if (rom_clusters_count == 0)
                {
                    writer.WriteLine("  UInt32 Dummy_u32;");
                }

                writer.WriteLine("}");
                writer.WriteLine("rbp_Type_par{0}_ApplicationMemory_st;", my_DatasetName);
                writer.WriteLine("");
                writer.WriteLine("#endif// (RBP_GS_PAR_CFG_APPLICATION_MODE == RBP_SW_ON)");
                writer.WriteLine("");
                writer.WriteLine("");
            } //! @end: Application memory structure.

            //! Global data ROM.
            {
                writer.WriteLine("//");
                writer.WriteLine("// global data ROM");
                writer.WriteLine("//");
                writer.WriteLine("");
                writer.WriteLine("typedef struct  rbp_Tag_par{0}_ROMData_st", my_DatasetName);
                writer.WriteLine("{");
                writer.WriteLine("  // version information");
                writer.WriteLine("  rbp_Type_par_InfoData_st InfoData_st;");
                writer.WriteLine("");
                writer.WriteLine("  rbp_Type_par_ParameterMemoryROM_st ParameterMemoryROM_st;");
                writer.WriteLine("  UInt8       StructureIntegrityHashEnd_pu8[20];");
                writer.WriteLine("}");
                writer.WriteLine("rbp_Type_par{0}_ROMData_st;", my_DatasetName);
                writer.WriteLine("");
                writer.WriteLine("");
            } //! @end: Global data ROM.

            //! Global meta data ROM.
            {
                writer.WriteLine("//");
                writer.WriteLine("// global meta data ROM");
                writer.WriteLine("//");
                writer.WriteLine("");
                writer.WriteLine("typedef struct  rbp_Tag_par_ROMMetaData_st");
                writer.WriteLine("{");
                writer.WriteLine("  void const * IndData_ppvd[rbp_Num_Clusters_du16];");
                writer.WriteLine("");

                {
                    int num_elements = 1;

                    foreach (cComponent component in my_ps.Components)
                    {
                        foreach (cParameterCluster cluster in component.ParameterClusters)
                        {
                            if ((cluster.MemoryArea == "NVM_INIT") || (cluster.MemoryArea == "RAM_INIT"))
                            {
                                num_elements++;
                            }
                            else
                            {
                                // Memory area is ROM or NVM, do nothing.
                            }
                        }
                    }

                    writer.WriteLine("  #if (( RBP_GS_PAR_CFG_INIT_NVM_MIRROR_MEM == RBP_SW_ON ) || ( RBP_GS_PAR_CFG_INIT_RAM_MIRROR_MEM == RBP_SW_ON ))");
                    writer.WriteLine("    rbp_Type_par_DefaultCopyData_st DefaultCopyData_pst[{0}];", num_elements);
                    writer.WriteLine("  #endif // ((RBP_GS_PAR_CFG_INIT_NVM_MIRROR_MEM == RBP_SW_ON ) || ( RBP_GS_PAR_CFG_INIT_RAM_MIRROR_MEM == RBP_SW_ON ))");
                    writer.WriteLine("");
                }


                writer.WriteLine("  #if ( RBP_GS_PAR_CFG_APPLICATION_MODE == RBP_SW_ON )");
                writer.WriteLine("    void * const ApplMemClusterPointer_ppvd[rbp_Num_Clusters_du16];");
                writer.WriteLine("  #endif // (RBP_GS_PAR_CFG_APPLICATION_MODE == RBP_SW_ON )");
                writer.WriteLine("");
                writer.WriteLine("  UInt16 const ClusterSize_pu16[rbp_Num_Clusters_du16];");
                writer.WriteLine("");
                writer.WriteLine("  #if ( RBP_GS_PAR_CFG_APPLICATION_MODE == RBP_SW_ON )");
                writer.WriteLine("    UInt8 const ApplSubVariantMode_pu8[rbp_Num_Clusters_du16];");
                writer.WriteLine("  #endif // (RBP_GS_PAR_CFG_APPLICATION_MODE == RBP_SW_ON )");
                writer.WriteLine("");
                writer.WriteLine("  #if ( RBP_GS_PAR_CFG_APPLICATION_MODE == RBP_SW_ON )");
                writer.WriteLine("    UInt8 const MaxApplSubVariants_pu8[rbp_Num_Clusters_du16];");
                writer.WriteLine("  #endif // (RBP_GS_PAR_CFG_APPLICATION_MODE == RBP_SW_ON )");
                writer.WriteLine("");
                writer.WriteLine("  rbp_Type_par_MajorVarMetaData_st MajorVarMetaData_pst[rbp_Num_Clusters_du16];");
                writer.WriteLine("  rbp_Type_par_MinorVarMetaData_st MinorVarMetaData_pst[rbp_Num_Minor_Var_Meta_Data_du16];");
                writer.WriteLine("  rbp_Type_par_SubVarMetaData_st   SubVarMetaData_pst[rbp_Num_Sub_Var_Meta_Data_du16];");
                writer.WriteLine("}");
                writer.WriteLine("rbp_Type_par_ROMMetaData_st;");
                writer.WriteLine("");
                writer.WriteLine("");
            } //! @end: Global meta data ROM.

            //! Global data RAM structure.
            {
                writer.WriteLine("//");
                writer.WriteLine("// global data RAM");
                writer.WriteLine("//");
                writer.WriteLine("");

                // For NVM_INIT Clusters (RAM Copy).
                writer.WriteLine("//For NVM_INIT Clusters (RAM Copy)");
                writer.WriteLine("typedef struct  rbp_Tag_par_NVM_MirrorData_st");
                writer.WriteLine("{");

                if (my_gc.Code_ExternalNVMRAMBuffer == "false")
                {
                    if ((RAMCOPYNeeded == true) && (NVM_RAM_Mirror_Copy_b == true))
                    {
                        // NVM_INIT Clusters are available.
                        writer.WriteLine("  rbp_Type_par_ParameterMemoryNVM_RAM_Mirror_st ParameterMemoryNVM_RAM_Mirror_st;");
                    }
                    else
                    {
                        // No NVM_INIT Clusters, so define a dummy member.
                        writer.WriteLine("  UInt32 Dummy_u32;");
                    }
                }
                else
                {
                    // Use External NVM Ram Buffer.
                    writer.WriteLine("  UInt32 Dummy_u32;");
                }
                writer.WriteLine("}");
                writer.WriteLine("rbp_Type_par_NVM_MirrorData_st;");
                writer.WriteLine("");

                // For RAM_INIT Clusters (RAM Copy).
                writer.WriteLine("//For RAM_INIT Clusters (RAM Copy)");
                writer.WriteLine("typedef struct  rbp_Tag_par_RAM_INIT_MirrorData_st");
                writer.WriteLine("{");

                if (my_gc.Code_ExternalNVMRAMBuffer == "false")
                {
                    if ((RAMCOPYNeeded == true) && (RAM_INIT_Mirror_Copy_b == true))
                    {
                        // RAM_INIT Clusters are available.
                        writer.WriteLine("  rbp_Type_par_ParameterMemoryRAM_INIT_Mirror_st ParameterMemoryRAM_INIT_Mirror_st;");
                    }
                    else
                    {
                        // No RAM_INIT Clusters, so define a dummy member.
                        writer.WriteLine("  UInt32 Dummy_u32;");
                    }
                }
                else
                {
                    // Use External NVM Ram Buffer.
                    writer.WriteLine("  UInt32 Dummy_u32;");
                }
                writer.WriteLine("}");
                writer.WriteLine("rbp_Type_par_RAM_INIT_MirrorData_st;");
                writer.WriteLine("");

                writer.WriteLine("typedef struct  rbp_Tag_par_RAMData_st");
                writer.WriteLine("{");

                writer.WriteLine("  void * ClusterPointer_ppvd[rbp_Num_Clusters_du16];");
                writer.WriteLine("");
                writer.WriteLine("  // [x][0] -> minor variant / [x][1] -> sub variant");
                writer.WriteLine("  #if ( RBP_GS_PAR_CFG_APPLICATION_MODE == RBP_SW_ON )");
                writer.WriteLine("    UInt8 VariantMemory_ppu8[rbp_Num_Clusters_du16][2];");
                writer.WriteLine("  #endif");
                writer.WriteLine("}");
                writer.WriteLine("rbp_Type_par_RAMData_st;");
                writer.WriteLine("");
            } //! @end: Global data RAM structure.

            // QAC
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_struct_gen_h_1 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_struct_gen_h_2 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_struct_gen_h_3 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_struct_gen_h_4 */ /*(details: see end of file)*/");
            writer.WriteLine("");
            writer.WriteLine("/*****************************************************************************/");
            writer.WriteLine("/* START OF EXPLANATION FOR RBP_RULE_DEVIATIONS: */");
            writer.WriteLine("/*===============================*/");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_struct_gen_h_1 */");
            writer.WriteLine("/* Deviation to GPG rule number: 1.3, 5.2*/");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Identifier name differ with minor changes. This is intended in ASW/BSW identifiers.");
            writer.WriteLine("   File is auto generated and therefore has too long Object-Macro names & structure element names.");
            writer.WriteLine("   This exception suppresses those warnings */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Review has been done. Pargen tool doesn't generate duplicate identifiers.");
            writer.WriteLine("   Parameter names are autogenerated and require information of its content,");
            writer.WriteLine("   this assures better quality even if the names get longer.");
            writer.WriteLine("   GHS compiler allows longer #defines (U)= theoretically unlimited  */");
            writer.WriteLine("");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_struct_gen_h_2 */");
            writer.WriteLine("/* Deviation to GPG rule number: 2217*/");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Comments exceeds more than 130 characters.*/");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Since it is comments not gonna effect safety */");
            writer.WriteLine("");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_struct_gen_h_3 */");
            writer.WriteLine("/* Deviation to GPG rule number: 1.1*/");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   #pragma ghs struct_min_alignment() is not recognised by QAC */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   It is recognised by GHS compiler and used only during compilation */");
            writer.WriteLine("");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_struct_gen_h_4 */");
            writer.WriteLine("/* Deviation to GPG rule number: 1039*/");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   More than one minor/sub variant is possible but may not be the case always. Hence array type is used  */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Necessary tests on hardware is done to ensure the expected behavior. */");
            writer.WriteLine("");
            writer.WriteLine("/* END OF EXPLANATION FOR RBP_RULE DEVIATIONS */");
            writer.WriteLine("/*****************************************************************************/");

            writer.WriteLine("#if (RBP_GS_COMPILER == RBP_GS_COMPILER_VC)");
            writer.WriteLine("  // remove warnings related to const members in rbp_Tag_par_ROMMetaData_st when compiling with Visual C++");
            writer.WriteLine("  #pragma warning(pop)");
            writer.WriteLine("#endif");
            writer.WriteLine("");

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("}");
            writer.WriteLine("#endif // __cplusplus");
            writer.WriteLine("#endif /* RBP_PAR_STRUCT{0}_GEN_H */", my_FileName_Suffix.ToUpper());

            // Close output file.
            writer.Close();
        }

        /// <summary>
        /// Generates inline functions for every cluster to access parameter cluster.
        /// </summary>
        /// <param name="my_ps">Reference to Parameter set.</param>
        /// <param name="my_ps_file_name">Reference to Input file name.</param>
        /// <param name="my_output_path">Output path for the generated file.</param>
        /// <param name="my_FileName_Suffix">Suffix to be appended in file name to distinguish files containing different datasets.</param>
        /// <param name="my_dt">Reference for date and time.</param>
        /// <param name="my_gc">Reference for general configuration.</param>
        public void PrintGenParDefineReadAccess( ref cParameterSet my_ps, 
                                              ref String my_ps_file_name,
                                              String my_output_path,
                                              string my_FileName_Suffix,
                                              ref DateTime my_dt,
                                              ref cGeneralConfiguration my_gc)
        {
            // Initialize the necessary variables.
            Program my_program = new Program();
            string my_gen_file_name = "rbp_par_read_access" + my_FileName_Suffix + "_gen.h";
            string my_source_file_name = "Gen_Header.cs";

            // Overwrite the output path if already exists.
            my_program.OverwriteOPPath(ref my_gc, ref my_output_path, my_gen_file_name);

            // Generated file header.
            my_program.PrintFileInfo(ref my_ps, ref my_ps_file_name, my_output_path, ref my_dt, my_gen_file_name, my_source_file_name);

            // Obtain absolute path of output file.
            var genFileNamePath = Path.Combine(Path.GetFullPath(my_output_path), my_gen_file_name);

            // Open output file.
            var writer = Program.CreateStreamWriter(genFileNamePath, true, Encoding.ASCII);

            writer.WriteLine("#ifndef RBP_PAR_READ_ACCESS{0}_GEN_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("#define RBP_PAR_READ_ACCESS{0}_GEN_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("");

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("extern \"C\"");
            writer.WriteLine("{");
            writer.WriteLine("#endif // __cplusplus");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Magic number                                                           -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#define RBP_PAR_READ_ACCESS_MAGIC_NUMBER_GEN  0x{0:d2}{1:d2}{2:d2}{3:d2}", my_dt.Month, my_dt.Day, my_dt.Hour, my_dt.Minute);
            writer.WriteLine("");

            writer.WriteLine("/* PRQA S 2217 RBP_RULE_DEV_rbp_par_read_access_gen_1 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA S 3219 RBP_RULE_DEV_rbp_par_read_access_gen_2 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA S 3450 RBP_RULE_DEV_rbp_par_read_access_gen_3 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA S 3480 RBP_RULE_DEV_rbp_par_read_access_gen_4 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA S 316  RBP_RULE_DEV_rbp_par_read_access_gen_5 */ /*(details: see end of file)*/");
            writer.WriteLine("");

            writer.WriteLine("/* Below functions, returns const pointer of the requested cluster (i.e. only read access).");
            writer.WriteLine(" * Provides QAC fix for warning 316 where ever the interface \"rbp_par_getParaReadAccess_pst(cln)\" is used within components");
            writer.WriteLine(" * QAC WARNING : Level 5 -> (0316)  Cast from a pointer to void to a pointer to object type. MISRA C:2012 Rule-11.5 ");
            writer.WriteLine(" */");

            writer.WriteLine("");
            foreach (cComponent component in my_ps.Components)
            {
                writer.WriteLine("//---------------------------------------------------------------------------------------------------------------------------");
                writer.WriteLine("//  Component name : {0}", component.Name);
                writer.WriteLine("//---------------------------------------------------------------------------------------------------------------------------");
                foreach( cParameterCluster cluster in component.ParameterClusters)
                {
                    if (cluster.MemoryArea != "NVM")
                    {
                        writer.WriteLine("//  Cluster name : {0}", cluster.Name);
                        writer.WriteLine("static RBP_INLINE rbp_Type_par_{0}_st const* rbp_par_getParaReadAccess_{0}_cpst (UInt16 f_cl_idx_u16)", cluster.Name);
                        writer.WriteLine("{");
                        writer.WriteLine("  return ((rbp_Type_par_{0}_st const *) (rbp_par_RAMData_st.ClusterPointer_ppvd[f_cl_idx_u16]));", cluster.Name);
                        writer.WriteLine("}");
                        writer.WriteLine("");
                    }
                }
            }

            writer.WriteLine("//-------------------------- End of Inline functions ------------------------------------------------");
            writer.WriteLine("");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_read_access_gen_1 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_read_access_gen_2 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_read_access_gen_3 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_read_access_gen_4 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_read_access_gen_5 */ /*(details: see end of file)*/");
            writer.WriteLine("/*****************************************************************************/");
            writer.WriteLine("/* START OF EXPLANATION FOR RBP_RULE_DEVIATIONS: */");
            writer.WriteLine("");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_read_access_gen_1 */");
            writer.WriteLine("/* Deviation to GPG rule number: 2217*/");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Because the function header is required to be defined in one line for easy understanding */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Having functions with header length more than 130 characters will not affect safety. It is just a name.*/");
            writer.WriteLine("");

            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_read_access_gen_2 */");
            writer.WriteLine("/* Deviation to GPG rule number: 2.1*/");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   static inline functions must be visible to all the translational unit which uses the interface");
            writer.WriteLine("   \"rbp_par_getParaReadAccess_pst(cln)\" so that the compiler can find the defintion  */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   No compilation error even if RBP_INLINE keyword is removed, becasue function is made static which");
            writer.WriteLine("   will be available within the translational unit. */");
            writer.WriteLine("");

            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_read_access_gen_3 */");
            writer.WriteLine("/* Deviation to GPG rule number: 3450 */");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Function declaration is not required as function defintion is always visible before its been called.");
            writer.WriteLine("   Declaring the functions will result in unnecessary increase in file size. */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Function is defined before its been called within the translation unit */");
            writer.WriteLine("");

            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_read_access_gen_4 */");
            writer.WriteLine("/* Deviation to GPG rule number: 3480 */");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Function is defined within header file as static inline so that its visible to ");
            writer.WriteLine("   all the translation unit which uses the interface \"rbp_par_getParaReadAccess_pst(cln)  */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   No compilation error will be thrown for the function, as it is static and is visible only within");
            writer.WriteLine("   that translation unit */");
            writer.WriteLine("");

            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_read_access_gen_5 */");
            writer.WriteLine("/* Deviation to GPG rule number: 11.5 */");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Casting to a structure type is neccessary for proper de-refernce of the member. */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Necessary testing on hardware is performed to verify the behaviour of the casting to different");
            writer.WriteLine("   structure pointers. */");
            writer.WriteLine("");

            writer.WriteLine("/* END OF EXPLANATION FOR RBP_RULE DEVIATIONS */");
            writer.WriteLine("/*****************************************************************************/");
            writer.WriteLine("");
            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("}");
            writer.WriteLine("#endif // __cplusplus");
            writer.WriteLine("");
            writer.WriteLine("#endif /* RBP_PAR_READ_ACCESS{0}_GEN_H */", my_FileName_Suffix.ToUpper());

            writer.Close();
        }

        /// <summary>
        /// Generates inline functions for every cluster to access parameter cluster based on minor and sub variant 
        /// </summary>
        /// <param name="my_ps">Reference to Parameter set.</param>
        /// <param name="my_ps_file_name">Reference to Input file name.</param>
        /// <param name="my_output_path">Output path for the generated file.</param>
        /// <param name="my_FileName_Suffix">Suffix to be appended in file name to distinguish files containing different datasets.</param>
        /// <param name="my_dt">Reference for date and time</param>
        /// <param name="my_gc">Reference for general configuration.</param>
        public void PrintGenParVariantAccess(ref cParameterSet my_ps, 
                                                 ref String my_ps_file_name,
                                                 String my_output_path,
                                                 string my_FileName_Suffix,
                                                 ref DateTime my_dt,
                                                 ref cGeneralConfiguration my_gc)
        {
            Program my_program = new Program();
            string my_gen_file_name = "rbp_par_variant_access" + my_FileName_Suffix + "_gen.h";
            string my_source_file_name = "Gen_Header.cs";

            // Overwrite the output path if already exists.
            my_program.OverwriteOPPath(ref my_gc, ref my_output_path, my_gen_file_name);

            // Generated file header.
            my_program.PrintFileInfo(ref my_ps, ref my_ps_file_name, my_output_path, ref my_dt, my_gen_file_name, my_source_file_name);

            // Obtain absolute path of output file.
            var genFileNamePath = Path.Combine(Path.GetFullPath(my_output_path), my_gen_file_name);

            // Open output file.
            var writer = Program.CreateStreamWriter(genFileNamePath, true, Encoding.ASCII);

            writer.WriteLine("#ifndef RBP_PAR_VARIANT_ACCESS{0}_GEN_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("#define RBP_PAR_VARIANT_ACCESS{0}_GEN_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("");

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("extern \"C\"");
            writer.WriteLine("{");
            writer.WriteLine("#endif // __cplusplus");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Magic number                                                           -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#define RBP_PAR_VARIANT_ACCESS_MAGIC_NUMBER_GEN  0x{0:d2}{1:d2}{2:d2}{3:d2}", my_dt.Month, my_dt.Day, my_dt.Hour, my_dt.Minute);
            writer.WriteLine("");

            writer.WriteLine("/* PRQA S 2217 RBP_RULE_DEV_rbp_par_variant_access_gen_1 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA S 3219 RBP_RULE_DEV_rbp_par_variant_access_gen_2 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA S 3450 RBP_RULE_DEV_rbp_par_variant_access_gen_3 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA S 3480 RBP_RULE_DEV_rbp_par_variant_access_gen_4 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA S 316  RBP_RULE_DEV_rbp_par_variant_access_gen_5 */ /*(details: see end of file)*/");
            writer.WriteLine("");

            writer.WriteLine("/* Below functions returns const pointer to the requested cluster (i.e. only read access).");
            writer.WriteLine(" * Provides QAC fix for warning 316 where ever the interface \"rbp_par_getParaVariantReadAccess_pst(cln, minv, subv)\" is used within components");
            writer.WriteLine(" * QAC WARNING : Level 5 -> (0316)  Cast from a pointer to void to a pointer to object type. MISRA C:2012 Rule-11.5 ");
            writer.WriteLine(" */");
            writer.WriteLine("");
            foreach (cComponent component in my_ps.Components)
            {
                writer.WriteLine("//---------------------------------------------------------------------------------------------------------------------------");
                writer.WriteLine("//  Component name : {0}", component.Name);
                writer.WriteLine("//---------------------------------------------------------------------------------------------------------------------------");
                foreach (cParameterCluster cluster in component.ParameterClusters)
                {
                    if (cluster.MemoryArea != "NVM")
                    {
                        writer.WriteLine("//  Cluster name : {0}", cluster.Name);
                        writer.WriteLine("static RBP_INLINE rbp_Type_par_{0}_st const* rbp_par_getParaVariantReadAccessCore_{0}_cpst (UInt16 f_cl_idx_u16, UInt8 f_miv_idx_u8,  UInt8 f_sub_idx_u8)", cluster.Name);
                        writer.WriteLine("{");
                        writer.WriteLine("  return ((rbp_Type_par_{0}_st const *) rbp_par_getParaVariantReadAccessCore_pvd(f_cl_idx_u16, f_miv_idx_u8, f_sub_idx_u8));", cluster.Name);
                        writer.WriteLine("}");
                        writer.WriteLine("");
                    }
                }
            }

            writer.WriteLine("//--------------------------------------- End of Inline Functions -----------------------------------------------");
            writer.WriteLine("");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_variant_access_gen_1 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_variant_access_gen_2 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_variant_access_gen_3 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_variant_access_gen_4 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_variant_access_gen_5 */ /*(details: see end of file)*/");
            writer.WriteLine("");
            writer.WriteLine("/*****************************************************************************/");
            writer.WriteLine("/* START OF EXPLANATION FOR RBP_RULE_DEVIATIONS: */");
            writer.WriteLine("");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_variant_access_gen_1 */");
            writer.WriteLine("/* Deviation to GPG rule number: 2217 */");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Because the function header is required to be defined in one line for easy understanding */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Having functions with header length more than 130 characters will not affect safety. It is just a name.*/");
            writer.WriteLine("");

            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_variant_access_gen_2 */");
            writer.WriteLine("/* Deviation to GPG rule number: 2.1 */");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   static inline functions must be visible to all the translational unit which uses the interface");
            writer.WriteLine("   \"rbp_par_getParaReadAccess_pst(cln)\" so that the compiler can find the defintion  */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   No compilation error even if RBP_INLINE keyword is removed, becasue function is made static which");
            writer.WriteLine("   will be available within the translational unit. */");
            writer.WriteLine("");

            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_variant_access_gen_3 */");
            writer.WriteLine("/* Deviation to GPG rule number: 3450 */");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Function declaration is not required as function defintion is always visible before its been called.");
            writer.WriteLine("   Declaring the functions will result in unnecessary increase in file size. */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Function is defined before its been called within the translation unit */");
            writer.WriteLine("");

            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_variant_access_gen_4 */");
            writer.WriteLine("/* Deviation to GPG rule number: 3480 */");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Function is defined within header file as static inline so that its visible to ");
            writer.WriteLine("   all the translation unit which uses the interface \"rbp_par_getParaReadAccess_pst(cln)  */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   No compilation error will be thrown for the function, as it is static and is visible only within");
            writer.WriteLine("   that translation unit */");
            writer.WriteLine("");

            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_variant_access_gen_5 */");
            writer.WriteLine("/* Deviation to GPG rule number: 11.5 */");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Casting to a structure type is neccessary for proper de-refernce of the member. */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Necessary testing on hardware is performed to verify the behaviour of the casting to different");
            writer.WriteLine("   structure pointers. */");
            writer.WriteLine("");

            writer.WriteLine("/* END OF EXPLANATION FOR RBP_RULE DEVIATIONS */");
            writer.WriteLine("/*****************************************************************************/");
            writer.WriteLine("");

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("}");
            writer.WriteLine("#endif // __cplusplus");
            writer.WriteLine("");
            writer.WriteLine("#endif /* RBP_PAR_VARIANT_ACCESS{0}_GEN_H */", my_FileName_Suffix.ToUpper());

            writer.Close();
        }

        /// <summary>
        /// Generates inline functions for NVM_INIT and RAM_INIT clusters to write parameter cluster based on minor and sub variant 
        /// </summary>
        /// <param name="my_ps">Reference to Parameter set.</param>
        /// <param name="my_ps_file_name">Reference to Input file name.</param>
        /// <param name="my_output_path">Output path for the generated file.</param>
        /// <param name="my_FileName_Suffix">Suffix to be appended in file name to distinguish files containing different datasets.</param>
        /// <param name="my_dt">Reference for date and time</param>
        /// <param name="my_gc">Reference for general configuration.</param>
        public void PrintGenParWriteAccess(ref cParameterSet my_ps, 
                                               ref String my_ps_file_name,
                                               String my_output_path,
                                               string my_FileName_Suffix,
                                               ref DateTime my_dt,
                                               ref cGeneralConfiguration my_gc)
        {
            Program my_program = new Program();
            string my_gen_file_name = "rbp_par_write_access" + my_FileName_Suffix + "_gen.h";
            string my_source_file_name = "Gen_Header.cs";

            // Overwrite the output path if already exists.
            my_program.OverwriteOPPath(ref my_gc, ref my_output_path, my_gen_file_name);

            // Generated file header.
            my_program.PrintFileInfo(ref my_ps, ref my_ps_file_name, my_output_path, ref my_dt, my_gen_file_name, my_source_file_name);

            // Obtain absolute path of output file.
            var genFileNamePath = Path.Combine(Path.GetFullPath(my_output_path), my_gen_file_name);

            // Open output file.
            var writer = Program.CreateStreamWriter(genFileNamePath, true, Encoding.ASCII);

            writer.WriteLine("#ifndef RBP_PAR_WRITE_ACCESS{0}_GEN_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("#define RBP_PAR_WRITE_ACCESS{0}_GEN_H", my_FileName_Suffix.ToUpper());
            writer.WriteLine("");

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("extern \"C\"");
            writer.WriteLine("{");
            writer.WriteLine("#endif // __cplusplus");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Magic number                                                           -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#define RBP_PAR_WRITE_ACCESS_MAGIC_NUMBER_GEN  0x{0:d2}{1:d2}{2:d2}{3:d2}", my_dt.Month, my_dt.Day, my_dt.Hour, my_dt.Minute);
            writer.WriteLine("");

            writer.WriteLine("/* PRQA S 2217 RBP_RULE_DEV_rbp_par_write_access_gen_1 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA S 3219 RBP_RULE_DEV_rbp_par_write_access_gen_2 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA S 3450 RBP_RULE_DEV_rbp_par_write_access_gen_3 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA S 3480 RBP_RULE_DEV_rbp_par_write_access_gen_4 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA S 316  RBP_RULE_DEV_rbp_par_write_access_gen_5 */ /*(details: see end of file)*/");
            writer.WriteLine("");
            writer.WriteLine("/* Below functions, returns pointer of the requested cluster (i.e. read\\write access).");
            writer.WriteLine(" * Provides QAC fix for warning 316 where ever the interface \"rbp_par_getParaWriteAccess_pst(cln, minv, subv)\" is used within components");
            writer.WriteLine(" * QAC WARNING : Level 5 -> (0316)  Cast from a pointer to void to a pointer to object type. MISRA C:2012 Rule-11.5 ");
            writer.WriteLine(" */");
            writer.WriteLine("");
            foreach (cComponent component in my_ps.Components)
            {
                writer.WriteLine("//---------------------------------------------------------------------------------------------------------------------------");
                writer.WriteLine("//  Component name : {0}", component.Name);
                writer.WriteLine("//---------------------------------------------------------------------------------------------------------------------------");
                foreach (cParameterCluster cluster in component.ParameterClusters)
                {
                    if (cluster.MemoryArea != "NVM")
                    {
                        if ((cluster.MemoryArea == "NVM_INIT") || (cluster.MemoryArea == "RAM_INIT"))
                        {
                            writer.WriteLine("//  Cluster name : {0}", cluster.Name);
                            writer.WriteLine("static RBP_INLINE rbp_Type_par_{0}_st* rbp_par_getParaWriteAccessCore_{0}_pst (UInt16 f_cl_idx_u16, UInt8 f_miv_idx_u8,  UInt8 f_sub_idx_u8)", cluster.Name);
                            writer.WriteLine("{");
                            writer.WriteLine("  return ((rbp_Type_par_{0}_st*) rbp_par_getParaWriteAccessCore_pvd(f_cl_idx_u16, f_miv_idx_u8, f_sub_idx_u8));", cluster.Name);
                            writer.WriteLine("}");
                            writer.WriteLine("");
                        }
                    }
                }
            }

            writer.WriteLine("//--------------------------------------- End of Inline Functions -----------------------------------------------");
            writer.WriteLine("");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_write_access_gen_1 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_write_access_gen_2 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_write_access_gen_3 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_write_access_gen_4 */ /*(details: see end of file)*/");
            writer.WriteLine("/* PRQA L:RBP_RULE_DEV_rbp_par_write_access_gen_5 */ /*(details: see end of file)*/");
            writer.WriteLine("/*****************************************************************************/");
            writer.WriteLine("/* START OF EXPLANATION FOR RBP_RULE_DEVIATIONS: */");
            writer.WriteLine("");
            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_write_access_gen_1 */");
            writer.WriteLine("/* Deviation to GPG rule number: 2217 */");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Because the function header is required to be defined in one line for easy understanding */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Having functions with header length more than 130 characters will not affect safety. It is just a name.*/");
            writer.WriteLine("");

            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_write_access_gen_2 */");
            writer.WriteLine("/* Deviation to GPG rule number: 2.1 */");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   static inline functions must be visible to all the translational unit which uses the interface");
            writer.WriteLine("   \"rbp_par_getParaReadAccess_pst(cln)\" so that the compiler can find the defintion  */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   No compilation error even if RBP_INLINE keyword is removed, becasue function is made static which");
            writer.WriteLine("   will be available within the translational unit. */");
            writer.WriteLine("");

            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_read_access_gen_3 */");
            writer.WriteLine("/* Deviation to GPG rule number: 3450 */");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Function declaration is not required as function defintion is always visible before its been called.");
            writer.WriteLine("   Declaring the functions will result in unnecessary increase in file size. */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Function is defined before its been called within the translation unit */");
            writer.WriteLine("");

            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_write_access_gen_4 */");
            writer.WriteLine("/* Deviation to GPG rule number: 3480 */");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Function is defined within header file as static inline so that its visible to ");
            writer.WriteLine("   all the translation unit which uses the interface \"rbp_par_getParaReadAccess_pst(cln)  */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   No compilation error will be thrown for the function, as it is static and is visible only within");
            writer.WriteLine("   that translation unit */");
            writer.WriteLine("");

            writer.WriteLine("/* RBP_RULE_DEV_rbp_par_write_access_gen_5 */");
            writer.WriteLine("/* Deviation to GPG rule number: 11.5 */");
            writer.WriteLine("/* Justification/reason for the necessity of the deviation:");
            writer.WriteLine("   Casting to a structure type is neccessary for proper de-refernce of the member. */");
            writer.WriteLine("/* Demonstration how safety and quality is still assured:");
            writer.WriteLine("   Necessary testing on hardware is performed to verify the behaviour of the casting to different");
            writer.WriteLine("   structure pointers. */");
            writer.WriteLine("");
            writer.WriteLine("/* END OF EXPLANATION FOR RBP_RULE DEVIATIONS */");
            writer.WriteLine("/*****************************************************************************/");
            writer.WriteLine("");

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("}");
            writer.WriteLine("#endif // __cplusplus");
            writer.WriteLine("");
            writer.WriteLine("#endif /* RBP_PAR_WRITE_ACCESS{0}_GEN_H */", my_FileName_Suffix.ToUpper());

            writer.Close();
        }

        /// <summary>
        /// PrintGenDSHeader function generates rbp_par_dsx_gen.h file.
        /// </summary>
        /// <param name="my_ps">Reference to Parameter set.</param>
        /// <param name="my_ps_file_name">Reference to Input file name.</param>
        /// <param name="my_output_path">Output path for the generated file.</param>
        /// <param name="my_FileName_Suffix">Suffix to be appended in file name to distinguish files containing different datasets.</param>
        /// <param name="my_dt">Reference for date and time</param>
        /// <param name="my_gc">Reference for general configuration.</param>
        /// <param name="my_DatasetName">Selected Dataset Name</param>
        public void PrintGenDSHeader(ref cParameterSet my_ps,
                                               ref String my_ps_file_name,
                                               String my_output_path,
                                               string my_FileName_Suffix,
                                               ref DateTime my_dt,
                                               ref cGeneralConfiguration my_gc,
                                               ref cHashes my_hashes,
                                               string my_DatasetName)
        {
            Program my_program = new Program();
            string my_gen_file_name = "rbp_par" + my_FileName_Suffix + "_gen.h";
            string my_source_file_name = "Gen_Header.cs";

            // Overwrite the output path if already exists.
            my_program.OverwriteOPPath(ref my_gc,ref my_output_path,my_gen_file_name);

            // Generated file header.
            my_program.PrintFileInfo(ref my_ps,ref my_ps_file_name,my_output_path,ref my_dt,my_gen_file_name,my_source_file_name);

            // Obtain absolute path of output file.
            var genFileNamePath = Path.Combine(Path.GetFullPath(my_output_path),my_gen_file_name);

            // Open output file.
            var writer = Program.CreateStreamWriter(genFileNamePath,true,Encoding.ASCII);

            writer.WriteLine("/* Include this header file in the Application SW build in order to get the hash access macros, DS cluster mapping structure declaration.");
            writer.WriteLine(" * Content within this file is specific to Dataset : \'{0}\' ", (my_DatasetName.Remove(0, 1)));
            writer.WriteLine("*/");
            
            writer.WriteLine("");
            writer.WriteLine("#ifndef RBP_PAR{0}_GEN_H",my_FileName_Suffix.ToUpper());
            writer.WriteLine("#define RBP_PAR{0}_GEN_H",my_FileName_Suffix.ToUpper());
            writer.WriteLine("");

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("extern \"C\"");
            writer.WriteLine("{");
            writer.WriteLine("#endif // __cplusplus");
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- Magic number                                                           -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");
            writer.WriteLine("#define RBP_PAR_DS_MAGIC_NUMBER_GEN  0x{0:d2}{1:d2}{2:d2}{3:d2}", my_dt.Month, my_dt.Day, my_dt.Hour, my_dt.Minute);
            writer.WriteLine("");

            {
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("/*- CAL-section structure integrity hash                                   -*/");
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("");
                writer.WriteLine("#ifdef RBP_COMPONENT_PAR");
                // CAL hash.
                writer.WriteLine("#define rbp_par_cal{1}_StructureIntegrityHash_mac {{ {0} }}", my_hashes.CALHash, my_DatasetName);
                writer.WriteLine("#endif");
                writer.WriteLine("");

                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("/*- CAL REFERENCE ID -- Version Information                                -*/");
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                // 64 bytes version identifier. 
                {
                    string tmp_string = my_gc.ST_CHORUS_CALSection_Version;
                    tmp_string = tmp_string.PadRight(64, '_');
                    writer.WriteLine("#define CAL{1}_VERSION_ID {0}", tmp_string, my_DatasetName);
                }
                writer.WriteLine("");

                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("/*- NVM-section structure integrity hash                                   -*/");
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("");
                writer.WriteLine("#ifdef RBP_COMPONENT_PAR");
                // NVM hash.
                writer.WriteLine("#define rbp_par_nvm{1}_StructureIntegrityHash_mac {{ {0} }}", my_hashes.NVMHash, my_DatasetName);
                writer.WriteLine("#endif");
                writer.WriteLine("");

                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("/*- CAL-section range resolution  hash                                     -*/");
                writer.WriteLine("/*--------------------------------------------------------------------------*/");
                writer.WriteLine("");
                writer.WriteLine("#ifdef RBP_COMPONENT_PAR");
                // Range Resolution hash.
                writer.WriteLine("#define rbp_par_cal{1}_RangeResHash_mac {{ {0} }}", my_hashes.CALRRHash, my_DatasetName);
                writer.WriteLine("#endif");
                writer.WriteLine("");
            }
            writer.WriteLine("");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- exported symbolic constants                                            -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            int cluster_count = 0;  // To get the count of the clusters in a given dataset (i.e. only for  ROM, RAM_INIT and NVM_INIT clusters)
            string my_cluster_count = string.Format("rbp{0}_clustercount_du16", my_DatasetName.ToLower());
            foreach (cComponent component in my_ps.Components)
            {
                foreach (cParameterCluster para in component.ParameterClusters)
                {
                    if (para.MemoryArea != "NVM")
                    {
                        // Number of clusters.
                        cluster_count++;
                    }
                }
            }

            writer.WriteLine("// Number of clusters excluding NVM.");
            writer.WriteLine("#define {0}{1}((UInt16)({2}))", my_cluster_count, new string(' ', 75 - my_cluster_count.Length), cluster_count);
            writer.WriteLine("");

            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("/*- exported data types                                                    -*/");
            writer.WriteLine("/*--------------------------------------------------------------------------*/");
            writer.WriteLine("");

            writer.WriteLine("// Required only for NRCS customer using the MULTIPLE dataset configuration");
            writer.WriteLine("// The below structure type is required to copy the Dataset Cluster mapping table from ROM to RAM. ");

            writer.WriteLine("struct rbp_Type_par{0}IndexTable_st", my_DatasetName);
            writer.WriteLine("{");
            writer.WriteLine("  UInt8  StartPattern_pu8[12]; // Pattern to indicate Start of DS_Mapping_Table");
            writer.WriteLine("  UInt32 StartAddress_u32;    // Start Address of the dataset");
            writer.WriteLine("  UInt16 ClIdx_Size_pu8[{0}][2];  // Cluster Index and Size array", my_cluster_count);
            writer.WriteLine("  UInt8  EndPattern_pu8[12];   // Pattern to indicate End of DS_Mapping_Table");
            writer.WriteLine("};");
            writer.WriteLine("");

            writer.WriteLine("#ifdef __cplusplus");
            writer.WriteLine("}");
            writer.WriteLine("#endif // __cplusplus");
            writer.WriteLine("");
            writer.WriteLine("#endif /* RBP_PAR{0}_GEN_H */", my_FileName_Suffix.ToUpper());

            // Close output file.
            writer.Close();

        }
        private static void pragma_option_end(cGeneralConfiguration my_gc, StreamWriter writer)
        {
            if (my_gc.RawDataStructurePadding != "DEFAULT")
            {
                writer.WriteLine("#if RBP_GS_COMPILER == RBP_GS_COMPILER_GHS");
                writer.WriteLine("  {0}", my_gc.ST_CHORUS_CALSection_StructureAlignmentEnd);
                writer.WriteLine("#elif RBP_GS_COMPILER == RBP_GS_COMPILER_GCC");
                writer.WriteLine("  #pragma pack()");
                writer.WriteLine("  //alternative: #pragma pack(pop)");
                writer.WriteLine("#elif RBP_GS_COMPILER == RBP_GS_COMPILER_VC");
                writer.WriteLine("  #pragma pack()");
                writer.WriteLine("#else");
                writer.WriteLine("  //No special struct alignment pragma");
                writer.WriteLine("#endif");
            }
        }

        private static void pragma_option_start(cGeneralConfiguration my_gc, StreamWriter writer)
        {
            writer.WriteLine("");
            if (my_gc.RawDataStructurePadding != "DEFAULT")
            {
                writer.WriteLine("#if RBP_GS_COMPILER == RBP_GS_COMPILER_GHS");
                writer.WriteLine("  {0}", my_gc.ST_CHORUS_CALSection_StructureAlignmentBegin);
                writer.WriteLine("#elif RBP_GS_COMPILER == RBP_GS_COMPILER_GCC");
                writer.WriteLine("  #pragma pack(4)");
                writer.WriteLine("  //alternative: #pragma pack(push,4)");
                writer.WriteLine("#elif RBP_GS_COMPILER == RBP_GS_COMPILER_VC");
                writer.WriteLine("  #pragma pack(4)");
                writer.WriteLine("#else");
                writer.WriteLine("  //No special struct alignment pragma");
                writer.WriteLine("#endif");
            }
        }
    }
}
