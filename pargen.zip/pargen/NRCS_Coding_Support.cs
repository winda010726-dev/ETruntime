using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace parsrv
{
    class NRCS
    {
        public NRCS(string set_param_cfg_file_name)
        {
            param_cfg_file_name = set_param_cfg_file_name;
        }

        string param_cfg_file_name;

        // Generate the file param_cfg_access_gen.c
        public void Print_CodingData(ref cParameterSet my_ps,
                                     ref cSegmentDefinition my_sd,
                                     ref String my_ps_file_name,
                                     String my_output_path,
                                     ref DateTime my_dt,
                                     ref cGeneralConfiguration my_gc,
                                     string Sorting_Order)
        {
            // Overwrite output path.
            if (my_gc.Code_OutputPath != "")
            {
                my_output_path = my_gc.Code_OutputPath;

                // Determine whether the directory exists.
                Program.DirectoryCreateDirectory(my_output_path);
            }

            // Obtain absolute path of output file.
            var outputPath = Path.Combine(Path.GetFullPath(my_output_path), param_cfg_file_name);

            // Delete old file automatically if existing.
            try
            {
                Program.FileDelete(outputPath);
            }
            catch
            {
                // Do not care about exceptions.
            }

            // Open output file.
            var writer = Program.CreateStreamWriter(outputPath, false, Encoding.ASCII);
            Console.WriteLine("generating: {0}", outputPath);

            writer.WriteLine("#include <rbp_global_include_api.h>");
            writer.WriteLine("#include <param_cfg_access.h>");

            writer.WriteLine("");

            writer.WriteLine("// returns the offset into the parameter table structure passed by reference for each cluster index");

            writer.WriteLine("void * rbp_par_getClusterArrayStartAddress_pvd(rbp_Type_par_ParameterMemoryRAM_INIT_Mirror_st const * f_paramTable_cpst, UInt16 f_cluster_idx_u16)");
            writer.WriteLine("{");
            writer.WriteLine("    // the following table is generated at run-time with addresses relative to the start address of f_paramTable_cpst");
            writer.WriteLine("    void * paramTableIndex_pvd[rbp_Num_Clusters_du16] =");
            writer.WriteLine("    {");

            int last_Component_Index = my_ps.Components.Count-1;
            int last_Cluster_Index   = my_ps.Components[last_Component_Index].ParameterClusters.Count - 1;
            string Last_cluster_name = my_ps.Components[last_Component_Index].ParameterClusters[last_Cluster_Index].Name;

            foreach (cComponent component in my_ps.Components)
            {
                foreach (cParameterCluster cluster in component.ParameterClusters)
                {
                    if ((cluster.MemoryArea != "NVM"))
                    {//This changes is done as a requirement from DAI TICKET _ NRCSTWO - 143897
                        if ((cluster.MemoryArea == "ROM") || (cluster.MemoryArea == "NVM_INIT"))
                        {
                            writer.Write("        NULL, // (void*) &f_paramTable_cpst->{0}_pst", cluster.Name);
                        }
                        else
                        {
                            writer.Write("        (void*) &f_paramTable_cpst->{0}_pst", cluster.Name);
                        }

                        if (cluster.Name != Last_cluster_name)
                        {
                            writer.WriteLine(",");
                        }
                        else
                        {
                            writer.WriteLine("");
                        }
                    }
                }
            }
            writer.WriteLine("    };");
            writer.WriteLine("    return (f_cluster_idx_u16 >= rbp_Num_Clusters_du16) ? NULL : paramTableIndex_pvd[f_cluster_idx_u16];");
            writer.WriteLine("} //rbp_par_getClusterArrayStartAddress_pvd");

            writer.WriteLine("");
            writer.WriteLine("");

            writer.WriteLine("// returns the total size of each cluster array");
            writer.WriteLine("UInt32 rbp_par_getClusterArraySize_u32(UInt16 f_cluster_idx_u16)");
            writer.WriteLine("{");
            writer.WriteLine("// the following is an unused pointer define to make it possible to access members of the type in the sizeof operator.");
            writer.WriteLine("    rbp_Type_par_ParameterMemoryROM_st const * l_paramTable_cpst = NULL;");
            writer.WriteLine("    // the following table contains the sizes of each array in the param table");
            writer.WriteLine("    UInt32 paramTableSizes_u32[rbp_Num_Clusters_du16] =");
            writer.WriteLine("    {");

            foreach (cComponent component in my_ps.Components)
            {
                foreach (cParameterCluster cluster in component.ParameterClusters)
                {
                    if ((cluster.MemoryArea != "NVM"))
                    {
                        writer.Write("        sizeof(l_paramTable_cpst->{0}_pst)", cluster.Name);
                        if (cluster.Name != Last_cluster_name)
                        {
                            writer.WriteLine(",");
                        }
                        else
                        {
                            writer.WriteLine("");
                        }
                    }
                }
            }

            writer.WriteLine("    };");
            writer.WriteLine("    return (f_cluster_idx_u16 >= rbp_Num_Clusters_du16) ? 0 : paramTableSizes_u32[f_cluster_idx_u16];");
            writer.WriteLine("} //rbp_par_getClusterArraySize_u32");

            writer.WriteLine("");
            writer.WriteLine("");
            /*
             * All the changes done here a ripoff from Gen_Header.cs
             * The earlier implmentation was not considering the gaps "in-between" the structures so a 
             * smaller size was generated. This implemenation gives the correct size.             * 
             */
            writer.WriteLine("// Structure for RAM_INIT Clusters only used for size calculation");
            writer.WriteLine("//NOTE: MUST NOT BE USED FOR ANY DECLARATION OUTSIDE THIS FILE");
            writer.WriteLine("typedef struct  rbp_Tag_par_RAM_INIT_ForSizeCalculation_only_st");
            writer.WriteLine("{");

            int num_lines = 0;

            foreach (cComponent component in my_ps.Components)
            {
                // Checking if a component name from xml exists in the sorting information from csv.
                if (Sorting_Order.Contains(component.Name))
                {
                    foreach (cParameterCluster cluster in component.ParameterClusters)
                    {
                        int max_count_sub_var = 0;

                        foreach (cVariantImplementation var_imp in cluster.VariantsImlementations)
                        {
                            int count_sub_var = 0;

                            foreach (cMinorVariant min_var in var_imp.MinorVariants)
                            {
                                count_sub_var += min_var.SubVariants.Count;
                            }

                            if (count_sub_var > max_count_sub_var)
                            {
                                max_count_sub_var = count_sub_var;
                            }
                        }
                        if ((cluster.MemoryArea == "RAM_INIT"))
                        {
                            writer.WriteLine("  rbp_Type_par_{0}_st {0}_pst[{1}];", cluster.Name, max_count_sub_var);
                            num_lines++;
                        }
                    }
                }
            }
            if (num_lines == 0)
            {
                writer.WriteLine("  UInt32 Dummy_u32;");
            }

            writer.WriteLine("}");
            writer.WriteLine("rbp_Type_par_RAM_INIT_ForSizeCalculation_only_st;");
            writer.WriteLine("");

            writer.WriteLine("// returns the total size D3 clusters");
            writer.WriteLine("UInt32 rbp_par_getD3ClusterSize_u32()");
            writer.WriteLine("{");
            writer.WriteLine("// NOTE: This locally defined structure is only for size calculation");
            writer.WriteLine("    rbp_Type_par_RAM_INIT_ForSizeCalculation_only_st l_temp_struct_st;;");

            writer.WriteLine("    return sizeof(l_temp_struct_st);");

            writer.WriteLine("}//rbp_par_getD3ClusterSize_u32");

            // Close output file.
            writer.Close();
        }
    }
}