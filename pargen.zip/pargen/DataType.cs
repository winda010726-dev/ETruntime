using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;


namespace parsrv
{
    // A class holds information about the datatypes, enums, quantizations.
    public class cDataTypes
    {
        // List of Enumeration Available.
        private List<cEnumeration> my_enumerations;

        // List if Quantizations.
        private List<cQuantization> my_quantizations;

        // List of Custom Types(User defined).
        private List<cCustomType> my_customTypes;


        [XmlElement("Enumeration")]
        public List<cEnumeration> Enumerations
        {
            get { return my_enumerations; }
            set { my_enumerations = value; }
        }

        [XmlElement("Quantization")]
        public List<cQuantization> Quantization
        {
            get { return my_quantizations; }
            set { my_quantizations = value; }
        }

        [XmlElement("CustomType")]
        public List<cCustomType> CustomTypes
        {
            get { return my_customTypes; }
            set { my_customTypes = value; }
        }

        // Default Constructor.
        public cDataTypes()
        {
            this.my_enumerations = new List<cEnumeration>();
            this.my_quantizations = new List<cQuantization>();
            this.my_customTypes = new List<cCustomType>();
        }

        // Parameterized constructor.
        public cDataTypes(List<cEnumeration> enumerations, List<cQuantization> quantizations, List<cCustomType> customTypes)
        {
            this.my_enumerations = enumerations;
            this.my_quantizations = quantizations;
            this.my_customTypes = customTypes;
        }
    }// End of class cDataType.


    // A class to handle the attributes and the data of a Literal.
    public class cLiteral
    {
        // Name of the literal.
        private string my_name;

        // Value of the literal.
        private string my_value;

        [XmlElement("Name")]
        public string Name
        {
            get { return my_name; }
            set { my_name = value; }
        }

        [XmlElement("Value")]
        public string Value
        {
            get { return my_value; }
            set { my_value = value; }
        }

        // Default Constructor.
        public cLiteral()
        {
            this.my_name = "enum0";
            this.my_value = "1";
        }

        // Parameterized constructor.
        public cLiteral(string Name, string Value)
        {
            this.my_name = Name;
            this.my_value = Value;
        }

    }// End of class cLiteral.

    // A class to handle the attributes and the data of a constant.
    public class cConstant
    {
        // Name of the constant.
        private string my_name;

        // 
        private string my_typeInModel;

        // Value of constant.
        private string my_value;

        // Information about the constant.
        private string my_description;

        [XmlElement("Name")]
        public string Name
        {
            get { return my_name; }
            set { my_name = value; }
        }
        [XmlElement("TypeInModel")]
        public string TypeInModel
        {
            get { return my_typeInModel; }
            set { my_typeInModel = value; }
        }
        [XmlElement("Value")]
        public string Value
        {
            get { return my_value; }
            set { my_value = value; }
        }
        [XmlElement("Description")]
        public string Description
        {
            get { return my_description; }
            set { my_description = value; }
        }

        // Default Constructor.
        cConstant()
        {
            this.my_name = "";
            this.my_typeInModel = "";
            this.my_value = "";
            this.my_description = "";
        }

        // Parameterized constructor.
        cConstant(string Name, string TypeInModel, string Value, string Description)
        {
            this.my_name = Name;
            this.my_typeInModel = TypeInModel;
            this.my_value = Value;
            this.my_description = Description;

        }
    }// End of class cConstant.


    public class cEnumeration
    {
        // Name of the enumeration.
        private string my_name;

        // BaseType (empty in XML 2.0 and 2.1).
        private string my_baseType;

        // Information of the enumeration.
        private string my_description;

        // Literals or values of enumeration.
        private List<cLiteral> my_literals;


        [XmlElement("Name")]
        public string Name
        {
            get { return my_name; }
            set { my_name = value; }
        }

        [XmlElement("Basetype")]
        public string Basetype
        {
            get { return my_baseType; }
            set { my_baseType = value; }
        }

        [XmlArray("Literals")]
        [XmlArrayItem("Literal")]
        public List<cLiteral> Literal
        {
            get { return my_literals; }
            set { my_literals = value; }
        }

        [XmlElement("Description")]
        public string Description
        {
            get { return my_description; }
            set { my_description = value; }
        }

        // Default Constructor.
        cEnumeration()
        {
            this.my_name = "";
            this.my_baseType = "";
            this.my_literals = new List<cLiteral>();
            this.my_description = "";
        }

        // Parameterized constructor
        cEnumeration(string Name, string Basetype, List<cLiteral> literals, string Description)
        {
            this.my_name = Name;
            this.my_baseType = Basetype;
            this.my_literals = literals;
            this.my_description = Description;
        }
    }// End of class cEnumeration.

    // A class to handle the attributes and the data of a Quantization.
    public class cQuantization
    {
        // Name of the Quantization.
        private string my_name;

        // Formula of the Quantization.
        private string my_formula;

        [XmlElement("Name")]
        public string Name
        {
            get { return my_name; }
            set { my_name = value; }
        }

        [XmlElement("Formula")]
        public string Description
        {
            get { return my_formula; }
            set { my_formula = value; }
        }

        // Default constructor.
        cQuantization()
        {
            this.my_name = "";
            this.my_formula = "";
        }

        // Parametrized constructor.
        cQuantization(string Name, string Formula)
        {
            this.my_name = Name;
            this.my_formula = Formula;
        }

    }// End of class cQuantization.

    // A class to hold the range of the parameter.
    public class cRange
    {
        // Minimum value of a parameter.
        private string my_min;

        // Maximum value of a parameter.
        private string my_max;

        [XmlElement("Min")]
        public string Min
        {
            get { return my_min; }
            set { my_min = value; }
        }

        [XmlElement("Max")]
        public string Max
        {
            get { return my_max; }
            set { my_max = value; }
        }

        // Default Constructor.
        public cRange()
        {
            this.my_min = "0";
            this.my_max = "1000";
        }

        // Parameterized constructor.
        public cRange(string Min, string Max)
        {
            this.my_min = Min;
            this.my_max = Max;
        }

    }// End of class cRange.

    // A class to handle the attributes and the data of a CustomType
    public class cCustomType
    {
        // Name of the user defined data type.
        private string my_name;

        // Data Type (i.e. UInt8,UInt16,...).
        private string my_typeInPlatform_TwoZero;

        // Description of the user defined Type.
        private string my_description;

        // Not used anywhere.
        private string my_offset;

        // Quantization of the provided data type.
        private string my_quantization;

        // Resolution.
        private string my_resolution;

        // Unit of the user defined data type.
        private string my_unit;

        // Range of the data type.
        private cRange my_range;

        [XmlElement("Name")]
        public string Name
        {
            get { return my_name; }
            set { my_name = value; }
        }

        [XmlElement("TypeInPlatform")]
        public string TypeInPlatform
        {
            get { return my_typeInPlatform_TwoZero; }
            set { my_typeInPlatform_TwoZero = value; }
        }

        [XmlElement("Description")]
        public string Description
        {
            get { return my_description; }
            set { my_description = value; }
        }
        [XmlElement("Range")]
        public cRange Range
        {
            get { return my_range; }
            set { my_range = value; }
        }
        [XmlElement("Offset")]
        public string Offset
        {
            get { return my_offset; }
            set { my_offset = value; }
        }

        [XmlElement("Quantization")]
        public string Quantization
        {
            get { return my_quantization; }
            set { my_quantization = value; }
        }

        [XmlElement("Resolution")]
        public string Resolution
        {
            get { return my_resolution; }
            set { my_resolution = value; }
        }

        [XmlElement("Unit")]
        public string Unit
        {
            get { return my_unit; }
            set { my_unit = value; }
        }

        // Default Constructor.
        cCustomType()
        {
            this.my_name = "";
            this.my_typeInPlatform_TwoZero = "";
            this.my_resolution = "1";
            this.my_description = "";
            this.my_offset = "0";
            this.my_quantization = "";
            this.my_range = new cRange();
            this.my_unit = "";
        }

        // Parameterized constructor.
        cCustomType(string Name, string TypeInPlatform, string Description, cRange Range, string Offset, string Quantization, string Resolution, string Unit)
        {
            this.my_name = Name;
            this.my_typeInPlatform_TwoZero = TypeInPlatform;
            this.Description = my_description;
            this.my_range = Range;
            this.my_offset = Offset;
            this.my_quantization = Quantization;
            this.my_resolution = Resolution;
            this.my_unit = Unit;
        }
    } // End of class cCustomType.

}
